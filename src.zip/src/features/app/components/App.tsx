import React from 'react'
import { FormattedMessage, IntlProvider } from 'react-intl'
import { Link, NavLink, Redirect, Route, Switch } from 'react-router-dom'

import { DefaultUserMenu } from 'rio-user-menu'
import { SessionExpiredDialog } from 'rio-session-expired-info'
import { ActionBarItem, ApplicationHeader, ApplicationLayout, NotificationsContainer } from 'rio-uikit'
import IframeResizer from '@rio-cloud/iframe-resizer'

import { DEFAULT_LOCALE } from '../../../configuration'
// import FaultCodes from 'containers/Dashboard'
import Dashboard from 'containers/Dashboard'
import CreateRoute from 'containers/Routes/CreateRoute'
import EditRoute from 'containers/Routes/EditRoute'
// import EditTrip from 'containers/Resume/EditTrip'
import Historic from 'containers/Historic'
import { DashboardProvider } from 'core/DashboardContext'
import Pdis from 'containers/Pdis'
import './App.css'
import { config } from '../../../config'
import { AppProperties } from './types'
import Sidebar from 'containers/Dashboard/Sidebar'
import { StyledMain, Wrapper } from './AppStyled'
import Resume from 'containers/Resume'
import ResumeMap from 'containers/Resume/Map'

class ServiceInfo extends React.Component {
  render() {
    const handleClick = () => null

    return (
      <div>
        <div className={'line-height-largest'}>
          <a href={'/'} onClick={handleClick}>
            <span>{'Release notes'}</span>
          </a>
        </div>
        <div className={'line-height-largest'}>
          <Link to={'/abcd'}>{'Link'}</Link>
        </div>
      </div>
    )
  }
}

export default class App extends React.Component<AppProperties, {}> {
  render() {
    const { hideSessionDialog, homeRoute, languageData, showSessionExpired, userLocale } = this.props

    const title = (
      <div>
        <span>{'Service XYZ'}</span>
        <span className={'text-color-gray margin-left-10'}>{'v1.1.0'}</span>
      </div>
    )

    const serviceInfoItem = (
      <ActionBarItem id={'serviceInfo'} className={'myItem'}>
        <ActionBarItem.Icon>
          <span className={'icon rioglyph rioglyph-info-sign'} />
          <span className={'badge bg-primary'}>{'1'}</span>
        </ActionBarItem.Icon>
        <ActionBarItem.Popover className={'myItemPopover'} title={title}>
          <ServiceInfo />
        </ActionBarItem.Popover>
      </ActionBarItem>
    )

    const navItems = [
      {
        key: 'resume',
        route: <NavLink to={'/resume-map'}>Resumo</NavLink>
      },
      {
        key: 'pdis',
        route: (
          <NavLink to={'/pdis'}>
            <FormattedMessage id='navbar.pdis' />
          </NavLink>
        )
      }
      // {
      //   key: 'CreateRoute',
      //   route: <NavLink to={'/historic'}><FormattedMessage id='navbar.pdis' /></NavLink>
      // },
    ]

    const appTitle = 'Routefence'
    const environment = process.env.NODE_ENV === 'production' ? 'production' : 'local'
    const userMenu = <DefaultUserMenu environment={environment} />
    const menuUrl = config.backend.MENU_SERVICE as string
    const appNavigator = <IframeResizer url={menuUrl} />

    // eslint-disable-next-line jsx-a11y/anchor-has-content
    const homeLink = <a href={homeRoute} />

    const assets: Array<string> = []

    return (
      <IntlProvider defaultLocale={DEFAULT_LOCALE} key={userLocale} locale={userLocale} messages={languageData}>
        <DashboardProvider value={assets}>
          <ApplicationLayout>
            <ApplicationLayout.Header>
              <ApplicationHeader
                label={appTitle}
                appNavigator={appNavigator}
                homeRoute={homeLink}
                navItems={navItems}
                actionBarItems={[serviceInfoItem, userMenu]}
              />
            </ApplicationLayout.Header>

            <ApplicationLayout.Sidebar>
              <Sidebar />
            </ApplicationLayout.Sidebar>

            <ApplicationLayout.Body>
              <NotificationsContainer />
              <SessionExpiredDialog locale={userLocale} onClose={hideSessionDialog} show={showSessionExpired} />
              <Wrapper>
                <StyledMain>
                  <Switch>
                    <Route path='/dashboard' component={Dashboard} />
                    <Route path='/pdis' component={Pdis} />
                    <Route path='/historic' component={Historic} />
                    <Route path='/resume' component={Resume} />
                    <Route path='/resume-map' component={ResumeMap} />
                    <Route path='/routefence-pdis/create' component={CreateRoute} />
                    <Route path='/routefence-pdis/edit' component={EditRoute} />
                    <Route path='/resume-edit' component={EditRoute} />
                    <Route path='/routefence-pdis/duplicate' component={EditRoute} />
                    <Route path='/routefence-pdis/linkVehicle' component={EditRoute} />
                    <Redirect to='/dashboard' />
                  </Switch>
                </StyledMain>
              </Wrapper>
            </ApplicationLayout.Body>
          </ApplicationLayout>
        </DashboardProvider>
      </IntlProvider>
    )
  }
}
