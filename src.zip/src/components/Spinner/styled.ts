import styled, { css, keyframes } from 'styled-components'
import { colors } from 'core/assets/styles'

interface StyledLoaderProps {
  fullscreen: boolean
}

const spin = keyframes`
  from { -webkit-transform: rotate(0deg); }
  to { -webkit-transform: rotate(360deg); }
`

export const StyledLoader = styled.div<StyledLoaderProps>`
  position: relative;
  top: 50%;
  width: 100%;

  ${({ fullscreen }) =>
    fullscreen &&
    css`
      background: ${colors.whiteMedium};
      height: 100%;
      position: fixed;
      top: 0;
      z-index: 3;
    `}

  .loading {
    height: 28px;
    left: 50%;
    margin: 0 0 0 -14px;
    position: absolute;
    top: 50%;
    width: 28px;

    .spinner {
      animation: ${spin} 1s infinite linear;
      height: 26px;
      left: 1px;
      position: absolute;
      top: 1px;
      width: 26px;
    }

    .mask {
      height: 12px;
      overflow: hidden;
      width: 12px;
    }

    .maskedCircle {
      border: 3px solid ${colors.primary};
      border-radius: 12px;
      height: 20px;
      width: 20px;
    }
  }
`
