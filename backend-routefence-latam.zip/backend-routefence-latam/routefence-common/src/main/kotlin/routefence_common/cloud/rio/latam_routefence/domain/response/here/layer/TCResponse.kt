package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.CurrencyAmount
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.RouteTollItem

@JsonIgnoreProperties(ignoreUnknown = true)
data class TCResponse(
    @JsonProperty("costsByCountry") var costsByCountry: Collection<CurrencyAmount>?,
    @JsonProperty("costsByCountryAndTollSystem") var costsByCountryAndTollSystem: Collection<CurrencyAmount>?,
    @JsonProperty("costsByTollSystem") var costsByTollSystem: Collection<CurrencyAmount>?,
    @JsonProperty("routeTollItems") var routeTollItems: Collection<RouteTollItem>?,
    @JsonProperty("totalCost") var totalCost: CurrencyAmount?
)