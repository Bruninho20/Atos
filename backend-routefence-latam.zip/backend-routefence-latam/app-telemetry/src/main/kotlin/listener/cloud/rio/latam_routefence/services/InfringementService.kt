package listener.cloud.rio.latam_routefence.services

import listener.cloud.rio.latam_routefence.infrastructure.repositories.InfringementRepository
import listener.cloud.rio.latam_routefence.infrastructure.repositories.TripRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.InfringementEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToNewEntity
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

@Service
@Transactional
class InfringementService(
    private val infringementRepository: InfringementRepository,
    private val tripRepository: TripRepository
) {

    fun save(infringementRequest: InfringementRequest): InfringementEntity {

        val tripOptional = tripRepository.findById(infringementRequest.trip).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(infringementRequest.trip))
        }
        return infringementRepository.save(infringementRequest.mapToNewEntity(tripOptional))
    }

    fun findByTripAndType(tripId: String, type: InfringementTypeEnum): Collection<InfringementEntity> {
        return infringementRepository.getByTripIdAndType(tripId, type)
    }

    fun closeInfringement(infringement: InfringementEntity): InfringementEntity {
        infringement.endDateTime = LocalDateTime.now()
        return infringementRepository.save(infringement)
    }

    fun findByTrip(tripId: String, startDateTime: String?, endDateTime: String?): List<InfringementEntity> {
        try {
            var tripInfringements: List<InfringementEntity>

            if (!startDateTime.isNullOrEmpty() && !endDateTime.isNullOrEmpty()) {
                val startTime = LocalDateTime.parse(startDateTime, DateTimeFormatter.ISO_DATE_TIME)
                    .atOffset(ZoneOffset.UTC)
                val endTime = LocalDateTime.parse(endDateTime, DateTimeFormatter.ISO_DATE_TIME)
                    .atOffset(ZoneOffset.UTC)
                tripInfringements = infringementRepository.getByTripByPeriod(tripId, startTime.toLocalDateTime(), endTime.toLocalDateTime())
                if (tripInfringements.isEmpty()) {
                    val beforeStartTime = startTime.minusMinutes(1)
                    val afterEndTime = endTime.plusMinutes(1)
                    tripInfringements = infringementRepository.getByTripByPeriod(tripId, beforeStartTime.toLocalDateTime(), afterEndTime.toLocalDateTime())
                }

            } else {
                tripInfringements = infringementRepository.getByTrip(tripId)
            }
            return tripInfringements

        } catch (e: Exception) {
            return listOf()
        }
    }

    fun deleteById(id: String) {
        infringementRepository.deleteById(id)
    }
}
