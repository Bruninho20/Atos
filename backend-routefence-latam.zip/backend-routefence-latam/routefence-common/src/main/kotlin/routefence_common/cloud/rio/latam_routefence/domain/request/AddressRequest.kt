package routefence_common.cloud.rio.latam_routefence.domain.request

data class AddressRequest (
    var id: String? = null,
    var label: String? = null,
    var countryCode: String? = null,
    var countryName: String? = null,
    var stateCode: String? = null,
    var state: String? = null,
    var city: String? = null,
    var district: String? = null,
    var street: String? = null,
    var postalCode: String? = null,
    var houseNumber: String? = null
)