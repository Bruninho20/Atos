import React, { FC, useState, useEffect } from 'react'
import { FormattedMessage, Intl, injectIntl } from 'react-intl'
import { useFetch } from 'core/providers/api/use-fetch'
import { downloadFile, EDownloadFileType } from 'core/utils/download-file'
import {
  WrapperContent,
  Card,
  IconCard,
  Description,
  CardContent,
  TextArea,
  DateArea,
  TypeInfraction,
  DateInfraction,
  HeaderCard
} from './styled'
import { Button } from 'components'
import { DatePicker, SimpleButtonDropdown } from 'rio-uikit'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import moment from 'moment'

interface PropsData {
  intl: Intl
  newData: any
  tripData: any
}

const InfractionDetails: FC<PropsData> = ({ intl, newData, tripData }) => {
  const { setUrl: setDownloadUrl, data } = useFetch()
  const [fileType, setFileType] = useState('')
  const [infractionsData, setInfractionsData] = useState<any>([])
  const [dateTime, setDateTime] = useState<any>({
    from: null,
    to: null
  })

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken: any = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  }

  useEffect(() => {
    const getInfractionData = async () => {
      try {
        // COMENTAR E DESCOMENTAR QUANDO MEXER LOCAL
        // const res = await axios.get(`${baseURL}/infringements/${data?.id}`, head)
        const res = await axios.get(`${baseURL}/infringements/${tripData?.tripId}`, head)
        setInfractionsData(res.data)
      } catch (error) {
        console.log(error)
      }
    }
    getInfractionData()
  }, [])

  const handleChangeDateTime = async () => {
    const getInfractionData = async () => {
      try {
        // COMENTAR E DESCOMENTAR QUANDO MEXER LOCAL
        // const res = await axios.get(`${baseURL}/infringements/${data?.id}`, head)
        const res = await axios.get(
          `${baseURL}/infringements/${tripData?.tripId}?startDateTime=${moment(
            dateTime?.from
          ).toISOString()}&endDateTime=${moment(dateTime?.to).toISOString()}`,
          head
        )
        setInfractionsData(res.data)
      } catch (error) {
        console.log(error)
      }
    }
    getInfractionData()
  }

  const onDownloadClick = async (type: string) => {
    setFileType(type)
    if (type === 'csv') {
      try {
        setDownloadUrl({
          path: `/download/${type}/${tripData?.tripId}`,
          method: 'POST',
          data: {
            startDateTime: dateTime?.from,
            endDateTime: dateTime?.to
          }
        })
      } catch (error) {
        console.log(error)
      }
    } else {
      try {
        setDownloadUrl({
          path: `/download.${type}/${tripData?.tripId}`,
          method: 'POST',
          data: {
            startDateTime: dateTime?.from,
            endDateTime: dateTime?.to
          }
        })
      } catch (error) {
        console.log(error)
      }
    }
  }

  useEffect(() => {
    if (fileType === 'csv') downloadFile(data, EDownloadFileType.CSV, 'infractionsReport')
    else if (fileType === 'xlsx') downloadFile(data, EDownloadFileType.XLSX, 'infractionsReport')
  }, [data])

  return (
    <WrapperContent>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 15, color: '#878585', fontWeight: '600' }}>Notificações</span>
        <SimpleButtonDropdown
          title={<span className='rioglyph rioglyph-download' aria-hidden={'true'} />}
          iconOnly
          items={[
            {
              value: (
                <div>
                  <span>
                    <FormattedMessage id='components.table.toolbar.exportCSV' />
                  </span>
                </div>
              ),
              onSelect: value => onDownloadClick('csv')
            },
            {
              value: (
                <div>
                  <span>
                    <FormattedMessage id='components.table.toolbar.exportXLSX' />
                  </span>
                </div>
              ),
              onSelect: value => onDownloadClick('xlsx')
            }
          ]}
        />
      </div>
      <CardContent style={{ borderRadius: 7, maxHeight: '80%' }}>
        <HeaderCard>
          <div style={{ display: 'flex', flexDirection: 'column', marginBottom: 20 }}>
            <div className='display-flex  gap-10 max-width-400 margin-bottom-10'>
              <div style={{ width: 170 }}>
                <label>From:</label>
                <DatePicker
                  inputProps={{ placeholder: 'Select Date' }}
                  onChange={(e: any) => setDateTime({ ...dateTime, from: e })}
                  clearableInput
                />
              </div>
              <div style={{ width: 170 }}>
                <label>To:</label>
                <DatePicker
                  inputProps={{ placeholder: 'Select Date' }}
                  onChange={(e: any) => setDateTime({ ...dateTime, to: e })}
                  clearableInput
                />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', alignContent: 'center' }}>
              <Button onClick={() => handleChangeDateTime()} label={'Atualizar'} />
            </div>
          </div>
        </HeaderCard>
        <div style={{ overflowY: 'scroll', overflowX: 'hidden' }}>
          {infractionsData &&
            infractionsData?.map((item: any) => {
              return (
                <Card>
                  <IconCard>
                    <span
                      style={{ color: '#D54747' }}
                      className='rioglyph rioglyph-exclamation-sign text-size-h3'></span>
                  </IconCard>
                  <TextArea>
                    <TypeInfraction>
                      <FormattedMessage id={item.type} />
                    </TypeInfraction>
                    <Description>{item.note}</Description>
                  </TextArea>
                  <DateArea>
                    <span style={{ fontSize: 11, fontWeight: 'bold', color: '#878585' }}>Inicio:</span>
                    <DateInfraction>{moment(item.startDateTime).format('DD/MM/yyyy HH:mm')}</DateInfraction>
                    <span style={{ fontSize: 11, fontWeight: 'bold', color: '#878585' }}>Fim:</span>
                    <DateInfraction>{moment(item.endDateTime).format('DD/MM/yyyy HH:mm')}</DateInfraction>
                  </DateArea>
                </Card>
              )

              //    <span style={{ fontSize: 16, fontWeight: 'bold' }}>
              //       <FormattedMessage id={item.type} />
              //     </span>
              //     <Description>{item.note}</Description>
              //     <DateInfraction>{moment(item.startDateTime).format('DD/MM/yyyy HH:MM')}</DateInfraction>
              //     <DateInfraction>{item.startDateTime}</DateInfraction>
            })}
        </div>
      </CardContent>
    </WrapperContent>
  )
}

export default injectIntl(InfractionDetails)
