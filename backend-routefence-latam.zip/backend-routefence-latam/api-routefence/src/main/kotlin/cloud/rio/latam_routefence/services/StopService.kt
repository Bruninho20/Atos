package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.mapper.mapToEntity
import cloud.rio.latam_routefence.infrastructure.repositories.RouteStopRepository
import cloud.rio.latam_routefence.infrastructure.repositories.StopRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteStopEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.StopEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToEntity
import routefence_common.cloud.rio.latam_routefence.utils.timeFromString
import java.util.*


@Service
@Transactional
class StopService(private val stopRepository: StopRepository, private val routeStopRepository: RouteStopRepository) {

    fun saveAllToRoute(routeRequest: RouteRequest, routeEntity: RouteEntity): List<RouteStopEntity>? {
        val stops = routeRequest.stops
        val routeStopListSaved = stops?.map { stop ->
            val savedStop = stopRepository.save(stop.mapToEntity(routeRequest.accountId!!))
            routeStopRepository.save(
                RouteStopEntity(
                    UUID.randomUUID().toString(),
                    routeEntity,
                    savedStop,
                    stop.rangeLimitMeters?.toInt(),
                    stop.stayTime?.timeFromString(),
                    stop.stopQueueOrder,
                    stop.type,
                    null
                )
            )
        }
        return routeStopListSaved
    }

    fun deleteByRouteForTests(routId: String) {
        routeStopRepository.deleteByRouteId(routId)
    }

    fun duplicateStops(
        routeRequest: RouteRequest,
        originalRouteEntity: RouteEntity,
        duplicatedRoute: RouteEntity
    ): List<RouteStopEntity> {
        val routeStopList = mutableListOf<RouteStopEntity>()
        routeRequest.stops?.forEach { stopRequest ->
            // checa se existe na lista original
            val existentStop = originalRouteEntity.stops?.firstOrNull { it.id == stopRequest.id }
            if (existentStop == null) {
                // cria do zero
                val newStopEntity = stopRepository.save(
                    StopEntity(
                        UUID.randomUUID().toString(),
                        stopRequest.name,
                        stopRequest.category,
                        stopRequest.position?.mapToEntity(),
                        duplicatedRoute.accountId,
                        stopRequest.note,
                        null
                    )
                )
                val newRouteStopEntity = RouteStopEntity(
                    UUID.randomUUID().toString(),
                    duplicatedRoute,
                    newStopEntity,
                    stopRequest.rangeLimitMeters?.toInt(),
                    stopRequest.stayTime?.timeFromString(),
                    stopRequest.stopQueueOrder,
                    stopRequest.type,
                    null
                )
                routeStopList.add(routeStopRepository.save(newRouteStopEntity))
            } else {
                // cria da entidade existente
                val newStopEntity = StopEntity(
                    UUID.randomUUID().toString(),
                    stopRequest.name ?: existentStop.stop?.name,
                    stopRequest.category ?: existentStop.stop?.category,
                    stopRequest.position?.mapToEntity() ?: existentStop.stop?.position,
                    existentStop.stop!!.accountId,
                    stopRequest.note ?: existentStop.stop!!.note,
                    null
                )
                val newRouteStopEntity = RouteStopEntity(
                    UUID.randomUUID().toString(),
                    duplicatedRoute,
                    newStopEntity,
                    stopRequest.rangeLimitMeters?.toInt() ?: existentStop.rangeLimitMeters,
                    stopRequest.stayTime?.timeFromString() ?: existentStop.stayTime,
                    stopRequest.stopQueueOrder,
                    stopRequest.type,
                    null
                )
                routeStopList.add(routeStopRepository.save(newRouteStopEntity))
            }
        }
        return routeStopList
    }

    fun editStops(
        routeRequest: RouteRequest,
        originalRouteEntity: RouteEntity
    ): List<RouteStopEntity> {
        val routeStopList = mutableListOf<RouteStopEntity>()
        routeRequest.stops?.forEach { stopRequest ->
            // checa se existe na lista original
            val existentStop = originalRouteEntity.stops?.firstOrNull { it.id == stopRequest.id }
            if (existentStop == null) {
                // cria do zero
                val newStopEntity = stopRepository.save(
                    StopEntity(
                        UUID.randomUUID().toString(),
                        stopRequest.name,
                        stopRequest.category,
                        stopRequest.position?.mapToEntity(),
                        originalRouteEntity.accountId,
                        stopRequest.note,
                        null
                    )
                )
                val newRouteStopEntity = RouteStopEntity(
                    UUID.randomUUID().toString(),
                    originalRouteEntity,
                    newStopEntity,
                    stopRequest.rangeLimitMeters?.toInt(),
                    stopRequest.stayTime?.timeFromString(),
                    stopRequest.stopQueueOrder,
                    stopRequest.type,
                    null
                )
                routeStopList.add(newRouteStopEntity)
            } else {
                // edita da entidade existente
                val newStopEntity = StopEntity(
                    existentStop.stop!!.id,
                    stopRequest.name ?: existentStop.stop!!.name,
                    stopRequest.category ?: existentStop.stop!!.category,
                    stopRequest.position?.mapToEntity() ?: existentStop.stop!!.position,
                    existentStop.stop!!.accountId,
                    stopRequest.note ?: existentStop.stop!!.note,
                    null
                )
                val newRouteStopEntity = RouteStopEntity(
                    existentStop.id,
                    originalRouteEntity,
                    newStopEntity,
                    stopRequest.rangeLimitMeters?.toInt() ?: existentStop.rangeLimitMeters,
                    stopRequest.stayTime?.timeFromString() ?: existentStop.stayTime,
                    stopRequest.stopQueueOrder,
                    stopRequest.type,
                    null
                )
                routeStopList.add(newRouteStopEntity)
            }
        }
        return routeStopList
    }
}