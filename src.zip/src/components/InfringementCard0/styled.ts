import styled from 'styled-components'

import { colors, metrics } from 'core/assets/styles'
import { Card2 } from 'components'

export const StyledCard = styled(Card2)`
  height: 220px;
  justify-content: center;
  padding: 0;
  text-align: center;
  width: 245px;
  margin-right: 8px;
  align-items: center;
  transition: box-shadow 10ms linear 0s;
  box-shadow: rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;
  cursor: pointer;
  border: 1px solid rgb(208, 216, 222);
  border-radius: 3px;

  :active, :hover {
  background-color: #E0FFFF;
  color: white;
}

  &.card-title {
    > div {
      h2 {
        color: ${colors.gray};
        font-size: ${metrics.fontSizeSubTitle};
      }
    }

    .class-button {
      height: 5px;
      width: 120px;
    }
  }
`

export const OffenderTitle = styled.p`
  font-size: ${metrics.fontSizeDefault};
  line-height: 15px;
  margin: 0 0 0 0;
  padding: 0 0 0 0;
`

export const TotalInfractions = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  padding: 0px 8px 8px 8px;
`

export const TotalCounter = styled.p`
  color: ${colors.primaryDark};
  font-size: ${metrics.fontSizeXLarge};
  font-weight: ${metrics.baseFontWeight};
  margin: 0 0 0 0;
  padding: 0 0 0 0;

  &.total {
    margin: 0 0 0 0;
    margin-left: ${metrics.baseMargin};
    padding: 0 0 0 0;
  }
`

export const TotalCounter2 = styled.p`
  color: ${colors.primaryDark};
  font-size: ${metrics.fontSizeMedium};
  font-weight: ${metrics.baseFontWeight};
  margin: 0 0 0 0;
  padding: 0 0 0 0;

  &.total {
    margin: 0 0 0 0;
    margin-left: ${metrics.baseMargin};
    padding: 0 0 0 0;
  }
`

export const Offender = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  text-align: center;
`

export const StyledSubTitle = styled.p`
  color: ${colors.primary};
  font-size: ${metrics.fontSizeMedium};
  line-height: 20px;
  margin: 0 0 0 0;
  padding: 0 0 0 0;
`

export const Driver = styled.div`
  text-align: left;
  p {
    margin: 0;
  }
`

export const DriverTitle = styled.p`
  color: ${colors.gray};
  font-size: ${metrics.fontSizeDefault};
  line-height: 18px;
  margin: 14px 0 0 0;
`

export const DriverInformation = styled.div`
  align-items: center;
  display: flex;
  justify-content: space-between;
  text-align: start;
`

export const DriverInformationLeft = styled.div`
  width: 183px;
  margin-top: 20px;

  p:first-child {
    border-bottom: 1px solid rgba(105, 122, 139, 0.2);
    margin-bottom: 1px solid black;
    padding-bottom: 4px;
    margin-right: 14px;
  }

  p {
    color: ${colors.primary};
    font-size: ${metrics.fontSizeDefault};
    line-height: 18px;
    margin: 0;
  }
`

export const DriverTotal = styled.div`
  text-align: right;

  p {
    color: ${colors.black};
    font-size: ${metrics.fontSizeTitle};
    font-weight: 600;
    line-height: 25px;
  }
`
