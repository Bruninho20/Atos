package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Maneuver(
    @JsonProperty("action") var action: String?,
    @JsonProperty("direction") var direction: String?,
    @JsonProperty("firstPoint") var firstPoint: Int?,
    @JsonProperty("id") var id: String?,
    @JsonProperty("instruction") var instruction: String?,
    @JsonProperty("instructionAfter") var instructionAfter: String?,
    @JsonProperty("instructionBefore") var instructionBefore: String?,
    @JsonProperty("lanes") var lanes: String?,
    @JsonProperty("lastPoint") var lastPoint: Int?,
    @JsonProperty("length") var length: Int?,
    @JsonProperty("nextRoadName") var nextRoadName: Collection<RoadName>?,
    @JsonProperty("position") var position: ManeuverPosition?,
    @JsonProperty("roadName") var roadName: Collection<RoadName>?,
    @JsonProperty("travelTime") var travelTime: Int?
)