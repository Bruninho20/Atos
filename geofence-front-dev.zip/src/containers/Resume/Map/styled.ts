import styled from 'styled-components';

import { Layout } from 'components';

export const DashboardWrapper = styled(Layout.Content)``;

export const Container = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
`

export const MapWrapper = styled.div`
  height: 100%;
  width: 100%;
`