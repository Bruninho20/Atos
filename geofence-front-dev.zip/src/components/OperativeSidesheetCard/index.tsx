import React from 'react'
import { FormattedMessage } from 'react-intl';
import { Row, Col } from 'react-bootstrap'

import { StyledCard, OperativeCard } from './styled'

interface MiniCardProps {
  title: any
  onCharge: any
  potencyLimiter: any
  ecoMode: any
  eletricFail: any
  coolingFail: any
  odometer: any
  distance: any
  time: any
}

const InfringementCard: React.FC<MiniCardProps> = ({
  title,
  onCharge,
  potencyLimiter,
  ecoMode,
  eletricFail,
  coolingFail,
  odometer,
  distance, 
  time
}) => {
  return (
    <StyledCard
      // action={action}
      title={title}
      // justify={justifyTitle}
      className='card-title'>
      <div>
        <Row>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='batteryCharging' />}>
              {onCharge}
            </OperativeCard>
          </Col>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='economyMode' />}>
              {ecoMode}
            </OperativeCard>
          </Col>
        </Row>
        <Row>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='potencyLimiter' />}>
              {potencyLimiter}
            </OperativeCard>
          </Col>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='odometer' />}>
              <p>{odometer}</p>
            </OperativeCard>
          </Col>
        </Row>
        <Row>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='electricFailure' />}>
              {eletricFail}
            </OperativeCard>
          </Col>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='refrigerationFailure' />}>
              {coolingFail}
            </OperativeCard>
          </Col>
        </Row>
        <Row>
        <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='distanceLastCharge' />}>
              <p>{distance}</p>
            </OperativeCard>
          </Col>
          <Col md='6'>
            <OperativeCard className='mini-card-title' title={<FormattedMessage id='timeLastCharge' />}>
              <p>{time}</p>
            </OperativeCard>
          </Col>
        </Row>
      </div>
    </StyledCard>
  )
}

export default InfringementCard
