package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class VehicleSpecification(
    @JsonProperty("commercial") var commercial: Boolean?,
    @JsonProperty("disabledEquipped") var disabledEquipped: Boolean?,
    @JsonProperty("emissionType") var emissionType: String?,
    @JsonProperty("fuelType") var fuelType: String?,
    @JsonProperty("heightAbove1stAxleMax") var heightAbove1stAxleMax: Int?,
    @JsonProperty("heightAbove1stAxleMin") var heightAbove1stAxleMin: Int?,
    @JsonProperty("heightMax") var heightMax: Int?,
    @JsonProperty("heightMin") var heightMin: Int?,
    @JsonProperty("hov") var hov: Boolean?,
    @JsonProperty("hybrid") var hybrid: Boolean?,
    @JsonProperty("lengthMax") var lengthMax: Int?,
    @JsonProperty("lengthMin") var lengthMin: Int?,
    @JsonProperty("limitedWeightMax") var limitedWeightMax: Int?,
    @JsonProperty("limitedWeightMin") var limitedWeightMin: Int?,
    @JsonProperty("minimalPollution") var minimalPollution: Boolean?,
    @JsonProperty("passengersCountMax") var passengersCountMax: Int?,
    @JsonProperty("passengersCountMin") var passengersCountMin: Int?,
    @JsonProperty("personFee") var personFee: Boolean?,
    @JsonProperty("shippedHazardousGoods") var shippedHazardousGoods: String?,
    @JsonProperty("tiresCountMax") var tiresCountMax: Int?,
    @JsonProperty("tiresCountMin") var tiresCountMin: Int?,
    @JsonProperty("tollVehicleType") var tollVehicleType: String?,
    @JsonProperty("trailerHeightMax") var trailerHeightMax: Int?,
    @JsonProperty("trailerHeightMin") var trailerHeightMin: Int?,
    @JsonProperty("trailerNumberAxlesMax") var trailerNumberAxlesMax: Int?,
    @JsonProperty("trailerNumberAxlesMin") var trailerNumberAxlesMin: Int?,
    @JsonProperty("trailerType") var trailerType: String?,
    @JsonProperty("trailersCount") var trailersCount: Int?,
    @JsonProperty("vehicleNumberAxlesMax") var vehicleNumberAxlesMax: Int?,
    @JsonProperty("vehicleNumberAxlesMin") var vehicleNumberAxlesMin: Int?,
    @JsonProperty("vehicleWeightMax") var vehicleWeightMax: Int?,
    @JsonProperty("vehicleWeightMin") var vehicleWeightMin: Int?
)
