import { accessToken } from 'configuration/tokenHandling/accessToken'
import { customBaseApi } from '../base-api'
import { fetcherAPi } from '../fetcher-api'

const list = (params: Record<string, unknown>) => fetcherAPi.post('/faultCodes', params)

const sendEmail = (params: Record<string, unknown>) => fetcherAPi.post('/email/dmcode/send', params)

const downloadFile = (fileType: 'csv' | 'xlsx',id: string, params?: Record<string, unknown>) =>
  customBaseApi(accessToken.getAccessToken())
    .post(`/download.${fileType}/${id}`, params, {
      responseType: fileType === 'xlsx' ? 'arraybuffer' : undefined
    })
    .then(({ data }) => data)


export const dmCode = {
  list,
  downloadFile,
  sendEmail
}
