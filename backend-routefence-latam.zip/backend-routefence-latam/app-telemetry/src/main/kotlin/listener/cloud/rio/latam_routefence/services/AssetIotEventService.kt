package listener.cloud.rio.latam_routefence.services

import listener.cloud.rio.latam_routefence.infrastructure.repositories.AssetIotEventPairingRepository
import listener.cloud.rio.latam_routefence.infrastructure.repositories.AssetIotEventPositionRepository
import listener.cloud.rio.latam_routefence.infrastructure.repositories.AssetIotEventStateEntityRepository
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage

@Service
@Transactional
class AssetIotEventService(
    private val assetIotEventPositionRepository: AssetIotEventPositionRepository,
    private val assetIotEventStateEntityRepository: AssetIotEventStateEntityRepository,
    private val assetIotEventPairingRepository: AssetIotEventPairingRepository,
    private val infringimentDetection: InfringementDetection,
    private val tripService: TripService
) {
    private val logger = LoggerFactory.getLogger(this.javaClass)

    fun save(assetIotEventMessage: AssetIotEventMessage) {
        if (assetIotEventMessage.trigger == "timer") {

            //TODO https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-368
            // Detalhes na descrição da task
            if (tripService.getActiveTrips(assetIotEventMessage.assetId.toString()).isNotEmpty())
            {
                try {
                    logger.debug("asset_Iot_Event_Message: $assetIotEventMessage")
                    logger.debug("assetId: ${assetIotEventMessage.assetId}")

                    if (assetIotEventMessage.position != null) {
                        val iotEventPosition = assetIotEventMessage.mapToAssetIotPosition()
                        assetIotEventPositionRepository.save(iotEventPosition)
                    }

                    if (assetIotEventMessage.state != null) {
                        val iotEventState = assetIotEventMessage.mapToAssetIotState()
                        assetIotEventStateEntityRepository.save(iotEventState)
                    }

                    tryStartInfringmentValidation(assetIotEventMessage)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } else if (assetIotEventMessage.trigger == "driver-login") {
             val iotEventPairing = assetIotEventMessage.mapToAssetIotPairing()
             assetIotEventPairingRepository.save(iotEventPairing)
        }
    }

    private fun tryStartInfringmentValidation(assetIotEventMessage: AssetIotEventMessage) {
        val completeIoT = tryCompleteIotEventMessage(assetIotEventMessage)
        infringimentDetection.start(completeIoT)
    }

    /**
     * Tenta completar a mensagem IoT.
     */
    fun tryCompleteIotEventMessage(iotMsg: AssetIotEventMessage): AssetIotEventMessage {
        val eventKey = "/event/"
        val posKey = "/pos/"
        val stateKey = "/state/"

        val eidEventBased = iotMsg.eid
            .replace(posKey, eventKey)
            .replace(stateKey, eventKey)

        val stateOpt = assetIotEventStateEntityRepository.findByEid(eidEventBased.replace(eventKey, stateKey))
        val positionOpt = assetIotEventPositionRepository.findByEid(eidEventBased.replace(eventKey, posKey))

        val state = stateOpt?.mapToAssetIotEventMessage()?.state
        val position = positionOpt?.mapToAssetIotEventMessage()?.position

        return AssetIotEventMessage(
            accountId = iotMsg.accountId,
            assetId = iotMsg.assetId,
            deviceId = iotMsg.deviceId,
            deviceType = iotMsg.deviceType,
            driverIdentification = iotMsg.driverIdentification,
            driverIdentificationType = iotMsg.driverIdentificationType,
            eid = iotMsg.eid,
            occurredAt = iotMsg.occurredAt,
            trigger = iotMsg.trigger,
            position = position,
            state = state,
            driverState = iotMsg.driverState,
            driverInfo = iotMsg.driverInfo
        )
    }

    fun getLastSpeed (assetId: String): Double?{
        return assetIotEventPositionRepository.findLastSpeedByAssetId(assetId)
    }
}