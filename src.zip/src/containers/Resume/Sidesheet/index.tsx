import React, { FC, useEffect, useState } from 'react'
import { SideSheetResume } from 'components'
import RouteDetails from './RouteDetails'
import VehicleDetails from './VehicleDetails'
import TripDetails from './TripDetails'
import InfractionDetails from './InfractionDetails'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'

const ResumeSidesheet: FC<{
  isOpen: boolean
  data?: any
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, data, onClose }) => {
  const [type, setType] = useState('trip')
  const [title, setTitle] = useState('Histórico da Viagem')
  const [routeData, setRouteData] = useState<any>([])
  const [infractionsData, setInfractionsData] = useState<any>([])
  const [summaryData, setSummaryData] = useState<any>([])

  console.log(infractionsData, 'infractionsData NO SIDESHEET')

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  const getSummaryData = async () => {
    try {
      const res = await axios.get(`${baseURL}/summary/${data?.tripId}`, head)

      setSummaryData(res.data)
    } catch (error) {
      console.log(error)
    }
  }

  const getRouteData = async () => {
    const res = await axios.get(`${baseURL}/routes/${data?.routeId}`, head)
    setRouteData([res.data])
  }

  const getInfractionsData = async () => {
    const res = await axios.get(`${baseURL}/infringements/${data?.tripId}`, head)
    setInfractionsData([res.data])
  }

  useEffect(() => {
    if (data?.routeId !== undefined) {
      getRouteData()
      getInfractionsData()
      getSummaryData()
    }
  }, [data])

  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  useEffect(() => {
    setType('trip')
    setTitle(`Histórico da Viagem`)
  }, [isOpen])

  const handleSetType = (e: string) => {
    setType(e)
    if (e === 'route') {
      setTitle(`Detalhes da Rota`)
    } else if (e === 'trip') {
      setTitle(`Histórico da Viagem`)
    } else if (e === 'infraction') {
      setTitle(`Histórico de Infrações`)
    } else {
      setTitle(`Detalhes do Veículo`)
    }
  }

  return (
    <>
      <SideSheetResume
        modal
        width='480px'
        padding='0'
        open={isOpen}
        title={title}
        onClick={() => handleOnClose(false)}
        onClickType={handleSetType}>
        {type === 'route' ? (
          <RouteDetails data={routeData[0]} />
        ) : type === 'trip' ? (
          <TripDetails data={data} />
        ) : type === 'vehicle' ? (
          <VehicleDetails data={summaryData} />
        ) : (
          <InfractionDetails data={infractionsData} tripData={data} />
        )}
      </SideSheetResume>
    </>
  )
}

export default ResumeSidesheet
