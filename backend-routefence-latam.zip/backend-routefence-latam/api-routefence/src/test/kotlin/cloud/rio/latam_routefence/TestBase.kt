package cloud.rio.latam_routefence

import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.io.IOException

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
abstract class TestBase {
    val ACCOUNT_ID: String = "4924568e-23f3-40f9-9730-ff88efc41172"

    fun setAccountContext(accountId: String = ACCOUNT_ID) {
        AccountContext.set(accountId)
    }
    fun clearAccountContext() {
        AccountContext.clear()
    }

    @Throws(IOException::class)
    fun getPayload(resource: String): String {
        val payload = javaClass.classLoader.getResourceAsStream(resource)
        return jacksonObjectMapper().readTree(payload).toString()
    }

    fun createRouteRequest(payload: String): RouteRequest {
        val mapper = jacksonObjectMapper()
        mapper.registerModule(JavaTimeModule())
        var obj = mapper.readValue<RouteRequest>(payload)
        return obj
    }
}