package cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.Route

@JsonIgnoreProperties(ignoreUnknown = true)
data class Response(
    @JsonProperty("route") var route: Collection<Route>?,
    @JsonProperty("warnings") var warnings: Collection<String>?,
    @JsonProperty("language") var language: String?
)