package routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AccountTenantEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.*
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Id
import javax.persistence.Table

@Entity
@Table(name = "TB_ASSET_IOT_EVENT_POSITION")
data class AssetIotEventPositionEntity(
    @Id
    @Column(name = "ID")
    val id: String = UUID.randomUUID().toString(),

    @Column(name = "ASSET_ID")
    val assetId: String,

    override var accountId: String = "",

    @Column(name = "DEVICE_ID")
    val deviceId: String,

    @Column(name = "DEVICE_TYPE")
    val deviceType: String?,

    @Column(name = "EID")
    val eid: String,

    @Column(name = "OCCURRED_AT")
    val occurredAt: LocalDateTime,

    @Column(name = "TRIGGER")
    val trigger: String,

    @Column(name = "DRIVER_IDENTIFICATION")
    val driverIdentification: String?,

    @Column(name = "DRIVER_IDENTIFICATION_TYPE")
    val driverIdentificationType: String?,

    @Column(name = "LATITUDE")
    val latitude: Double,

    @Column(name = "LONGITUDE")
    val longitude: Double,

    @Column(name = "ALTITUDE")
    val altitude: Double?,

    @Column(name = "ACCURACY")
    val accuracy: Double?,

    @Column(name = "ALTITUDE_ACCURACY")
    val altitudeAccuracy: Double?,

    @Column(name = "HEADING")
    val heading: Double?,

    @Column(name = "SPEED")
    val speed: Double?
): AccountTenantEntity(accountId) {
    fun mapToAssetIotEventMessage() : AssetIotEventMessage {
        return AssetIotEventMessage(
            accountId = accountId,
            assetId = UUID.fromString(assetId),
            deviceId = UUID.fromString(deviceId),
            deviceType = deviceType,
            driverIdentification = driverIdentification,
            driverIdentificationType = driverIdentificationType,
            eid = eid,
            occurredAt = occurredAt.atOffset(ZoneOffset.UTC),
            trigger = trigger,
            position = AssetPositionMessage(
                latitude = this.latitude,
                longitude = this.longitude,
                altitude = this.altitude,
                accuracy = this.accuracy,
                altitudeAccuracy = this.altitudeAccuracy,
                heading = this.heading,
                speed = this.speed
            ),
            driverState = null,
            state = null,
            driverInfo = null
        )
    }
}



