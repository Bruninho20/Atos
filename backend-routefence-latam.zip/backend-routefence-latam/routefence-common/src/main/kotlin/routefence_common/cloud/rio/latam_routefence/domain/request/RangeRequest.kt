package routefence_common.cloud.rio.latam_routefence.domain.request

data class RangeRequest (
    var id: String? = null,
    var trafficConditions: String? = null,
    var avoidToll: String? = null,
    var avoidRoad: String? = null,
    var ignoreTrafficRestrictions: String? = null
)

