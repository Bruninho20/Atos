package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class Item (
    val title: String?,
    val id: String?,
    val politicalView: String?,
    val resultType: String?,
    val houseNumberType: String?,
    val addressBlockType: String?,
    val localityType: String?,
    val administrativeAreaType: String?,
    val address: Address?,
    val position: Position?,
    val access: List<Position>?,
    val distance: Long?,
    val mapView: MapView?,
    val categories: List<Category>?,
    val foodTypes: List<Category>?,
    val houseNumberFallback: Boolean?,
    val timeZone: TimeZone?,
    val streetInfo: List<StreetInfo>?,
    val countryInfo: CountryInfo?
)
