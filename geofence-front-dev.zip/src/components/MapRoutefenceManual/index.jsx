import React, { useEffect, useState } from 'react';
import axios from 'axios'
import { Map as RioMap, EventUtils, Route, Marker, SingleMapMarker, ContextMenu, ContextMenuItem } from 'rio-uikit-map';
import { decode } from 'core/utils/flexiblePolyline'


const RouteExample = ({ data, handleOpenConfigDialog, handleOpenAddressDialogManual, handleSaveRouteParameters, handleAddStops }) => {
  const [coordLabel, setCoordLabel] = useState();
  const [showSpinner, setShowSpinner] = useState(true);
  // const [shapePoints, setShapePoints] = useState([])
  const [avoidFeature, setAvoidFeature] = useState([])
  const [newData, setNewData] = useState([])
  const [vias, setVias] = useState([])
  const [numberRefresh, setNumberRefresh] = useState(0)
  const [stopArrayV8, setStopArrayV8] = useState(data?.allStops)

  const [initialPosition, setInitialPosition] = useState([
    {
      lat: -23.5475,
      lng: -46.63611
    },
    {
      lat: -23.5475,
      lng: -46.63611
    },
  ])

  // const handleSaveCrossing = () => {
  //   const body = {
  //     name: '',
  //     category: 'CROSSING',
  //     rangeLimitMeters: 0,
  //     stayTime: '00:00',
  //     position: {
  //       lat: data?.stops?.position.lat,
  //       lng: data?.stops?.position.lng,
  //       address: data?.stops?.address
  //     }
  //   }

  //   handleAddStops([...stopArray, body])
  // }

  const handleGetAndSaveCrossing = (data) => {
    axios
      .get(
        `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${data.lat},${data.lng}&lang=en-US&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result) => {
        const body = {
          name: '',
          category: 'CROSSING',
          rangeLimitMeters: 0,
          stayTime: '00:00',
          position: {
            lat: result?.data?.items[0]?.position?.lat,
            lng: result?.data?.items[0]?.position?.lng,
            address: result?.data?.items[0]?.address
          }
        }

        handleAddStops(body)
      })
  }

  const handlSetStopArray = () => {

    const arrayStopV8 = newData?.allStops?.map((item) => {
      return (
        `&via=${item?.position?.lat},${item?.position?.lng}`
      )
    })
    setStopArrayV8(arrayStopV8)
  }

  useEffect(() => {
    handlSetStopArray()
  }, [newData?.allStops])

  const [refresh, setRefresh] = useState(false)

  const formatCoordinates = coordinates => {
    return [
      Math.abs(coordinates.lat.toFixed(4)) + (coordinates.lat > 0 ? 'N' : 'S'),
      Math.abs(coordinates.lng.toFixed(4)) + (coordinates.lng > 0 ? 'E' : 'W'),
    ].join(' ');
  };

  let arrayPoints = []

  useEffect(() => {

    setNumberRefresh(1)
  }, [data?.allStops])


  const handleOpenContextMenu = contextMenuCoordinates => {
    setShowSpinner(true);

    setCoordLabel(formatCoordinates(contextMenuCoordinates));

    setTimeout(() => setShowSpinner(false), 1000);
  };

  const handleSetStartRoute = (coordinates) => {
    arrayPoints.unshift({ lat: coordinates.lat, lng: coordinates.lng })
    handleOpenAddressDialogManual({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      },
      points: arrayPoints
    }, 'originRoute', true)
  }

  const handleSetStop = (coordinates) => {
    handleOpenConfigDialog({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      }
    }, 'stops', true)
  }

  const handleSetFinishRoute = (coordinates) => {
    arrayPoints.push({ lat: coordinates.lat, lng: coordinates.lng })
    handleOpenAddressDialogManual({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      },
      points: arrayPoints
    }, 'destinyRoute', true)
  }

  let teste = []

  const handleAddPoint = (coordinates) => {
    handleGetAndSaveCrossing({ lat: coordinates.lat, lng: coordinates.lng })
    arrayPoints.push({ lat: coordinates.lat, lng: coordinates.lng })
    if (coordinates.lat) {
      teste.push(`&via=${coordinates.lat},${coordinates.lng}`)
    }

    // if (arrayPoints.length >= 2) {
    //   setInitialPosition(arrayPoints)
    // }
    // handleAddPointsToShape(arrayPoints)
    setVias(teste)
    setNumberRefresh(coordinates)

  }

  const handleSubtractPoint = () => {
    teste.pop()
    setVias(teste)
    arrayPoints.pop()
    // handleAddPointsToShape(arrayPoints)
  }

  const contextMenuItems = [
    <ContextMenuItem
      className='bg-lightest text-color-dark'
      labelClassName='text-medium'
      label={coordLabel}
      icon='rioglyph-map-marker'
      hasSpinner={showSpinner}
    />,
    <ContextMenuItem icon='rioglyph-start' label='Ínicio da Rota' callback={(e) => handleSetStartRoute(e)} />,
    <ContextMenuItem icon='rioglyph rioglyph-plus-sign' label='Adicionar Ponto' callback={(e) => handleAddPoint(e)} />,
    <ContextMenuItem icon='rioglyph rioglyph-minus-sign' label='Remover Ponto' callback={() => handleSubtractPoint()} />,
    <ContextMenuItem icon='rioglyph-route' label='Adicionar Parada' callback={(e) => handleSetStop(e)} />,
    <ContextMenuItem icon='rioglyph-finish' label='Fim da Rota' callback={(e) => handleSetFinishRoute(e)} />,
  ];

  const eventListenerMap = {
    [EventUtils.TAP]: event => {
      event.stopPropagation();
      console.log(event.currentTarget.c.R.src.a.position)

    }
  };

  const avoidRoad = data?.routeParameters?.avoidRoad === true ? '-2' : '0'
  const avoidToll = data?.routeParameters?.avoidToll === true ? '-1' : '0'

  const stopsWaypoint = data?.allStops?.length > 0 ? data?.allStops?.map((item, index) => {
    return (
      `waypoint${index + 1}=geo!${item?.position?.lat},${item?.position?.lng}&`
    )
  }) : ''

  const trafficConditions = newData?.routeParameters?.trafficConditions === true ? 'traffic&' : ''

  useEffect(() => {
    if(data?.destinyRouteData?.addressStop?.postalCode !== newData?.destinyRouteData?.addressStop?.postalCode
      || data?.originRouteData?.addressStop?.postalCode !== newData?.originRouteData?.addressStop?.postalCode
      || data?.allStops !== newData?.allStops
      ) 
    setNewData(data)
  }, [data])

  let arrayAvoidFeature = []

  // const handleGetAvoidFeature = () => {
  //   if (newData?.routeParameters?.avoidRoad === true) {
  //     if (!arrayAvoidFeature.includes('controlledAccessHighway')) {
  //       arrayAvoidFeature.push('controlledAccessHighway')
  //     } else {
  //       const index = arrayAvoidFeature.indexOf('controlledAccessHighway')
  //       arrayAvoidFeature.splice(index, 1)
  //     }
  //   }
  //   if (newData?.routeParameters?.avoidToll === true) {
  //     if (!arrayAvoidFeature.includes('tollRoad')) {
  //       arrayAvoidFeature.push('tollRoad')
  //     } else {
  //       const index = arrayAvoidFeature.indexOf('tollRoad')
  //       arrayAvoidFeature.splice(index, 1)
  //     }
  //   }
  //   setAvoidFeature(arrayAvoidFeature)
  // }

  // useEffect(() => {
  //   handleGetAvoidFeature()
  // }, [newData?.routeParameters])

  let ArrayOfShape = []

  const handleGetShape = () => {
    axios
      .get(` https://router.hereapi.com/v8/routes?lang=pt-br,en-us&apikey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&${trafficConditions}${avoidFeature.length >= 1 ? `avoid[features]=${avoidFeature.join()}` : ''}&return=polyline,summary,actions,instructions,routeHandle&transportMode=truck&origin=${newData?.originRouteData?.lat},${newData?.originRouteData?.lng}&destination=${newData?.destinyRouteData?.lat},${newData?.destinyRouteData?.lng}${stopArrayV8?.join('')}`)
      .then(result => {
        const getPolylineArray = result?.data?.routes[0]?.sections.map((item) => {
          return {
            shape: decode(item.polyline)
          }
        })

        const shapeArray = getPolylineArray.map((item) => {
          return (
            ArrayOfShape.push(item.shape.polyline)
          )
        })

        const concatArrays = ArrayOfShape.flat()
        const getPoints = concatArrays.map((value) => {
          return {
            lat: (value[0]).toString(),
            lng: (value[1]).toString()
          }
        })
        setInitialPosition(getPoints)
        handleSaveRouteParameters(result?.data)
      })
  }

  useEffect(() => {
    handleGetShape()
  }, [numberRefresh, data?.allStops])

  useEffect(() => {
    handleAddPoint({ lat: data?.destinyRouteData?.lat, lng: data?.destinyRouteData?.lng })
  }, [newData])

  const getMiddlePos = (positions) =>
    positions[Math.floor(positions.length / 2)]

  const position = { lat: initialPosition[0]?.lat, lng: initialPosition[0]?.lng };



  const offset = 0.3;

  const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'

  const getRandomValueToForceRerender = () => Math.random();

  const Routes = () => {
    const [activeRouteId, setActiveRouteId] = useState(1);
    const isActive = id => activeRouteId === id;
    const isFirstRouteActive = isActive(1);
    const isSecondRouteActive = isActive(2);

    const markersStops = data?.allStops?.length > 0 ? data?.allStops?.map((item, index) => {

      const position = { lat: item?.position?.lat, lng: item?.position?.lng }

      return (
        <Marker
          key={index}
          customData={{ id: index + 1 }}
          position={position}
          eventListenerMap={markerEventListenerMap}
          icon={
            <SingleMapMarker
              iconNames={item.category !== 'CROSSING' ? ['route'] : ['pin']}
              name={item.name}
              markerColor='bg-map-marker-route'
              active={isFirstRouteActive}
              fixed
            />
          }
        />
      )
    }) : ''

    const markerEventListenerMap = {
      [EventUtils.TAP]: event => {
        event.stopPropagation();
        setActiveRouteId(event.currentTarget.getData().id);
      },
    };

    return (
      <React.Fragment>
        <Route
          key={getRandomValueToForceRerender()}
          positions={initialPosition}
          startIcon={<SingleMapMarker iconNames={['start']} markerColor='bg-map-marker-asset' />}
          endIcon={<SingleMapMarker iconNames={['finish']} markerColor='bg-map-marker-asset' />}
          isRouteAlternative={!isFirstRouteActive}
          hasArrows={true}
          markers={markersStops}
        />
      </React.Fragment>
    );
  };

  return (
    <>
      <RioMap
        credentials={{
          apikey:
            typeof apiKey === 'string'
              ? apiKey
              : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
        }}
        center={getMiddlePos(initialPosition)}
        zoom={11}
        height={900}
        eventListenerMap={eventListenerMap}
        hideMapSettings
      >
        <Routes />
        {/* {data.allStops.length >= 1 ? data?.allStops?.map((item, index) => {
          const position = { lat: item?.position?.lat, lng: item?.position?.lng }
          return (
            <Marker
              key={index}
              customData={{ id: index }}
              position={position}
              icon={
                <SingleMapMarker
                  iconNames={['route']}
                  name={'TESTE'}
                  markerColor='bg-map-marker-route'
                  fixed
                />
              }
            />
          )
        }) : null} */}
        <ContextMenu
          onOpen={handleOpenContextMenu}
          menuItems={contextMenuItems}
        // contextMenuEvent={contextMenuData.event}
        // targetPosition={contextMenuData.targetPosition}
        />
        <div style={{ height: 200, width: 200, position: 'relative', zIndex: 99, backgroundColor: 'white' }}></div>
      </RioMap>
    </>

  );
};

export default RouteExample;