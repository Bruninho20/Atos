package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.VehicleDataEntity
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext

@Repository
class VehicleDataCustomRepositoryImpl : VehicleDataCustomRepository {

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun findVehicleByChassis(chassis: String): VehicleDataEntity? {
        val sql = "SELECT * FROM TB_VEHICLE_DATA"
        val query = entityManager.createNativeQuery(sql, VehicleDataEntity::class.java)

        val resultList = query.resultList as List<VehicleDataEntity>

        for (vehicleData in resultList) {
            val combinedValue = "${vehicleData.geoAndAreaAndManufacturerCode}${vehicleData.bodyworkCode}${vehicleData.engineCode}${vehicleData.safetySystemCode}${vehicleData.vehicleClassCode}${vehicleData.factoryCode}"
            if (combinedValue == chassis) {
                return vehicleData
            }
        }

        return null
    }
}