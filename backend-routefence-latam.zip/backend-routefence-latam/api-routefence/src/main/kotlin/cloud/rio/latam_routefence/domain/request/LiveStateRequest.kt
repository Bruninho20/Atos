package cloud.rio.latam_routefence.domain.request

data class LiveStateRequest(
    val assetIds: List<String>? = emptyList(),
    val tagIds: List<String>? = emptyList(),
)