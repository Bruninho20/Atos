package cloud.rio.latam_routefence.enums

enum class EmailStatusEnum {
    SENT,ERROR
}
