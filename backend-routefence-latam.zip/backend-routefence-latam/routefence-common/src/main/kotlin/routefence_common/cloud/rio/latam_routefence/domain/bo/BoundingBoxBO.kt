package routefence_common.cloud.rio.latam_routefence.domain.bo

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class BoundingBoxBO(
    @JsonProperty("lat") val lat: Double,
    @JsonProperty("lng") val lng: Double
)
