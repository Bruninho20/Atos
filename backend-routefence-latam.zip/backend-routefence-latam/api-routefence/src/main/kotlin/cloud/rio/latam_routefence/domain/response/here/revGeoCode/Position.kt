package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class Position(
    val lat: Long?,
    val lng: Long?
)
