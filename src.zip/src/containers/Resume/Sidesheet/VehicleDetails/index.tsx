import React, { FC } from 'react'
import { WrapperContent, CardContent, Card, Label, Description, Container } from './styled'
import moment from 'moment'

interface PropsData {
  data: any
}

const VehicleDetails: FC<PropsData> = ({ data }) => {
  console.log(data, 'DATA NO VEHICLE SIDESHEET')

  return (
    <WrapperContent>
      <CardContent style={{ borderRadius: 8 }}>
        <Card>
          <span className='rioglyph rioglyph-settings' style={{ fontSize: 50, color: '#878585' }}></span>
          <h6 style={{ color: '#878585' }}>{`${data?.mileage?.toFixed(1)} km`}</h6>
        </Card>
        <Card>
          <span className='rioglyph rioglyph-speed' style={{ fontSize: 50, color: '#878585' }}></span>
          <h6 style={{ color: '#878585' }}>{`${data?.speed?.toFixed(1)} km/h`}</h6>
        </Card>
      </CardContent>
      <Container>
        <Label>Nome:</Label>
        <Description>{data?.driverName}</Description>
        <Label>Nº Chassi:</Label>
        <Description>{data?.chassi}</Description>
        <Label>Veículo:</Label>
        <Description>{data?.assetName}</Description>
        <Label>Tipo:</Label>
        <Description>{data?.asset?.type === 'bus' ? 'ÔNIBUS' : 'CAMINHÂO'}</Description>
      </Container>
      <Container>
        <Label>Endereço:</Label>
        <Description>{data?.latLongLastPosition?.addressStop?.label}</Description>
        <Label>Posição:</Label>
        <Description>{`${data?.latLongLastPosition?.lat},${data?.latLongLastPosition?.lng}`}</Description>
        <Label>Ultima Atualização:</Label>
        <Description>{moment(data?.dateTimeLastPosition).format('DD/MM/yyyy HH:mm')}</Description>
      </Container>
    </WrapperContent>
  )
}
export default VehicleDetails
