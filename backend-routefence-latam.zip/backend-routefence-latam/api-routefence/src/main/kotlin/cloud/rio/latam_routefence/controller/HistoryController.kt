package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.services.HistoryService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import routefence_common.cloud.rio.latam_routefence.domain.response.HistoryResponse

@RestController
class HistoryController(private val historyService: HistoryService) {

    @GetMapping("/history/{tripId}")
    fun findAssetByTripAndPeriod(
        @PathVariable tripId: String,
        @RequestParam("startDateTime") startDateTime: String?,
        @RequestParam("endDateTime") endDateTime: String?
    ): HistoryResponse {
        return historyService.findTripByTripAndPeriod(tripId, startDateTime, endDateTime)
    }
}