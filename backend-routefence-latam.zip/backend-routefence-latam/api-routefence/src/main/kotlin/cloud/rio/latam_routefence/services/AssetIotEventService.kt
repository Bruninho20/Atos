package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.domain.request.LiveStateRequest
import cloud.rio.latam_routefence.domain.response.LiveStateResponse
import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import cloud.rio.latam_routefence.infrastructure.repositories.AssetIotEventPositionRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import javax.servlet.http.HttpServletRequest

@Service
@Transactional
class AssetIotEventService(
    private val assetIotEventPositionRepository: AssetIotEventPositionRepository,
    private val assetService: AssetService
) {

     @Transactional(readOnly = true)
    fun getLiveState(request: HttpServletRequest, liveState: LiveStateRequest): List<LiveStateResponse> {
        val assetsMap = validateAssets(request, liveState.tagIds, liveState.assetIds)
        return assetIotEventPositionRepository.getLiveSate(assetsMap)
    }

    fun validateAssets(
        request: HttpServletRequest, tagIds: List<String>?,
        assetIds: List<String>?
    ): HashMap<String, AssetDTO> {
        val assetsMap = assetService.list(request, tagIds, assetIds)

        if (assetsMap.isEmpty())
            throw RoutefenceException.RoutefenceNotFoundException("Vehicles.not.found")
        return assetsMap
    }
}