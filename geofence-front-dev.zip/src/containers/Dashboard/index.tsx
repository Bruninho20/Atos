import React, { FC } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
// import { isEmpty } from 'lodash'
// import DashboardContext from 'core/DashboardContext'
// import { DEFAULT_LOCALE } from 'configuration/lang/lang'
import { Welcome } from 'components'
// import FaultCodes from './FaultCodes'
// import { Period } from 'components/DateTimeFilter'
import { DashboardWrapper } from './styled'

const Dashboard: FC<{ intl: Intl }> = ({}) => {
  return (
    <DashboardWrapper>
      <Welcome
        title={<FormattedMessage id='welcome.title' />}
        description=''
      />
    </DashboardWrapper>
  )
}

export default injectIntl(Dashboard)
