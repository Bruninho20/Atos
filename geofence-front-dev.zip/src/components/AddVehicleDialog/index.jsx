import React, { FC, useState, useEffect, useCallback, useContext } from 'react'
import { Table } from 'react-bootstrap'
import { Dialog, DatePicker, Notification } from 'rio-uikit'
import moment from 'moment'
import { accessToken } from 'configuration/tokenHandling/accessToken'
// import { useForm } from 'react-hook-form'
import useDebounce from 'core/utils/use-debounce'
import { ModalForm, StyledTree } from './styled'
import useSWR from 'swr'
import { fetcherGet } from 'core/utils/fetch'
import axios from 'axios'
import { useHistory } from 'react-router-dom'
import isEmpty from 'lodash/fp/isEmpty'
import { createAssetsList, sanitizeAssetsList, sanitizeTagsList } from './helper'
import DashboardContext from 'core/DashboardContext'
import AutoComplete from 'components/AutoComplete'

const AddVehicleDialog = ({ isOpen, onClose, type, saveLinkedVehicles, data, typeToTrip }) => {
  const history = useHistory()
  // const { setValue, register } = useForm()
  const { linkedVehiclesContext, setLinkedVehiclesContext, routeContext } = useContext(DashboardContext)
  const [buttonSaveName, setButtonSaveName] = useState('Salvar')
  const [linkedVehicles, setLinkedVehicles] = useState([])
  const [trucks, setTrucks] = useState()
  const [truckTags, setTruckTags] = useState({})
  const [tags1, setTags] = useState([])
  const [dateSelected, setDateSelected] = useState('')
  const [assets1, setAssets] = useState([])
  const [selectedTruckTagsIds, setSelectedTruckTagsIds] = useState([])
  const [selectedTruckIds, setSelectedTruckIds] = useState([])
  const [expandedTruckTags, setExpandedTruckTags] = useState([])
  const [vehicles, setVehicles] = useState([])
  const debouncedCallVehicles = useDebounce(selectedTruckIds, 1000)

  useEffect(() => {
    if (linkedVehiclesContext?.length >= 1) {
      setLinkedVehicles(linkedVehiclesContext)
    }
  }, [isOpen])

  const handleSelectedDriver = (e) => {
    console.log(e, 'DRIVER SELECTED NA FUNCAO')
    if (linkedVehicles.flat()[e.index].driverSelected) {
      delete linkedVehicles.flat()[e.index].driverSelected
    }
    linkedVehicles.flat()[e.index].driverSelected = { name: e.name, id: e.id }
  }

  const handleStartDateTime = (e, index) => {
    const cloneStopArray = cloneObject(linkedVehicles.flat())
    if (cloneStopArray[index]?.startDateTime) {
      delete linkedVehicles.flat()[index].startDateTime
    }
    cloneStopArray[index].startDateTime = e
    setLinkedVehicles(cloneStopArray)
  }

  console.log(linkedVehiclesContext, 'linkedVehiclesContext')

  const defaultExpandedTruckTags = []

  const getTags = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const getAssets = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const { data: tags, error: statusTags } = useSWR('https://api.tags.rio.cloud/tags', getTags)
  const { data: assets, error: statusAssets } = useSWR('https://api.assets.rio.cloud/assets?embed=(tags)', getAssets)



  useEffect(() => {
    async function initialData() {
      if (!statusAssets && !isEmpty(assets)) {
        setTrucks(sanitizeAssetsList(assets))
      }
      if (!statusTags && !isEmpty(tags)) {
        setTruckTags(sanitizeTagsList(tags))
      }

      setExpandedTruckTags(defaultExpandedTruckTags)
    }
    initialData()
  }, [assets, statusAssets, statusTags, tags, isOpen])

  useEffect(() => {
    if (debouncedCallVehicles) {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      getData()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedCallVehicles])

  const getData = useCallback(() => {
    const tags = selectedTruckTagsIds.filter((item) => item !== 'empty')

    setTags(tags)
    setAssets(selectedTruckIds)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTruckIds, selectedTruckTagsIds])

  const handleSelectTruck = ({ items, groups }) => {
    // console.log(items, groups, 'items, groups')
    const assetsList = createAssetsList({ items, groups, trucks })
    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    // handleTip()
    setSelectedTruckIds(assetsList)
    setSelectedTruckTagsIds(groups)
  }

  const handleExpandTruckGroups = (expandedTruckGroups) => {
    setExpandedTruckTags(expandedTruckGroups)
  }

  const getDrivers = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const { data: drivers } = useSWR('https://api.geo.latam-maintenance.rio.cloud/rio-routefence/driver', getDrivers)

  const handleAddVehicle = () => {
    const addDates = trucks?.map(item => {
      return {
        ...item,
        startDateTime: dateSelected
      }
    })

    console.log(trucks, 'trucks')
    const selectedTrucks = addDates?.filter(item => selectedTruckIds?.includes(item.id))

    if (typeToTrip === '/resume-edit' && linkedVehicles.length >= 1 || typeToTrip === '/resume-edit' && selectedTrucks?.length > 1) {
      Notification.error('Não é possivel adicionar mais de um veículo')
      return
    }
    setLinkedVehicles([...linkedVehicles, selectedTrucks])
    setButtonSaveName('Salvar')
  }

  const handleDeleteVehicleRow = (index) => {
    const cloneStopArray = cloneObject(linkedVehicles.flat())
    cloneStopArray.splice(index, 1)
    setLinkedVehicles(cloneStopArray)
    setVehicles(cloneStopArray)
  }

  const handleClose = () => {
    setLinkedVehicles([])
    setVehicles([])
    setSelectedTruckIds([])
    setSelectedTruckTagsIds([])
    setTags([])
    setAssets([])
    setTruckTags([])
    setDateSelected('')
    onClose()
  }

  const cloneObject = (object) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  console.log(linkedVehicles, 'linkedVehicles')

  const handleSaveClose = async () => {

    const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

    const customAcessToken = accessToken.getAccessToken()
    console.log(customAcessToken)

    var head = {
      headers: {
        Authorization: `Bearer ${customAcessToken}`
      }
    }

    const verifyDate = linkedVehicles?.flat()?.filter(item => item.startDateTime === "")


    if (linkedVehicles?.flat()?.length < 1) {
      Notification.error('É necessario selecionar um veículo')
    }
    else if (verifyDate?.length >= 1) {
      Notification.error('É necessario inserir uma data')
    }
    else {
      if (type === 'linkVehicleOut' && typeToTrip !== '/resume-edit') {
        try {
          const bodyToLink = {
            linkedVehicles: linkedVehicles?.flat()?.map((value) => {
              return {
                assetId: value?.id,
                driverId: value?.driverSelected?.id,
                startDateTime: moment(value.startDateTime).toISOString(),
                routeId: data?.id
              }
            })
          }

          const res = await axios.post(`${baseURL}/trips/`, bodyToLink.linkedVehicles, head)
          if (res.status === 200 || res.status === 201) {
            Notification.success('Veículo vinculado com sucesso')
            history.push(`/resume`)
          } else {
            Notification.error('Houve um erro ao vincular o veículo')
          }
        } catch (error) {
          console.log(error, 'error')
        }
      } if (typeToTrip === '/resume-edit') {
        try {

          const bodyTrip = {
            assetId: linkedVehicles[0][0]?.id,
            driverId: linkedVehicles[0][0]?.driverSelected?.id,
            id: data,
            routeId: routeContext.id,
            startDateTime: linkedVehicles[0][0]?.startDateTime
          }

          const res = await axios.put(`${baseURL}/trips/${data}`, bodyTrip, head)
          console.log(res, 'res')
          if (res.status === 200 || res.status === 201) {
            Notification.success('Veículo editado com sucesso')
            history.push(`/resume`)
          } else {
            Notification.error('Houve um erro ao editar o veículo')
          }
        } catch (error) {
          console.log(error, 'error')
        }
      } else {
        saveLinkedVehicles(linkedVehicles)

        let cloneLinkedVehicles = cloneObject(linkedVehiclesContext)
        linkedVehicles.flat().forEach(function (element) {
          cloneLinkedVehicles.push(element);
        });
        setLinkedVehiclesContext(linkedVehicles.flat())
      }
      setLinkedVehicles([])
      setVehicles([])
      setSelectedTruckIds([])
      setSelectedTruckTagsIds([])
      setTags([])
      setAssets([])
      setTruckTags([])
      setDateSelected('')
      onClose()
    }
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={typeToTrip === '/resume-edit' ? 'Editar veículo da viagem' : 'Vincular veículos a essa rota ?'}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>
                {truckTags && trucks && (
                  <>
                    <div className='row g-3' style={{ maxHeight: 300, overflow: 'scroll', marginTop: -30 }}>
                      <div className='col-md-12'>
                        <StyledTree
                          groups={truckTags}
                          items={trucks}
                          expandedGroups={expandedTruckTags}
                          onExpandGroupsChange={handleExpandTruckGroups}
                          selectedGroups={selectedTruckTagsIds}
                          selectedItems={selectedTruckIds}
                          onSelectionChange={handleSelectTruck}
                          searchPlaceholder={'Buscar'}
                          hasMultiselect={true}
                        />
                      </div>
                    </div>
                    <div className='row g-2'>
                      <div className='col-md-9' style={{ marginTop: 28 }}>
                        <DatePicker
                          value={dateSelected}
                          onChange={(e) => setDateSelected(moment(new Date(e)))}
                          inputProps={{ placeholder: 'Select Date' }}
                        />
                      </div>
                      <div className='col-md-3' style={{ marginTop: 10 }}>
                        <button
                          type='button'
                          style={{ marginTop: '18px', width: '100%' }}
                          className='btn btn-default'
                          onClick={handleAddVehicle}>
                          Adicionar
                        </button>
                      </div>
                    </div>
                  </>
                )}
                <div style={{ marginTop: 5, height: 280, maxHeight: 400, overflow: 'scroll' }}>
                  <Table striped bordered hover variant='dark'>
                    <thead style={{ border: '1px solid' }}>
                      <tr>
                        <th style={{ fontSize: 14, fontWeight: 'bold' }}>Veículo</th>
                        <th style={{ fontSize: 14, fontWeight: 'bold' }}>Motorista</th>
                      </tr>
                    </thead>
                    <tbody>
                      {linkedVehicles &&
                        linkedVehicles?.flat()?.map((item, index) => {
                          return (
                            <tr>
                              <td style={{ fontSize: 14, width: 220 }}>{item.name}</td>
                              <td style={{ width: 300 }}>
                                <AutoComplete
                                  assetId={item.assetId}
                                  drivers={drivers}
                                  setDriver={(e) =>
                                    handleSelectedDriver({
                                      index,
                                      name: e.display_name,
                                      id: e.id
                                    })}
                                  data={item.driverSelected?.name}
                                />
                                {/* <select
                                  style={{ width: 150 }}
                                  placeholder='Selecione o motorista'
                                  className='form-control'
                                  id='exampleFormControlSelect1'
                                  value={item?.driverSelected?.name}
                                  onChange={(e) =>
                                    handleSelectedDriver({
                                      index,
                                      name: e.target?.value?.split('/')[0].trim(),
                                      id: e.target?.value?.split('/')[1].trim()
                                    })
                                  }>
                                  {item.driverSelected?.name ? (
                                    <option>{item.driverSelected?.name}</option>
                                  ) : (
                                    <option>Selecione o motorista</option>
                                  )}

                                  {drivers?.map((value) => {
                                    const driverData = `${value.display_name} / ${value.id}`
                                    return <option value={driverData}>{value.display_name}</option>
                                  })}
                                </select> */}
                              </td>
                              <td style={{ width: 200 }}>
                                <DatePicker
                                  value={
                                    item.startDateTime ? moment(item.startDateTime).format('DD/MM/yyyy HH:mm') : ''
                                  }
                                  onChange={(e) => handleStartDateTime(moment(new Date(e)).toISOString(), index)}
                                  inputProps={{ placeholder: 'Select Date' }}
                                />
                              </td>
                              <td>
                                <span
                                  style={{ cursor: 'pointer', width: 40 }}
                                  onClick={() => handleDeleteVehicleRow(index)}
                                  className={'rioglyph rioglyph-trash'}
                                  aria-hidden={'true'}></span>
                              </td>
                            </tr>
                          )
                        })}
                    </tbody>
                  </Table>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={handleClose}>
              Cancelar
            </button>
            <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
              {buttonSaveName}
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={onClose}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddVehicleDialog
