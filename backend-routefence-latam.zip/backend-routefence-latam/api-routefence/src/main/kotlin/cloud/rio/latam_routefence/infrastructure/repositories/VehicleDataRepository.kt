package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.VehicleDataEntity

interface VehicleDataRepository : JpaRepository<VehicleDataEntity,String>