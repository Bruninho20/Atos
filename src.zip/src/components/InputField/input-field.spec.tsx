import React from 'react'
import { waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import InputField from './input-field'
import { renderWithTheme, screen } from 'utils/tests/helpers'
import { Formik } from 'formik'

describe('<InputText />', () => {
  const handleOnChange = jest.fn()

  it('should render', () => {
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField id="1" type="text" name="codigo" placeholder="codigo" />
      </Formik>
    )
    expect(screen.getByPlaceholderText('codigo')).toBeInTheDocument()
  })

  it('Renders without Label', () => {
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField
          id="codigo"
          name="codigo"
          value="Código"
          type="number"
          onChange={handleOnChange}
        />
      </Formik>
    )

    expect(screen.queryByLabelText('Label')).not.toBeInTheDocument()
  })

  it('Renders with placeholder', () => {
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField
          id="codigo"
          name="codigo"
          value="Código"
          type="password"
          onChange={handleOnChange}
          placeholder="hey you"
        />
      </Formik>
    )

    expect(screen.getByPlaceholderText('hey you')).toBeInTheDocument()
  })

  it('Does not changes its value when disabled', async () => {
    const onTyping = jest.fn()
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField
          id="codigo"
          name="codigo"
          value="Código"
          type="number"
          onChange={handleOnChange}
          placeholder="hey you"
          disabled
        />
      </Formik>
    )

    const input = screen.getByPlaceholderText('hey you')
    expect(input).toBeDisabled()

    const text = 'This is my new text'
    userEvent.type(input, text)

    await waitFor(() => {
      expect(input).not.toHaveValue(text)
    })
    expect(onTyping).not.toHaveBeenCalled()
  })

  it('Is not accessible by tab when disabled', () => {
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField
          id="codigo"
          name="codigo"
          value="Código"
          type="text"
          onChange={handleOnChange}
          placeholder="hey you"
          disabled
          key={'codigo'}
          labelFor={'codigo'}
        />
      </Formik>
    )

    const input = screen.getByRole('textbox')
    expect(document.body).toHaveFocus()

    userEvent.tab()
    expect(input).not.toHaveFocus()
  })

  it('Renders with error', () => {
    renderWithTheme(
      <Formik initialValues={{}} onSubmit={jest.fn()}>
        <InputField
          id="codigo"
          name="codigo"
          value="Código"
          type="number"
          onChange={handleOnChange}
          placeholder="hey you"
          hasError
          errorMessage="This is an error"
        />
      </Formik>
    )

    expect(screen.getByText('This is an error')).toBeInTheDocument()
  })
})
