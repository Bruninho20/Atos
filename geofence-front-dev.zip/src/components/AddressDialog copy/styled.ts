import styled from 'styled-components'

export const Container = styled.div`
  width: auto;
  padding: 10px;
  flex: 1;
  flex-direction: row;

.class-button {
  margin-bottom: 15px;
}
`

export const ModalForm = styled.div`
  width: auto;
  padding: 10px;

  .class-title {
    color: #000;
    font-weight: 700;
    font-size: 4vh;
    margin-bottom: 20px;
  }

  .class-input {
    width: 450px;
    height: 40px;
    margin-bottom: 7px;
    margin-top: 8px;
  }

  .class-input-name {
    width: 450px;
    height: 40px;
    margin-bottom: 7px;
    margin-top: -30px;
  }

  .class-subtitle {
      font-size: 2vh;
      font-weight: 600;
      margin-bottom: 10px;
  }
`

