/* eslint-disable react/display-name */
import React from 'react';

const Marker = () => () => <div />;
const Map = () => () => <div />;
const SingleMapMarker = () => () => <div />;
const Circle = () => <div />;

export { Marker, Map, SingleMapMarker, Circle };
