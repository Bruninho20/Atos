package routefence_common.cloud.rio.latam_routefence.utils

import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.LoggerFactory
import routefence_common.cloud.rio.latam_routefence.domain.response.routing.ResponseHere
import javax.persistence.AttributeConverter
import javax.persistence.Converter

@Converter(autoApply = true)
class ResponseHereConverter : AttributeConverter<ResponseHere, String> {

    private val logger = LoggerFactory.getLogger(this.javaClass)
    private val objectMapper = ObjectMapper()

    override fun convertToDatabaseColumn(responseHere: ResponseHere?): String? {
        try {
            return objectMapper.writeValueAsString(responseHere)
        } catch (ex: JsonProcessingException) {
            logger.error(ex.localizedMessage)
        }
        return null
    }

    override fun convertToEntityAttribute(dbData: String?): ResponseHere? {
        try {
            return objectMapper.readValue(dbData, ResponseHere::class.java)
        } catch (ex: JsonProcessingException) {
            logger.error(ex.localizedMessage)
        }
        return null
    }

}