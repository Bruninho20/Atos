package listener.cloud.rio.latam_routefence

import listener.cloud.rio.latam_routefence.services.InfringementDetection
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import java.time.OffsetDateTime
import java.util.*

@SpringBootTest
class SimulatorInfringementDetectionTest(@Autowired val infringementDetection: InfringementDetection): TestBase() {

    @Test
    fun testStop() {

        setAccountContext()

        val list = listOf(
            //Velocidade
            Simulator(-23.036773, -45.556717, OffsetDateTime.parse("2023-02-14T10:00:00.761Z"), 120.0),
            Simulator(-23.035449, -45.554582, OffsetDateTime.parse("2023-02-14T10:01:00.761Z"), 70.0),
            Simulator(-23.033210, -45.551431, OffsetDateTime.parse("2023-02-14T10:02:00.761Z"), 100.0),

            //Parada programada
            Simulator(-22.91992, -45.45099, OffsetDateTime.parse("2023-02-14T10:30:00.761Z"), 0.0),
            Simulator(-22.951770, -45.403619, OffsetDateTime.parse("2023-02-14T11:50:00.761Z"), 20.0),

            //Desvio de rota
            Simulator(-22.945442, -45.404321, OffsetDateTime.parse("2023-02-14T12:00:00.761Z"), 80.0),
            Simulator(-22.946699, -45.393609, OffsetDateTime.parse("2023-02-14T12:20:00.761Z"), 70.0),

            // Parada não programada
            Simulator(-22.945522, -45.391170, OffsetDateTime.parse("2023-02-14T12:40:00.761Z"), 0.0),
            Simulator(-22.945172, -45.390479, OffsetDateTime.parse("2023-02-14T12:50:00.761Z"), 70.0),

            Simulator(-22.944869, -45.389871, OffsetDateTime.parse("2023-02-14T13:00:00.761Z"), 0.0),
            Simulator(-22.944694, -45.389512, OffsetDateTime.parse("2023-02-14T13:02:00.761Z"), 70.0)

        )

        list.forEach {
            val iotMessage = AssetIotEventMessage(
                assetId = UUID.fromString("13c8e616-cded-46e2-ba75-013f0b027e4e"),
                accountId = "d87f9f41-5950-45b1-9044-ecb5d32039d8",
                deviceId = UUID.fromString("8664cbbb-ff0b-4332-89dc-1aa283f1856d"),
                deviceType = "tbm3",
                driverIdentification = null,
                driverIdentificationType = null,
                eid = "tbm:2006290118/67/1675694409761/394/state/d9010aed-3df8-432f-bdc2-b4f0bd7d9949",
                occurredAt = it.occurredAt,
                trigger = "timer",
                position = AssetPositionMessage(
                    it.latitude,
                    it.longitude,
                    altitude = 739.2000122070312,
                    accuracy = 3.200000047683716,
                    altitudeAccuracy = null,
                    heading = 51.9900016784668,
                    speed = it.speed
                ),
                state = AssetStateMessage(
                    mileage = 212191.5625,
                    ignitionOn = true,
                    fuelLevel = 71.19999694824219,
                    stateOfCharge = null,
                    electricRange = null,
                    engineSpeed = 1566.0,
                    wheelSpeed = 27.8984375,
                    tachoSpeed = 28.0,
                    fuelConsumption = null,
                    acceleratorPedal = null,
                    weightTotal = null,
                    ptoInformation = null,
                    electronicRetarderState = null,
                    driveState = null,
                    fuelRate = null,
                    instantaneousFuelEconomy = null,
                    engineOperationTime = null
                ),
                driverInfo = null,
                driverState = null
            )

//            Thread.sleep(10000)

            infringementDetection.start(iotMessage)

        }
    }

}

data class Simulator(
    val latitude: Double,
    val longitude: Double,
    val occurredAt: OffsetDateTime,
    val speed: Double
)