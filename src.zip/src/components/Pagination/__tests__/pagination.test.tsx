import React from 'react';
import { cleanup, fireEvent, render } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Pagination } from 'components';

afterEach(cleanup);

it('should start with 50 pages loeaded then load 50 per click. Maximum allowed should be 200. Falhas text', () => {
  const page = 1;
  const handleClick = () => page + 1;
  const { getByText, queryByText, queryByTestId } = render(
    <Pagination
      paginationDescription="Falhas"
      buttonEverythingLoadedLabel="Tudo carregado!"
      buttonLoadMoreLabel="Carregar mais"
      size={200}
      page={page}
      lenghtPerPage={50}
      onLoadmore={handleClick}
    />
  );

  expect(queryByText('Tudo carregado!')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeTruthy();
  expect(getByText('50 Falhas'));
  expect(getByText('50 / 200'));

  fireEvent.click(getByText('Carregar mais'));
  expect(queryByText('Tudo carregado!')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeTruthy();
  expect(getByText('100 Falhas'));
  expect(getByText('100 / 200'));

  fireEvent.click(getByText('Carregar mais'));
  expect(queryByText('Tudo carregado!')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeTruthy();
  expect(getByText('150 Falhas'));
  expect(getByText('150 / 200'));

  fireEvent.click(getByText('Carregar mais'));
  expect(queryByText('Carregar mais')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeFalsy();
  expect(getByText('200 Falhas'));
  expect(getByText('200 / 200'));

  fireEvent.click(getByText('Tudo carregado!'));
  expect(queryByText('Carregar mais')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeFalsy();
  expect(getByText('200 Falhas'));
  expect(getByText('200 / 200'));
});

it('should start with 20 pages loeaded then load 20 per click. Maximum allowed should be 43. Sucessos text', () => {
  const page = 1;
  const handleClick = () => page + 1;
  const { getByText, queryByText, queryByTestId } = render(
    <Pagination
      paginationDescription="Sucessos"
      buttonEverythingLoadedLabel="Tudo carregado!"
      buttonLoadMoreLabel="Carregar mais"
      size={43}
      page={page}
      lenghtPerPage={20}
      onLoadmore={handleClick}
    />
  );

  expect(queryByText('Tudo carregado!')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeTruthy();
  expect(getByText('20 Sucessos'));
  expect(getByText('20 / 43'));

  fireEvent.click(getByText('Carregar mais'));
  expect(queryByText('Tudo carregado!')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeTruthy();
  expect(getByText('40 Sucessos'));
  expect(getByText('40 / 43'));

  fireEvent.click(getByText('Carregar mais'));
  expect(queryByText('Tudo carregado!')).toBeTruthy();
  expect(queryByTestId('icon-arrow-down')).toBeFalsy();
  expect(getByText('43 Sucessos'));
  expect(getByText('43 / 43'));

  fireEvent.click(getByText('Tudo carregado!'));
  expect(queryByText('Carregar mais')).toBeFalsy();
  expect(queryByTestId('icon-arrow-down')).toBeFalsy();
  expect(getByText('43 Sucessos'));
  expect(getByText('43 / 43'));
});
