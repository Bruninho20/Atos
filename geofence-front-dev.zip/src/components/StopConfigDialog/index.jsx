import React, { FC, useState, useEffect, useContext } from 'react'
import axios from 'axios'
import { DatePicker, Dialog, Notification, Slider } from 'rio-uikit'
import { ModalForm } from './styled'
import moment from 'moment'
import DashboardContext from 'core/DashboardContext'

const AddressDialog = ({
  title,
  isOpen,
  onClose,
  getLatLng,
  type,
  handleSaveStopManual,
  geolocation
}) => {
  const { allStopsContext, setAllStopsContext } = useContext(DashboardContext)
  const [limitMeters, setLimitMeters] = useState(0)
  const [postalCode, setPostalCode] = useState('')
  const [address, setAddress] = useState('')
  const [number, setNumber] = useState('')
  const [state, setState] = useState('')
  const [city, setCity] = useState('')
  const [neighborhood, setNeighborhood] = useState('')
  const [country, setCountry] = useState('')
  const [categoryStop, setCategoryStop] = useState('')
  const [stayTimeStop, setStayTimeStop] = useState('')
  const [nameStop, setNameStop] = useState('')
  const [dataToStop, setDataToStop] = useState()
  const [cep, setCep] = useState('')

  useEffect(() => {
    if (type === 'stopsSidesheet') {
      setStayTimeStop('')
      setLimitMeters(0)
      setPostalCode('')
      setAddress('')
      setState('')
      setCep('')
      setCountry('')
      setCity('')
      setNeighborhood('')
      setNumber('')
    }
  }, [isOpen])

  const cloneObject = (object) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  console.log(stayTimeStop, 'stayTimeStop')

  const handleAddStopsManual = () => {
    if (dataToStop) {
      if (nameStop === '' || categoryStop === '' || stayTimeStop === 'Invalid date' || stayTimeStop === '' ) {
        Notification.error('É necessario preencher todos os campos')
      } else {

        let cloneAllStops = cloneObject(allStopsContext)

        const body = {
          name: nameStop,
          category: categoryStop,
          rangeLimitMeters: limitMeters,
          type: 'STOPOVER',
          stayTime: moment(stayTimeStop).format('HH:mm'),
          position: {
            lat: dataToStop?.position.lat,
            lng: dataToStop?.position.lng,
            address: dataToStop?.address,
          }
        }

        cloneAllStops.push(body)

        setAllStopsContext(cloneAllStops)

        handleSaveStopManual(body)
        getLatLng(body, `${type}`, geolocation?.points)
        setStayTimeStop('')
        setLimitMeters(0)
        setPostalCode('')
        setAddress('')
        setState('')
        setCep('')
        setCountry('')
        setCity('')
        setNeighborhood('')
        onClose()
        setNumber('')
      }


    } else {
      Notification.error('É necessario preencher todos os campos')
      return
    }


  }

  const handleCep = (e) => {
    setCep(e)
    const cep = e?.replace(/[^0-9]/g, '')

    if (cep?.length !== 8) {
      return
    }

    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(res => res.json())
      .then(data => {
        setPostalCode(data.cep)
        setAddress(data.logradouro)
        setState(data.uf)
        setCountry(data.pais)
        setCity(data.localidade)
        setNeighborhood(data.bairro)
      })
  }

  const handleGetParametersRoute = () => {
    axios
      .get(
        `https://geocode.search.hereapi.com/v1/geocode?q=${number}+${address}%2C+${postalCode}+${state}%2C+${country}&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result) => {
        setDataToStop(result.data.items[0])
      })
  }

  const handleGetAddressFromGeolocation = () => {
    axios
      .get(
        `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${geolocation?.position?.lat},${geolocation?.position?.lng}&lang=en-US&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result) => {
        setCep(result?.data?.items[0]?.address?.postalCode)
        setPostalCode(result?.data?.items[0]?.address?.postalCode)
        setAddress(result?.data?.items[0]?.address?.street)
        setState(result?.data?.items[0]?.address?.stateCode)
        setNumber(result?.data?.items[0]?.address?.houseNumber)
        setCity(result?.data?.items[0]?.address?.city)
        setNeighborhood(result?.data?.items[0]?.address?.district)
      })
  }

  console.log(geolocation, 'geolocation')

  useEffect(() => {
    handleGetAddressFromGeolocation()
  }, [geolocation, isOpen])

  useEffect(() => {
    handleGetParametersRoute()
  }, [number, limitMeters, stayTimeStop])

  const formatCep = (cpf) => {
    return cpf
      .replace(/\D/g, '')
      .replace(/[^0-9]/g, '')
      .replace(/(\d{5})(\d{3})/, '$1-$2')
  }

  const handleSaveClose = () => {
    setStayTimeStop('')
    setLimitMeters(0)
    setPostalCode('')
    setAddress('')
    setState('')
    setCountry('')
    setCep('')
    setCity('')
    setNeighborhood('')
    onClose()
    setNumber('')
  }

  const handleOnCloseButton = () => {
    setStayTimeStop('')
    setLimitMeters(0)
    setPostalCode('')
    setAddress('')
    setState('')
    setCep('')
    setCountry('')
    setCity('')
    setNeighborhood('')
    onClose()
    setCep('')
    setNumber('')
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={title}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>
                <div className='row g-3'>
                  <div className='col-md-7'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Nome Parada</span>
                    <input
                      id='stopName'
                      type='text'
                      name='stopName'
                      className='form-control'
                      onChange={e => setNameStop(e.target.value)}
                    />
                  </div>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Categoria</span>
                    <div className={'input-group'}>
                      <select
                        className='form-control'
                        id='exampleFormControlSelect1'
                        // value={typeStopRecent}
                        onChange={(e) => setCategoryStop(e.target.value)}>
                        <option>Selecione</option>
                        <option value='DEALER'>DEALER</option>
                        <option value='LUNCH_REST'>ALMOÇO / DESCANSO</option>
                        <option value='END_OF_DAY'>FIM DE JORNADA DE TRABALHO</option>
                        <option value='LOAD_UNLOAD'>CARGA / DESCARGA</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className='row g-3'>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>CEP</span>
                    <input
                      value={cep}
                      autoComplete='nope'
                      onChange={(e) => handleCep(formatCep(e.target.value))}
                      maxLength={9}
                      id='cpf'
                      type='text'
                      name='cep'
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-6'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Endereço</span>
                    <input
                      value={address}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Número</span>
                    <input
                      value={number}
                      autoComplete='nope'
                      onChange={e => setNumber(e.target.value)}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
                <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Bairro</span>
                    <input
                      value={neighborhood}
                      autoComplete='nope'
                      onBlur={(e) => handleCep(e)}
                      maxLength={20}
                      id='cpf'
                      type='text'
                      name='cep'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Cidade</span>
                    <input
                      value={city}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Estado</span>
                    <input
                      value={state}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
                <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-6' style={{ marginTop: 12 }}>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Raio</span>
                    <Slider
                      value={limitMeters}
                      onDragEnd={(e) => {
                        setLimitMeters(e)
                      }}
                      className='margin-bottom-40'
                      minValue={0}
                      maxValue={2000}
                      step={5}
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Distância</span>
                    <div className={'input-group'}>
                      <input
                        type='text'
                        defaultValue={0}
                        value={limitMeters}
                        onChange={(e) => setLimitMeters(e.target.value)}
                        className='form-control'
                        id='first'
                      />
                      <span className={'input-group-addon'}>
                        <span aria-hidden={'true'}>m</span>
                      </span>
                    </div>
                  </div>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Tempo de Permanência</span>
                    <DatePicker dateFormat={false} onChange={(e) => setStayTimeStop(e)} />
                  </div>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={handleSaveClose}>
              Cancelar
            </button>
            <button type='button' className='btn btn-primary' onClick={handleAddStopsManual}>
              Salvar
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={handleOnCloseButton}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddressDialog
