package cloud.rio.latam_routefence.infrastructure.consumedapi.drivers

import cloud.rio.latam_routefence.auth.InternalAuthResponse
import cloud.rio.latam_routefence.auth.InternalToken
import cloud.rio.latam_routefence.infrastructure.consumedapi.base.BaseAPIClient
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.stereotype.Component
import org.springframework.web.client.RestTemplate
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.servlet.http.HttpServletRequest

@Component
class DriverApiClient(private val restTemplate: RestTemplate, request: HttpServletRequest): BaseAPIClient(request) {
    companion object {
        private const val URL_DRIVER_BASE = "https://api.drivers.rio.cloud/drivers"
    }

    fun listDriver(request: HttpServletRequest): DriversDTO? {
        return restTemplate.exchange(
            createUrl(),
            HttpMethod.GET,
            HttpEntity("parameters", getHeaders()),
            DriversDTO::class.java
        ).body
    }

    fun getByIdentification(driverIdentification: String, accountId: String, token: InternalAuthResponse? = null): DriversDTO? {
        var internalToken: InternalToken? = null

        if(token != null){
            internalToken = InternalToken(token, accountId)
        }

        val header = if(token == null) {getHeaders()} else{
            if (internalToken != null) {
                createInternalAuthHeader(internalToken)
            }
            else{
                getHeaders()
            }
        }

        return restTemplate.exchange(
            createUrl(UrlParameters(identification = driverIdentification, account_id = accountId)),
            HttpMethod.GET,
            HttpEntity("parameters", header),
            DriversDTO::class.java
        ).body
    }

    private fun createUrl(params: UrlParameters): String {
        return createUrl(
            params.identification,
            params.embed,
            params.account_id,
            params.identification_type
        )
    }

    /**
     * Cria a url com parâmetros configuráveis, a fim de controlar a quantidade de dados trafegados na rede
     * @param identification UUID driverId
     * @param embed comma separeted [identifications, tags]
     * @param account_id UUID accountId
     * @param identification_type country-specific-driver-license | rio-driver-identification
     */
    private fun createUrl(
        identification: String? = null,
        embed: String? = null,
        account_id: String? = AccountContext.get(),
        identification_type: String? = null
    ): String {
        val paramList = mutableListOf<String>()
        identification?.let { paramList.add("identification=$it") }
        account_id?.let { paramList.add("account_id=$it") }
        embed?.let { paramList.add("embed=$it") }
        identification_type?.let { paramList.add("identification_type=$it") }

        var query = ""
        paramList.forEach {
            query += if (query.isNotEmpty()) "&$it" else "?$it"
        }

        return "$URL_DRIVER_BASE${query}"
    }
}

data class UrlParameters(
    var identification: String? = null,
    var embed: String? = null,
    var account_id: String? = null,
    var identification_type: String? = null
)