package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Place(
    @JsonProperty("type") val type: String?,
    @JsonProperty("location") val location: Location?,
    @JsonProperty("originalLocation") val originalLocation: Location?
)