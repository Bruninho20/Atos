package routefence_common.cloud.rio.latam_routefence.domain.bo

import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum

data class TrafficViolationBO(
    val type: InfringementTypeEnum,
    val note: String?
){
    override fun toString(): String {
        return "type: $type, note: $note"
    }
}