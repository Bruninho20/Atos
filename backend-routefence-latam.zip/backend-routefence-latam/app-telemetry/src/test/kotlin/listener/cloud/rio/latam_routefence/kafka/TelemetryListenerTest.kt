package listener.cloud.rio.latam_routefence.kafka

import listener.cloud.rio.latam_routefence.TestBase
import listener.cloud.rio.latam_routefence.kafka.Topics.Companion.ASSET_IOTEVENT_TOPIC
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class TelemetryListenerTest : TestBase() {

    @Test
    fun `Send message state`() {

        for (i in 1..10) {

            val message = "{\n" +
                    "    \"asset_id\": \"507e051f-2f87-47ab-af7d-b5159bcec63a\",\n" +
                    "    \"account_id\": \"58d21607-1dd6-4aaf-8f4b-4e2ae409b323\",\n" +
                    "    \"device_id\": \"8f342a69-c62c-4e16-8492-b9d3ccd4c5e8\",\n" +
                    "    \"device_type\": \"tbm3\",\n" +
                    "    \"eid\": \"tbm:2006290119/67/1673488061258/24/state/42f9e401-4cd2-4a65-ab5e-35c6f0e56c41${i}\",\n" +
                    "    \"occurred_at\": \"2023-01-12T01:47:41.257Z\",\n" +
                    "    \"trigger\": \"timer\",\n" +
                    "    \"state\": {\n" +
                    "        \"mileage\": 226711.90625,\n" +
                    "        \"ignition_on\": true,\n" +
                    "        \"fuel_level\": 26.799999237060547,\n" +
                    "        \"engine_speed\": 600,\n" +
                    "        \"wheel_speed\": 0,\n" +
                    "        \"tacho_speed\": 0    }\n" +
                    "}"

            val future = kafkaTemplate.send(ASSET_IOTEVENT_TOPIC, message)
            future.addCallback({ result -> onSuccessSend(result) }, { ex -> onError(ex) })
        }
    }


    @Test
    fun `Send message pairing`() {
        val message = "{\n" +
                "    \"asset_id\":\"507e051f-2f87-47ab-af7d-b5159bcec63a\",\n" +
                "    \"account_id\":\"58d21607-1dd6-4aaf-8f4b-4e2ae409b323\",\n" +
                "    \"device_id\":\"1e118846-fe8e-40ea-be36-a6a0e1065171\",\n" +
                "    \"device_type\":\"tbm3\",\n" +
                "    \"driver_identification\":\"77856482928\",\n" +
                "    \"driver_identification_type\":\"country-specific-driver-license\",\n" +
                "    \"eid\":\"tbm:2110040123/72/1678386471761/35/d5e68762-786f-4d88-8ba8-5264f62ebd95\",\n" +
                "    \"occurred_at\":\"2023-03-18T18:27:51.717Z\",\n" +
                "    \"trigger\":\"driver_login\"\n" +
                "}"

        println("MSG_\t${message}")

        val future = kafkaTemplate.send(ASSET_IOTEVENT_TOPIC, message)
        future.addCallback({ result -> onSuccessSend(result) }, { ex -> onError(ex) })
    }

    @Test
    fun `Send message position`() {
        for (i in 1..10) {
            val message = "{\n" +
                    "    \"asset_id\": \"507e051f-2f87-47ab-af7d-b5159bcec63a\",\n" +
                    "    \"account_id\": \"58d21607-1dd6-4aaf-8f4b-4e2ae409b323\",\n" +
                    "    \"device_id\": \"8f342a69-c62c-4e16-8492-b9d3ccd4c5e8\",\n" +
                    "    \"device_type\": \"tbm3\",\n" +
                    "    \"eid\": \"tbm:2006290119/67/1673488061258/24/pos/42f9e401-4cd2-4a65-ab5e-35c6f0e56c41${i}\",\n" +
                    "    \"occurred_at\": \"2023-01-12T01:47:41Z\",\n" +
                    "    \"trigger\": \"timer\",\n" +
                    "    \"position\": {\n" +
                    "        \"latitude\": -23.541563034057617,\n" +
                    "        \"longitude\": -46.577117919921875,\n" +
                    "        \"altitude\": 710.2000122070312,\n" +
                    "        \"accuracy\": 8.300000190734863,\n" +
                    "        \"heading\": 0,\n" +
                    "        \"speed\": 0.0888959988951683    }\n" +
                    "}"


            val future = kafkaTemplate.send(ASSET_IOTEVENT_TOPIC, message)
            future.addCallback({ result -> onSuccessSend(result) }, { ex -> onError(ex) })
        }
    }
}