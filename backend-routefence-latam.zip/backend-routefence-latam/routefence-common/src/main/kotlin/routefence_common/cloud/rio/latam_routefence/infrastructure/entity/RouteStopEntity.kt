package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_ROUTE_HAS_STOP")
data class RouteStopEntity(
    @Id
    @Column(name = "ID")
    val id: String? = UUID.randomUUID().toString(),

    @ManyToOne
    @JoinColumn(name = "ROUTE_ID")
    val route: RouteEntity?,

    @ManyToOne
    @JoinColumn(name = "STOP_ID")
    val stop: StopEntity?,

    @Column(name = "RANGE_LIMIT_METERS")
    var rangeLimitMeters: Int?,

    @Column(name = "STAY_TIME")
    var stayTime: LocalDateTime?,

    @Column(name = "STOP_QUEUE_ORDER")
    var stopQueueOrder: Int,

    @Column(name = "STOP_TYPE")
    @Enumerated(EnumType.STRING)
    var type: StopTypeEnum?,

    @OneToMany(mappedBy = "routeStop", cascade = [CascadeType.ALL])
    val tripStop: List<TripStopEntity>?
)
