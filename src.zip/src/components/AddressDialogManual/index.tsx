import React, { FC, useState, useEffect, useContext } from 'react'
import axios from 'axios'
import { Dialog } from 'rio-uikit'
import { ModalForm } from './styled'
import DashboardContext from 'core/DashboardContext'

interface DialogtFaultCodesProps {
  title: string
  isOpen: boolean
  onClose: () => void
  type: string
  geolocation: any
  // onChange: () => void
}

const AddressDialog: FC<DialogtFaultCodesProps> = ({ title, isOpen, onClose, type, geolocation }) => {
  const {
    setOriginRouteContext,
    setDestinyRouteContext,
    originRouteContext,
    destinyRouteContext,
    originGeolocationContext,
    destinyGeolocationContext
  } = useContext(DashboardContext)
  const [postalCode, setPostalCode] = useState('')
  const [address, setAddress] = useState('')
  const [number, setNumber] = useState('')
  const [state, setState] = useState('')
  const [city, setCity] = useState('')
  const [neighborhood, setNeighborhood] = useState('')
  const [country, setCountry] = useState('BR')
  const [cep, setCep] = useState('')
  const [dataToSave, setDataToSave] = useState<any>()

  useEffect(() => {
    if (
      (originRouteContext?.lat && type === 'originRoute') ||
      (originRouteContext?.lat && type === 'originRouteSidesheet')
    ) {
      setDataToSave('')
      setCep(originRouteContext?.address?.postalCode)
      setPostalCode(originRouteContext?.address?.postalCode)
      setAddress(originRouteContext?.address?.street)
      setNumber(originRouteContext?.address?.houseNumber)
      setState(originRouteContext?.address?.state)
      setCity(originRouteContext?.address?.city)
      setNeighborhood(originRouteContext?.address?.district)
    } else if (
      (!originRouteContext?.lat && type === 'originRoute') ||
      (!destinyRouteContext?.lat && type === 'originRouteSidesheet')
    ) {
      setDataToSave('')
      setCep('')
      setPostalCode('')
      setAddress('')
      setNumber('')
      setState('')
      setCity('')
      setNeighborhood('')
    } else if (
      (!destinyRouteContext?.lat && type === 'destinyRoute') ||
      (!destinyRouteContext?.lat && type === 'destinyRouteSidesheet')
    ) {
      setDataToSave('')
      setCep('')
      setPostalCode('')
      setAddress('')
      setNumber('')
      setState('')
      setCity('')
      setNeighborhood('')
    } else if (
      (destinyRouteContext?.lat && type === 'destinyRoute') ||
      (destinyRouteContext?.lat && type === 'destinyRouteSidesheet')
    ) {
      setDataToSave('')
      setCep(destinyRouteContext?.address?.postalCode)
      setPostalCode(destinyRouteContext?.address?.postalCode)
      setAddress(destinyRouteContext?.address?.street)
      setNumber(destinyRouteContext?.address?.houseNumber)
      setState(destinyRouteContext?.address?.state)
      setCity(destinyRouteContext?.address?.city)
      setNeighborhood(destinyRouteContext?.address?.district)
    }
  }, [isOpen])

  const handleCep = (e: any) => {
    setCep(e)
    const cep = e?.replace(/[^0-9]/g, '')

    if (cep?.length !== 8) {
      return
    }

    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(res => res.json())
      .then(data => {
        setPostalCode(data.cep)
        setAddress(data.logradouro)
        setState(data.uf)
        setCountry(data.pais)
        setCity(data.localidade)
        setNeighborhood(data.bairro)
      })

    // const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'

    // fetch(`https://geocode.search.hereapi.com/v1/geocode?q=postalCode:${cep}&apiKey=${apiKey}`)
    //   .then(response => response.json())
    //   .then(data => {
    //     const location = data?.items[0]?.address
    //     setPostalCode(location?.postalCode)
    //     setAddress(location?.street)
    //     setState(location?.state)
    //     setCountry(location?.pais)
    //     setCity(location?.city)
    //     setNeighborhood(location.neighborhood)
    //     // console.log(location.label) // exibe o endereço completo
    //     // console.log(location.street) // exibe a rua
    //     // console.log(location.city) // exibe a cidade
    //     // console.log(location.postalCode) // exibe o código postal
    //     // console.log(location.countryName) // exibe o nome do país
    //   })
    //   .catch(error => {
    //     console.error(error)
    //   })
  }

  const handleGetParametersRoute = () => {
    axios
      .get(
        `https://geocode.search.hereapi.com/v1/geocode?q=${number}+${address}%2C+${postalCode}+${state}%2C+${country}&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result: any) => {
        if (type === 'destinyRouteSidesheet' || type === 'originRouteSidesheet') {
          setDataToSave(result.data.items[0])
        } else {
          setDataToSave({
            ...dataToSave,
            address: result.data.items[0]?.address,
            addressStop: result.data.items[0]?.address
          })
        }
      })
  }

  const handleGetAddressFromGeolocation = (data: any) => {
    axios
      .get(
        `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${data.lat},${data.lng}&lang=en-US&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result: any) => {
        setCep(result?.data?.items[0]?.address?.postalCode)
        setPostalCode(result?.data?.items[0]?.address?.postalCode)
        setAddress(result?.data?.items[0]?.address?.street)
        setState(result?.data?.items[0]?.address?.stateCode)
        setNumber(result?.data?.items[0]?.address?.houseNumber)
        setCity(result?.data?.items[0]?.address?.city)
        setNeighborhood(result?.data?.items[0]?.address?.district)
      })
  }

  console.log(dataToSave, 'DATA TO SAVE')

  useEffect(() => {
    if (type === 'originRoute') {
      handleGetAddressFromGeolocation(originGeolocationContext)
      setDataToSave({ ...dataToSave, lat: originGeolocationContext?.lat, lng: originGeolocationContext?.lng })
    } else if (type === 'destinyRoute') {
      handleGetAddressFromGeolocation(destinyGeolocationContext)
      setDataToSave({ ...dataToSave, lat: destinyGeolocationContext?.lat, lng: destinyGeolocationContext?.lng })
    }
  }, [geolocation])

  useEffect(() => {
    handleGetParametersRoute()
  }, [number])

  const formatCep = (cpf: string) => {
    return cpf
      .replace(/\D/g, '')
      .replace(/[^0-9]/g, '')
      .replace(/(\d{5})(\d{3})/, '$1-$2')
  }

  const handleSaveClose = () => {
    if (type === 'originRoute') {
      setOriginRouteContext({
        address: { ...dataToSave?.address, houseNumber: number },
        addressStop: { ...dataToSave?.address, houseNumber: number },
        lat: originGeolocationContext?.lat,
        lng: originGeolocationContext?.lng
      })
    } else if (type === 'destinyRoute') {
      setDestinyRouteContext({
        address: { ...dataToSave?.address, houseNumber: number },
        addressStop: { ...dataToSave?.address, houseNumber: number },
        lat: destinyGeolocationContext?.lat,
        lng: destinyGeolocationContext?.lng
      })
    } else if (type === 'originRouteSidesheet') {
      setOriginRouteContext({
        address: { ...dataToSave?.address, houseNumber: number },
        addressStop: { ...dataToSave?.address, houseNumber: number },
        lat: dataToSave?.position?.lat,
        lng: dataToSave?.position?.lng
      })
    } else if (type === 'destinyRouteSidesheet') {
      setDestinyRouteContext({
        address: { ...dataToSave?.address, houseNumber: number },
        addressStop: { ...dataToSave?.address, houseNumber: number },
        lat: dataToSave?.position?.lat,
        lng: dataToSave?.position?.lng
      })
    }
    setDataToSave('')
    onClose()
    // setCep('')
  }

  const handleOnCloseButton = () => {
    onClose()
    setCep('')
    setPostalCode('')
    setAddress('')
    setNumber('')
    setState('')
    setCity('')
    setNeighborhood('')
    setDataToSave('')
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={title}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>
                <div className='row g-3'>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>CEP</span>
                    <input
                      value={cep}
                      autoComplete='nope'
                      onChange={(e: any) => handleCep(formatCep(e.target.value))}
                      maxLength={9}
                      id='cpf'
                      type='text'
                      name='cep'
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-6'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Endereço</span>
                    <input
                      value={address}
                      autoComplete='nope'
                      onChange={e => setAddress(e.target.value)}
                      maxLength={60}
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Número</span>
                    <input
                      value={number}
                      autoComplete='nope'
                      onChange={e => setNumber(e.target.value)}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
                <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Bairro</span>
                    <input
                      value={neighborhood}
                      autoComplete='nope'
                      onChange={e => setNeighborhood(e.target.value)}
                      maxLength={20}
                      id='cpf'
                      type='text'
                      name='cep'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Cidade</span>
                    <input
                      value={city}
                      autoComplete='nope'
                      onChange={e => setCity(e.target.value)}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Estado</span>
                    <input
                      value={state}
                      autoComplete='nope'
                      onChange={e => setState(e.target.value)}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button
              type='button'
              style={{ marginRight: '10px' }}
              className='btn btn-default'
              onClick={handleOnCloseButton}>
              Cancelar
            </button>
            <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
              Salvar
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={handleOnCloseButton}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddressDialog
