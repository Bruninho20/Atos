import styled from 'styled-components'
import metrics from 'core/assets/styles/metrics'

interface ProgressBarProps {
  percentage: number
}

export const PagerDescription = styled.p`
  font-size: ${metrics.fontSizeDefault};
  font-weight: bold;
  margin: 0;
`

export const PaginatioSection = styled.section`
  display: flex;
  text-align: center;
`

export const ProgressWrapper = styled.div`
  margin: 0 auto 0 auto;
  max-width: 150px;
`

export const ProgressBar = styled.div<ProgressBarProps>`
  width: ${({ percentage }) => percentage}%;
`

export const PaginationGlosary = styled.p`
  white-space: nowrap;
`

export const Pager = styled.div`
  width: 100%;
`
