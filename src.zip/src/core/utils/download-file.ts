export enum EDownloadFileType {
  CSV = 'text/csv',
  XLSX = 'application/vnd.ms-excel'
}

const getFileName = (fileName: string, downloadFileType: EDownloadFileType) => {
  switch (downloadFileType) {
    case EDownloadFileType.CSV:
      return `${fileName}.csv`
    case EDownloadFileType.XLSX:
      return `${fileName}.xlsx`
  }
}

export const downloadFile = (data: any, downloadFileType: EDownloadFileType, name = 'download') => {
  if (data) {
    const blob = new Blob([data], { type: downloadFileType })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.setAttribute('hidden', '')
    link.setAttribute('href', url)
    link.setAttribute('download', getFileName(name, downloadFileType))
    document.body.appendChild(link)
    link.click()
  }
}