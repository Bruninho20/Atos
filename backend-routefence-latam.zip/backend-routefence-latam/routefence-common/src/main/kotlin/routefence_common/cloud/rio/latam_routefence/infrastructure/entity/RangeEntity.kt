package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_RANGE")
data class RangeEntity (
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "TRAFFIC_CONDITIONS")
    var trafficConditions: Boolean? = null,

    @Column(name = "AVOID_TOLL")
    var avoidToll: Boolean? = null,

    @Column(name = "AVOID_ROAD")
    var avoidRoad: Boolean? = null,

    @Column(name = "IGNORE_TRAFFIC_RESTRICTIONS")
    var ignoreTrafficRestrictions: Boolean? = null
)