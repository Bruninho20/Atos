package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonManagedReference
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.Fetch
import org.hibernate.annotations.FetchMode
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import java.lang.StringBuilder
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_TRIP")
data class TripEntity(
    @Id
    @Column(name = "ID")
    val id: String? = UUID.randomUUID().toString(),

    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    var status: TripStatusEnum,

    @Column(name = "START_DATETIME")
    val startDateTime: LocalDateTime,

    @Column(name = "CREATED_AT")
    val createdAt: LocalDateTime? = LocalDateTime.now(),

    @Column(name = "DRIVER_ID")
    val driverId: String?,

    @Column(name = "ASSET_ID")
    val assetId: String,

    @Column(name = "DELETED_AT")
    var deletedAt: LocalDateTime? = null,

    @Column(name = "FINISHED_AT", )
    var finishedAt: LocalDateTime? = null,

    @Column(name = "STARTED_AT", )
    var startedAt: LocalDateTime? = null,

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ROUTE_ID", referencedColumnName = "ID")
    @JsonIgnore
    var route: RouteEntity,

    @JsonManagedReference
    @OneToMany(mappedBy = "trip", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    val infringements: List<InfringementEntity>? = emptyList(),

    override var accountId: String = ""
): AccountTenantEntity(accountId) {
    override fun hashCode(): Int {
        return Objects.hash(id)
    }

    override fun toString(): String {
        val sb = StringBuilder()
        sb.append("id: $id, ")
            .append("status: $status")
            .append("startDateTime: $startDateTime")
            .append("createdAt: ${createdAt.toString()}")
            .append("driverId: $driverId")
        return sb.toString()
    }
}