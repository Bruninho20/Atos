package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.SummaryApi
import cloud.rio.latam_routefence.domain.response.SummaryResponse
import cloud.rio.latam_routefence.services.SummaryService
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest

@RestController
class SummaryController(
    private val summaryService: SummaryService
) : SummaryApi {

    override fun getByTripId(id: String): SummaryResponse {
        return summaryService.getSummaryData(id)
    }
}