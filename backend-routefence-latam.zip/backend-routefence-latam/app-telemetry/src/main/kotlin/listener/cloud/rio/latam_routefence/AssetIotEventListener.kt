package listener.cloud.rio.latam_routefence

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import listener.cloud.rio.latam_routefence.kafka.Topics
import listener.cloud.rio.latam_routefence.services.AssetIotEventService
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.context.annotation.ComponentScan
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.messaging.handler.annotation.Payload
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.time.LocalDateTime
import java.time.OffsetDateTime

@ComponentScan
@EntityScan("routefence_common.cloud.rio.latam_routefence.infrastructure.entity")
@EnableAutoConfiguration
class AssetIotEventListener(
    private val assetIotEventService: AssetIotEventService
) {
    private val logger: Logger = LoggerFactory.getLogger(AssetIotEventListener::class.java)

    @Autowired
    private lateinit var objectMapper: ObjectMapper

    @KafkaListener(topics = [Topics.ASSET_IOTEVENT_TOPIC], groupId = Topics.AGGREGATION_GROUP_ID)
    fun consume(@Payload(required = false) message: String?) {
        if (!message.isNullOrEmpty()) {
            try {
//                println("KAFKA LISTENER [${LocalDateTime.now()}]: Received a kafka message on topic = $Topics || $message")

                val event = objectMapper.readValue<AssetIotEventMessage>(message)

//                só processa se a mensagem tiver no máximo 6h
                //if(event.occurredAt.isBefore(OffsetDateTime.now().minusHours(6))) return

                AccountContext.set(event.accountId)
                logger.info("KAFKA LISTENER [${LocalDateTime.now()}]: Received a kafka message on topic = $Topics || $message")

//                if(event.assetId.toString() != "507e051f-2f87-47ab-af7d-b5159bcec63a")
                assetIotEventService.save(event)
            } catch (e: Exception) {
                logger.info("Error while trying to deserialize/save this AssetIotEvent message: ${e.message} || ${e.cause} || $message")
            } finally {
                AccountContext.clear()
            }
        }
    }
}
