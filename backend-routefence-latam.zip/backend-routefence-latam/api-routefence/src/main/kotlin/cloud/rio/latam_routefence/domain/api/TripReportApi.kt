package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.TripResumeReportResponse


interface TripReportApi {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(produces = ["application/json"])
    fun getAllIdTripReport(
        tripId: String,
        @RequestParam(required = false, value = "orderBy") orderBy: String?,
        @RequestParam(required = false, value = "search") search: String?,
        @RequestParam(required = false, value = "page") page: Int?,
        @RequestParam(required = false, value = "pageSize") pageSize: Int?,
        @RequestParam(required = false, value = "status") status: TripStatusEnum?
    ): BaseCollectionResponse<TripResumeReportResponse>

    @PostMapping("/download/csv/{tripId}", produces = [MediaType.APPLICATION_OCTET_STREAM_VALUE])
    fun downloadCsv(
        @PathVariable tripId: String,
        @RequestParam(required = false, value = "orderBy") orderBy: String?,
        @RequestParam(required = false, value = "search") search: String?,
        @RequestParam(required = false, value = "status") status: TripStatusEnum?,
    ): ResponseEntity<ByteArray>


    @PostMapping("/download.xlsx/{tripId}" , produces = [MediaType.APPLICATION_OCTET_STREAM_VALUE])
    fun downloadXlsx(
        @PathVariable tripId: String,
        @RequestParam(required = false, value = "orderBy") orderBy: String?,
        @RequestParam(required = false, value = "search") search: String?,
        @RequestParam(required = false, value = "status") status: TripStatusEnum?,
    ): ResponseEntity<ByteArray>
}