import { useEffect, useState } from 'react';
import customBaseApi from 'core/providers/api';

export const useFetch = (initialUrl, initialData) => {
  const [data, setData] = useState(initialData);
  const [url, setUrl] = useState(initialUrl);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const { path, ...rest } = url;
      setError(false);
      setLoading(true);

      try {
        const res = await customBaseApi().request(path, rest);
        setData(res);
      } catch (error) {
        setError(true);
      } finally {
        setLoading(false);
      }
    };
    if (url) fetchData();
  }, [url]);

  const status = loading ? 'loading' : error ? 'error' : 'sucess';

  return { data, status, loading, error, setUrl };
};
