import React, { FC, useState, useEffect } from 'react'
import {
  AreaIconColumn,
  DateInfraction,
  Description,
  HeaderSecondCard,
  IntervalCard,
  Text,
  WrapperContent,
  WrapperSecondCard
} from './styled'
import moment from 'moment'
import axios from 'axios'
import {
  CardContent,
  HeaderFirstCard,
  WrapperFirstCard,
  Content1FirstCard,
  Content2FirstCard,
  BottomFirstCard,
  Card
} from './styled'
// import { DateTimeFilter } from 'components'
import { injectIntl, Intl } from 'react-intl'
// import { DEFAULT_LOCALE } from 'configuration/lang/lang'
// import { Period } from 'components/DateTimeFilter'
import { DatePicker } from 'rio-uikit'
import { Button } from 'components'
import { accessToken } from 'configuration/tokenHandling/accessToken'

interface PropsData {
  data: any
  intl: Intl
}

const TripDetails: FC<PropsData> = ({ data, intl }) => {
  const [historicData, setHistoricData] = useState<any>([])
  const [startEndAddress, setStartEndAddress] = useState<any>({})
  const [summaryData, setSummaryData] = useState<any>([])
  const [dateTime, setDateTime] = useState<any>({
    from: '',
    to: ''
  })

  useEffect(() => {
    if (data) {
      setDateTime({
        from: '',
        to: ''
      })
    }
  }, [data])

  const getAddressReverseGeocoding = async (start: any, end: any) => {
    const resStart = await axios.get(
      `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${start?.lat}%2C${start?.long}&lang=pt-BR&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
    )

    const resEnd = await axios.get(
      `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${end?.lat}%2C${end?.long}&lang=pt-BR&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
    )
    setStartEndAddress({
      start: {
        location: resStart?.data?.items[0],
        dateTime: start.occurred_at
      },
      end: {
        location: resEnd?.data?.items[0],
        dateTime: end.occurred_at
      }
    })
  }

  useEffect(() => {
    if (historicData?.locationData?.length >= '') {
      getAddressReverseGeocoding(
        historicData?.locationData[0],
        historicData?.locationData[historicData?.locationData?.length - 1]
      )
    }
  }, [historicData])

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)
  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  const getSummaryData = async () => {
    try {
      const res = await axios.get(`${baseURL}/summary/${data?.tripId}`, head)

      setSummaryData(res.data)
    } catch (error) {
      console.log(error)
    }
  }

  const getHistoricData = async () => {
    try {
      const res = await axios.get(`${baseURL}/history/${data?.tripId}`, head)
      setHistoricData(res.data)
    } catch (error) {
      console.log(error)
    }
  }

  console.log(dateTime, 'dateTime')
  console.log(historicData, 'historicData')

  useEffect(() => {
    if (data?.tripId) {
      getSummaryData()
      getHistoricData()
    }
  }, [data])

  const handleChangeDateTime = () => {
    // console.log(period, 'period')
    setDateTime('')

    const getHistoricData = async () => {
      try {
        const res = await axios.get(
          `${baseURL}/history/${data?.tripId}?startDateTime=${moment(dateTime?.from)
            .subtract(3, 'hours')
            .toISOString()}&endDateTime=${moment(dateTime?.to).subtract(3, 'hours').toISOString()}`,
          head
        )
        setHistoricData(res.data)
        console.log(res, 'RES NO HISTORIC')
      } catch (error) {
        console.log(error)
      }

      try {
        const res = await axios.get(
          `${baseURL}/summary/${data?.tripId}?startDateTime=${moment(dateTime?.from)
            .subtract(3, 'hours')
            .toISOString()}&endDateTime=${moment(dateTime?.to).subtract(3, 'hours').toISOString()}`,
          head
        )

        setSummaryData(res.data)
      } catch (error) {
        console.log(error)
      }
    }
    getHistoricData()
  }

  console.log(historicData, 'historic dat')
  console.log(summaryData, 'summary data')
  console.log(moment(historicData?.startedAt).format('DD/MM/yyyy HH:mm'), 'historicData?.startedAt')

  return (
    <WrapperContent>
      <CardContent style={{ borderRadius: 7 }}>
        <HeaderFirstCard>
          <span className='rioglyph rioglyph-start' style={{ fontSize: 26, color: '#878585' }}></span>
          <span style={{ fontSize: 20 }}>{historicData?.duration}</span>
          <span className='rioglyph rioglyph-finish' style={{ fontSize: 26, color: '#878585' }}></span>
        </HeaderFirstCard>
        <WrapperFirstCard>
          <Content1FirstCard>
            <span style={{ fontSize: 14 }}>
              <b>
                {`Início: ${
                  historicData?.startedAt === undefined || historicData?.startedAt === 'null'
                    ? ''
                    : moment(historicData?.startedAt).format('DD/MM/yyyy HH:mm')
                }`}
              </b>
            </span>
            <span style={{ fontSize: 14 }}>
              {data?.originRouteData?.address?.street === 'null'
                ? `${data?.originRouteData.lat}, ${data?.originRouteData.long}`
                : data?.originRouteData?.address?.label}
            </span>
          </Content1FirstCard>
          <AreaIconColumn>
            <span className='rioglyph rioglyph-arrow-right' style={{ fontSize: 30, color: '#878585' }}></span>
          </AreaIconColumn>
          <Content2FirstCard>
            <span style={{ fontSize: 14 }}>
              <b>
                {`Fim: ${
                  historicData?.finishedAt === undefined || historicData?.finishedAt === 'null'
                    ? ''
                    : moment(historicData?.finishedAt).format('DD/MM/yyyy HH:mm')
                }`}
              </b>
            </span>
            <span style={{ fontSize: 14, display: 'flex' }}>
              {data?.destinyRouteData?.address?.street === 'null'
                ? `${data?.destinyRouteData.lat}, ${data?.destinyRouteData.long}`
                : data?.destinyRouteData?.address?.label}
            </span>
          </Content2FirstCard>
        </WrapperFirstCard>
        <BottomFirstCard>
          <span style={{ fontSize: 12 }}>
            {`Ultima atualização: ${moment(data?.dateTimeLastPosition).format('DD/MM/yyyy HH:mm')}`}{' '}
          </span>
        </BottomFirstCard>
      </CardContent>
      <CardContent style={{ borderRadius: 7 }}>
        <HeaderSecondCard>
          <div style={{ display: 'flex', flexDirection: 'column', marginBottom: 20 }}>
            <div className='display-flex  gap-10 max-width-400 margin-bottom-10'>
              <div style={{ width: 170 }}>
                <label>De:</label>
                <DatePicker onChange={(e: any) => setDateTime({ ...dateTime, from: e })} clearableInput />
              </div>
              <div style={{ width: 170 }}>
                <label>Até:</label>
                <DatePicker onChange={(e: any) => setDateTime({ ...dateTime, to: e })} clearableInput />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', alignContent: 'center' }}>
              <Button onClick={() => handleChangeDateTime()} label={'Atualizar'} />
            </div>
          </div>
        </HeaderSecondCard>
        <WrapperSecondCard>
          <Card>
            <div
              style={{
                display: 'flex',
                flexDirection: 'row',
                width: '100%',
                padding: 10,
                height: 'auto',
                justifyContent: 'space-between'
              }}>
              <div style={{ width: '75%' }}>
                <span
                  className='rioglyph rioglyph-start text-size-h5'
                  style={{ color: '#d6d2d2', marginRight: 8 }}></span>
                <Description>Primeira posição no período consultado</Description>
              </div>
              <div style={{ width: '25%', display: 'flex', justifyContent: 'flex-end' }}>
                <DateInfraction>{moment(startEndAddress?.start?.dateTime).format('DD/MM/yyyy HH:mm')}</DateInfraction>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'row',
                width: '100%',
                padding: '0 10px',
                height: 'auto',
                marginTop: -10
              }}>
              <div style={{ width: '100%', display: 'flex', flexDirection: 'row', marginBottom: 15 }}>
                <div style={{ width: 40, height: '100%' }}>
                  <span
                    className='rioglyph rioglyph-map-marker text-size-h5'
                    style={{ color: '#d6d2d2', marginRight: 8 }}></span>
                </div>
                <Text>{startEndAddress?.start?.location?.address?.label}</Text>
              </div>
            </div>
          </Card>
          <IntervalCard>
            <span style={{ fontSize: 12 }}></span>
          </IntervalCard>
          <Card>
            <div
              style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
                width: '100%',
                padding: 10,
                height: 'auto'
              }}>
              <div style={{ width: '70%' }}>
                <span
                  className='rioglyph rioglyph-finish text-size-h5'
                  style={{ color: '#d6d2d2', marginRight: 8 }}></span>
                <Description>Última posição no período consultado</Description>
              </div>
              <div style={{ width: '30%', display: 'flex', justifyContent: 'flex-end' }}>
                <DateInfraction>{moment(startEndAddress?.end?.dateTime).format('DD/MM/yyyy HH:mm')}</DateInfraction>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'row',
                width: '100%',
                padding: '0 10px',
                height: 'auto',
                marginTop: -10
              }}>
              <div style={{ width: '100%', display: 'flex', flexDirection: 'row', marginBottom: 15 }}>
                <div style={{ width: 40, height: '100%' }}>
                  <span
                    className='rioglyph rioglyph-map-marker text-size-h5'
                    style={{ color: '#d6d2d2', marginRight: 8 }}></span>
                </div>
                <Text>{startEndAddress?.end?.location?.address?.label}</Text>
              </div>
            </div>
          </Card>
        </WrapperSecondCard>
      </CardContent>
    </WrapperContent>
  )
}

export default injectIntl(TripDetails)
