package cloud.rio.latam_routefence.infrastructure.mapper

import cloud.rio.latam_routefence.domain.response.TripResponse
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.TripRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

fun TripRequest.mapToEntity(routeEntity: RouteEntity): TripEntity {
    return TripEntity(
        id = this.id,
        driverId = this.driverId.toString(),
        assetId = this.assetId.toString(),
        route = routeEntity,
        infringements = null,
        status = TripStatusEnum.SCHEDULED,
        startDateTime = this.startDateTime.toLocalDateTime()
    )
}

fun TripRequest.mapToNewEntity(routeEntity: RouteEntity): TripEntity {
    return TripEntity(
        driverId = this.driverId.toString(),
        assetId = this.assetId.toString(),
        route = routeEntity,
        infringements = null,
        status = TripStatusEnum.SCHEDULED,
        startDateTime = this.startDateTime.toLocalDateTime()
    )
}

fun TripEntity.mapToResponse(): TripResponse {
    return TripResponse(
        id = this.id!!,
        driver = this.driverId,
        asset = this.assetId,
        route = this.route.mapToResponse(),
        infringements = this.infringements?.map { it.mapToResponse() },
        status = this.status,
        startDateTime = this.startDateTime.toString(),
        startedAt = this.startedAt.toString(),
        finishedAt = this.finishedAt.toString(),
        deletedAt = this.deletedAt.toString()
    )
}