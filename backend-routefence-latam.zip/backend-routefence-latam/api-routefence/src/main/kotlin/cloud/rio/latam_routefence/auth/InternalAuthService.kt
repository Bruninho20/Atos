package cloud.rio.latam_routefence.auth

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.util.LinkedMultiValueMap
import org.springframework.web.client.RestTemplate
import java.util.*
import javax.naming.AuthenticationException
import javax.transaction.Transactional


@Service
@Transactional
class InternalAuthService {

    @Autowired
    private lateinit var restTemplate: RestTemplate

    companion object {
        private const val LOG_PREFIX = "LOGGER 'InternalAuthService' ->"
        private const val URL = "https://auth.iam.rio.cloud/oauth/token"
        private const val CREDENTIALS = "66f42238-fb74-11ec-a382-784f43566792:bbjyeifqofwouqcrqmdsvvsxzm"
    }

    fun getAuthToken(): InternalAuthResponse {
        try {
            val response: ResponseEntity<InternalAuthResponse> = restTemplate.exchange(
                URL,
                HttpMethod.POST,
                HttpEntity(getFormBody(), createHeader()),
                InternalAuthResponse::class.java
            )
            val result = response.body!!
            println("$LOG_PREFIX token received!")
            return result
        } catch (ex: Exception) {
            println("$LOG_PREFIX Error getting token : ${ex.message}")
            throw AuthenticationException("Internal authentication failed with message: ${ex.message}")
        }
    }

    private fun createHeader(): HttpHeaders {
        val auth64 = String(Base64.getEncoder().encode(CREDENTIALS.toByteArray()))
        val headers = HttpHeaders()
        headers.add(HttpHeaders.AUTHORIZATION, "Basic $auth64")
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
        return headers
    }

    private fun getFormBody(): LinkedMultiValueMap<String, String> {
        val formBody = LinkedMultiValueMap<String, String>()
        formBody.add("grant_type", "client_credentials")
        return formBody
    }
}