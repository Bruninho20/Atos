package routefence_common.cloud.rio.latam_routefence.utils

import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.LoggerFactory
import routefence_common.cloud.rio.latam_routefence.domain.bo.BoundingBoxBO
import javax.persistence.AttributeConverter
import javax.persistence.Converter

@Converter(autoApply = true)
class AvoidAreaConverter : AttributeConverter<List<BoundingBoxBO>, String> {

    private val logger = LoggerFactory.getLogger(this.javaClass)
    private val objectMapper = ObjectMapper()

    override fun convertToDatabaseColumn(boundingBoxBO: List<BoundingBoxBO>?): String? {
        try {
            return if(boundingBoxBO == null){
                null
            }else{
                objectMapper.writeValueAsString(boundingBoxBO)
            }
        } catch (ex: JsonProcessingException) {
            logger.error(ex.localizedMessage)
        }
        return null
    }

    override fun convertToEntityAttribute(dbData: String?): List<BoundingBoxBO>? {
        try {
            return if(dbData == null || dbData == "null"){
                null
            }else{
                objectMapper.readValue(dbData, Array<BoundingBoxBO>::class.java).toList()
            }
        } catch (ex: JsonProcessingException) {
            logger.error(ex.localizedMessage)
        }
        return null
    }
}