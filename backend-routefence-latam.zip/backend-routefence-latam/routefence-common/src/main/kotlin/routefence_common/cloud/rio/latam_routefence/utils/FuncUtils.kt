package routefence_common.cloud.rio.latam_routefence.utils

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


fun String.timeFromString(): LocalDateTime {
    val time = this.split(":")
    val hour = time[0].toInt()
    val minute = time[1].toInt()

    return LocalDateTime.of(2000, 1, 1, hour, minute)
}

fun LocalDateTime?.timeFromDateTime() : String?{
    this?.let {
        return it.format(DateTimeFormatter.ofPattern("HH:mm"))
    }

    return null
}
