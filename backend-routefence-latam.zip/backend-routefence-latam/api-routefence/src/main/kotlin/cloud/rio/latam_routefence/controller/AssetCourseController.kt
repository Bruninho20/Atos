package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.AssetCourseApi
import cloud.rio.latam_routefence.domain.response.AssetCourseResponse
import cloud.rio.latam_routefence.services.AssetCourseService
import cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse
import org.springframework.web.bind.annotation.RestController

@RestController
class AssetCourseController(
    private val assetCourseService: AssetCourseService
): AssetCourseApi {
    override fun getAssetCourse(id: String): Collection<AssetCourseResponse> {
        return assetCourseService.findByTripId(id).map { it.mapToResponse() }
    }
}