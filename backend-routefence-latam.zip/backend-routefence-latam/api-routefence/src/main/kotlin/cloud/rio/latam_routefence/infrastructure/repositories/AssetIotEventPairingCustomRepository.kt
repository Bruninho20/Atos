package cloud.rio.latam_routefence.infrastructure.repositories

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventPairingEntity

interface AssetIotEventPairingCustomRepository{

    fun getAllPairingUnprocessed(): List<AssetIotEventPairingEntity>
}