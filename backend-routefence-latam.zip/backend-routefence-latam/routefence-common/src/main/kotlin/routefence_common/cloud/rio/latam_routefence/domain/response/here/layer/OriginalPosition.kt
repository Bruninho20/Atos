package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class OriginalPosition(
    @JsonProperty("latitude") var latitude: Double?,
    @JsonProperty("longitude") var longitude: Double?
)