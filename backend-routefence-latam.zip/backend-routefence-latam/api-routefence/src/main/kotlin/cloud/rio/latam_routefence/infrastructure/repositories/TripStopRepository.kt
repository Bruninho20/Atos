package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteStopEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripStopEntity
import java.util.*

interface TripStopRepository : JpaRepository<TripStopEntity, String> {

    @Query("SELECT ts FROM TripStopEntity ts WHERE ts.trip = :trip AND ts.routeStop = :routeStop")
    fun findByTripAndRouteStop(
        @Param("trip") trip: TripEntity,
        @Param("routeStop") routeStop: RouteStopEntity
    ): Optional<TripStopEntity>

}