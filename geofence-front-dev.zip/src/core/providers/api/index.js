import defaultsDeep from 'lodash/defaultsDeep'
import axios from 'axios'
import { onResponseError, validateRequest } from '../interceptor'

const CustomBaseApi = customAcessToken => {
  const BaseApi = axios.create({
    baseURL: process.env.REACT_APP_ENVIRONMENT_CONFIG,
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  })

  BaseApi.interceptors.request.use(validateRequest)
  BaseApi.interceptors.response.use(null, onResponseError)

  BaseApi.request = (path, options) => {
    const mergedOptions = defaultsDeep(options, customAcessToken)

    return BaseApi(path, mergedOptions).then(resp => resp.data)
  }

  return BaseApi
}

export default CustomBaseApi
