package routefence_common.cloud.rio.latam_routefence.domain.response

data class RangeResponse (
    var id: String? = null,
    var trafficConditions: String? = null,
    var avoidToll: String? = null,
    var avoidRoad: String? = null,
    var ignoreTrafficRestrictions: String? = null
)