import React, { FC, useState, useEffect, useCallback, useContext } from 'react'
import { Table } from 'react-bootstrap'
import { Dialog, DatePicker, Notification } from 'rio-uikit'
import moment from 'moment'
import { accessToken } from 'configuration/tokenHandling/accessToken'
// import { useForm } from 'react-hook-form'
import useDebounce from 'core/utils/use-debounce'
import { ModalForm, StyledTree } from './styled'
import useSWR from 'swr'
import { fetcherGet } from 'core/utils/fetch'
import axios from 'axios'
import { useHistory } from 'react-router-dom'
import isEmpty from 'lodash/fp/isEmpty'
import { createAssetsList, sanitizeAssetsList, sanitizeTagsList } from './helper'
import DashboardContext from 'core/DashboardContext'
import AutoComplete from 'components/AutoComplete'

const AddVehicleDialog = ({ isOpen, onClose, type, data, typeToTrip }) => {
  const history = useHistory()
  // const { setValue, register } = useForm()
  const { linkedVehiclesContext, setLinkedVehiclesContext, routeContext } = useContext(DashboardContext)
  const [buttonSaveName, setButtonSaveName] = useState('Salvar')
  const [linkedVehicles, setLinkedVehicles] = useState([])
  const [trucks, setTrucks] = useState()
  const [truckTags, setTruckTags] = useState({})
  const [tags1, setTags] = useState([])
  const [dateSelected, setDateSelected] = useState('')
  const [assets1, setAssets] = useState([])
  const [selectedTruckTagsIds, setSelectedTruckTagsIds] = useState([])
  const [selectedTruckIds, setSelectedTruckIds] = useState([])
  const [expandedTruckTags, setExpandedTruckTags] = useState([])
  const [vehicles, setVehicles] = useState([])
  const debouncedCallVehicles = useDebounce(selectedTruckIds, 1000)

  useEffect(() => {
    if (linkedVehiclesContext?.length >= 1) {
      setLinkedVehicles(linkedVehiclesContext)
    }
  }, [isOpen])

  const handleSelectedDriver = (e) => {
    if (linkedVehicles.flat()[e.index].driverSelected) {
      delete linkedVehicles.flat()[e.index].driverSelected
    }
    linkedVehicles.flat()[e.index].driverSelected = { name: e.name, id: e.id }
  }

  const handleStartDateTime = (e, index) => {
    const cloneStopArray = cloneObject(linkedVehicles.flat())
    if (cloneStopArray[index]?.startDateTime) {
      delete linkedVehicles.flat()[index].startDateTime
    }
    console.log(cloneStopArray, 'cloneStopArray')
    cloneStopArray[index].startDateTime = e
    setLinkedVehicles([cloneStopArray])
  }

  const defaultExpandedTruckTags = []

  const getTags = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const getAssets = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  console.log(data, 'DATA NO VEHICLES')

  const { data: tags, error: statusTags } = useSWR('https://api.tags.rio.cloud/tags', getTags)
  const { data: assets, error: statusAssets } = useSWR('https://api.assets.rio.cloud/assets?embed=(tags)', getAssets)



  useEffect(() => {
    async function initialData() {
      if (!statusAssets && !isEmpty(assets)) {
        setTrucks(sanitizeAssetsList(assets))
      }
      if (!statusTags && !isEmpty(tags)) {
        setTruckTags(sanitizeTagsList(tags))
      }

      setExpandedTruckTags(defaultExpandedTruckTags)
    }
    initialData()
  }, [assets, statusAssets, statusTags, tags, isOpen])

  useEffect(() => {
    if (debouncedCallVehicles) {
      getData()
    }
  }, [debouncedCallVehicles])

  const getData = useCallback(() => {
    const tags = selectedTruckTagsIds.filter((item) => item !== 'empty')

    setTags(tags)
    setAssets(selectedTruckIds)
  }, [selectedTruckIds, selectedTruckTagsIds])

  const handleSelectTruck = ({ items, groups }) => {
    const assetsList = createAssetsList({ items, groups, trucks })
    setSelectedTruckIds(assetsList)
    setSelectedTruckTagsIds(groups)
  }

  const handleExpandTruckGroups = (expandedTruckGroups) => {
    setExpandedTruckTags(expandedTruckGroups)
  }

  const getDrivers = async (url) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  console.log(linkedVehiclesContext, 'linkedVehiclesContext')
  console.log(linkedVehicles, 'LINKED VEHICLES')

  const { data: drivers } = useSWR('https://api.geo.latam-maintenance.rio.cloud/rio-routefence/driver', getDrivers)

  useEffect(() => {
    if (typeToTrip === '/resume-edit') {
      setLinkedVehicles([[{
        id: data?.assetData?.id,
        tripId: data?.tripId,
        name: data?.assetData?.name,
        driverSelected: {
          name: data?.driver,
          id: data?.driverData?.id
        },
        startDateTime: `${data?.start_datetime?.split('/')[2].slice(0, 4)}-${data?.start_datetime?.split('/')[1].slice(0, 2)}-${data?.start_datetime?.split('/')[0].slice(0, 2)}T${data?.start_datetime?.split(' ')[1]}:00.000Z`
      }]])
    }
  }, [isOpen])

  const handleAddVehicle = () => {
    const addDates = trucks?.map(item => {
      return {
        ...item,
        startDateTime: dateSelected
      }
    })

    const selectedTrucks = addDates?.filter(item => selectedTruckIds?.includes(item.id))

    if (typeToTrip === '/resume-edit' && linkedVehicles.length >= 1 || typeToTrip === '/resume-edit' && selectedTrucks?.length > 1) {
      Notification.error('Não é possivel adicionar mais de um veículo')
      return
    }
    setLinkedVehicles([...linkedVehicles, selectedTrucks])
    setButtonSaveName('Salvar')
  }

  const handleDeleteVehicleRow = (index) => {
    const cloneStopArray = cloneObject(linkedVehicles.flat())
    cloneStopArray.splice(index, 1)
    setLinkedVehicles(cloneStopArray)
    setVehicles(cloneStopArray)
  }

  const handleClose = () => {
    setLinkedVehicles([])
    setVehicles([])
    setSelectedTruckIds([])
    setSelectedTruckTagsIds([])
    setTags([])
    setAssets([])
    setTruckTags([])
    setDateSelected('')
    onClose()
  }

  const cloneObject = (object) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  const handleSaveClose = async () => {

    const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

    const customAcessToken = accessToken.getAccessToken()
    console.log(customAcessToken)

    var head = {
      headers: {
        Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
      }
    }

    const verifyDate = linkedVehicles?.flat()?.filter(item => item.startDateTime === "")


    if (linkedVehicles?.flat()?.length < 1) {
      Notification.error('É necessario selecionar um veículo')
    }
    else if (verifyDate?.length >= 1) {
      Notification.error('É necessario inserir uma data')
    }
    else {
      if (type === 'linkVehicleOut' && typeToTrip !== '/resume-edit') {
        try {
          const bodyToLink = {
            linkedVehicles: linkedVehicles?.flat()?.map((value) => {
              return {
                assetId: value?.id,
                driverId: value?.driverSelected?.id,
                startDateTime: moment(value.startDateTime).toISOString(),
                routeId: data?.id
              }
            })
          }

          const res = await axios.post(`${baseURL}/trips/`, bodyToLink.linkedVehicles, head)
          if (res.status === 200 || res.status === 201) {
            Notification.success('Veículo vinculado com sucesso')
            history.push(`/resume`)
          } else {
            Notification.error('Houve um erro ao vincular o veículo')
          }
        } catch (error) {
          console.log(error, 'error')
        }
      } if (typeToTrip === '/resume-edit') {
        alert('bateu aqui')
        try {
          console.log(linkedVehicles, 'linkedVehicles')
          const bodyTrip = {
            assetId: linkedVehicles[0][0]?.id,
            driverId: linkedVehicles[0][0]?.driverSelected?.id,
            id: data.tripId,
            routeId: routeContext.id,
            startDateTime: moment(linkedVehicles[0][0]?.startDateTime).subtract(3, 'hours').toISOString()
          }

          console.log(bodyTrip, 'BODYTOSAVE')

          const res = await axios.put(`${baseURL}/trips/${data.tripId}`, bodyTrip, head)
          console.log(res, 'res')
          if (res.status === 200 || res.status === 201) {
            Notification.success('Veículo editado com sucesso')
            history.push(`/resume`)
          } else {
            Notification.error('Houve um erro ao editar o veículo')
          }
        } catch (error) {
          console.log(error, 'error')
        }
      } else {

        let cloneLinkedVehicles = cloneObject(linkedVehiclesContext)
        linkedVehicles.flat().forEach(function (element) {
          cloneLinkedVehicles.push(element);
        });
        setLinkedVehiclesContext(linkedVehicles.flat())
      }
      setLinkedVehicles([])
      setVehicles([])
      setSelectedTruckIds([])
      setSelectedTruckTagsIds([])
      setTags([])
      setAssets([])
      setTruckTags([])
      setDateSelected('')
      onClose()
    }
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={typeToTrip === '/resume-edit' ? 'Editar veículo da viagem' : 'Vincular veículos a essa rota ?'}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>
                {truckTags && trucks && (
                  <>
                    <div className='row g-3' style={{ maxHeight: 300, overflow: 'scroll', marginTop: -30 }}>
                      <div className='col-md-12'>
                        <StyledTree
                          groups={truckTags}
                          items={trucks}
                          expandedGroups={expandedTruckTags}
                          onExpandGroupsChange={handleExpandTruckGroups}
                          selectedGroups={selectedTruckTagsIds}
                          selectedItems={selectedTruckIds}
                          onSelectionChange={handleSelectTruck}
                          searchPlaceholder={'Buscar'}
                          hasMultiselect={true}
                        />
                      </div>
                    </div>
                    <div className='row g-2'>
                      <div className='col-md-9' style={{ marginTop: 28 }}>
                        <DatePicker
                          value={dateSelected}
                          onChange={(e) => setDateSelected(moment(new Date(e)))}
                        // inputProps={{ placeholder: 'Select Date' }}
                        />
                      </div>
                      <div className='col-md-3' style={{ marginTop: 10 }}>
                        <button
                          type='button'
                          style={{ marginTop: '18px', width: '100%' }}
                          className='btn btn-default'
                          onClick={handleAddVehicle}>
                          Adicionar
                        </button>
                      </div>
                    </div>
                  </>
                )}
                <div style={{ marginTop: 5, height: 280, maxHeight: 400, overflow: 'scroll' }}>
                  <Table striped bordered hover variant='dark'>
                    <thead style={{ border: '1px solid' }}>
                      <tr>
                        <th style={{ fontSize: 14, fontWeight: 'bold' }}>Veículo</th>
                        <th style={{ fontSize: 14, fontWeight: 'bold' }}>Motorista</th>
                      </tr>
                    </thead>
                    <tbody>
                      {linkedVehicles &&
                        linkedVehicles?.flat()?.map((item, index) => {
                          return (
                            <tr>
                              <td style={{ fontSize: 14, width: 220 }}>{item.name}</td>
                              <td style={{ width: 300 }}>
                                <AutoComplete
                                  assetId={item.assetId}
                                  drivers={drivers}
                                  setDriver={(e) =>
                                    handleSelectedDriver({
                                      index,
                                      name: e.display_name,
                                      id: e.id
                                    })}
                                  data={item.driverSelected?.name}
                                />
                                {/* <select
                                  style={{ width: 150 }}
                                  placeholder='Selecione o motorista'
                                  className='form-control'
                                  id='exampleFormControlSelect1'
                                  value={item?.driverSelected?.name}
                                  onChange={(e) =>
                                    handleSelectedDriver({
                                      index,
                                      name: e.target?.value?.split('/')[0].trim(),
                                      id: e.target?.value?.split('/')[1].trim()
                                    })
                                  }>
                                  {item.driverSelected?.name ? (
                                    <option>{item.driverSelected?.name}</option>
                                  ) : (
                                    <option>Selecione o motorista</option>
                                  )}

                                  {drivers?.map((value) => {
                                    const driverData = `${value.display_name} / ${value.id}`
                                    return <option value={driverData}>{value.display_name}</option>
                                  })}
                                </select> */}
                              </td>
                              <td style={{ width: 200 }}>
                                <DatePicker
                                  value={
                                    item.startDateTime ? moment(item.startDateTime).add(3, 'hours').format('DD/MM/yyyy HH:mm') : ''
                                  }
                                  onChange={(e) => handleStartDateTime(moment(new Date(e)).toISOString(), index)}
                                />
                              </td>
                              <td>
                                <span
                                  style={{ cursor: 'pointer', width: 40 }}
                                  onClick={() => handleDeleteVehicleRow(index)}
                                  className={'rioglyph rioglyph-trash'}
                                  aria-hidden={'true'}></span>
                              </td>
                            </tr>
                          )
                        })}
                    </tbody>
                  </Table>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={handleClose}>
              Cancelar
            </button>
            <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
              {buttonSaveName}
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={onClose}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddVehicleDialog
