package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_STOP_CHECK")
data class TripStopEntity(
    @Id
    @Column(name = "ID")
    val id: String? = UUID.randomUUID().toString(),

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ROUTE_HAS_STOP_ID", referencedColumnName = "ID")
    val routeStop: RouteStopEntity?,

    @JoinColumn(name = "TRIP_ID", referencedColumnName = "ID")
    @OneToOne(cascade = [CascadeType.ALL])
    val trip: TripEntity?,

    @Column(name = "CHECK_IN")
    var checkIn: LocalDateTime?,

    @Column(name = "CHECK_OUT")
    var checkOut: LocalDateTime?
)