package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.util.*
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Id
import javax.persistence.Table

@Entity
@DynamicUpdate
@Table(name = "TB_VEHICLE_DATA")
data class VehicleDataEntity(

    @Id
    @Column(name = "ID")
    val id: String? = UUID.randomUUID().toString(),

    @Column(name = "MODEL")
    var model: String? = null,

    @Column(name = "COMMERCIAL_NAME")
    var commercialName: String? = null,

    @Column(name = "M_M_V")
    var m_m_v: String? = null,

    @Column(name = "RENAVAM_CODE")
    var renavamCode: String? = null,

    @Column(name = "MODEL_CODES")
    var modelCodes: String? = null,

    @Column(name = "POSITION_1_2_3")
    var geoAndAreaAndManufacturerCode: String? = null,

    @Column(name = "POSITION_4")
    var bodyworkCode: String? = null,

    @Column(name = "POSITION_5")
    var engineCode: String? = null,

    @Column(name = "MOTOR")
    var motor: String? = null,

    @Column(name = "POSITION_6")
    var safetySystemCode: String? = null,

    @Column(name = "SECURITY_SYSTEM_MIN")
    var securitySystemMin: String? = null,

    @Column(name = "SECURITY_SYSTEM_MAX")
    var securitySystemMax: String? = null,
    @Column(name = "POSITION_7_8")
    var vehicleClassCode: String? = null,

    @Column(name = "POSITION_9")
    var controlDigit: String? = null,

    @Column(name = "POSITION_10")
    var modelYear: String? = null,

    @Column(name = "POSITION_11")
    var factoryCode: String? = null,

    @Column(name = "POSITION_12_A_17")
    var sequentialProd: String? = null,

    @Column(name = "PBT_REGULATORY_WEIGHT_KG")
    var regulatoryWeightKg: String? = null,

    @Column(name = "TECHNICAL_WEIGHT_KG")
    var technicalWeightKg: String? = null,

    @Column(name = "FIRST_AXLE_KG")
    var firstAxleKg: String? = null,

    @Column(name = "SECOND_AXLE_KG")
    var secondAxleKg: String? = null,

    @Column(name = "THIRD_AXLE_KG")
    var thirdAxleKg: String? = null,

    @Column(name = "FOURTH_AXLE_KG")
    var fourthAxleKg: String? = null,

    @Column(name = "PBTC")
    var pbtc: String? = null,

    @Column(name = "CMT")
    var cmt: String? = null,

    @Column(name = "WHEELBASE")
    var wheelbase: String,

    @Column(name = "ISSUE_TYPE")
    var issueType: String
)