package listener.cloud.rio.latam_routefence.services

import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.PointOfInterestEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage

@Service
class StartOfTrip (private val tripService: TripService): IInfringible {

    override fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest? {
        if (trip.status == TripStatusEnum.SCHEDULED||trip.status == TripStatusEnum.INTERRUPTED||trip.status == TripStatusEnum.DELAYED) {
            if (poiList?.firstOrNull { it.type == PointOfInterestEnum.ORIGIN }?.type == PointOfInterestEnum.ORIGIN) {
                val assetIgnition = asset.state?.ignitionOn
                val speed = asset.position?.speed

                if (speed != null) {
                    if (assetIgnition ==true&& speed >= 20.0 ){
                        tripService.startedTrip(trip.id)
                    }
                }
            }
        }
        return null
    }
}
