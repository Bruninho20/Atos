package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse
import javax.validation.Valid

@RequestMapping("/routes")
interface RouteApi: RoutefenceBaseApi {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(produces = ["application/json"])
    fun saveRoute(@RequestBody route: RouteRequest): RouteResponse

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/{id}", produces = ["application/json"])
    fun getOneRoute(@PathVariable(value = "id") id: String): RouteResponse

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(produces = ["application/json"])
    fun getAll(
        @RequestParam(required = false, defaultValue = "0") page: Int,
        @RequestParam(required = false, defaultValue = "10") pageSize: Int,
        @RequestParam(required = false, defaultValue = "routeName") orderBy: String,
        @RequestParam(name = "routeName", required = false) routeName: String?
    ): BaseCollectionResponse<RouteResponse>

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @PutMapping("/{id}", produces = ["application/json"])
    fun updateRoute(@PathVariable(value = "id") id: String, @RequestBody routeRequest: @Valid RouteRequest): RouteResponse

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @DeleteMapping("/{id}", produces = ["application/json"])
    @ResponseStatus(HttpStatus.OK)
    fun delete(@PathVariable id: String)
}
