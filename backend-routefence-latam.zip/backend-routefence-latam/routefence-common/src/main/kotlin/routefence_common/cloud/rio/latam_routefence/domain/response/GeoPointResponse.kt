package routefence_common.cloud.rio.latam_routefence.domain.response

import com.fasterxml.jackson.annotation.JsonProperty

data class GeoPointResponse (
    var id: String? = null,
    var lat: Float? = 0F,
    var lng: Float? = 0F,

    @JsonProperty("addressStop")
    var address: AddressResponse? = null
)