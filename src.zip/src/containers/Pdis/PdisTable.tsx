import React, { FC, useEffect, useState, useContext } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
import { format } from 'date-fns'
// import useCustomSWRInfinite from 'core/utils/useCustomSWRInfinite'
// import useDebounce from 'core/utils/use-debounce'
import { Pagination, Table } from 'components'
import { SortDirection } from 'rio-uikit'
import { Row, Sort } from 'components/Table'
import { Period } from 'components/DateTimeFilter'
import FaultCodesDetailsSidesheet, { CustomFaultCodesModel } from './FaultCodesDetailsSidesheet'
// import DashboardContext from 'core/DashboardContext'
import { DashboardWrapper } from './styled'
import AddVehicleDialog from 'components/AddVehicleDialog'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import axios from 'axios'
import DashboardContext from 'core/DashboardContext'

export interface Points {
  start: {
    latitude: number
    longitude: number
  }
  end: {
    latitude: number
    longitude: number
  }
}

export interface FaultCodeModel {
  stops: any
  name: string
  date: string
  fmi: string
  fmiDescription: string
  lampStatus: string
  latitude: string
  longitude: string
  sourceAddress: string
  spn: string
  spnDescription: string
  description: string
  roles: string
  status: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
  stop: StopModel
  stopName: string
  stopCategorya: string
  addressStop: string
  rangeLimitMeters: string
  stayTime: string
  // }
  roadParameters: RangeModel
  trafficConditions: string
  avoidToll: string
  avoidRoad: string
  ignoreTrafficRestrictions: string
  // }
  vehicle: VehicleModel
  type: string
  comTotal: string
  height: string
  width: string
  maxWeight: string
  maxWeightAxle: string
  numberAxle: string
  trailerAxle: string
  pollutantClass: string
  dangerClassification: string
  // }
  costs: CostsModel
  tollValue: string
  operativeCosts: string
  fuelAverageCosts: string
  averageConsume: string
  totalCosts: string
  // }
}

export interface Route {
  address: any
  id: string
  lat: string
  lng: string
  addressStop: any
}

export interface PdisDetailsModel {
  id: any
  accountId: any
  addressStop: any
  roles: string
  status: string
  date: string
  routeName: string
  originRoute: Route
  destinyRoute: Route
  rangeToleranceLimit: string
  stops: StopModel
  roadParameters: RangeModel
  vehicleVocationalInfo: VehicleModel
  costs: CostsModel
  linkedVehicles: any
  startDateTime: string
  rangeToleranceLimite: string
}

export interface RouteModel {
  roles: string
  status: string
  date: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
}

export interface StopModel {
  id: string
  position: any
  name: string
  category: string
  addressStop: string
  rangeLimitMeters: string
  stayTime: string
  order: number
}

export interface RangeModel {
  id: string
  trafficConditions: string
  avoidToll: string
  avoidRoad: string
  ignoreTrafficRestrictions: string
}

export interface VehicleModel {
  type: string
  comTotal: string
  height: string
  width: string
  maxWeight: string
  maxWeightAxle: string
  numberAxle: string
  trailerAxle: string
  pollutantClass: string
  dangerClassification: string
}

export interface CostsModel {
  tollValue: string
  operativeCosts: string
  fuelAverageCosts: string
  averageConsume: string
  totalCosts: string
}

export interface PdisModel {
  roles: string
  status: string
  date: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
  stops: StopModel
  roadParameters: RangeModel
  vehicle: VehicleModel
  costs: CostsModel
}

interface PdisData extends Row {
  data: { data: PdisDetailsModel[] }
  total: number
}

interface FaultCodesProps {
  assetsId: string[]
  tagsId: string[]
  dateTime: Period
  intl: Intl
}

const Resume: FC<FaultCodesProps> = ({ intl }) => {
  const {
    setLinkedVehiclesContext,
    setAvoidPointsContext,
    setAllStopsContext,
    setOriginRouteContext,
    setDestinyRouteContext,
    setVehicleVocacionalContext,
    setCostsContext,
    setResponseHereContext,
    setRouteContext
  } = useContext(DashboardContext)

  const [dateTime, setDateTime] = useState<Period>({
    from: '',
    to: ''
  })

  useEffect(() => {
    setLinkedVehiclesContext([])
    setAvoidPointsContext([])
    setAllStopsContext([])
    setOriginRouteContext({})
    setDestinyRouteContext({})
    setVehicleVocacionalContext({})
    setCostsContext({})
    setResponseHereContext({})
    setRouteContext({})
  }, [])

  console.log(dateTime)

  const handleChangeDateTime = (period: Period) => {
    setDateTime(period)
  }

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  console.log(handleChangeDateTime)

  const [faultCodesDetails, setFaultCodesDetails] = useState<{ isOpen: boolean; data?: CustomFaultCodesModel }>({
    isOpen: false,
    data: undefined
  })
  const [sort, setSort] = useState({ sortBy: 'routeName', sortDirection: SortDirection.ASCENDING })
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [dataToAddVehicle, setDataToAddVehicle] = useState<any>([])
  const [search, setSearch] = useState('')
  const [pageNo, setPageNo] = useState(0)
  // const debouseSearch = useDebounce(search, 1000)
  const [data, setData] = useState<any>([])

  const pageSize = 50
  const [propsData, setProps] = useState({})

  // const { data: faultCodes = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   'api/perla-tests/vehicleStatus/faultCodes',
  //   'POST',
  //   propsData,
  //   pageSize
  // )

  // const { data: pdisData = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   '/routes/',
  //   'GET',
  //   propsData,
  //   pageSize
  // )

  const getTrips = async () => {
    // const baseURL = 'https://api.geo.latam-maintenance.rio.cloud/rio-routefence'

    const res = await axios.get(`${baseURL}/routes?pageSize=${pageSize}&page=${pageNo}&orderBy=${sort.sortBy}`, head)

    if (res.status === 200 || res.status === 201) {
      setData([res])
    } else if (res.statusText !== 'OK') {
      console.log('vazio')
    } else {
      console.log('ERROOOOOOOOOOOOOO')
    }
  }

  useEffect(() => {
    getTrips()
  }, [])

  // const getFaultCodes = (
  //   assetsId: string[],
  //   tagsId: string[],
  //   startAt: string,
  //   endAt: string,
  //   search: string,
  //   order: string,
  //   status: string
  // ) => {
  //   let propsData: Record<string, unknown> = {
  //     assetIds: assetsId,
  //     tagIds: tagsId,
  //     pageSize,
  //     startAt,
  //     endAt,
  //     search,
  //     status
  //   }

  //   if (order !== '[]' && order !== '') {
  //     propsData = {
  //       ...propsData,
  //       order: [order]
  //     }
  //   }

  //   setProps(propsData)
  // }

  const status = ''

  // const order = sort.sortBy ? `${sort.sortDirection === SortDirection.ASCENDING ? '' : '-'}${sort.sortBy}` : ''

  const handleChangeSort = async (sortBy: Sort['sortBy'], sortDirection: Sort['sortDirection']) => {
    console.log(sortDirection, 'sortDirection')
    if (sortDirection === 'desc') sortBy = `-${sortBy}`
    setSort({ sortBy, sortDirection })
    const res = await axios.get(`${baseURL}/routes?pageSize=${pageSize}&page=${pageNo}&orderBy=${sortBy}`, head)

    setData([res])

    if (res?.status === 200 || res?.status === 201) {
      setData([res])
    } else {
      console.log('error')
    }
  }

  const handleSearch = async (search: string) => {
    setSearch(search)
    const res = await axios.get(
      `${baseURL}/routes?pageSize=${pageSize}&page=${pageNo}&search=${search}&orderBy=${sort.sortBy}`,
      head
    )

    setData([res])

    if (res?.status === 200 || res?.status === 201) {
      setData([res])
    } else {
      console.log('error')
    }
  }

  const handleFetchMore = () => {
    setPageNo(pageNo + 1)
  }

  const handleLineClick = (data: CustomFaultCodesModel) => {
    setFaultCodesDetails({
      isOpen: true,
      data
    })
  }

  const convertStatusRoute = (status: boolean): string => {
    switch (status) {
      case false:
        return 'Inativa'
      default:
        return 'Ativa'
    }
  }

  const rowsPagineted = data?.map((pdisDataPage: PdisData) => {
    return pdisDataPage
      ? pdisDataPage?.data?.data?.map((pdisDataRow: any, index: any) => {
          const dateTimeZoneZero = format(new Date(pdisDataRow?.date), "yyyy-MM-dd'T'HH:mm:ss.SSS") + '-00:00'

          return {
            id: pdisDataRow.id,
            accountId: pdisDataRow?.accountId,
            index: index.toString(),
            date: format(new Date(dateTimeZoneZero), 'dd/MM/yyyy HH:mm:ss'),
            start_datetime: format(new Date(dateTimeZoneZero), 'dd/MM/yyyy HH:mm:ss'),
            // originRoute: pdisDataRow?.originRoute?.addressStop?.label,
            // destinyRoute: pdisDataRow?.destinyRoute?.addressStop?.label,
            originRoute:
              pdisDataRow?.originRoute?.addressStop?.label?.length < 5
                ? `${pdisDataRow?.originRoute.lat}, ${pdisDataRow?.originRoute.lng}`
                : pdisDataRow?.originRoute?.addressStop?.label,
            destinyRoute:
              pdisDataRow?.destinyRoute?.addressStop?.label?.length < 5
                ? `${pdisDataRow?.destinyRoute.lat}, ${pdisDataRow?.destinyRoute.lng}`
                : pdisDataRow?.destinyRoute?.addressStop?.label,
            routeName: pdisDataRow?.routeName,
            route_name: pdisDataRow?.routeName,
            roadParameters: pdisDataRow?.roadParameters,
            responseHere: pdisDataRow?.responseHere,
            stops: pdisDataRow?.stops,
            vehicle: pdisDataRow?.vehicleVocationalInfo,
            linkedVehicles: pdisDataRow?.linkedVehicles,
            rangeToleranceLimit: pdisDataRow?.rangeToleranceLimit,
            roles: pdisDataRow?.roles,
            startDateTime: pdisDataRow?.startDateTime,
            status: convertStatusRoute(pdisDataRow?.status),
            originRouteData: pdisDataRow.originRoute,
            destinyRouteData: pdisDataRow.destinyRoute,
            stopName: pdisDataRow.stops?.name,
            stopCategorya: pdisDataRow.stops?.category,
            addressStop: pdisDataRow.stops?.position?.addressStop,
            rangeLimitMeters: pdisDataRow.stops?.rangeLimitMeters,
            stayTime: pdisDataRow.stops?.stayTime,
            trafficConditions: pdisDataRow.roadParameters?.trafficConditions,
            avoidToll: pdisDataRow.roadParameters?.avoidToll,
            avoidRoad: pdisDataRow.roadParameters?.avoidRoad,
            ignoreTrafficRestrictions: pdisDataRow.roadParameters?.ignoreTrafficRestrictions,
            type: pdisDataRow.vehicleVocationalInfo?.type,
            comTotal: pdisDataRow.vehicleVocationalInfo?.comTotal,
            height: pdisDataRow.vehicleVocationalInfo?.height,
            width: pdisDataRow.vehicleVocationalInfo?.width,
            maxWeight: pdisDataRow.vehicleVocationalInfo?.maxWeight,
            maxWeightAxle: pdisDataRow.vehicleVocationalInfo?.maxWeightAxle,
            numberAxle: pdisDataRow.vehicleVocationalInfo?.numberAxle,
            trailerAxle: pdisDataRow.vehicleVocationalInfo?.trailerAxle,
            pollutantClass: pdisDataRow.vehicleVocationalInfo?.pollutantClass,
            dangerClassification: pdisDataRow.vehicleVocationalInfo?.dangerClassification,
            tollValue: pdisDataRow.costs?.tollValue,
            operativeCosts: pdisDataRow.costs?.operativeCosts,
            totalCosts: pdisDataRow.costs?.totalCosts,
            fuelAverageCosts: pdisDataRow.costs?.fuelAverageCosts,
            averageConsume: pdisDataRow.costs?.averageConsume
          }
        })
      : []
  })

  console.log(rowsPagineted, 'rowsPagineted')

  const handleMenu = (item: string) => {
    setProps({ ...propsData, status: item })
  }

  const handleLinkVehicle = (id: string) => {
    setOpenAddVehicleDialog(true)
    setDataToAddVehicle(id)
  }

  // useEffect(() => {
  //   getFaultCodes(assetsId, tagsId, dateTime.from, dateTime.to, debouseSearch, order, status)
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [assetsId, tagsId, dateTime.from, dateTime.to, debouseSearch, order])

  // useEffect(() => {
  //   setSize(1)
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [propsData])

  return (
    <>
      <FaultCodesDetailsSidesheet
        isOpen={faultCodesDetails.isOpen}
        data={faultCodesDetails.data}
        onClose={() => setFaultCodesDetails({ isOpen: false })}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type={'linkVehicleOut'}
        typeToTrip={''}
        data={dataToAddVehicle}
      />
      <DashboardWrapper>
        <Table
          handleLinkVehicle={handleLinkVehicle}
          name='pdisTable'
          status={status}
          rowsPagineted={rowsPagineted}
          rowsCount={pageSize}
          disabledColumns={[]}
          columnsStyle={{
            route_name: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 100
            },
            originRoute: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 150
            },
            destinyRoute: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 150
            },
            status: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 50
            },
            start_datetime: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 100
            }
          }}
          columnLabels={{
            route_name: 'Nome',
            originRoute: 'Inicio da Rota',
            destinyRoute: 'Término da Rota',
            status: 'Status',
            start_datetime: 'Data'
          }}
          defaultColumnOrder={['route_name', 'originRoute', 'destinyRoute', 'status', 'start_datetime']}
          sort={sort}
          settingsCloseButtonText={<FormattedMessage id='settingsCloseButtonText' />}
          settingsNotFoundMessage={<FormattedMessage id='settingsNotFoundMessage' />}
          settingsResetButtonText={<FormattedMessage id='settingsResetButtonText' />}
          settingsSearchPlaceholder={intl.formatMessage({ id: 'settingsSearchPlaceholder' })}
          settingsTitle={<FormattedMessage id='settingsTitle' />}
          searchLabel={intl.formatMessage({ id: 'searchLabel' }, { value: intl.formatMessage({ id: 'failures' }) })}
          search={search}
          lineClickName='allColumns'
          onLineClick={(handleLineClick as unknown) as (row: Row) => void}
          onChangeSearch={handleSearch}
          onChangeSort={handleChangeSort}
          typeTable='routefence-pdis'
          handleMenu={handleMenu}
          showResumeButton={false}
        />
        {data && data.total > 0 && (
          <Pagination
            paginationDescription={intl.formatMessage({ id: 'paginationDescription' })}
            buttonLoadMoreLabel={<FormattedMessage id='buttonLoadMoreLabel' />}
            buttonEverythingLoadedLabel={<FormattedMessage id='buttonEverythingLoadedLabel' />}
            lenghtPerPage={pageSize || 50}
            page={pageNo || 1}
            onLoadmore={handleFetchMore}
            size={data[0]?.total || 50}
          />
        )}
      </DashboardWrapper>
    </>
  )
}

export default injectIntl(Resume)
