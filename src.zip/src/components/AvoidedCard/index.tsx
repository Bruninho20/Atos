import React, { FC } from 'react';

import {
  DriverInformationLeft,
  StyledCard,
  TotalCounter,
  TotalCounter2,
  TotalInfractions
} from './styled';

interface CardCo2Avoited{
  title: any;
  content: any;
  unity: any;
  description: any

}

const Co2Card: FC<CardCo2Avoited> = ({ title, content, unity, description }) => {

  return (
    <StyledCard
      title={title}
      className="card-title"
    >
      <TotalInfractions>
        <TotalCounter>{content} </TotalCounter>
        <TotalCounter2>{unity}</TotalCounter2>
      </TotalInfractions>      
          <DriverInformationLeft>          
            <p>{description}</p>          
          </DriverInformationLeft>     
      </StyledCard>
  );
};

export default Co2Card;
