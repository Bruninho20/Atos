import styled, { css } from 'styled-components';
import { metrics } from 'core/assets/styles';

interface PaperProps {
  width?: string;
  elevation?: string;
}

const Paper = styled.section<PaperProps>`
  background-color: white;
  border-radius: ${metrics.baseRadius};
  display: flex;
  flex-direction: column;
  transition: box-shadow 150ms linear;
  width: ${({ width }) => (width ? width : 'auto')};

  ${({ elevation }) =>
  elevation === 'true' &&
    css`
      box-shadow: 0 2px 1px -1px rgba(0, 0, 0, 0.2),
        0 1px 1px 0 rgba(0, 0, 0, 0.14), 0 1px 3px 0 rgba(0, 0, 0, 0.12);
      cursor: pointer;

      &:hover {
        box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.2),
          0px 3px 4px rgba(0, 0, 0, 0.12), 0px 2px 4px rgba(0, 0, 0, 0.14);
      }
    `}
`;

export default Paper;
