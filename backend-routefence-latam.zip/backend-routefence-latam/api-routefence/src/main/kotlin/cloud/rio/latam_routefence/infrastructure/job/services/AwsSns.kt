package cloud.rio.latam_routefence.infrastructure.job.services

import com.amazonaws.services.sns.AmazonSNS
import com.amazonaws.services.sns.AmazonSNSClientBuilder
import com.amazonaws.services.sns.model.AmazonSNSException
import com.amazonaws.services.sns.model.MessageAttributeValue
import com.amazonaws.services.sns.model.PublishRequest
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component

@Component
class AwsSns {

    private val AWS_SNS_SMS_TYPE = "AWS.SNS.SMS.SMSType"
    private val AWS_SNS_SMS_TYPE_VALUE = "Transactional"
    private val AWS_SNS_DATA_TYPE = "String"

    private val log = LoggerFactory.getLogger(AwsSns::class.java)
    private var snsClient: AmazonSNS? = null

    fun sendNotification(message: String, number: String) {
        try {
            //publishRequest(message, number)
        } catch (e: AmazonSNSException) {
            log.error(e.errorMessage)
        }
    }

    fun sendTest(message: String, number: String) {
        try {
            publishRequestTest(message, number)
        } catch (e: Exception) {
            log.error(e.message)
        }
    }

    private fun publishRequestTest(message: String, number: String) {
        try {
            // The time for request/response round trip to aws in milliseconds
            val requestTimeout = 3000
            val smsAttributes: MutableMap<String, MessageAttributeValue> = HashMap()
            smsAttributes[AWS_SNS_SMS_TYPE] = MessageAttributeValue()
                .withStringValue(AWS_SNS_SMS_TYPE_VALUE)
                .withDataType(AWS_SNS_DATA_TYPE)
            //snsClient!!.setRegion(Region.getRegion(Regions.EU_WEST_1))
            val request = getSnsClient()!!.publish(
                PublishRequest()
                    .withMessage(message)
                    .withPhoneNumber(number)
                    .withMessageAttributes(smsAttributes)
                    .withSdkRequestTimeout(requestTimeout)
            )

            log.info(request.toString())
        } catch (e: RuntimeException) {
            //log.error("Error occurred sending sms to {} ", mobileNo, e);
            throw Exception("Error while sending sms please try again later ", e)
        }
    }

    private fun publishRequest(message: String, number: String) {
        val request = PublishRequest()
            .withMessage(message)
            .withPhoneNumber(number)

        val result = getSnsClient()!!.publish(request)
        log.info("Sns with id:" + result.messageId + " return with status of:" + result)
    }

    private fun getSnsClient(): AmazonSNS? {
        return snsClient ?: buildSnsClient()
    }

    private fun buildSnsClient(): AmazonSNS? {
        snsClient = AmazonSNSClientBuilder.defaultClient()
        return snsClient
    }
}