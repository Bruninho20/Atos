package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.VehicleDataApi
import cloud.rio.latam_routefence.services.VehicleDataService
import org.springframework.web.bind.annotation.RestController
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleDataResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleResponse

@RestController
class VehicleDataController(private val vehicleDataService: VehicleDataService): VehicleDataApi {

    override fun decodeChassis(chassis: String, emissionType: String): VehicleResponse {
        return vehicleDataService.decodeChassis(chassis,emissionType)
    }

    override fun findVehicleByCode(chassis: String): VehicleDataResponse? {
        return vehicleDataService.findVehicleByCode(chassis)
    }
}