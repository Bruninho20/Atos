import styled from 'styled-components'

export const WrapperContent = styled.div`
  padding: 7px;
  display: flex;
  flex-direction: column;
  width: 430px;
  height: 100%;
  padding: 15px;
`

export const SideSheetContentWrapper = styled.div`
  padding: 0 15px 45px 15px;
  margin-top: 15px;
  width: 100%;
  margin-bottom: 100px;
`

export const CardContent = styled.div`
  margin-top: 25px;
  display: flex;
  flex-direction: column;
  width: 100%
  border: 1px solid;
  height: auto;
  box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
`

export const HeaderFirstCard = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 0px 10px;
  width: 100%;
  height: 40px;
`

export const HeaderSecondCard = styled.div`
  margin-top: 20px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 40px 10px;
  width: 100%;
  height: 120px;
  border-bottom: 1px solid #d6d2d2;
`

export const WrapperFirstCard = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-content: center;
  align-items: center;
  width: 100%;
  height: auto;
`

export const WrapperSecondCard = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: auto;
`
export const Content1FirstCard = styled.div`
  padding: 25px 10px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-content: flex-start;
  width: 41%;
`

export const Content2FirstCard = styled.div`
  padding: 25px 10px;
  display: flex;
  flex-direction: column;
  width: 41%;
`

export const AreaIconColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  justify-content: center;
  width: 8%
  height: 100%;
`

export const BottomFirstCard = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-content: center;
  align-items: center;
  width: 100%;
  height: 40px;
  border-top: 1px solid #d6d2d2;
`

export const HeadInsideCard = styled.div`
  height: 50px;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 10px;
  background-color: blue;
`

export const BodyInsideCard = styled.div`
  height: 60px;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-start;
`

export const Card = styled.div`
  height: auto;
  width: 100%;
  display: flex;
  flex-direction: column;
`

export const IntervalCard = styled.div`
  height: 30px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-content: center;
  align-items: center;
  background-color: #e9e9ea;
  border-top: 1px solid #d6d2d2;
  border-bottom: 1px solid #d6d2d2;
`

export const IconCard = styled.div`
  display: flex;
  width: 30px;
  height: 30px;
  justify-content: center;
  margin-right: 10px;
  align-content: center;
  align-items: center;
  background-color: gray;
`

export const Container = styled.div`
  margin-top: 25px;
  display: flex;
  flex-direction: column;
  justify-content: start-flex;
  border-bottom: 1px solid #adadad;
`

export const Label = styled.span`
  color: #878585;
  margin-left: 3px;
  margin-bottom: 0;
  font-size: 12px;
`

export const Description = styled.span`
  color: #000;
  font-size: 14px;
  font-weight: bold;
`

export const Text = styled.span`
  color: #878585;
  font-size: 14px;
`

export const DateInfraction = styled.span`
  color: #878585;
  font-size: 11px;
  display: flex,
  justify-content: flex-end;
`
