import React, { FC } from 'react';
import { TableSettingsDialog, TableSettingsDialogProps } from 'rio-uikit';

type SettingsProps = Pick<
  TableSettingsDialogProps,
  | 'columnLabels'
  | 'show'
  | 'onHide'
  | 'onColumnChange'
  | 'defaultColumnOrder'
  | 'columnOrder'
  | 'disabledColumns'
  | 'hiddenColumns'
  | 'columnsDetails'
  | 'onColumnDetailsChange'
  | 'title'
  | 'closeButtonText'
  | 'resetButtonText'
  | 'searchPlaceholder'
  | 'notFoundMessage'
>;

const Settings: FC<SettingsProps> = ({
  closeButtonText,
  columnLabels,
  columnOrder,
  columnsDetails,
  defaultColumnOrder,
  disabledColumns,
  hiddenColumns,
  notFoundMessage,
  resetButtonText,
  searchPlaceholder,
  show,
  title,
  onColumnChange,
  onColumnDetailsChange,
  onHide
}) => (
  <TableSettingsDialog
    show={show}
    title={title}
    onHide={onHide}
    onColumnChange={onColumnChange}
    defaultColumnOrder={defaultColumnOrder}
    defaultHiddenColumns={[]}
    columnOrder={columnOrder}
    hiddenColumns={hiddenColumns}
    columnLabels={columnLabels}
    disabledColumns={disabledColumns}
    closeButtonText={closeButtonText}
    resetButtonText={resetButtonText}
    searchPlaceholder={searchPlaceholder}
    notFoundMessage={notFoundMessage}
    columnsDetails={columnsDetails}
    autoLabel="auto"
    onColumnDetailsChange={onColumnDetailsChange}
    immediateChange
  />
);

export default Settings;
