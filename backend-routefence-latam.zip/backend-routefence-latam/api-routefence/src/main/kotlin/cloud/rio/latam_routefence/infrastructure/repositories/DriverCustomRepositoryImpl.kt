package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.persistence.EntityManagerFactory

@Repository
class DriverCustomRepositoryImpl: DriverCustomRepository {

    @Autowired
    lateinit var entityManagerFactory: EntityManagerFactory

    override fun getDriversOrderByMostLinkedToAsset(assetId: String): List<String> {
        val entityManager = entityManagerFactory.createEntityManager()
        val accountId = AccountContext.get()
        val query = entityManager.createNativeQuery(
            """
        SELECT driver_id, COUNT(*) as vinculos
        FROM TB_TRIP
        WHERE asset_id = :assetId AND account_id = :accountId
        GROUP BY driver_id
        ORDER BY vinculos DESC
        """
        )
        query.setParameter("assetId", assetId)
        query.setParameter("accountId", accountId)
        val results = query.resultList as List<Array<Any>>

        entityManager.close()

        return results.map { it[0] as String }
    }
}