package cloud.rio.latam_routefence.services

import com.project.custom.domain.request.SendSimpleMailRequest
import com.project.custom.services.AwsEmailService
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
@Transactional
class SendEmailService(
    private val awsEmailService: AwsEmailService,
) {
    fun sendEmail(to: List<String>, subject: String, textBody: String) {
        awsEmailService.sendSimpleEmail(
            SendSimpleMailRequest(
                to = to,
                subject = subject,
                textBody = textBody
            )
        )
    }
}