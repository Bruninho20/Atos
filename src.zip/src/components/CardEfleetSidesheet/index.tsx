import React, { FC } from 'react';

import { CardBody, StyledCard, SubTitle, Title, WrapperTitle } from './styled';

interface CardProps {
  action?(): void;
  children: React.ReactNode;
  className?: string;
  justify?: string;
  margin?: string;
  subTitle?: any | React.ReactNode;
  title?: any | React.ReactNode;
  minWidth?: string;
  width?: string;
}

const Card: FC<CardProps> = ({
  action,
  children,
  className,
  subTitle = '',
  title,
  margin,
  minWidth,
  justify,
  width
}) => {
  const handleClick = (event: { keyCode: number }) => {
    if (event.keyCode === 13 && action) action();
  };

  return (
    <StyledCard
      margin={margin}
      minWidth={minWidth}
      className={className}
      elevation={action ? 'true' : 'false'}
      onClick={action}
      onKeyUp={action && handleClick}
      tabIndex={action ? 0 : undefined}
      width={width}
    >
      {title && (
        <WrapperTitle justify={justify}>
          <Title>{title}</Title>
          <SubTitle>{subTitle}</SubTitle>
        </WrapperTitle>
      )}
      <CardBody>{children}</CardBody>
    </StyledCard>
  );
};

export default React.memo(Card);
