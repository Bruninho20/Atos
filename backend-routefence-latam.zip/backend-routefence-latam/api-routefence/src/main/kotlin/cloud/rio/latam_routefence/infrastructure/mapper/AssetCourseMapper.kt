package cloud.rio.latam_routefence.infrastructure.mapper

import cloud.rio.latam_routefence.domain.response.AssetCourseResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity

fun AssetCourseEntity.mapToResponse(): AssetCourseResponse {
    return AssetCourseResponse(
        id = this.id,
        lat = this.lat,
        lng = this.lng,
        heading = this.heading,
        speed = this.speed,
        occurredAt = this.occurredAt.toString(),
        tripId = this.trip.id
    )
}