package cloud.rio.latam_routefence.config

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.core.env.Environment
import routefence_common.cloud.rio.latam_routefence.config.DataSourceBase
import javax.sql.DataSource

@Configuration
class DataSourceConfig: DataSourceBase() {
    @Autowired
    private lateinit var environment: Environment

    @Bean
    @Primary
    override fun dataSource(environment: Environment): DataSource {
        return super.dataSource(environment)
    }
}