/* eslint-disable indent */
import styled, { css } from 'styled-components';

import { colors, metrics } from 'core/assets/styles';
import Paper from '../Paper';

interface StyledCardProps {
  action?: boolean;
  margin?: string;
  minWidth?: string;
}

interface WrapperTitleProps {
  justify?: string;
}

export const CardBody = styled.div`
  border-top: 1px solid ${colors.borderDefault};
  height: 100%;
  padding: 1rem;
`;

export const StyledCard = styled(Paper)<StyledCardProps>`
  border: 1px solid ${colors.borderDefault};
  border-radius: ${metrics.baseRadius};
  position: relative;
  ${({ margin }) => `margin: ${margin};`}
  ${({ minWidth }) => `min-width: ${minWidth};`}
  width: ${({ width }) => (width ? width : 'auto')};


  @media screen and (max-width: 768px) {
    width: auto;
  }

  ${({ action }) =>
    action &&
    css`
      cursor: pointer;
    `}

  &:focus {
    border: 1px solid ${colors.grayMedium};
    outline: none;
  }
`;

export const WrapperTitle = styled.div<WrapperTitleProps>`
  align-items: center;
  display: flex;
  height: 30px;
  justify-content: ${({ justify }) => justify || 'start'};
  padding: 0 1rem;
`;

export const Title = styled.h1`
  color: ${colors.gray};
  font-size: ${metrics.fontSizeDefault};
  font-weight: normal;
  margin: 0;
  text-transform: none;
`;

export const SubTitle = styled.h2`
  color: ${colors.primaryDark};
  font-size: ${metrics.fontSizeTitle};
  font-weight: 600;
  margin: 0;
`;
