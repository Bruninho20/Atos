import React, { FC, useState, useEffect } from 'react'
import { FormattedMessage, Intl, injectIntl } from 'react-intl'
// import { useFetch } from 'core/providers/api/use-fetch'
import { downloadFile, EDownloadFileType } from 'core/utils/download-file'
import {
  WrapperContent,
  Card,
  IconCard,
  Description,
  CardContent,
  TextArea,
  DateArea,
  TypeInfraction,
  DateInfraction,
  HeaderCard
} from './styled'
import { Button } from 'components'
import { DatePicker, Notification, SimpleButtonDropdown } from 'rio-uikit'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import moment from 'moment'
import { geoApi } from 'core/providers/api/geo-api'

interface PropsData {
  intl: Intl
  newData: any
  tripData: any
  data: any
}

const InfractionDetails: FC<PropsData> = ({ intl, newData, tripData }) => {
  // const { setUrl: setDownloadUrl, data } = useFetch()
  // const [fileType, setFileType] = useState('')
  const [infractionsData, setInfractionsData] = useState<any>([])
  const [dateTime, setDateTime] = useState<any>({
    from: null,
    to: null
  })

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken: any = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  useEffect(() => {
    const getInfractionData = async () => {
      try {
        // COMENTAR E DESCOMENTAR QUANDO MEXER LOCAL
        // const res = await axios.get(`${baseURL}/infringements/${data?.id}`, head)
        const res = await axios.get(`${baseURL}/infringements/${tripData?.tripId}`, head)
        setInfractionsData(res.data)
      } catch (error) {
        console.log(error)
      }
    }
    getInfractionData()
  }, [])

  const handleChangeDateTime = async () => {
    if (
      (moment(dateTime?.from).toISOString() === null && moment(dateTime?.to).toISOString() !== null) ||
      (moment(dateTime?.from).toISOString() !== null && moment(dateTime?.to).toISOString() === null)
    ) {
      Notification.error('É necessário informar as duas datas')
    } else {
      if (moment(dateTime?.from).toISOString() === null) {
        const getInfractionData = async () => {
          try {
            // COMENTAR E DESCOMENTAR QUANDO MEXER LOCAL
            // const res = await axios.get(`${baseURL}/infringements/${data?.id}`, head)
            const res = await axios.get(`${baseURL}/infringements/${tripData?.tripId}`, head)
            setInfractionsData(res.data)
          } catch (error) {
            console.log(error)
          }
        }
        getInfractionData()
      } else {
        const getInfractionData = async () => {
          try {
            // COMENTAR E DESCOMENTAR QUANDO MEXER LOCAL
            // const res = await axios.get(`${baseURL}/infringements/${data?.id}`, head)
            const res = await axios.get(
              `${baseURL}/infringements/${tripData?.tripId}?startDateTime=${moment(
                dateTime?.from
              ).toISOString()}&endDateTime=${moment(dateTime?.to).toISOString()}`,
              head
            )
            setInfractionsData(res.data)
          } catch (error) {
            console.log(error)
          }
        }
        getInfractionData()
      }
    }
  }

  const onDownloadClick = async (type: string) => {
    // setFileType(type)

    if (type === 'csv' || type === 'xlsx') {
      const data = await geoApi.dmCode.downloadFile(type, tripData?.tripId)
      downloadFile(data, type === 'csv' ? EDownloadFileType.CSV : EDownloadFileType.XLSX, 'infractionsReport')
    }
  }

  // useEffect(() => {
  //   if (fileType === 'csv') {
  //     alert('csv')
  //     downloadFile(data, EDownloadFileType.CSV, 'infractionsReport')
  //   } else if (fileType === 'xlsx') {
  //     alert('xlsx')
  //     downloadFile(data, EDownloadFileType.XLSX, 'infractionsReport')
  //   }
  // }, [data])

  return (
    <WrapperContent>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 15, color: '#878585', fontWeight: '600' }}>Notificações</span>
        <SimpleButtonDropdown
          title={<span className='rioglyph rioglyph-download' aria-hidden={'true'} />}
          iconOnly
          items={[
            {
              value: (
                <div>
                  <span>
                    <FormattedMessage id='components.table.toolbar.exportCSV' />
                  </span>
                </div>
              ),
              onSelect: value => onDownloadClick('csv')
            },
            {
              value: (
                <div>
                  <span>
                    <FormattedMessage id='components.table.toolbar.exportXLSX' />
                  </span>
                </div>
              ),
              onSelect: value => onDownloadClick('xlsx')
            }
          ]}
        />
      </div>
      <CardContent style={{ borderRadius: 7, maxHeight: '80%' }}>
        <HeaderCard>
          <div style={{ display: 'flex', flexDirection: 'column', marginBottom: 20 }}>
            <div className='display-flex  gap-10 max-width-400 margin-bottom-10'>
              <div style={{ width: 170 }}>
                <label>De:</label>
                <DatePicker onChange={(e: any) => setDateTime({ ...dateTime, from: e })} clearableInput />
              </div>
              <div style={{ width: 170 }}>
                <label>Até:</label>
                <DatePicker onChange={(e: any) => setDateTime({ ...dateTime, to: e })} clearableInput />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', alignContent: 'center' }}>
              <Button onClick={() => handleChangeDateTime()} label={'Atualizar'} />
            </div>
          </div>
        </HeaderCard>
        <div style={{ overflowY: 'scroll', overflowX: 'hidden' }}>
          {infractionsData &&
            infractionsData?.map((item: any) => {
              return (
                <Card>
                  <IconCard>
                    <span
                      style={{ color: '#D54747', marginLeft: 5 }}
                      className='rioglyph rioglyph-exclamation-sign text-size-h3'></span>
                  </IconCard>
                  <TextArea>
                    <TypeInfraction>
                      <FormattedMessage id={item.type} />
                    </TypeInfraction>
                    <Description>{item.note}</Description>
                    <Description>
                      {!item.addressStop ? `${item?.location.lat}, ${item?.location.lat}` : item?.addressStop?.label}
                    </Description>
                  </TextArea>
                  <DateArea>
                    <span style={{ fontSize: 11, fontWeight: 'bold', color: '#878585' }}>Inicio:</span>
                    <DateInfraction>
                      {item.startDateTime === 'null'
                        ? ''
                        : moment(item.startDateTime).subtract(3, 'hours').format('DD/MM/yyyy HH:mm')}
                    </DateInfraction>
                    <span style={{ fontSize: 11, fontWeight: 'bold', color: '#878585' }}>Fim:</span>
                    <DateInfraction>
                      {item.endDateTime === 'null'
                        ? ''
                        : moment(item.endDateTime).subtract(3, 'hours').format('DD/MM/yyyy HH:mm')}
                    </DateInfraction>
                  </DateArea>
                </Card>
              )

              //    <span style={{ fontSize: 16, fontWeight: 'bold' }}>
              //       <FormattedMessage id={item.type} />
              //     </span>
              //     <Description>{item.note}</Description>
              //     <DateInfraction>{moment(item.startDateTime).format('DD/MM/yyyy HH:MM')}</DateInfraction>
              //     <DateInfraction>{item.startDateTime}</DateInfraction>
            })}
        </div>
      </CardContent>
    </WrapperContent>
  )
}

export default injectIntl(InfractionDetails)
