package cloud.rio.latam_routefence.infrastructure.consumedapi.base

import cloud.rio.latam_routefence.auth.InternalToken
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import javax.servlet.http.HttpServletRequest

open class BaseAPIClient(private val request: HttpServletRequest) {

    fun getHeaders(): HttpHeaders {
        val headers = HttpHeaders()
        headers[HttpHeaders.AUTHORIZATION] = request.getHeader(HttpHeaders.AUTHORIZATION)
        headers[HttpHeaders.CONTENT_TYPE] = MediaType.APPLICATION_JSON_VALUE
        return headers
    }

    fun createInternalAuthHeader(internalToken: InternalToken): HttpHeaders {
        val headers = HttpHeaders()
        headers[HttpHeaders.CONTENT_TYPE] = MediaType.APPLICATION_JSON_VALUE
        headers[HttpHeaders.AUTHORIZATION] = "${internalToken.token.tokenType} ${internalToken.token.accessToken}"
        return headers
    }
}