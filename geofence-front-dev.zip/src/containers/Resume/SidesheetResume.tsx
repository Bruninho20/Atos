import React, { FC } from 'react'
import { FormattedMessage } from 'react-intl'

import { SideSheet } from 'components'

import {
  InfractionDetailsTable,
  InfractionDetailsTableColumnLeft,
  InfractionDetailsTableColumnRight,
  InfractionDetailsTableRow,
  InfractionDetailsTableRowLast,
  SideSheetContentWrapper,
  StyledExpanderPanel
} from 'components/SidesheetTable/styled'

const ResumeDetailsSidesheet: FC<{
  isOpen: boolean
  data?: any
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, data, onClose }) => {
  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  const renderRouteTable = (routeData: any) => (
    <>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='routeName' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.routeName.toUpperCase()}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='originRoute' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.originRouteData?.addressStop?.label}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='destinyRoute' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.destinyRouteData?.addressStop?.label}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='rangeToleranceLimit' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.rangeToleranceLimit}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='status' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.status}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='date' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.date}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
    </>
  )

  const renderRangeTable = (routeData: any) => (
    <>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='trafficConditions' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.trafficConditions === true ? 'SIM' : 'NÃO'}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='avoidToll' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.avoidToll === true ? 'SIM' : 'NÃO'}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='avoidRoad' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.avoidRoad === true ? 'SIM' : 'NÃO'}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='ignoreTrafficRestrictions' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            {data?.ignoreTrafficRestrictions === true ? 'SIM' : 'NÃO'}
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
    </>
  )

  const renderVehicleTable = (routeData: any) => (
    <>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='type' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.type}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='comTotal' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.comTotal}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='height' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.height}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='width' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.width}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='maxWeight' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.maxWeight}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='maxWeightAxle' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.maxWeightAxle}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='numberAxle' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.numberAxle}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='trailerAxle' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.trailerAxle}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='pollutantClass' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.pollutantClass}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='dangerClassification' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{data?.dangerClassification}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
    </>
  )

  const renderCostsTable = (routeData: any) => (
    <>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='tollValue' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{`R$ ${Number(data?.tollValue).toFixed(
            2
          )}`}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='operativeCosts' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{`R$ ${Number(data?.operativeCosts).toFixed(
            2
          )}`}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='fuelAverageCosts' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{`R$ ${Number(data?.fuelAverageCosts).toFixed(
            2
          )}`}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='averageConsume' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{`${Number(data?.averageConsume).toFixed(
            2
          )} Km/L`}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
      <InfractionDetailsTable>
        <InfractionDetailsTableRow>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id='totalCosts' />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{`R$ ${Number(data?.totalCosts).toFixed(
            2
          )}`}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      </InfractionDetailsTable>
    </>
  )

  return (
    <>
      <SideSheet
        modal
        width='445px'
        padding='0'
        open={isOpen}
        title={`Detalhes da Rota`}
        onClick={() => handleOnClose(false)}>
        <SideSheetContentWrapper>
          <StyledExpanderPanel title='Rota' open={true}>
            {renderRouteTable ?? renderRouteTable}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Paradas' open={true}>
            {data?.stops?.map((item: any) => {
              return (
                <>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stopName' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>
                        {String(item?.name).toUpperCase()}
                      </InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stopCategorya' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{item?.category}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='addressStop' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>
                        {item?.position?.addressStop?.label}
                      </InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='rangeLimitMeters' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{data?.rangeToleranceLimit}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRowLast>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stayTime' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{item?.stayTime}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRowLast>
                  </InfractionDetailsTable>
                  
                </>
              )
            })}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Faixa' open={true}>
            {renderRangeTable ?? renderRangeTable}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Veículo' open={true}>
            {renderVehicleTable ?? renderVehicleTable}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Custos' open={true}>
            {renderCostsTable ?? renderCostsTable}
          </StyledExpanderPanel>
          <div style={{ height: 80 }}></div>
        </SideSheetContentWrapper>
      </SideSheet>
    </>
  )
}

export default ResumeDetailsSidesheet
