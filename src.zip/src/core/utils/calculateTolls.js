
import axios from 'axios'

const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'


export const calculateTolls = async (data) => {

    const arrayStop = data?.allStopsContext?.map((item, index) => {
        return (
            `&waypoint${index + 1}=${item?.position?.lat},${item?.position?.lng}`
        )
    })

    const destinyWaypoint = `waypoint${arrayStop?.length + 1}=${data?.destinyRouteContext?.lat},${data?.destinyRouteContext?.lng}`

    const res = await axios.get(`https://fleet.api.here.com/2/calculateroute.json?jsonAttributes=41&waypoint0=${data?.originRouteContext?.lat},${data?.originRouteContext?.lng}${arrayStop}&${destinyWaypoint}&currency=BRL&tollVehicleType=3&vehicleNumberAxles=${data?.vehicleVocacionalContext?.numberAxle === undefined ? 1 : data?.vehicleVocacionalContext?.numberAxle}&trailerNumberAxles=${data?.vehicleVocacionalContext?.trailerAxle === undefined ? 1 : data?.vehicleVocacionalContext?.trailerAxle}&hybrid=0&emissionType=5&fuelType=diesel&disabledEquipped=0&minimalPollution=0&hov=0&passengersCount=1&tiresCount=14&commercial=1&heightAbove1stAxle=1m&mode=fastest;truck;traffic:disabled&rollups=none,country;tollsys&alternatives=1&apiKey=${apiKey}&jsoncallback=parseRoutingResponse`)
    const jsonStr = res.data?.slice(21).slice(0, -1)
    const jsonObj = JSON.parse(jsonStr);
    const sumTolls = jsonObj?.response?.route[0]?.cost?.totalCost.replace('.', ',')
    const kmTotal = jsonObj?.response?.route[0]?.summary?.distance
    return ({ sumTolls, kmTotal, status: res.status })

}