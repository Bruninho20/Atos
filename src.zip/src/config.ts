import { ConfigState } from './types'

const getBoolEnvValue = (envValue: string): boolean => {
  return typeof process.env[envValue] !== 'undefined' && process.env[envValue] === 'true'
}

export const config: ConfigState = {
  backend: {
    AUTHENTICATION_SERVICE: process.env.REACT_APP_AUTHENTICATION_SERVICE,
    MENU_SERVICE: process.env.REACT_APP_MENU_SERVICE
  },
  homeRoute: process.env.REACT_APP_HOME_ROUTE,
  id: process.env.REACT_APP_ID,
  login: {
    authority: process.env.REACT_APP_LOGIN_AUTHORITY,
    // TODO: Request and supply your App's `client_id` as
    //       well as the needed OAuth scopes here
    clientId: 'ed72e7c5-bb7c-44be-8699-63fac02c6c9d',
    oauthScope: ['openid', 'profile', 'email', 'tags.read','map.read', 'phone','asset-administration.read'],
    mockAuthorization: getBoolEnvValue('REACT_APP_LOGIN_MOCK_AUTHORIZATION'),
    mockLocale: process.env.REACT_APP_LOGIN_MOCK_LOCALE,
    preventRedirect: getBoolEnvValue('REACT_APP_LOGIN_PREVENT_REDIRECT'),
    redirectUri: process.env.REACT_APP_LOGIN_REDIRECT_URI,
    silentRedirectUri: process.env.REACT_APP_LOGIN_SILENT_REDIRECT_URI
  },
  logoutUri: process.env.REACT_APP_LOGOUT_URI,
  // TODO: Create a project in Sentry and use the token here
  sentryToken: 'https://7dbc789aca1a4f06bd7badc5d78bdc25@o117480.ingest.sentry.io/5237813'
}
