import React, { FC } from 'react'
import { FormattedMessage } from 'react-intl'
import useSWR from 'swr'
import { isEmpty } from 'lodash'

import { fetcherPost } from 'core/utils/fetch'

import { CardFilter, FilterType } from '..'

import { CardMultipleScores, Placeholder } from 'components'
import { PlaceholderProps } from 'components/Placeholder'
import { ScoreTypes } from 'components/CardMultipleScores'

export type ScoreObject = {
  id: string
  score: number
  type: ScoreTypes
}

interface OperativeCardData {
  link: string
  more: {
    description: string
    id: string
  }[]
  scores: ScoreObject[]
  total: number
}

interface FaultCodesCardProps {
  assetsId: string[]
  tagsId: string[]
  filter: FilterType
  onFilterClick: (filter: CardFilter) => void
}

const FaultCodesCard: FC<FaultCodesCardProps> = ({ assetsId, tagsId, filter, onFilterClick }) => {
  const { data, error, isValidating } = useSWR<OperativeCardData>(['/api/perla-tests/vehicleStatus/faultCodesCard', assetsId, tagsId], url =>
    fetcherPost(url, { assetIds: assetsId, tagIds: tagsId, vehicleOperationCondition: 'DEFAULT' })
  )

  const handleFilterClick = (filter: string) => {
    onFilterClick({
      card: 'faultCodes',
      filter
    })
  }

  const isEmptyData = isEmpty(data)
  const totalScore =
    !isEmptyData && data?.scores
      ? [data?.scores[0].score, data?.scores[1].score].reduce((acc, curr) => {
          return acc + curr
        }, 0)
      : undefined

  return (
    <div style={{ minHeight: '215px', width: '100%', marginLeft: '15px' }}>
      <Placeholder
        short
        contentsName={<FormattedMessage id='vehiclesStatus.faultCodes.placeholder.contentsName' />}
        isEmpty={isEmptyData && !isValidating}
        status={error ? 'error' : ('success' as PlaceholderProps['status'])}>
        <>
          <CardMultipleScores
            id='faultCodes'
            filter={filter}
            loading={isEmptyData}
            scores={!isEmptyData ? data?.scores : undefined}
            title={<FormattedMessage id='vehiclesStatus.faultCodes.card.title' />}
            totalScore={typeof totalScore === 'number' ? totalScore : 0}
            footerDescription={<FormattedMessage id='vehiclesStatus.faultCodes.card.footerDescription' />}
            footerDescriptionClicked={<FormattedMessage id='vehiclesStatus.faultCodes.card.footerDescriptionClicked' />}
            footerDescriptionClickedUnit={
              <FormattedMessage id='vehiclesStatus.faultCodes.card.footerDescriptionClickedUnit' />
            }
            onFilterClick={handleFilterClick}
          />
        </>
      </Placeholder>
    </div>
  )
}

export default FaultCodesCard
