import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { accessToken } from 'configuration/tokenHandling/accessToken'

import { AutoSuggest } from 'rio-uikit';

const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

const customAcessToken = accessToken.getAccessToken()
console.log(customAcessToken)

var head = {
  headers: {
    Authorization: `Bearer ${customAcessToken}`
  }
}

const SimpleAutoSuggestExample = ({ drivers, setDriver, data, assetId }) => {
  const [value, setValue] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    const getDrivers = async () => {
      const res = await axios.get(`${baseURL}/driver?assetId ${assetId}`, head)
      console.log(res, 'GETDRIVERS')
    }
    getDrivers()

  }, [assetId])


  useEffect(() => {
    if (data) {
      setValue(data)
    }
  }, [data])

  const handleSuggestionsFetchRequested = result => {
    const newValue = result.value;
    setValue(newValue);
    setSuggestions(drivers.filter(option => option?.display_name?.toLowerCase()?.includes(newValue?.toLowerCase())));
  };

  const renderSuggestion = suggestion => <span>{suggestion.display_name}</span>;

  const inputProps = {
    placeholder: 'Digite para pesquisar',
    value,
  };

  return (
    <div className='row'>
      <div className='col-sm-10 form-group'>
        <AutoSuggest
          inputProps={inputProps}
          suggestions={suggestions}
          onSuggestionsFetchRequested={handleSuggestionsFetchRequested}
          renderSuggestion={renderSuggestion}
          closeOnSelect={true}
          onSuggestionSelected={(e, i) => {
            setDriver(i.suggestion)
            setValue(i.suggestion.display_name)
          }}
        />
      </div>
    </div>
  );
};

export default SimpleAutoSuggestExample;