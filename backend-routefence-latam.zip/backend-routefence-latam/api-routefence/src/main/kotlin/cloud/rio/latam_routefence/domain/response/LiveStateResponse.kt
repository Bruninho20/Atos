package cloud.rio.latam_routefence.domain.response

data class LiveStateResponse(
    val id: String,
    val assetId: String,
    val occurredAt: String,
    val vehicle: VehicleInfoResponse,
    val position: PositionResponse
)

data class PositionResponse(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double?,
    val accuracy: Double?,
    val altitudeAccuracy: Double?,
    val heading: Double?,
    val speed: Double?,
    val mileage: Double?
)

data class VehicleInfoResponse(
    val vehicleId: String,
    val vehicle: String,
    val identification: String,
    val identificationType: String,
    val brand: String,
    val type: String
)

