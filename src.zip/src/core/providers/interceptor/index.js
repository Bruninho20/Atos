export function onResponseError(error) {
  return Promise.reject(error);
}

export function validateRequest(config) {
  return config;
}
