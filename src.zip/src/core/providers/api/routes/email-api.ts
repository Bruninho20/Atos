import { fetcherAPi } from "../fetcher-api"

const list = (userId: string) => fetcherAPi.get(`/userEmails`)

export const email = {
  list
}
