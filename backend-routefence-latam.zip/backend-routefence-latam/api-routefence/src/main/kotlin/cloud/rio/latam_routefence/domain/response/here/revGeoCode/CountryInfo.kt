package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class CountryInfo(
    val alpha2: String?,
    val alpha3: String?
)
