import React, { useState, useEffect } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container } from './styled'
import { MapToResume } from '../../../components'
import { Row } from 'components/Table'
import { PdisDetailsModel } from '../interfaces/index'
import ResumeSidesheet from '../Sidesheet/index'
import { useHistory } from 'react-router-dom'
import { fetcherGet } from 'core/utils/fetch'
import useSWR from 'swr'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import moment from 'moment'

interface PdisData extends Row {
  data: { data: PdisDetailsModel[] }
  total: number
}

const MapDash: React.FC = () => {
  const history = useHistory()

  const [sidesheetDetais, setSidesheetDetails] = useState<{ isOpen: boolean; data?: PdisDetailsModel }>({
    isOpen: false,
    data: undefined
  })
  const [allPositions, setAllPositions] = useState<any>([])

  const pageSize = 50
  const [data, setData] = useState<any>([])
  const [refreshLocations, setRefreshLocations] = useState(false)
  const [statusCurrent, setStatusCurrent] = useState('')
  console.log(setStatusCurrent)

  const getAssets = async (url: string) => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const { data: trucks } = useSWR('https://api.assets.rio.cloud/assets?embed=(tags)', getAssets)

  const pageNo = 0

  console.log(allPositions, 'ALL POSITIONS')

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  const getAllGeolocation = async () => {
    const res = await axios.get('https://api.asset-history.rio.cloud/live-state/assets?locale=en-GB', head)
    setAllPositions(res.data)
  }

  const getTrips = async () => {
    if (statusCurrent === '') {
      const res = await axios.get(`${baseURL}/trips/resume?${pageSize}=&pageNo=${pageNo}&orderBy=ASC`, head)

      setData([res])

      if (res?.status === 200 || res?.status === 201) {
        setData([res])
      } else {
        console.log('error')
      }
    } else {
      const res = await axios.get(`${baseURL}/trips/resume?${pageSize}=&pageNo=${pageNo}&status=${statusCurrent}`, head)

      if (res.status === 200 || res.status === 201) {
        setData([res])
      } else if (res.statusText !== 'OK') {
        console.log('vazio')
      } else {
        console.log('ERROOOOOOOOOOOOOO')
      }
    }
  }

  useEffect(() => {
    getTrips()
    getAllGeolocation()
  }, [statusCurrent])

  const convertStatusRoute = (status: string): string => {
    switch (status) {
      case 'STARTED':
        return 'Em Andamento'
      case 'SCHEDULED':
        return 'Programada'
      case 'FINISHED':
        return 'Finalizada'
      default:
        return 'Programada'
    }
  }

  setTimeout(() => {
    setRefreshLocations(!refreshLocations)
  }, 20000)

  useEffect(() => {
    if (data[0]?.data?.data?.length >= 1) {
      getAllGeolocation()
    }
  }, [data])

  const rowsPagineted = data?.map((pdisDataPage: PdisData) => {
    return pdisDataPage
      ? pdisDataPage?.data?.data?.map((pdisDataRow: any, index: any) => {
          return {
            ...pdisDataRow,
            index: index.toString(),
            startedAt: moment(pdisDataRow.startedAt).format('DD/MM/yyyy HH:MM'),
            startDateTime: moment(pdisDataRow.startDateTime).format('DD/MM/yyyy HH:MM'),
            originRoute: pdisDataRow?.positionOrigin?.address?.label,
            destinyRoute: pdisDataRow?.positionDestiny?.address?.label,
            routeName: pdisDataRow?.route?.routeName,
            triId: pdisDataRow?.tripId,
            assetId: pdisDataRow?.assetId,
            driverId: pdisDataRow?.driverId,
            routeId: pdisDataRow?.route.routeId,
            status: convertStatusRoute(pdisDataRow?.status),
            originRouteData: pdisDataRow?.positionOrigin,
            destinyRouteData: pdisDataRow?.positionDestiny
          }
        })
      : []
  })

  const handleGoToMap = () => {
    history.push({
      pathname: `/resume-map`
    })
  }

  const handleGoToList = () => {
    history.push({
      pathname: `/resume`
    })
  }

  const handleOpenSidesheet = (open: boolean, data: any) => {
    setSidesheetDetails({
      isOpen: true,
      data
    })
  }

  return (
    <div>
      <ResumeSidesheet
        isOpen={sidesheetDetais.isOpen}
        data={sidesheetDetais.data}
        onClose={() => setSidesheetDetails({ isOpen: false })}
      />
      <Container>
        <MapWrapper>
          <div className='btn-toolbar' style={{ marginLeft: 16, position: 'absolute', right: 55, top: 60, zIndex: 99 }}>
            <div className='TableViewToggles btn-group display-flex flex-row'>
              <button className='btn btn-default btn-icon-only' style={{ width: 50 }} onClick={handleGoToList}>
                <span>Lista</span>
              </button>
              <button className='btn btn-default btn-icon-only active' style={{ width: 50 }} onClick={handleGoToMap}>
                <span>Mapa</span>
              </button>
            </div>
          </div>
          <MapToResume
            data={{ rowsPagineted, allPositions, trucks }}
            handleOpenSidesheet={handleOpenSidesheet}
            openedSidesheet={sidesheetDetais.isOpen}
          />
        </MapWrapper>
      </Container>
    </div>
  )
}

export default injectIntl(MapDash)
