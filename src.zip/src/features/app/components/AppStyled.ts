import styled from 'styled-components'
import media from 'styled-media-query'

import { colors } from 'core/assets/styles'

export const Wrapper = styled.section`
  display: flex;
  overflow: hidden;

  ${media.lessThan('medium')`
    flex-direction: column;
  `}
`

export const StyledMain = styled.main`
  background: ${colors.baseBackground};
  min-height: calc(100vh - 55px);
  position: relative;
  width: 100%;
`
export const StyledMainMap = styled.main`
  background: ${colors.baseBackground};
  min-height: calc(100vh - 55px);
  position: relative;
  width: 100%;
`