import React, { FC } from 'react'
import { WrapperContent, CardContent, Card, Label, Description, Container } from './styled'

interface PropsData {
  data: any
}

const VehicleDetails: FC<PropsData> = ({ data }) => {

  return (
    <WrapperContent>
      <CardContent style={{ borderRadius: 8 }}>
        <Card>
          <span className='rioglyph rioglyph-settings' style={{ fontSize: 30, color: '#878585' }}></span>
          <h6 style={{ color: '#878585' }}>39.444 km</h6>
        </Card>
        <Card>
          <span className='rioglyph rioglyph-speed' style={{ fontSize: 50, color: '#878585' }}></span>
          <h6 style={{ color: '#878585' }}>68 km/h</h6>
        </Card>
      </CardContent>
      <Container>
        <Label>Nome:</Label>
        <Description>Pedro Alvares</Description>
        <Label>Nº Chassi:</Label>
        <Description>764H64K8736652K98P</Description>
      </Container>
      <Container>
        <Label>Endereço:</Label>
        <Description>Rua Marcos Arruda, 458 - Belem - São Paulo - SP</Description>
        <Label>Posição:</Label>
        <Description>-16.76554, -49.88776</Description>
        <Label>Ultima Atualização:</Label>
        <Description>11/02/2023 10:40</Description>
      </Container>
    </WrapperContent>
  )
}
export default VehicleDetails
