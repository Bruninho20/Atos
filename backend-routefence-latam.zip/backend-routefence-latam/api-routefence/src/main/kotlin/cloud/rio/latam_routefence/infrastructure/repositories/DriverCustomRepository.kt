package cloud.rio.latam_routefence.infrastructure.repositories

interface DriverCustomRepository {
    fun getDriversOrderByMostLinkedToAsset(assetId: String): List<String>
}