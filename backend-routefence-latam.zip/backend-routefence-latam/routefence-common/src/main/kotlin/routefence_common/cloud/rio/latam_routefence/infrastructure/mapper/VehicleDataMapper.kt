package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleDataResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.VehicleDataEntity

fun VehicleDataEntity.maptoResponse(decodeChassis: VehicleResponse):VehicleDataResponse{
    return VehicleDataResponse(
        id = id,
        model = model,
        commercialName =commercialName,
        m_m_v= m_m_v,
        renavamCode = renavamCode,
        modelCodes = modelCodes,
        position123 = "${decodeChassis.geographicArea},${decodeChassis.country},${decodeChassis.manufacturer}",
        position4 = decodeChassis.bodywork,
        motor = motor,
        position6 = decodeChassis.safetySystem,
        securitySystemMin = securitySystemMin,
        securitySystemMax = securitySystemMax,
        position7_8 =  decodeChassis.vehicleClass,
        controlDigit =decodeChassis.controlDigit,
        modelYear =decodeChassis.modelYear,
        factoryCode = decodeChassis.factoryCode,
        sequentialProd = decodeChassis.sequentialProd,
        regulatoryWeightKg = regulatoryWeightKg,
        technicalWeightKg = technicalWeightKg,
        firstAxleKg = firstAxleKg,
        secondAxleKg = secondAxleKg,
        thirdAxleKg = thirdAxleKg,
        fourthAxleKg = fourthAxleKg,
        pbtc = pbtc,
        cmt = cmt,
        wheelbase =wheelbase,
        issueType = issueType
    )
}