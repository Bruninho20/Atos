package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.request.MessageRequest
import cloud.rio.latam_routefence.services.SendEmailService
import cloud.rio.latam_routefence.services.SendSmsService
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/dev-utils")
class DevUtilsController(
    private val smsService: SendSmsService,
    private val emailService: SendEmailService
){
    @ResponseStatus(HttpStatus.OK)
    @PostMapping("send-email")
    fun sendEmail(@RequestBody @Valid messageRequest: MessageRequest){
        return emailService.sendEmail(
            messageRequest.recipientList,
            messageRequest.subject,
            messageRequest.content
        )
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("send-sms", produces = ["application/json"], )
    fun sendSms(@RequestBody @Valid smsMessage: MessageRequest){
        return smsService.sendSms(
            smsMessage.recipientList,
            "${smsMessage.subject}: ${smsMessage.content}"
        )
    }
}