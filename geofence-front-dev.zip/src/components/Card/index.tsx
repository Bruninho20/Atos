import React, { FC } from 'react'

import { Body, CardStyled, Header, HeaderTitle, Link } from './styled'

import ButtonMore, { List } from '../ButtonMore'
import { isEmpty } from 'lodash'

export interface CardProps {
  title: string | React.ReactElement
  footerTitle?: string | React.ReactElement
  titleMoreLinks?: List[]
  hasMoreLinks?: boolean
  loading: boolean
  list?: List[]
  footerClicked?: boolean
  hasFooterClick?: boolean
  onFooterClick?: () => void
}

const Card: FC<CardProps & { children?: React.ReactNode }> = ({
  title,
  footerTitle,
  loading,
  footerClicked = false,
  hasFooterClick,
  list,
  titleMoreLinks,
  hasMoreLinks,
  children,
  onFooterClick
}) => {
  return (
    <CardStyled>
      <Header>
        <HeaderTitle>{title}</HeaderTitle>
        {hasMoreLinks && <ButtonMore list={titleMoreLinks || []} disabled={isEmpty(titleMoreLinks)} />}
      </Header>
      <Body>{children}</Body>
      {footerTitle && onFooterClick && hasFooterClick && (
        <div>
          <Link
            disabled={loading}
            clicked={footerClicked}
            label={footerTitle}
            onClick={onFooterClick}
            className='btn-link'
          />
        </div>
      )}
    </CardStyled>
  )
}

export default Card
