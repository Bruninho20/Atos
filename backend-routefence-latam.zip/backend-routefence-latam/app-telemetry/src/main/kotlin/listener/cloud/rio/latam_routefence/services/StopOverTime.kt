package listener.cloud.rio.latam_routefence.services

import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.PointOfInterestEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import listener.cloud.rio.latam_routefence.infrastructure.repositories.TripStopRepository
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripStopEntity
import routefence_common.cloud.rio.latam_routefence.utils.DateFormatter
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

@Service
class StopOverTime(
    private val tripStopRepository: TripStopRepository,
    private val infringementService: InfringementService
) : IInfringible {

    private val logger = LoggerFactory.getLogger(this.javaClass)

    override fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest? {

        if (trip.status == TripStatusEnum.STARTED) {

            if (poiList != null) {
                val stopList = poiList.filter { it.type == PointOfInterestEnum.STOP }

                if (stopList.isNotEmpty()) {
                    val nearestStop = stopList.reduce(PointOfInterestBO.Compare::nearest)
                    val tripStop = tripStopRepository.getByRouteStopAndTrip(nearestStop.id, trip.id)?: return null

                    if (tripStop.checkIn == null) {
                        tripStop.checkIn = DateFormatter.formatUTC(asset.occurredAt)
                        tripStopRepository.save(tripStop)
                    }
                } else {
                    val tripStop = tripStopRepository.getByTripIdAndCheckInAndCheckOut(trip.id) ?: return null

                    if (tripStop.checkIn != null && tripStop.checkOut == null) {

                        val timeLimit = tripStop.checkIn!!
                            .plusHours(tripStop.routeStop!!.stayTime!!.hour.toLong())
                            .plusMinutes(tripStop.routeStop!!.stayTime!!.minute.toLong())


                        if (DateFormatter.formatUTC(asset.occurredAt).isBefore(timeLimit)) {
                            closeTripStop(tripStop, asset.occurredAt)
                        } else {
                            closeTripStop(tripStop, asset.occurredAt)

                            if (tripStop.checkIn != null && tripStop.checkOut != null) {

                                return setInfringement(
                                    asset.occurredAt,
                                    asset.position!!.latitude.toFloat(),
                                    asset.position!!.longitude.toFloat(),
                                    trip.id,
                                    note = timeLimit
                                )
                            }
                        }
                    }
                }
            }
        }
        return null
    }

    private fun setInfringement(
        occurredAt: OffsetDateTime, lat: Float, lng: Float, tripId: String, note: LocalDateTime?
    ): InfringementRequest {
        val fmt =  DateTimeFormatter.ofPattern("HH:mm:ss")

        return InfringementRequest(
            id = null,
            type = InfringementTypeEnum.STOP_OVERTIME,
            note = "Hora limite: ${note!!.format(fmt)} | saída às ${DateFormatter.formatUTC(occurredAt).format(fmt)}",
            startDateTime = note,
            endDateTime = DateFormatter.formatUTC(occurredAt),
            location = GeoPointRequest(null, lat, lng, null),
            trip = tripId

        )
    }

    private fun closeTripStop(tripStop: TripStopEntity, occurredAt: OffsetDateTime) {
        tripStop.checkOut = DateFormatter.formatUTC(occurredAt)
        tripStopRepository.save(tripStop)
    }
}
