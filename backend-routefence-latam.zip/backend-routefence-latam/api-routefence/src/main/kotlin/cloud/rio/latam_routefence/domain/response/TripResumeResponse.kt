package cloud.rio.latam_routefence.domain.response

import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriverDTO
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.AddressResponse

data class TripResumeResponse(
    val tripId: String,
    val status: TripStatusEnum,
    val startDateTime: String,
    val driver: DriverDTO,
    val asset: AssetDTO,
    val startedAt: String?,
    val finishedAt: String?,
    val route: RouteResumeResponse,
    val positionOrigin: PositionOriginResumeResponse,
    val positionDestiny: PositionDestinyResumeResponse
    )

data class RouteResumeResponse(
    val routeId: String,
    val routeName: String
)

data class PositionOriginResumeResponse(
    var lat: Float,
    var long: Float,
    val address: AddressResponse
)

data class PositionDestinyResumeResponse(
    var lat: Float,
    var long: Float,
    val address: AddressResponse
)
