
package listener.cloud.rio.latam_routefence.tenant

import org.aspectj.lang.JoinPoint
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Before
import org.springframework.stereotype.Component
import routefence_common.cloud.rio.latam_routefence.tenant.ServiceAspectBase
import javax.persistence.EntityManager

@Aspect
@Component
class ServiceAspect(em: EntityManager): ServiceAspectBase(em) {

    @Before("execution (* listener.cloud.rio.latam_routefence.services..*.*(..))")
    @Throws(Throwable::class)
    override fun filter(pjp: JoinPoint) {
        super.filter(pjp)
    }
}
