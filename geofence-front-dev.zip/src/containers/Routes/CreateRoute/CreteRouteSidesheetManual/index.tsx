import React, { FC, useState, useEffect } from 'react'
import { InputCurrency } from 'components'
import { Col, Row, Table } from 'react-bootstrap'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import {
  ClearableInput,
  SimpleButtonDropdown,
  Slider,
  Checkbox,
  ExpanderPanel,
  Notification,
  Button,
  DatePicker,
  // AutoSuggest
} from 'rio-uikit'
import { useForm } from 'react-hook-form'
import axios from 'axios'
import moment from 'moment'
import { useHistory } from 'react-router-dom'

interface CreateRouteSidesheetProps {
  handleOpenAddressDialog: (type: string, open: boolean) => void
  handleOpenAddVehiclesDialog: (open: boolean) => void
  handleAddStops: (stops: any) => void
  handleChangeMode: (type: string) => void
  handleUpdateParameters: (routeParameters: any) => void
  data: any
}

const CreateRouteSidesheet: FC<CreateRouteSidesheetProps> = ({
  handleOpenAddressDialog,
  data,
  handleChangeMode,
  handleOpenAddVehiclesDialog,
  handleAddStops,
  handleUpdateParameters
}) => {
  const history = useHistory()
  const { setValue, getValues, handleSubmit, register } = useForm()

  const [limitMeters, setLimitMeters] = useState(0)
  const [limitMetersPark, setLimitMetersPark] = useState(0)
  const [totalCostsValue, setTotalCostsValue] = useState(0)
  const [stopArray, setStopArray] = useState<any>(data?.allStops)
  const [nameStopRecent, setNameStopRecent] = useState('')
  const [typeStopRecent, setTypeStopRecent] = useState('')
  const [stopTime, setStopTime] = useState('')
  // const [startTime, setStartTime] = useState('')
  const [trafficConditions, setTrafficConditions] = useState(false)
  const [avoidToll, setAvoidToll] = useState(false)
  const [avoidRoad, setAvoidRoad] = useState(false)
  const [activeRoute, setActiveRoute] = useState(true)
  // const [valueAddress, setValueAddress] = useState<any>('')
  // const [suggestions, setSuggestions] = useState<any>([])
  const [ignoreTrafficRestrictions, setIgnoreTraffic] = useState(false)
  const [vehicleSelected, setVehicleSelected] = useState('')
  const [addressStopRecent, setAddressStopRecent] = useState('')
  const [registerData, setRegisterData] = useState<any>({
    routeName: '',
    originRoute: {
      lat: '',
      lng: '',
      address: ''
    },
    destinyRoute: {
      lat: '',
      lng: '',
      address: ''
    },
    rangeToleranceLimit: ' ',
    // startDateTime: startTime,
    stops: [],
    roadParameters: {
      trafficConditions: false,
      avoidToll: false,
      avoidRoad: false,
      ignoreTrafficRestrictions: false
    },
    vehicleVocationalInfo: {
      type: ' ',
      comTotal: ' ',
      height: ' ',
      width: ' ',
      maxWeight: ' ',
      maxWeightAxle: ' ',
      numberAxle: ' ',
      trailerAxle: ' ',
      pollutantClass: ' ',
      dangerClassification: ' '
    },
    costs: {
      tollValue: ' ',
      operativeCosts: ' ',
      fuelAverageCosts: ' ',
      averageConsume: ' ',
      totalCosts: ' '
    }
  })

  // const simpleSuggestions = Array.from({ length: 10 }, (_, index) => ({
  //   label: `Suggestion ${index + 1}`
  // }))

  // const handleSuggestionsFetchRequested = (result: any) => {
  //   const newValue = result.value
  //   setValueAddress(newValue)
  //   setSuggestions(simpleSuggestions.filter((suggestion: any) => suggestion.label.includes(newValue)))
  // }

  // const renderSuggestion = (suggestion: any) => <span>{suggestion.label}</span>

  // const inputProps = {
  //   placeholder: 'Start typing ...',
  //   valueAddress
  // }

  console.log(setRegisterData)

  useEffect(() => {
    setAddressStopRecent(data?.stops?.address?.label)
  }, [data.stops])

  const handleSaveStop = () => {
    const body = {
      name: nameStopRecent,
      category: getValues('stopCategory'),
      rangeLimitMeters: limitMeters,
      stayTime: moment(stopTime).format('HH:mm'),
      position: {
        lat: data?.stops?.position.lat,
        lng: data?.stops?.position.lng,
        address: data?.stops?.address
      }
    }

    handleAddStops([...stopArray, body])

    setStopArray([...stopArray, body])
    setNameStopRecent('')
    setLimitMeters(0)
    setAddressStopRecent('')
    setTypeStopRecent('')
    setStopTime('00:00')
  }

  useEffect(() => {
    setStopArray(data?.allStops)
  }, [data?.allStops])

  const cloneObject = (object: any) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  const handleDeleteStopRow = (index: any) => {
    const cloneStopArray = cloneObject(stopArray)
    cloneStopArray.splice(index, 1)
    setStopArray(cloneStopArray)
    handleAddStops(cloneStopArray)
  }

  const handleSaveRoute = async () => {
    const body = {
      ...registerData,
      routeName: getValues('routeName'),
      originRoute: {
        lat: data?.originRouteData.lat,
        lng: data?.originRouteData.lng,
        addressStop: data?.originRouteData.addressStop
      },
      destinyRoute: {
        lat: data?.destinyRouteData.lat,
        lng: data?.destinyRouteData.lng,
        addressStop: data?.destinyRouteData.addressStop
      },
      status: activeRoute,
      // startDateTime: moment(startTime).subtract(3, 'hours').toISOString(),
      rangeToleranceLimit: limitMetersPark,
      stops: stopArray,
      roadParameters: {
        trafficConditions: trafficConditions,
        avoidToll: avoidToll,
        avoidRoad: avoidRoad,
        ignoreTrafficRestrictions: ignoreTrafficRestrictions
      },
      vehicleVocationalInfo: {
        type: vehicleSelected,
        comTotal: getValues('comTotal'),
        height: getValues('height'),
        width: getValues('width'),
        maxWeight: getValues('maxWeight'),
        maxWeightAxle: getValues('maxWeightAxle'),
        numberAxle: getValues('numberAxle'),
        trailerAxle: getValues('trailerAxle'),
        pollutantClass: getValues('pollutantClass'),
        dangerClassification: getValues('dangerClassification')
      },
      costs: {
        tollValue: getValues('tollValue'),
        operativeCosts: getValues('operativeCosts'),
        fuelAverageCosts: getValues('fuelAverageCosts'),
        averageConsume: getValues('averageConsume'),
        totalCosts: totalCostsValue
      },
      linkedVehicles: data?.linkedVehicles.map((value: any) => {
        return {
          assetId: value.id,
          driverId: value.driverSelected.id,
          startDateTime: value.startDateTime
        }
      }),
      responseHere: data?.responseHere
    }

    const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

    const customAcessToken = accessToken.getAccessToken()
    console.log(customAcessToken)
    var head = {
      headers: {
        Authorization: `Bearer ${customAcessToken}`
      }
    }

    try {
      const res = await axios.post(`${baseURL}/routes/`, body, head)
      if (res.status === 200 || res.status === 201) {
        Notification.success('Rota criada com sucesso')
        history.push(`/pdis`)
      } else {
        Notification.error('Houve um erro ao criar a rota')
      }
    } catch (error) {
      console.log(error, 'error')
    }
  }

  useEffect(() => {
    if (data?.linkedVehicles?.length > 0) {
      setActiveRoute(true)
    } else if (data?.linkedVehicles?.length < 1) {
      setActiveRoute(false)
    }
  }, [data])

  const onSubmit = () => {}

  const DummyRowDropdown = () => (
    <span>
      <SimpleButtonDropdown
        title={<span className='rioglyph rioglyph-option-vertical' />}
        bsStyle='link'
        iconOnly
        disabled
        items={[
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-pencil margin-right-10' />
                <span>Edit</span>
              </div>
            )
          },
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-duplicate margin-right-10' />
                <span>Duplicate</span>
              </div>
            )
          },
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-trash margin-right-10' />
                <span>Delete</span>
              </div>
            )
          }
        ]}
      />
    </span>
  )

  // const startTimeColapse = (
  //   <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
  //     <span style={{ fontSize: 14, fontWeight: 600 }}>Insira o horário</span>
  //     <DatePicker
  //       value={startTime}
  //       onChange={(e: any) => setStartTime(e)}
  //       inputProps={{ placeholder: 'Select Date' }}
  //     />
  //   </Row>
  // )

  // const categoryOptions = [
  //   { id: '1', label: 'DEALER' },
  //   { id: '2', label: 'ALMOÇO / DESCANSO' },
  //   { id: '3', label: 'FIM DE JORNADA DE TRABALHO' },
  //   { id: '4', label: 'CARGA / DESCARGA' }
  // ]

  const handleCalculateTotalCosts = () => {
    const tollValue = Number(getValues('tollValue').replace(',', '.'))
    const operativeCosts = Number(getValues('operativeCosts').replace(',', '.'))
    // const fuelAverageCosts = getValues('fuelAverageCosts')
    // const averageConsume = getValues('averageConsume')
    const total = tollValue + operativeCosts
    setTotalCostsValue(total)
  }

  const setStop = (
    <Row style={{ padding: 15 }}>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Nome Parada</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <ClearableInput value={nameStopRecent} onChange={(value: string) => setNameStopRecent(value)} />
        </div>
      </Row>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Categoria</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <select
            className='form-control'
            id='exampleFormControlSelect1'
            value={typeStopRecent}
            onChange={(e: any) => {
              setValue('stopCategory', e.target.value)
              setTypeStopRecent(e.target.value)
            }}>
            <option>Selecione</option>
            <option value='DEALER'>DEALER</option>
            <option value='LUNCH_REST'>ALMOÇO / DESCANSO</option>
            <option value='END_OF_DAY'>FIM DE JORNADA DE TRABALHO</option>
            <option value='LOAD_UNLOAD'>CARGA / DESCARGA</option>
          </select>
        </div>
      </Row>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Endereço</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <input
            {...register('address', {
              required: {
                value: true,
                message: 'aaaa'
              },
              minLength: {
                value: 9,
                message: 'aaaa'
              }
            })}
            value={addressStopRecent}
            className='form-control'
            // onChange={(value: string) => console.log(value)}
            onClick={() => handleOpenAddressDialog('stops', true)}
          />
        </div>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Raio</span>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Col md='7'>
          <Slider
            value={limitMeters}
            onDragEnd={(e: any) => {
              setLimitMeters(e)
            }}
            className='margin-bottom-40'
            minValue={0}
            maxValue={300}
            step={5}
          />
        </Col>
        <Col md='5'>
          <div className={'input-group'}>
            <ClearableInput onChange={(value: number) => setLimitMeters(value)} value={limitMeters} />
            <span className={'input-group-addon'}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
            </span>
          </div>
        </Col>
        {/* <Col md='4'>
          <div className={'input-group'}>
            <ClearableInput
              value={limitMeters}
              onChange={(value: ) => console.log(value, 'limiteeeeeeeeeeeeee')}
            />
            <span className={'input-group-addon'}>
              <span aria-hidden={'true'}>m</span>
            </span>
          </div>
        </Col> */}
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Tempo de Permanência</span>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <DatePicker value={stopTime} onChange={(e: any) => setStopTime(e)} dateFormat={false} />
      </Row>
      <Row style={{ paddingLeft: 20, display: 'flex', justifyContent: 'space-between', marginTop: 30 }}>
        <Col md='6'>
          <Button onClick={handleSaveStop}>
            <span>Adicionar Parada</span>
          </Button>
        </Col>
      </Row>
    </Row>
  )

  useEffect(() => {
    handleUpdateParameters({
      trafficConditions: trafficConditions,
      avoidToll: avoidToll,
      avoidRoad: avoidRoad,
      ignoreTrafficRestrictions: ignoreTrafficRestrictions
    })
  }, [trafficConditions, avoidToll, avoidRoad, ignoreTrafficRestrictions])

  const rangeOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox inline checked={trafficConditions} onClick={() => setTrafficConditions(!trafficConditions)}>
            Considerar condições de transito
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox inline checked={avoidToll} onClick={() => setAvoidToll(!avoidToll)}>
            Evitar pedágio
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox inline checked={avoidRoad} onClick={() => setAvoidRoad(!avoidRoad)}>
            Evitar Rodovia
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox
            inline
            checked={ignoreTrafficRestrictions}
            onClick={() => setIgnoreTraffic(!ignoreTrafficRestrictions)}>
            Ignorar restrições em torno dos veículos
          </Checkbox>
        </Row>
      </Row>
    </>
  )

  console.log(data?.linkedVehicles, 'data?.linkedVehicles data?.linkedVehicles')

  const linkedVehicles = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10 }}>
          {data?.linkedVehicles[0]?.length < 1 ? (
            <div>
              <span>Não tem veículos</span>
            </div>
          ) : (
            <Table striped bordered hover>
              <thead style={{ border: '1px solid' }}>
                <tr>
                  <th style={{ fontSize: 14, fontWeight: 'bold' }}>Nome</th>
                  <th style={{ fontSize: 14, fontWeight: 'bold' }}>Motorista</th>
                </tr>
              </thead>
              <tbody>
                {data?.linkedVehicles[0]?.map((item: any) => {
                  console.log(item, 'ITEM NO SIDESHEET')
                  return (
                    <tr>
                      <td style={{ fontSize: 14 }}>{item?.name}</td>
                      <td style={{ fontSize: 14 }}>{item?.driverSelected?.name}</td>
                    </tr>
                  )
                })}
              </tbody>
            </Table>
          )}
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Button onClick={() => handleOpenAddVehiclesDialog(true)}>Adicionar veículo</Button>
        </Row>
      </Row>
    </>
  )

  const vehicleOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Tipo de Veículo</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              id='exampleFormControlSelect1'
              value={vehicleSelected}
              onChange={(e: any) => setVehicleSelected(e.target.value)}>
              <option>Selecione</option>
              <option value='CAR'>CAR</option>
              <option value='TRUCK'>TRUCK</option>
              <option value='TRAILER'>TRAILER</option>
              <option value='VAN'>VAN</option>
            </select>
          </div>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Com. total</span>
            <div className={'input-group'}>
              <ClearableInput onChange={(value: string) => setValue('comTotal', value)} value={getValues('type')} />
            </div>
          </Col>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Altura</span>
            <div className={'input-group'}>
              <ClearableInput onChange={(value: string) => setValue('height', value)} value={getValues('type')} />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
              </span>
            </div>
          </Col>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Largura</span>
            <div className={'input-group'}>
              <ClearableInput onChange={(value: string) => setValue('width', value)} value={getValues('type')} />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
              </span>
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Peso max.</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) => setValue('maxWeight', value)}
                value={getValues('maxWeight')}
                type='number'
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>kg</span>
              </span>
            </div>
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Carga max. eixo</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) => setValue('maxWeightAxle', value)}
                value={getValues('maxWeightAxle')}
                type='number'
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>kg</span>
              </span>
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Eixo de veículos</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) => setValue('numberAxle', value)}
                value={getValues('numberAxle')}
                type='number'
              />
            </div>
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Eixo de reboque</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) => setValue('trailerAxle', value)}
                value={getValues('trailerAxle')}
              />
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Classe de emissão de poluentes</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              onChange={(e: any) => setValue('pollutantClass', e.target.value)}
              value={getValues('pollutantClass')}>
              <option>Selecione</option>
              <option value='EURO I'>EURO I</option>
              <option value='EURO II'>EURO II</option>
              <option value='EURO III'>EURO III</option>
              <option value='EURO IV'>EURO IV</option>
              <option value='EURO V'>EURO V</option>
              <option value='EURO VI'>EURO VI</option>
              <option value='EURO EEV'>EURO EEV</option>
              <option value='ELETRIC VEHICLES I'>VEÍCULO ELÉTRICO</option>
            </select>
          </div>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Classificação de perigos</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              value={getValues('dangerClassification')}
              onChange={(e: any) => setValue('dangerClassification', e.target.value)}>
              <option>Selecione</option>
              <option value='BAIXO'>BAIXO</option>
              <option value='MÉDIO'>MÉDIO</option>
              <option value='ALTO'>ALTO</option>
            </select>
          </div>
          <div className={'input-group'}></div>
        </Row>
      </Row>
    </>
  )

  const costsOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Pedágio</span>
            <InputCurrency
              id='tollValue'
              name='tollValue'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              onValueChange={value => setValue('tollValue', value)}
            />
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Custo operacional</span>
            <InputCurrency
              id='operativeCosts'
              name='operativeCosts'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              onValueChange={value => setValue('operativeCosts', value)}
            />
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='5'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Combustivel Custo médio</span>
            <InputCurrency
              id='fuelAverageCosts'
              name='fuelAverageCosts'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              onValueChange={value => setValue('fuelAverageCosts', value)}
            />
          </Col>
          <Col md='2' style={{ marginTop: 40 }}>
            <span style={{ fontSize: 18, fontWeight: 600 }}>
              <b>X </b>1/
            </span>
          </Col>
          <Col md='5' style={{ marginTop: 20 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Consumo médio</span>
            <InputCurrency
              id='averageConsume'
              name='averageConsume'
              type='text'
              suffix=' km/l'
              defaultValue={0}
              decimalsLimit={0}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              onValueChange={(value: any) => setValue('averageConsume', value)}
            />
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Custo Total</span>
          <InputCurrency
            id='totalCosts'
            name='totalCosts'
            type='text'
            prefix='R$ '
            decimalsLimit={2}
            allowDecimals={true}
            value={totalCostsValue}
            decimalSeparator=','
            groupSeparator='.'
            // onValueChange={(value: any) => setValue('totalCosts', value)}
          />
        </Row>
        <Row style={{ display: 'flex', justifyContent: 'space-between', marginTop: 30 }}>
          <Col md='6'>
            <Button onClick={handleCalculateTotalCosts}>
              <span>Calcular</span>
            </Button>
          </Col>
        </Row>
      </Row>
    </>
  )

  return (
    <>
      <div
        style={{
          padding: 10,
          backgroundColor: 'white',
          height: 900,
          overflow: 'scroll'
        }}>
        <Row style={{ borderBottom: '1px solid' }}>
          <Col md='8'>
            <span style={{ marginLeft: 5, marginTop: 10, marginBottom: 5, fontSize: 20 }}>
              <b>NOVA ROTA</b>
            </span>
          </Col>
          <Col md='4'>
            <div className='btn-toolbar' style={{ marginBottom: 4 }}>
              <div className='TableViewToggles btn-group display-flex flex-row'>
                <button
                  className='btn btn-default btn-icon-only '
                  style={{ width: 50 }}
                  onClick={() => handleChangeMode('auto')}>
                  <span>Auto</span>
                </button>
                <button
                  className='btn btn-default btn-icon-only active'
                  style={{ width: 50 }}
                  onClick={() => handleChangeMode('manual')}>
                  <span>Manual</span>
                </button>
              </div>
            </div>
          </Col>
        </Row>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Row>
            <Col style={{ padding: 15, overflow: 'scroll' }}>
              <span style={{ fontSize: 16, fontWeight: 600 }}>Nome da Rota</span>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 10 }}>
                <div className={'input-group'}>
                  <ClearableInput
                    onChange={(value: string) => setValue('routeName', value)}
                    value={getValues('routeName')}
                  />
                </div>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                {/* <AutoSuggest
                  inputProps={inputProps}
                  suggestions={suggestions}
                  noItemMessage='This does not look like anything to me'
                  onSuggestionsFetchRequested={handleSuggestionsFetchRequested}
                  renderSuggestion={renderSuggestion}
                  openOnFocus
                /> */}
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <div className={'input-group'}>
                  <span className={'input-group-addon'}>
                    <span className={'rioglyph rioglyph-time-alt'} aria-hidden={'true'}></span>
                  </span>
                  <input
                    {...register('origin.address', {
                      required: {
                        value: true,
                        message: 'aaaa'
                      },
                      minLength: {
                        value: 9,
                        message: 'aaaa'
                      }
                    })}
                    value={data?.originRouteData?.addressStop?.label}
                    className='form-control'
                    placeholder={'Encontre Saída'}
                    // onChange={(value: string) => console.log(value)}
                    onClick={() => handleOpenAddressDialog('originRoute', true)}
                  />
                </div>
              </Row>

              {stopArray.map((value: any, index: any) => {
                return (
                  <Row style={{ marginBottom: 10 }}>
                    <Col md='1'>
                      <DummyRowDropdown />
                    </Col>
                    <Col md='11' style={{ marginRight: -5 }}>
                      <div style={{ display: 'flex', flexDirection: 'row' }}>
                        <div className={'input-group'} style={{ width: '90%' }}>
                          <span className={'input-group-addon'}>
                            <span className={'rioglyph rioglyph-arrow-down'} aria-hidden={'true'}></span>
                          </span>
                          <input
                            value={value?.position?.address?.label}
                            className='form-control'
                            disabled
                            style={{ borderRadius: 7 }}
                          />
                        </div>
                        <div
                          style={{ display: 'flex', alignContent: 'center', justifyContent: 'center', width: '10%' }}>
                          <span
                            style={{ fontSize: 20, cursor: 'pointer', marginTop: 5 }}
                            onClick={() => handleDeleteStopRow(index)}
                            className={'rioglyph rioglyph-trash'}
                            aria-hidden={'true'}></span>
                        </div>
                      </div>
                    </Col>
                  </Row>
                )
              })}

              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <div className={'input-group'}>
                  <span className={'input-group-addon'}>
                    <span className={'rioglyph rioglyph-drive-history'} aria-hidden={'true'}></span>
                  </span>
                  <input
                    value={data?.destinyRouteData?.addressStop?.label}
                    className='form-control'
                    placeholder={'Encontre Destino'}
                    // onChange={(value: string) => console.log(value)}
                    onClick={() => handleOpenAddressDialog('destinyRoute', true)}
                  />
                </div>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Tolerância de Desvio</span>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <Col md='7'>
                  <Slider
                    value={limitMetersPark}
                    className='margin-bottom-40'
                    onDragEnd={(e: any) => {
                      setLimitMetersPark(e)
                    }}
                    minValue={0}
                    maxValue={300}
                    step={5}
                  />
                </Col>
                <Col md='5'>
                  <div className={'input-group'}>
                    <ClearableInput onChange={(value: number) => setLimitMetersPark(value)} value={limitMetersPark} />
                    <span className={'input-group-addon'}>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
                    </span>
                  </div>
                </Col>
              </Row>
              <ExpanderPanel
                title={<span style={{ fontSize: 16, fontWeight: 600 }}>Parada</span>}
                iconLeft
                bsStyle='separator'>
                {(open: any) => {
                  return setStop
                }}
              </ExpanderPanel>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <span style={{ fontSize: 20 }}>Opções</span>
              </Row>
              {/* <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Hora da Partida</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return startTimeColapse
                  }}
                </ExpanderPanel>
              </Row> */}
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Faixa</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return rangeOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Veículo</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return vehicleOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Custos</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return costsOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Veículos vinculados a rota</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return linkedVehicles
                  }}
                </ExpanderPanel>
              </Row>
              <Row
                style={{
                  paddingLeft: 20,
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginTop: 30
                }}>
                <Col md='2'>
                  <Checkbox onClick={() => setActiveRoute(!activeRoute)} checked={activeRoute}>
                    Ativo
                  </Checkbox>
                </Col>
                <Col md='12' style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <Button onClick={handleSaveRoute}>
                    <span>Criar Routefence</span>
                  </Button>
                </Col>
              </Row>
              <Row style={{ marginBottom: 50, paddingLeft: 37, paddingRight: 10 }}></Row>
            </Col>
          </Row>
        </form>
      </div>
    </>
  )
}

export default CreateRouteSidesheet
