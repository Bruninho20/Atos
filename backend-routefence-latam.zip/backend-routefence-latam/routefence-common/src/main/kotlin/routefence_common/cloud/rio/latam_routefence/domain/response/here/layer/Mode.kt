package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Mode(
    @JsonProperty("type") var type: String?,
    @JsonProperty("transportModes") var transportModes: Collection<String>?,
    @JsonProperty("trafficMode") var trafficMode: String?
)