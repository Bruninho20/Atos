package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.RangeRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.RangeResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RangeEntity

fun RangeRequest.mapToEntity(): RangeEntity {
    return RangeEntity (
        trafficConditions = this.trafficConditions!!.toBoolean(),
        avoidToll = this.avoidToll!!.toBoolean(),
        avoidRoad = this.avoidRoad!!.toBoolean(),
        ignoreTrafficRestrictions = this.ignoreTrafficRestrictions!!.toBoolean()
    )
}

fun RangeEntity.mapToResponse() : RangeResponse {
    return RangeResponse(
        id = this.id,
        trafficConditions = this.trafficConditions.toString(),
        avoidToll = this.avoidToll.toString(),
        avoidRoad = this.avoidRoad.toString(),
        ignoreTrafficRestrictions = this.ignoreTrafficRestrictions.toString()
    )
}

fun RangeEntity?.copyFromRequest(req: RangeRequest?) : RangeEntity? {
    req?.trafficConditions?.let { this?.trafficConditions = it.toBoolean() }
    req?.avoidToll?.let { this?.avoidToll = it.toBoolean() }
    req?.avoidRoad?.let { this?.avoidRoad = it.toBoolean() }
    req?.ignoreTrafficRestrictions?.let { this?.ignoreTrafficRestrictions = it.toBoolean() }

    return this
}

fun RangeRequest.mapToDuplicatedEntity(rangeEntity: RangeEntity?): RangeEntity{
    return RangeEntity(
        trafficConditions = if(this.trafficConditions == null) rangeEntity?.trafficConditions else this.trafficConditions.toBoolean(),
        avoidRoad = if(this.avoidRoad == null) rangeEntity?.avoidRoad else this.avoidRoad.toBoolean(),
        avoidToll = if(this.avoidToll == null) rangeEntity?.avoidToll else this.avoidToll.toBoolean(),
        ignoreTrafficRestrictions = if(this.ignoreTrafficRestrictions == null) rangeEntity?.ignoreTrafficRestrictions else this.ignoreTrafficRestrictions.toBoolean()
    )
}