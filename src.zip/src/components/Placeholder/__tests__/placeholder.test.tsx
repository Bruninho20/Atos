import React from 'react';
import { cleanup } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Placeholder } from 'components';
import renderWithReactIntl from 'renderWithReactIntl';

afterEach(cleanup);

it('should render child when sucess and is not empty', () => {
  const status = 'success';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={false} contentsName="dados">
      <div>
        <p>Content is loadead</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeFalsy();
  expect(queryByText('Content is loadead')).toBeTruthy();
  expect(queryByText('Ops! Algo deu errado')).toBeFalsy();
});

it('should render specific message when sucess but is empty', () => {
  const status = 'success';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={true} contentsName="dados">
      <div>
        <p>Content is loadead</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeTruthy();
  expect(queryByText('Content is loadead')).toBeFalsy();
  expect(queryByText('Ops! Algo deu errado')).toBeFalsy();
});

it('should render error message when status error and is not empty', () => {
  const status = 'error';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={false} contentsName="dados">
      <div>
        <p>Content is loadead</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeFalsy();
  expect(queryByText('Content is loadead')).toBeFalsy();
  expect(queryByText('Ops! Algo deu errado')).toBeTruthy();
});

it('should render error message when status error and is empty', () => {
  const status = 'error';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={true} contentsName="dados">
      <div>
        <p>Content is loadead</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeFalsy();
  expect(queryByText('Content is loadead')).toBeFalsy();
  expect(queryByText('Ops! Algo deu errado')).toBeTruthy();
});

it('should render the content when status is loading and is empty', () => {
  const status = 'loading';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={true} contentsName="dados">
      <div>
        <p>Content with skeleton is loading</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeFalsy();
  expect(queryByText('Content with skeleton is loading')).toBeTruthy();
  expect(queryByText('Ops! Algo deu errado')).toBeFalsy();
});

it('should render the content when status is loading and is empty', () => {
  const status = 'loading';
  const { queryByText } = renderWithReactIntl(
    <Placeholder status={status} isEmpty={true} contentsName="dados">
      <div>
        <p>Content with skeleton is loading</p>
      </div>
    </Placeholder>
  );

  expect(queryByText('Não existem dados neste período')).toBeFalsy();
  expect(queryByText('Content with skeleton is loading')).toBeTruthy();
  expect(queryByText('Ops! Algo deu errado')).toBeFalsy();
});
