package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Section (
    @JsonProperty("id") val id: String?,
    @JsonProperty("type") val type: String?,
    @JsonProperty("actions") val actions: List<Action>?,
    @JsonProperty("departure") val departure: Arrival?,
    @JsonProperty("arrival") val arrival: Arrival?,
    @JsonProperty("summary") val summary: Summary?,
    @JsonProperty("polyline") val polyline: String?,
    @JsonProperty("language") val language: String?,
    @JsonProperty("transport") val transport: Transport?
)
