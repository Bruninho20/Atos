package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.AssetApi
import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import cloud.rio.latam_routefence.services.AssetService
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest

@RestController
class AssetController(private val assetService: AssetService): AssetApi {

   override fun assetsList(request: HttpServletRequest): List<AssetDTO> {
        return assetService.list(request).values.toList().sortedBy { it.name }
    }
}