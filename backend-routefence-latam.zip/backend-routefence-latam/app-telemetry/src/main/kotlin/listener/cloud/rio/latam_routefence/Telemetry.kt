package listener.cloud.rio.latam_routefence

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.WebApplicationType
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.boot.builder.SpringApplicationBuilder
import org.springframework.context.annotation.ComponentScan

@ComponentScan
@EntityScan("routefence_common.cloud.rio.latam_routefence.infrastructure.entity")
@EnableAutoConfiguration
class Telemetry {

    private val logger: Logger = LoggerFactory.getLogger(javaClass)

    fun initScan(args: Array<String>) {
        try {
            val configurableApplicationContext = SpringApplicationBuilder(AssetIotEventListener::class.java)
                .web(WebApplicationType.NONE)
                .run(*args)

            configurableApplicationContext.getBean(AssetIotEventListener::class.java)

            while (true) {
                Thread.sleep(36000)
            }
        } catch (e: Exception) {
            logger.error("Error while trying to start the Telemetry Listener: ${e.message} || ${e.cause}")
        }
    }
}
