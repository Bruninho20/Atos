package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import routefence_common.cloud.rio.latam_routefence.domain.enums.ScheduleLinkSendingTypeEnum
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "TB_SCHEDULED_MESSAGES_WITH_LINK")
data class ScheduledMessagesWithLinkEntity(

    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    override var accountId: String = "",

    @Column(name = "TRIP_ID")
    var tripId: String,

    @Column(name = "TYPE")
    @Enumerated(EnumType.STRING)
    var type: ScheduleLinkSendingTypeEnum?,

    @Column(name = "MESSAGE")
    var message: String?,

    @Column(name = "RECIPIENT")
    var recipient: String?,

    @Column(name = "TRIES")
    var tries: Int,

    @Column(name = "LAST_TRY_DATETIME")
    var lastTryDateTime: LocalDateTime?,

    @Column(name = "SEND_DATETIME")
    var sendDateTime: LocalDateTime?,

    @Column(name = "SENT_DATETIME")
    var sentDateTime: LocalDateTime?,

    @Column(name = "SENT")
    var sent: Boolean = false

): AccountTenantEntity(accountId)


