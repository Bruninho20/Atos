import React, { FC, useContext, useState } from 'react'
import { injectIntl, Intl } from 'react-intl'
// import { isEmpty } from 'lodash'
import DashboardContext from 'core/DashboardContext'
// import { DEFAULT_LOCALE } from 'configuration/lang/lang'
import { Layout } from 'components'
import PdisTable from './PdisTable'
import { Period } from 'components/DateTimeFilter'
import { DashboardWrapper } from './styled'

const Dashboard: FC<{ intl: Intl }> = ({ intl }) => {
  const { assets, tags } = useContext(DashboardContext)

  const [dateTime] = useState<Period>({
    from: '',
    to: ''
  })

  // const handleChangeDateTime = (period: Period) => {
  //   setDateTime(period)
  // }

  return (
    <Layout.Wrapper>
      <DashboardWrapper>
        <div style={{ display: 'none' }}>
          {/* <DateTimeFilter
            label={<FormattedMessage id='datetime.label' />}
            locale={intl?.locale ? intl.locale : DEFAULT_LOCALE}
            textToday={<FormattedMessage id='datetime.textToday' />}
            textLastWeek={<FormattedMessage id='datetime.textLastWeek' />}
            textLastMonth={<FormattedMessage id='datetime.textLastMonth' />}
            textCustom={<FormattedMessage id='datetime.textCustom' />}
            textApply={<FormattedMessage id='datetime.textApply' />}
            textCancel={<FormattedMessage id='datetime.textCancel' />}
            onBoarding={{
              title: intl.formatMessage({ id: 'datetime.onboarding.title' }),
              content: intl.formatMessage({ id: 'datetime.onboarding.content' })
            }}
            onChangeDate={handleChangeDateTime}
          /> */}
        </div>
        <PdisTable assetsId={assets} tagsId={tags} dateTime={dateTime} />
        {/* {dateTime.from !== '' && dateTime.to !== '' && (!isEmpty(assets) || !isEmpty(tags)) ? (
          <PdisTable assetsId={assets} tagsId={tags} dateTime={dateTime} />
        ) : (
          <Welcome
            title={<FormattedMessage id='welcome.title' />}
            description={<FormattedMessage id='welcome.description' />}
          />
        )} */}
      </DashboardWrapper>
    </Layout.Wrapper>
  )
}

export default injectIntl(Dashboard)
