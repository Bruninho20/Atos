import React, { FC, useEffect, useState } from 'react'
import { SideSheetResume } from 'components'
import RouteDetails from './RouteDetails'
import VehicleDetails from './VehicleDetails'
import TripDetails from './TripDetails'
import InfractionDetails from './InfractionDetails'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'

const ResumeSidesheet: FC<{
  isOpen: boolean
  data?: any
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, data, onClose }) => {
  const [type, setType] = useState('trip')
  const [title, setTitle] = useState('Histórico da Viagem')
  const [routeData, setRouteData] = useState<any>([])
  const [infractionsData, setInfractionsData] = useState<any>([])

  console.log(infractionsData, 'infractionsData NO SIDESHEET')

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  }

  const getRouteData = async () => {
    const res = await axios.get(`${baseURL}/routes/${data?.routeId}`, head)
    setRouteData([res.data])
  }

  const getInfractionsData = async () => {
    const res = await axios.get(`${baseURL}/infringements/${data?.tripId}`, head)
    setInfractionsData([res.data])
  }

  useEffect(() => {
    if (data?.routeId !== undefined) {
      getRouteData()
      getInfractionsData()
    }
  }, [data])

  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  const handleSetType = (e: string) => {
    setType(e)
    if (e === 'route') {
      setTitle(`Detalhes da Rota`)
    } else if (e === 'trip') {
      setTitle(`Histórico da Viagem`)
    } else if (e === 'infraction') {
      setTitle(`Histórico de Infrações`)
    } else {
      setTitle(`Detalhes do Veículo`)
    }
  }

  return (
    <>
      <SideSheetResume
        modal
        width='480px'
        padding='0'
        open={isOpen}
        title={title}
        onClick={() => handleOnClose(false)}
        onClickType={handleSetType}>
        {type === 'route' ? (
          <RouteDetails data={routeData[0]} />
        ) : type === 'trip' ? (
          <TripDetails data={data} />
        ) : type === 'vehicle' ? (
          <VehicleDetails data={data} />
        ) : (
          <InfractionDetails data={infractionsData} tripData={data} />
        )}
      </SideSheetResume>
    </>
  )
}

export default ResumeSidesheet
