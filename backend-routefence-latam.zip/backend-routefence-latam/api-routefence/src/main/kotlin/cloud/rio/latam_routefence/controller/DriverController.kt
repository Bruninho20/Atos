package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriverDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriversDTO
import cloud.rio.latam_routefence.domain.api.DriverApi
import cloud.rio.latam_routefence.services.DriverService
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest

@RestController
 class DriverController(private val driverService: DriverService) : DriverApi {
    override fun getDrivers(request: HttpServletRequest, assetId: String?): DriversDTO? {
        return driverService.list(request, assetId)
    }

    override fun getById(driverId: String): DriverDTO {
        return driverService.getById(driverId)
    }
}