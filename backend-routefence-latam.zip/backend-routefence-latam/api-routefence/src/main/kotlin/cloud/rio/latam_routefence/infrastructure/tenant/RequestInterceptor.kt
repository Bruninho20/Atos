package cloud.rio.latam_routefence.infrastructure.tenant

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import org.apache.tomcat.util.codec.binary.Base64
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component
import org.springframework.web.servlet.HandlerInterceptor
import org.springframework.web.servlet.ModelAndView
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@Component
class RequestInterceptor : HandlerInterceptor {

    @Autowired
    private val mapper = ObjectMapper()

    @Throws(Exception::class)
    override fun preHandle(request: HttpServletRequest, response: HttpServletResponse, handler: Any): Boolean {
        val authorization = request.getHeader(HttpHeaders.AUTHORIZATION)
        if (authorization.isNullOrEmpty())
            return setResponse(response)

        val jwtSplit = authorization.split(".")

        val mapValues: JsonNode

        try {
            mapValues = mapper.readTree(String(Base64.decodeBase64(jwtSplit[1]), Charsets.UTF_8))
        } catch (e: Exception) {
            throw RoutefenceException.RoutefenceNotFoundException("#ERROR# Error decode JWT: ${jwtSplit}")
        }

        if (mapValues["account"].textValue().isNullOrEmpty())
            return setResponse(response)

        AccountContext.set(mapValues["account"].textValue())
        return true
    }

    @Throws(Exception::class)
    override fun postHandle(request: HttpServletRequest, response: HttpServletResponse, handler: Any, modelAndView: ModelAndView?) {
        AccountContext.clear()
    }

    private fun setResponse(response: HttpServletResponse?) : Boolean {
        response?.writer?.write("Request not authorized")
        response?.status = HttpStatus.UNAUTHORIZED.value()
        return false
    }
}


