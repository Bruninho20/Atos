package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class CurrencyAmount(
    @JsonProperty("adminId") var adminId: String?,
    @JsonProperty("amountInTargetCurrency") var amountInTargetCurrency: Double?,
    @JsonProperty("country") var country: String?,
    @JsonProperty("languageCode") var languageCode: String?,
    @JsonProperty("name") var name: String?,
    @JsonProperty("tollSystemId") var tollSystemId: String?
)
