import { AppPropertiesFromDispatch, AppPropertiesFromState } from '../containers/types'

export type AppProperties = AppPropertiesFromDispatch & AppPropertiesFromState
