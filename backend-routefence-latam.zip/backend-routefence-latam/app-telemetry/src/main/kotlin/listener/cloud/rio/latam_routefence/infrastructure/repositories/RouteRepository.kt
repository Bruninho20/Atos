package listener.cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity

@Repository
interface RouteRepository : JpaRepository<RouteEntity, String> {

    @Query(value = "SELECT r.* FROM tb_route r INNER JOIN tb_trip t ON r.id = t.ROUTE_ID WHERE t.id = :tripId AND r.deletion_date isnull", nativeQuery = true)
    fun getRouteByTripId(@Param("tripId") tripId: String): RouteEntity?
}