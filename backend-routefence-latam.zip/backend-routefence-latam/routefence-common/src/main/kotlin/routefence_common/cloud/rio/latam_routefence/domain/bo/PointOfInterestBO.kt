package routefence_common.cloud.rio.latam_routefence.domain.bo

import routefence_common.cloud.rio.latam_routefence.domain.enums.PointOfInterestEnum

data class PointOfInterestBO(
    val id: String,
    val type: PointOfInterestEnum,
    val proximity: Double
) {
    override fun toString(): String {
        return "id: $id, type: $type, proximity: $proximity"
    }

    object Compare {
        fun nearest(a: PointOfInterestBO, b: PointOfInterestBO): PointOfInterestBO {
            return if (a.proximity!!.toInt() < b.proximity!!.toInt()) a else b
        }
    }
}