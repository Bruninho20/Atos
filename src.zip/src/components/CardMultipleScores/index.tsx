import React, { FC, useEffect, useState } from 'react'
import ContentLoader from 'react-content-loader'

import { ScoreObject } from 'containers/VehiclesStatus/OperativeCard'
import { FilterType } from 'containers/VehiclesStatus'

import Card, { CardProps } from 'components/Card'

import { BodyWrapper, FooterText, Score, ScoreWrapper } from './styled'

interface CardMultipleScoresProps extends CardProps {
  id: string
  footerDescription: string | React.ReactElement
  footerDescriptionClicked: string | React.ReactElement
  footerDescriptionClickedUnit: string | React.ReactElement
  scores?: ScoreObject[]
  totalScore: number | undefined
  filter: FilterType
  onFilterClick: (filter: string) => void
}
export type ScoreTypes = 'CRITICAL' | 'ATTENTION' | 'NORMAL' | 'default'
const getScoreClicked = (score: ScoreTypes) => {
  const scoreDescriptions: Record<ScoreTypes, string> = {
    CRITICAL: 'em falha crítica',
    ATTENTION: 'em atenção',
    NORMAL: 'sem falhas',
    default: 'desconhecido'
  }

  return scoreDescriptions[score as ScoreTypes] || 'default'
}

const CardMultipleScores: FC<CardMultipleScoresProps> = ({
  id,
  title,
  scores,
  totalScore = 0,
  loading,
  footerTitle,
  footerDescription,
  footerDescriptionClicked,
  footerDescriptionClickedUnit,
  filter,
  onFilterClick,
  onFooterClick
}) => {
  const [clicked, setClicked] = useState<ScoreTypes>()
  const [clickedTotal, setTotalClicked] = useState<ScoreTypes>('default')

  const renderFooter = () => {
    if (clicked) {
      return (
        <FooterText type={clicked} loading={loading}>
          {footerDescription}{' '}<span>{getScoreClicked(clickedTotal)}</span>
        </FooterText>
      )
    }

    return (
      <FooterText loading={loading}>
        {footerDescriptionClicked}{' '}
        <strong>
          {!loading ? (
            totalScore
          ) : (
            <ContentLoader width='40px' height='30px' style={{ borderRadius: '3px' }}>
              <rect width='100%' height='100%' />
            </ContentLoader>
          )}
        </strong>{' '}
        {footerDescriptionClickedUnit}
      </FooterText>
    )
  }

  useEffect(() => {
    if (filter !== id) {
      setClicked(undefined)
    }
  }, [filter, id])

  return (
    <Card title={title} loading={loading} footerTitle={footerTitle} onFooterClick={onFooterClick}>
      <BodyWrapper>
        <div style={{ marginTop: '11px', marginBottom: '13px', display: 'flex' }}>
          {!scores
            ? [1, 2, 3].map(val => (
                <ContentLoader key={val} width='84px' height='74px' style={{ borderRadius: '3px', marginLeft: '15px' }}>
                  <rect width='100%' height='100%' />
                </ContentLoader>
              ))
            : scores.map((score, index) => (
                <ScoreWrapper firstScore={index === 0} key={score.type}>
                  <Score
                    bsStyle={score.type}
                    clicked={(clicked || score.type) !== score.type}
                    label={(score.score as unknown) as string}
                    onClick={() => {
                      if (score.type === clicked) {
                        onFilterClick('')
                        setClicked(undefined)
                        setTotalClicked('default')
                      } else {
                        onFilterClick(score.id)
                        setClicked(score.type)
                        setTotalClicked(score.type)
                      }
                    }}
                  />
                </ScoreWrapper>
              ))}
        </div>
        {renderFooter()}
      </BodyWrapper>
    </Card>
  )
}

export default CardMultipleScores
