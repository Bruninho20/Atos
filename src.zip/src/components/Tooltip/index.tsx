import React, { FC } from 'react'
import { Tooltip as RioTooltip, tooltipPlacement, tooltipWidth } from 'rio-uikit'
import { OverlayTrigger } from 'react-bootstrap'

interface ToolTipProps {
  placement?: tooltipPlacement
  position?: tooltipPlacement
  text: string
  showOnClick?: boolean
  className?: string
  children: React.ReactElement
  width?: tooltipWidth
}

const Tooltip: FC<ToolTipProps> = ({ position, className, showOnClick, placement, text, children, width = 150 }) => {
  const tooltipPosition = position ? position : placement

  return (
    <OverlayTrigger
      placement='right'
      overlay={
        <RioTooltip id='tooltip' className={`${tooltipPosition} ${className}`} width={width}>
          <span style={{ fontSize: 12 }}>{text}</span>
        </RioTooltip>
      }>
      {children}
    </OverlayTrigger>
  )
}

export default Tooltip
