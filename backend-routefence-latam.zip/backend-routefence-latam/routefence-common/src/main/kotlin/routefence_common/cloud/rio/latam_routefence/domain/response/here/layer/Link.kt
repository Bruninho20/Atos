package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Link(
    @JsonProperty("linkId") var linkId: String?,
    @JsonProperty("length") var length: Double?,
    @JsonProperty("remainDistance") var remainDistance: Double?,
    @JsonProperty("remainTime") var remainTime: Double?,
    @JsonProperty("shape") var shape: Collection<Double>?,
    @JsonProperty("functionalClass") var functionalClass: Int?,
    @JsonProperty("confidence") var confidence: Double?,
    @JsonProperty("segmentRef") var segmentRef: String?,
    @JsonProperty("consumption") var consumption: Double?,
    @JsonProperty("cost") var cost: CostDetails?,
    @JsonProperty("timezone") var timezone: Int?,
    @JsonProperty("warning") var warning: Collection<ResponseIssue>?,
    @JsonProperty("attributes") var attributes: SpeedLimitsFcn?
)