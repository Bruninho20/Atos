package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_ASSET_COURSE")
data class AssetCourseEntity(
    @Id
    @Column(name = "ID")
    val id: String = UUID.randomUUID().toString(),

    @Column(name = "LATITUDE")
    val lat: Double,

    @Column(name = "LONGITUDE")
    val lng: Double,

    @Column(name = "HEADING")
    val heading: Double?,

    @Column(name = "SPEED_KMH")
    val speed: Double?,

    @Column(name = "MILEAGE")
    val mileage: Double?,

    @Column(name = "OCCURRED_AT")
    var occurredAt: LocalDateTime,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "trip_id", referencedColumnName = "ID")
    val trip: TripEntity,

    override var accountId: String = ""
): AccountTenantEntity(accountId)
