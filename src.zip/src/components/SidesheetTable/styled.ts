import styled from 'styled-components'
import { ExpanderPanel } from 'rio-uikit'

import { colors, metrics } from 'core/assets/styles'

export const InfractionDetailsTable = styled.table`
  padding: 15px;
  width: 100%;
`

export const InfractionDetailsTableRow = styled.tr`
  border-top: 1px ${colors.baseBackground} solid;
  height: 40px;
`

export const InfractionDetailsTableRowLast = styled.tr`
  border-top: 1px ${colors.baseBackground} solid;
  border-bottom: 7px ${colors.baseBackground} solid;
  height: 40px;
`

export const InfractionDetailsTableColumnLeft = styled.td`
  width: 160px;
  color: ${colors.gray};
  font-size: 14px;
  padding: 0 10px;
`

export const InfractionDetailsTableColumnRight = styled.td`
  font-size: 14px;
`

export const StyledPanel = styled.div`
  border-bottom: 1px ${colors.borderDefault} solid;
  padding: 10px 15px 10px 15px;
`

export const SideSheetContentWrapper = styled.div`
  padding: 0 15px 45px 15px;
  margin-top: 15px;
  width: 100%;
  margin-bottom: 100px;
`

export const StyleMapPanelWrapper = styled.div`
  border: 1px ${colors.borderDefault} solid;
  border-radius: 3px;
  height: auto;
  margin-top: 15px;
`

export const StyledExpanderPanel = styled(ExpanderPanel)`
  .panel-heading {
    .title {
      font-size: ${metrics.fontSizeMedium};
      font-family: 'Antonio';
    }

    border: 1px ${colors.borderDefault} solid;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
  }
  .panel-body {
    border-bottom: 1px ${colors.borderDefault} solid;
    border-left: 1px ${colors.borderDefault} solid;
    border-right: 1px ${colors.borderDefault} solid;
    padding: 0;
  }
`
