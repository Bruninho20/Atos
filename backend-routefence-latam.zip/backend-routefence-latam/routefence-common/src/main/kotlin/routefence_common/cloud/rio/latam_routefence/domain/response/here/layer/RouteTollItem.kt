package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class RouteTollItem(
    @JsonProperty("adminId") var adminId: Int?,
    @JsonProperty("conditionId") var conditionId: Int?,
    @JsonProperty("country") var country: String?,
    @JsonProperty("fromSegmentIndex") var fromSegmentIndex: Int?,
    @JsonProperty("linkIds") var linkIds: Collection<Int>?,
    @JsonProperty("toSegmentIndex") var toSegmentIndex: Int?,
    @JsonProperty("tollCostAlternatives") var tollCostAlternatives: Collection<TollCost>?,
    @JsonProperty("tollStructures") var tollStructures: Collection<TollStructure>?,
    @JsonProperty("tollSystem") var tollSystem: Collection<TSystem>?,
    @JsonProperty("tollType") var tollType: String?,
    @JsonProperty("topologySegmentIds") var topologySegmentIds: Collection<Int>?,
    @JsonProperty("usageFeeRequiredTime") var usageFeeRequiredTime: String?
)
