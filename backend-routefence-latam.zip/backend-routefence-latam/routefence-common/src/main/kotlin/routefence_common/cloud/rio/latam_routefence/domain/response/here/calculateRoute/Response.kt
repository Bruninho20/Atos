package routefence_common.cloud.rio.latam_routefence.domain.response.here.calculateRoute

import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.Route
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Response(
    @JsonProperty("route") var route: Collection<Route>?,
    @JsonProperty("warnings") var warnings: Collection<Warnings>?,
    @JsonProperty("language") var language: String?
)