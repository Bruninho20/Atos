package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class TollCost(
    @JsonProperty("amount") var amount: Double?,
    @JsonProperty("amountInTargetCurrency") var amountInTargetCurrency: Double?,
    @JsonProperty("currency") var currency: String?,
    @JsonProperty("daylightHours") var daylightHours: Int?,
    @JsonProperty("discountAvailable") var discountAvailable: Int?,
    @JsonProperty("ferryType") var ferryType: String?,
    @JsonProperty("levelOfAccuracy") var levelOfAccuracy: String?,
    @JsonProperty("methodOfPayment") var methodOfPayment: Int?,
    @JsonProperty("pass") var pass: Pass?,
    @JsonProperty("returnJourney") var returnJourney: Int?,
    @JsonProperty("time") var time: String?,
    @JsonProperty("vehicleSpecification") var vehicleSpecification: VehicleSpecification?
)
