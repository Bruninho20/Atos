import React, { FC, useState, useEffect, useContext } from 'react'
import { DatePicker, Dialog, Notification, Slider } from 'rio-uikit'
import { ModalForm } from './styled'
import moment from 'moment'
import DashboardContext from 'core/DashboardContext'
import InputCurrency from 'components/InputCurrency/input-currency'

const AttentionAreaConfig = ({
  title,
  isOpen,
  onClose,
  index
}) => {
  const { attentionContext, setAttentionContext } = useContext(DashboardContext)
  const [limitMeters, setLimitMeters] = useState(0)
  const [minSpeed, setMinSpeed] = useState()
  const [maxSpeed, setMaxSpeed] = useState()
  const [stayTime, setStayTime] = useState('')

  useEffect(() => {
    const res = attentionContext[0] ? attentionContext[0][index] : ''
    if (res?.stayTime) setStayTime(res.stayTime)
    if (res?.minSpeed) setMinSpeed(res.minSpeed)
    if (res?.maxSpeed) setMaxSpeed(res.maxSpeed)
  }, [isOpen])

  const cloneObject = (obj) => {
    let newObj = Array.isArray(obj) ? [] : {};
    if (obj && typeof obj === "object") {
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          if (typeof obj[key] === "object") {
            newObj[key] = cloneObject(obj[key]);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
    }
    return newObj;
  };

  const handleSaveConfig = (index) => {
    const cloneAttentionArea = cloneObject(attentionContext)

    const obj = cloneAttentionArea[0][index]; // objeto no índice especificado

    // Adicionar as novas chaves ao objeto
    obj.minSpeed = minSpeed;
    obj.maxSpeed = maxSpeed;
    obj.stayTime = moment(stayTime).format('HH:mm');

    // Substituir o objeto no índice especificado pelo novo objeto modificado
    cloneAttentionArea[0].splice(index, 1, obj);

    console.log(cloneAttentionArea, 'TESTE ARRAYF');

    setAttentionContext(cloneAttentionArea)
    handleSaveClose()
  }

  const handleDeleteAttentionArea = (index) => {
    console.log(index, 'INDEX PARA EXCLUIR')
    const cloneAttentionArea = cloneObject(attentionContext)
    console.log(cloneAttentionArea, 'cloneAttentionArea ANTES  EXCLUIR')
    cloneAttentionArea[0].splice(index, 1)

    setAttentionContext(cloneAttentionArea)
    handleSaveClose()
  }

  const handleSaveClose = () => {
    setStayTime('')
    setMinSpeed()
    setMaxSpeed()
    onClose()
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={title}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>

                <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Velocidade Mínima</span>
                    <InputCurrency
                      id='minSpeed'
                      name='minSpeed'
                      type='text'
                      suffix=' km/h'
                      decimalsLimit={0}
                      allowDecimals={false}
                      decimalSeparator=','
                      groupSeparator='.'
                      value={minSpeed}
                      onValueChange={value =>
                        setMinSpeed(value)
                      }
                    />
                  </div>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Velocidade Máxima</span>
                    <InputCurrency
                      id='maxSpeed'
                      name='maxSpeed'
                      type='text'
                      suffix=' km/h'
                      decimalsLimit={0}
                      allowDecimals={false}
                      decimalSeparator=','
                      groupSeparator='.'
                      value={maxSpeed}
                      onValueChange={value =>
                        setMaxSpeed(value)
                      }
                    />
                  </div>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Tempo de Permanência</span>
                    <DatePicker dateFormat={false} onChange={(e) => setStayTime(e)} />
                  </div>
                </div>
                {/* <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-6' style={{ marginTop: 12 }}>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Raio</span>
                    <Slider
                      value={limitMeters}
                      onDragEnd={(e) => {
                        setLimitMeters(e)
                      }}
                      className='margin-bottom-40'
                      minValue={0}
                      maxValue={2000}
                      step={5}
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Distância</span>
                    <div className={'input-group'}>
                      <input
                        type='text'
                        defaultValue={0}
                        value={limitMeters}
                        onChange={(e) => setLimitMeters(e.target.value)}
                        className='form-control'
                        id='first'
                      />
                      <span className={'input-group-addon'}>
                        <span aria-hidden={'true'}>m</span>
                      </span>
                    </div>
                  </div>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Tempo de Permanência</span>
                    <DatePicker dateFormat={false} onChange={(e) => setStayTime(e)} />
                  </div>
                </div> */}
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>
              <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={() => handleDeleteAttentionArea(index)}>
                Excluir
              </button>
            </div>
            <div>
              <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={handleSaveClose}>
                Cancelar
              </button>
              <button type='button' className='btn btn-primary' onClick={() => handleSaveConfig(index)}>
                Salvar
              </button>
            </div>
          </div>

        }
        bsSize={Dialog.SIZE_MD}
        onHide={handleSaveClose}
        showCloseButton={true}
      />
    </div>
  )
}

export default AttentionAreaConfig
