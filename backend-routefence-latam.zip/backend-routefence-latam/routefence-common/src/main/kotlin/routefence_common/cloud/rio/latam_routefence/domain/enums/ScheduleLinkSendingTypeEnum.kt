package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class ScheduleLinkSendingTypeEnum {
    SMS, EMAIL
}