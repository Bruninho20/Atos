import React, { FC } from 'react'

import { Dialog } from 'rio-uikit'

import { ModalForm } from './styled'

interface DialogtFaultCodesProps {
  title: string
  isOpen: boolean
  onClose: () => void
  onChange: () => void
  resetCalc?: () => void
  valueOdometer: any
  handleChangeOdometer: any
}

const DialogFaultCodes: FC<DialogtFaultCodesProps> = ({ title, isOpen = false, onClose, onChange, resetCalc, valueOdometer, handleChangeOdometer }) => {

const handleSaveClose = () => {
  onChange()
  onClose()
}

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title="Ajustar cálculo de CO2 e Diesel evitado"
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form className='row g-3'>
                <div className='col-md-6'>
                  <label className='form-label'>Consumo médio em km/l</label>
                  <input type='text' className='form-control' id='inputPassword4' onChange={handleChangeOdometer} value={valueOdometer}/>
                </div>
                <div>
                  <span>
                    *Preencha este campo para calculo de emissão de Co2 e consumo de combustível evitado
                  </span>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button type='button' style={{marginRight:'10px'}} className='btn btn-default' onClick={resetCalc}>
            Resetar
            </button>
              <button type='button' style={{marginRight:'10px'}} className='btn btn-default' onClick={handleSaveClose}>
            Cancelar
            </button>
          <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
            Salvar
          </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={onClose}
        showCloseButton={true}
      />
    </div>
  )
}

export default DialogFaultCodes
