import React, { FC, useCallback, useEffect, useRef, useState } from 'react'
import { Close } from 'styled-icons/material'
import { metrics } from 'core/assets/styles'
import Container from '../Container'
import Tooltip from 'components/Tooltip'
import { Content, Header, Overlay, Title, WrapperCloseBtn, SideBar, WrapperContainer, ButtonSideBar } from './styled'

interface SideSheetProps {
  children?: React.ReactNode
  open?: boolean
  onClick(): void
  onClickType(e: string): void
  modal?: boolean
  padding?: string
  position?: string
  title?: string | React.ReactElement
  isOnModal?: boolean
  width?: string
}

const SideSheet: FC<SideSheetProps> = ({
  children = null,
  modal = false,
  onClick,
  onClickType,
  open = true,
  padding = null,
  position = 'right',
  title = null,
  isOnModal = false,
  width = '320px'
}) => {
  const modalRef = useRef<HTMLDivElement>(null)
  const overlayRef = useRef<HTMLDivElement>(null)
  const [type, setType] = useState('trip')

  const closeModal = useCallback(
    (event: MouseEvent) => {
      if (modalRef && !modalRef.current?.contains(event.target as Node)) {
        if (overlayRef && overlayRef.current?.contains(event.target as Node)) onClick()
      }
    },
    [onClick]
  )

  useEffect(() => {
    if (open && modal) {
      document.addEventListener('click', closeModal, false)
    }
    return () => {
      document.removeEventListener('click', closeModal, false)
    }
  }, [closeModal, modal, open])

  const handleClickType = (e: string) => {
    onClickType(e)
    setType(e)
  }

  return (
    <>
      {open && modal && <Overlay ref={overlayRef} />}
      <Content
        open={open}
        position={position}
        width={width}
        padding={padding || 0}
        ref={modalRef}
        isOnModal={isOnModal}>
        {title ? (
          <Header>
            <Title>{title}</Title>
            <Close onClick={onClick} size='20' className='closeBtn' style={{ display: 'none' }} />
          </Header>
        ) : (
          <WrapperCloseBtn position={position}>
            <button type='button' className='close' onClick={onClick}>
              <span aria-hidden='true'>×</span>
              <span className='sr-only'>Close</span>
            </button>
          </WrapperCloseBtn>
        )}
        <WrapperContainer>
          <SideBar>
            <Tooltip text='Detalhes do Veículo'>
              <ButtonSideBar
                style={{ color: type === 'vehicle' ? '#44acd3' : '#878585' }}
                onClick={() => handleClickType('vehicle')}>
                <span
                  style={{ marginTop: 17, cursor: 'pointer' }}
                  className='rioglyph rioglyph-truck text-size-h2'></span>
              </ButtonSideBar>
            </Tooltip>
            <Tooltip text='Detalhes da Rota'>
              <ButtonSideBar
                style={{ color: type === 'route' ? '#44acd3' : '#878585' }}
                onClick={() => handleClickType('route')}>
                <span
                  style={{ marginTop: 17, cursor: 'pointer' }}
                  className='rioglyph rioglyph-route-view text-size-h2'></span>
              </ButtonSideBar>
            </Tooltip>

            <Tooltip text='Histórico da Viagem'>
              <ButtonSideBar
                style={{ color: type === 'trip' ? '#44acd3' : '#878585' }}
                onClick={() => handleClickType('trip')}>
                <span
                  style={{ marginTop: 17, cursor: 'pointer' }}
                  className='rioglyph rioglyph-drive-history text-size-h2'></span>
              </ButtonSideBar>
            </Tooltip>

            <Tooltip text='Infrações'>
              <ButtonSideBar
                style={{ color: type === 'infraction' ? '#44acd3' : '#878585' }}
                onClick={() => handleClickType('infraction')}>
                <span
                  style={{ marginTop: 17, cursor: 'pointer' }}
                  className='rioglyph rioglyph-warning-sign text-size-h2'></span>
              </ButtonSideBar>
            </Tooltip>
          </SideBar>
          <Container padding={padding ? padding : `0 ${metrics.baseMargin}`}>{children}</Container>
        </WrapperContainer>
      </Content>
    </>
  )
}

export default React.memo(SideSheet)
