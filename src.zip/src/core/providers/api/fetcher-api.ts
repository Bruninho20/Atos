import { accessToken } from 'configuration/tokenHandling/accessToken'
import { customBaseApi } from 'core/providers/api/base-api'

export const fetcherAPi = {
  post: (url: string, params: Record<string, unknown>) =>
    customBaseApi(accessToken.getAccessToken())
      .post(url, { ...params })
      .then(({ data }) => data),
  get: (url: string, params?: Record<string, unknown>) =>
    customBaseApi(accessToken.getAccessToken())
      .get(url, { params })
      .then(({ data }) => data),
  put: (url: string, params: Record<string, unknown>) =>
    customBaseApi(accessToken.getAccessToken())
      .put(url, { ...params })
      .then(({ data }) => data),
  delete: (url: string, params: Record<string, unknown>) =>
    customBaseApi(accessToken.getAccessToken())
      .delete(url, { ...params })
      .then(({ data }) => data)
}
