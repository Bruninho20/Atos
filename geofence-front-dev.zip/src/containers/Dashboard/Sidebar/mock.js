/* eslint-disable @typescript-eslint/camelcase */
export const mockTags = {
  items: [
    {
      id: '39d01a3d-fec5-4c81-8246-6df36fcc1403',
      type: 'user',
      name: 'AcceptanceTest',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019'
    },
    {
      id: '6acb4da7-8cd0-4d91-b536-4489b2f5d292',
      type: 'user',
      name: 'desenvolvimento',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019'
    },
    {
      id: '664aefdd-cbb0-4663-92e9-908226d3fcb0',
      type: 'user',
      name: 'Teste Loga',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019'
    },
    {
      id: '77a203d7-6b3b-4f98-9d82-6326ff4e27cb',
      type: 'user',
      name: 'Teste Sompo',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019'
    }
  ]
};

export const mockAssets = {
  items: [
    {
      id: '03d94f94-e05a-48b9-a186-30f8d37d9395',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW411',
      status: 'active',
      type: 'truck',
      identification: '9536T8274FR501273',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            },
            {
              id: '664aefdd-cbb0-4663-92e9-908226d3fcb0'
            }
          ]
        }
      }
    },
    {
      id: '0c870ab3-0916-46f6-86a5-e0fc04f39a4f',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'MN 37',
      status: 'active',
      type: 'truck',
      identification: '9539B8TJ6KR999271',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '1299ceef-f031-48f2-8c8d-2d2d40fa363a',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'Latam Desk Device 190124-0123',
      status: 'active',
      type: 'truck',
      identification: '9538TEST190124123',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '1bc43533-3321-4072-8bd6-b408827a4aeb',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'MN 44',
      status: 'active',
      type: 'truck',
      identification: '9539B8TJ1KR999274',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '2ce98908-7080-4708-9fee-5efc5e060b0f',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW 482',
      status: 'active',
      type: 'truck',
      identification: '953688270JR999210',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '2edd4105-039d-48ee-8e88-b6e8c997091f',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'Constellation PVS1',
      status: 'active',
      type: 'truck',
      identification: '953658244KR900002',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: '3b569008-1b15-4891-9dff-a8a8e49b8f73',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'TGX Resende',
      status: 'active',
      type: 'truck',
      identification: '95388XZZ4KE801005',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '3e0672e2-9744-4734-8f46-8a2112db3a4c',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'EWF 2',
      status: 'active',
      type: 'truck',
      identification: '9536882K0JR999213',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '6109a483-cb99-47ae-8b33-74526036e86f',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'Phevos PPF1',
      status: 'active',
      type: 'truck',
      identification: '9535V6TBXJR999211',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: '6d5a66ec-4da7-4236-8ed4-22c44013aa42',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW 468 – VW Delivery 3,5Ton',
      status: 'active',
      type: 'truck',
      identification: '9535PGTB6HR712328',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: '772f0835-564b-4f67-9da8-16a980e0fda2',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW 401 - VW Delivery 4 Ton',
      status: 'active',
      type: 'truck',
      identification: '9535PGTB7HR999209',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '77a203d7-6b3b-4f98-9d82-6326ff4e27cb'
            },
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: '81233ac0-cc38-4ba2-9a3e-79352c900745',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'Desk Device Latam 190705-0190 VW Munich',
      status: 'active',
      type: 'truck',
      identification: 'WMAPRTFM190705190',
      identification_type: 'vin',
      brand: 'MAN',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: '9d045a70-99f5-4745-8d28-6ca3d4d3379b',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'ZUP-01',
      status: 'active',
      type: 'truck',
      identification: '9532AXAZTEST19272',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '6acb4da7-8cd0-4d91-b536-4489b2f5d292'
            }
          ]
        }
      }
    },
    {
      id: 'a2e2bea1-f7cd-4423-823a-a59b93da546f',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW 515',
      status: 'active',
      type: 'truck',
      identification: '9536R8272LR025308',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: 'a75514c4-0aed-4ae8-a08b-d161e140ff3b',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW Constellation Munich',
      status: 'active',
      type: 'truck',
      identification: '953638273ER428525',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: 'ac98ba33-c7e7-45ae-bee9-85388d7e88a9',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'TGX PPF1',
      status: 'active',
      type: 'truck',
      identification: '9532AXAZ3KE901277',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: [
            {
              id: '664aefdd-cbb0-4663-92e9-908226d3fcb0'
            },
            {
              id: '39d01a3d-fec5-4c81-8246-6df36fcc1403'
            }
          ]
        }
      }
    },
    {
      id: 'd4c8d08a-5c14-4746-b474-e87265977b11',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'MN 45',
      status: 'active',
      type: 'truck',
      identification: '953998TH6KR999280',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    },
    {
      id: 'fb6f276c-4204-40ef-9313-d152a20fcf59',
      account_id: 'edca08ab-8979-441f-8b16-16682e188019',
      name: 'VW431',
      status: 'active',
      type: 'truck',
      identification: '9536G824XHR706853',
      identification_type: 'vin',
      brand: 'MAN/VW',
      _embedded: {
        tags: {
          items: []
        }
      }
    }
  ]
};
