import React, { FC, useContext } from 'react'
import { Dialog } from 'rio-uikit'
import DashboardContext from 'core/DashboardContext'
import { useHistory } from 'react-router-dom'

interface DialogtFaultCodesProps {
  title: string
  isOpen: boolean
  onClose: () => void
  subtitle: string
}

const AddressDialog: FC<DialogtFaultCodesProps> = ({ title, isOpen, onClose, subtitle }) => {
  const {
    setAllStopsContext,
    setOriginRouteContext,
    setDestinyRouteContext,
    setRoadParametersContext,
    setResponseHereContext,
    setAvoidPointsContext,
    setVehicleVocacionalContext,
    setCostsContext,
    setRouteContext,
    setLinkedVehiclesContext
  } = useContext(DashboardContext)
  const history = useHistory()

  const handleSaveClose = () => {
    setLinkedVehiclesContext([])
    setAvoidPointsContext([])
    setAllStopsContext([])
    setOriginRouteContext({})
    setDestinyRouteContext({})
    setVehicleVocacionalContext({})
    setCostsContext({})
    setResponseHereContext({})
    setRouteContext({})
    setRoadParametersContext({})
    onClose()

    history.push({
      pathname: `/pdis`
    })
  }

  const handleOnCloseButton = () => {
    onClose()
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={title}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <span>{subtitle}</span>
          </div>
        }
        footer={
          <div>
            <button
              type='button'
              style={{ marginRight: '10px' }}
              className='btn btn-default'
              onClick={handleOnCloseButton}>
              Não
            </button>
            <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
              Sim
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={handleOnCloseButton}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddressDialog
