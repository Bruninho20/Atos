package listener.cloud.rio.latam_routefence.services

import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

@Service
class InfringementRegistration(private val infringementService: InfringementService) {

    private val logger = LoggerFactory.getLogger(this.javaClass)

    fun new(infringementRequest: InfringementRequest?) {
        if (infringementRequest != null) {
            val infringements =
                infringementService.findByTripAndType(infringementRequest.trip, infringementRequest.type)
            if (infringements.isEmpty()) {
                val infringementSaved = infringementService.save(infringementRequest).mapToResponse()
                logger.debug("infracao ${infringementSaved.id} do tipo ${infringementSaved.type} salva")
            } else {
                logger.debug("ja existe infracao ${infringementRequest.type} em aberto")
            }
        }

    }
}