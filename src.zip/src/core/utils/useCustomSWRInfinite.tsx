import { useSWRInfinite } from 'swr'
import { fetcherGet, fetcherPost } from './fetch'

type Status = 'success' | 'error' | 'loading'

interface Props {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: any[] | undefined
  size: number
  setSize: (number: number) => void
  status: Status
}

function useCustomSWRInfinite<Data = Record<string, unknown>[], Error = unknown>(
  url: string,
  method: 'GET' | 'POST',
  propsData: Record<string, unknown>,
  pageSize = 50
): Props {
  const { data, error, isValidating, size, setSize } = useSWRInfinite<Data, Error>(
    index => [index, propsData],
    index =>
      method === 'GET'
        ? fetcherGet(url, { pageSize, page: index, ...propsData })
        : fetcherPost(url, { pageSize, page: index, ...propsData }),
    {
      revalidateAll: false,
      revalidateOnFocus: false,
      revalidateOnMount: false,
      revalidateOnReconnect: false
    }
  )

  const status: Status = error ? 'error' : isValidating ? 'loading' : 'success'

  return { data, status, size, setSize }
}

export default useCustomSWRInfinite
