#!/usr/bin/env bash

if ! [ -x "$(command -v aws)" ]; then
    echo "Intalling awscli"
    pip uninstall -y urllib3
    yum --assumeyes update && yum --assumeyes install awscli
fi

echo Start license check
./gradlew downloadLicenses
jq '[.licences[].name] | unique | .[]' server/build/reports/license/license-dependency.json > licenses/${REPOSITORY_NAME}.txt
aws s3 cp s3://${LICENSE_BUCKET_NAME}/whitelist-gradle.txt licenses/approved_licenses.txt
echo Uploading the used licenses to S3
aws s3 cp licenses/${REPOSITORY_NAME}.txt s3://${LICENSE_BUCKET_NAME}/reports/${PROJECT_NAME}/${REPOSITORY_NAME}.txt

echo add unapproved license to dynamodb
LICENSES=""
LICENSES=`diff <(sort licenses/${REPOSITORY_NAME}.txt) <(sort licenses/approved_licenses.txt) | grep "<" | sed 's/^<//g' | sed "s/\"//g" | tr '\n' ';'`

if [ -z "$LICENSES" ]
    then
        echo "No unapproved licenses"
    else
        echo "Unapproved licenses: $LICENSES"
        exit 1
fi
