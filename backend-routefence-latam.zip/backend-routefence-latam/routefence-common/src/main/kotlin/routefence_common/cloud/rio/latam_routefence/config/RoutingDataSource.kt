package routefence_common.cloud.rio.latam_routefence.config

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource

class RoutingDataSource : AbstractRoutingDataSource() {
    enum class Route {
        PRIMARY, REPLICA
    }

    override fun determineCurrentLookupKey(): Any? {
        return routeContext.get()
    }

    companion object {
        private val routeContext = ThreadLocal<Route>()
        fun clearReplicaRoute() {
            routeContext.remove()
        }

        fun setReplicaRoute() {
            routeContext.set(Route.REPLICA)
        }
    }
}