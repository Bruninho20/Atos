package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.domain.Pageable
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.TripResumeReportResponse
import cloud.rio.latam_routefence.domain.response.TripResumeResponse

interface TripCustomRepository {

    fun listResume(search: String?, status: TripStatusEnum?, pageable: Pageable): List<TripResumeResponse>

    fun listResumeReport(tripId:String,search: String?, status: TripStatusEnum?, pageable: Pageable): List<TripResumeReportResponse>

}