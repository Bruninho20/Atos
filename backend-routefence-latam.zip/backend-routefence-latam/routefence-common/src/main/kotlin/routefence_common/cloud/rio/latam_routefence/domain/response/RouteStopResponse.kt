package routefence_common.cloud.rio.latam_routefence.domain.response

import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopCategoryEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum

data class RouteStopResponse(
    val id: String?,
    val name: String?,
    val category: StopCategoryEnum?,
    val rangeLimitMeters: String?,
    val position: GeoPointResponse?,
    val stayTime: String?,
    val type: StopTypeEnum?,

    @JsonProperty("order")
    val stopQueueOrder: Int,
) {
    object Compare {
        fun max(a: RouteStopResponse, b: RouteStopResponse): RouteStopResponse {
            return if (a.stopQueueOrder < b.stopQueueOrder) a else b
        }
    }
}

