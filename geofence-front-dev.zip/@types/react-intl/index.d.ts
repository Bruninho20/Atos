declare module 'react-intl' {
  export { FormattedMessage, injectIntl, IntlProvider } from 'react-intl'

  export type Intl = {
    locale: string
    formatMessage(
      props: { id: string },
      values?: Record<string, string | number>
    ): string
  }
}
