import React from 'react';
import { IntlProvider } from 'react-intl';
import { render } from '@testing-library/react';
import ptBr from 'features/translations/pt-BR.json';
import './setupTests';
import InjectIntlWrapper from 'InjectIntlWrapper';

const renderWithReactIntl = (component: JSX.Element) => {
  return {
    ...render(
      <IntlProvider locale={'pt-BR'} messages={ptBr}>
        <InjectIntlWrapper>{component}</InjectIntlWrapper>
      </IntlProvider>
    )
  };
};

export default renderWithReactIntl;
