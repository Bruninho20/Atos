import React, { useState } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container, SidesheetWrapper } from './styled'
import EditTripSidesheet from './EditTripSidesheet'
import { AddressDialog, MapRoutefenceAuto } from '../../../components'
import AddVehicleDialog from 'components/AddVehicleDialog'
import StopConfigDialog from 'components/StopConfigDialog'

const EditRoute: React.FC = (props: any) => {
  const [openAddressDialog, setOpenAddressDialog] = useState(false)
  const [openStopConfigDialog, setOpenStopConfigDialog] = useState(false)
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [typeRoupePoint, setTypeRoutePoint] = useState('')
  const [data, setData] = useState(props?.history?.location?.state?.body)

  const path = props.match.path

  const handleOpenAddressDialog = (value: any, type: string, open: boolean) => {
    console.log(value)
    setOpenAddressDialog(open)
    setTypeRoutePoint(type)
  }

  const handleOpenAddVehiclesDialog = (open: boolean) => {
    setOpenAddVehicleDialog(open)
  }

  const handleOpenConfigDialog = (open: boolean) => {
    setOpenStopConfigDialog(open)
  }

  const handleGetLatLng = (value: any, type: string) => {
    if (type === 'originRoute') {
      setData({
        ...data,
        originRouteData: {
          addressStop: value.address,
          lat: value.position.lat,
          lng: value.position.lng
        }
      })
    }
    if (type === 'destinyRoute') {
      setData({
        ...data,
        destinyRouteData: {
          addressStop: value.address,
          lat: value.position.lat,
          lng: value.position.lng
        }
      })
    }
    if (type === 'stops') {
      setData({ ...data, stops: value })
    }
  }

  const handleSaveRouteParameters = (parameters: object) => {
    setData({ ...data, routeParameters: parameters })
  }

  const handleAddVehicles = (vehicles: any) => {
    setData({ ...data, linkedVehicles: vehicles })
  }

  const handleAddStops = (stops: any) => {
    setData({ ...data, allStops: stops })
  }

  const handleUpdateParameters = (routeParameters: any) => {
    setData({ ...data, routeParameters })
  }

  let stopArrayManual: any = []

  const handleAddStopsManual = (stop: object) => {
    stopArrayManual.push(stop)
    handleAddStops(stopArrayManual)
  }

  const handleAddCrossing = (crossing: never) => {
    // // crie uma cópia do objeto data
    // const newData = { ...data }
    // // adicione o novo objeto no array allStops
    // newData.allStops.push(crossing)
    // // atualize o estado do objeto data com a nova cópia
    // setData(newData)
  }

  const handleOpenAddressDialogManual = (value: any, type: string, open: boolean) => {
    // setOpenAddressDialogManual(open)
    // setTypeRoutePoint(type)
    // setGeolocationStop(value)
  }

  return (
    <div>
      <AddressDialog
        title='Procurar endereço'
        isOpen={openAddressDialog}
        onClose={() => setOpenAddressDialog(false)}
        type={typeRoupePoint}
        getLatLng={handleGetLatLng}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type='linkVehicleOut'
        typeToTrip={''}
        saveLinkedVehicles={handleAddVehicles}
        data={undefined}
      />
      <StopConfigDialog
        title='Adicionar Parada'
        isOpen={openStopConfigDialog}
        onClose={() => setOpenStopConfigDialog(false)}
        type={typeRoupePoint}
        handleSaveStopManual={handleAddStopsManual}
        geolocation={'teste'}
        getLatLng={handleGetLatLng}
      />

      <Container>
        <MapWrapper>
          <MapRoutefenceAuto
            data={data}
            handleSaveRouteParameters={handleSaveRouteParameters}
            handleOpenConfigDialog={handleOpenConfigDialog}
            handleOpenAddressDialogManual={handleOpenAddressDialogManual}
            handleAddStops={handleAddCrossing}
          />
        </MapWrapper>
        <SidesheetWrapper>
          <EditTripSidesheet
            handleOpenAddressDialog={handleOpenAddressDialog}
            handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
            handleAddStops={handleAddStops}
            data={data}
            path={path}
            handleUpdateParameters={handleUpdateParameters} handleChangeMode={function (type: string): void {
              throw new Error('Function not implemented.')
            } } handleOpenStopDialog={function (): void {
              throw new Error('Function not implemented.')
            } } setOpenConfirm={function (type: string): void {
              throw new Error('Function not implemented.')
            } }          />
        </SidesheetWrapper>
      </Container>
    </div>
  )
}

export default injectIntl(EditRoute)
