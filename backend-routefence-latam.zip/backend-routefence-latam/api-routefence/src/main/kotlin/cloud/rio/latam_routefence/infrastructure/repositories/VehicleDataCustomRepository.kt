package cloud.rio.latam_routefence.infrastructure.repositories

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.VehicleDataEntity

interface VehicleDataCustomRepository {
    fun findVehicleByChassis(chassis: String): VehicleDataEntity?
}