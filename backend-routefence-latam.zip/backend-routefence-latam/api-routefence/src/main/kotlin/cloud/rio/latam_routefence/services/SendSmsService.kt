package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.job.services.AwsSns
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
@Transactional
class SendSmsService(
    private val awsEmailService: AwsSns,
) {
    fun sendSms(to: List<String>, textBody: String) {
        to.forEach { recipient ->
            awsEmailService.sendTest(textBody, recipient)
        }
    }
}