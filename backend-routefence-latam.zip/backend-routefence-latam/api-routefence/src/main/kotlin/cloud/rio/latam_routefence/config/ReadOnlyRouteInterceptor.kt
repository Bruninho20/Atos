package cloud.rio.latam_routefence.config

import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.springframework.core.annotation.Order
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.config.ReadOnlyRouteInterceptorBase

@Aspect
@Component
@Order(0)
class ReadOnlyRouteInterceptor: ReadOnlyRouteInterceptorBase() {
    @Around("@annotation(transactional)")
    @Throws(Throwable::class)
    override fun proceed(proceedingJoinPoint: ProceedingJoinPoint, transactional: Transactional): Any? {
        return super.proceed(proceedingJoinPoint, transactional)
    }
}