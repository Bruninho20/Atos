import React, { FC, useCallback, useEffect, useRef } from 'react'
import { Close } from 'styled-icons/material'
import { metrics } from 'core/assets/styles'

import Container from '../Container'
import { Content, Header, Overlay, Title, WrapperCloseBtn } from './styled'

interface SideSheetProps {
  children?: React.ReactNode
  open?: boolean
  onClick(): void
  modal?: boolean
  padding?: string
  position?: string
  title?: string | React.ReactElement
  isOnModal?: boolean
  width?: string
}

const SideSheet: FC<SideSheetProps> = ({
  children = null,
  modal = false,
  onClick,
  open = true,
  padding = null,
  position = 'right',
  title = null,
  isOnModal = false,
  width = '320px'
}) => {
  const modalRef = useRef<HTMLDivElement>(null)
  const overlayRef = useRef<HTMLDivElement>(null)

  const closeModal = useCallback(
    (event: MouseEvent) => {
      if (modalRef && !modalRef.current?.contains(event.target as Node)) {
        if (overlayRef && overlayRef.current?.contains(event.target as Node)) onClick()
      }
    },
    [onClick]
  )

  useEffect(() => {
    if (open && modal) {
      document.addEventListener('click', closeModal, false)
    }
    return () => {
      document.removeEventListener('click', closeModal, false)
    }
  }, [closeModal, modal, open])

  return (
    <>
      {open && modal && <Overlay ref={overlayRef} />}
      <Content
        open={open}
        position={position}
        width={width}
        padding={padding || 0}
        ref={modalRef}
        isOnModal={isOnModal}>
        {title ? (
          <Header>
            <Title>{title}</Title>
            <Close onClick={onClick} size='20' className='closeBtn' style={{ display: 'none' }} />
          </Header>
        ) : (
          <WrapperCloseBtn position={position}>
            <button type='button' className='close' onClick={onClick}>
              <span aria-hidden='true'>×</span>
              <span className='sr-only'>Close</span>
            </button>
          </WrapperCloseBtn>
        )}
        <Container padding={padding ? padding : `0 ${metrics.baseMargin}`}>{children}</Container>
      </Content>
    </>
  )
}

export default React.memo(SideSheet)
