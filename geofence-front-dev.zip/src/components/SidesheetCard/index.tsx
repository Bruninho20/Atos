import React from 'react';
// import { FormattedMessage } from 'react-intl';
import Speedometer from '../Speedometer'


import {
  StyledCard,
} from './styled';

interface MiniCardProps {
  title: any;
  description: any;
}


const InfringementCard: React.FC<MiniCardProps> = ({
  title,
  description
}) => {
  return (
    <StyledCard
    // action={action}
    title={title}
    // justify={justifyTitle}
    className="card-title"
  >
    <div>
      <Speedometer
      description={description}>
        </Speedometer>  
    </div>
    
  </StyledCard>
);
};

export default InfringementCard;
