import { HIDE_SESSION_EXPIRED_DIALOG } from './types'

export const hideSessionExpiredDialog = () => {
  return {
    type: HIDE_SESSION_EXPIRED_DIALOG
  }
}

interface HideSessionExpiredAction {
  type: typeof HIDE_SESSION_EXPIRED_DIALOG;
}

export type AppActions = HideSessionExpiredAction;

export const DATE_TIME = 'app/DATE_TIME'

interface HideSessionExpiredAction {
    type: typeof HIDE_SESSION_EXPIRED_DIALOG;
}

