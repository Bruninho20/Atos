package cloud.rio.latam_routefence.infrastructure.consumedapi.drivers

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonProperty

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class DriverDTO(
    @JsonProperty("metadata")
    val metadata: MetadataDTO? = null,
    @JsonProperty("account_id")
    val account_id: String,
    @JsonProperty("id")
    val id: String,
    @JsonProperty("email")
    val email: String?,
    @JsonProperty("first_name")
    var first_name: String? = "",
    @JsonProperty("last_name")
    val last_name: String? = "",
    @JsonProperty("display_name")
    val display_name: String? = null,
    @JsonProperty("phone_number")
    val phone_number: String?,
    @JsonProperty("status")
    val status: String,
    @JsonProperty("_embedded")
    var _embedded: IdentificationsDTO? = null
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class MetadataDTO(
    @JsonProperty("tenant")
    val tenant: String ="",
    @JsonProperty("allowed_actions")
    val allowed_actions: List<String> = emptyList()
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class IdentificationsDTO(
    @JsonProperty("identifications")
    val identifications : List<IdentificationDTO>
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class IdentificationDTO(
    @JsonProperty("id")
    val id: String,
    @JsonProperty("identification_type")
    val identification_type: String,
    @JsonProperty("identification")
    val identification: String,
    @JsonProperty("card_type")
    val card_type: String? = null
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class DriversDTO(
    @JsonProperty("priority")
    var priority:MutableList<DriverDTO>? = mutableListOf(),

    @JsonProperty("items")
    var items: MutableList<DriverDTO> = mutableListOf(),

    @JsonProperty("_links")
    var _links: Links? = null
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class Links(
    @JsonProperty("self")
    val self: Link? = null,

    @JsonProperty("next")
    val next: Link? = null
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class Link(
    @JsonProperty("href")
    val href: String
)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class Identification (

    @JsonProperty("tags")
    var tags: Identification = Identification(),
)