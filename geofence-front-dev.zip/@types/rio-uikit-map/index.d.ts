declare module 'rio-uikit-map' {
  import React from 'react';

  interface MapProps {
    credentials: string;
    center: { lat: string | number; lng: string | number };
    zoom: number;
    hideMapSettings?: boolean;
  }
  class Map extends React.Component<MapProps> {}


  type markerColor =
    | 'bg-map-marker-asset'
    | 'bg-map-marker-poi'
    | 'bg-map-marker-event';

  interface SingleMapMarkerProps {
    bearing?: number;
    name?: string;
    warningCount?: number;
    exceptionCount?: number;
    active?: boolean;
    moving?: boolean;
    iconNames?: string[];
    markerColor?: markerColor;
  }

  class SingleMapMarker extends React.Component<SingleMapMarkerProps> {}
}
