import React, { useState, useEffect } from 'react';

import { AutoSuggest } from 'rio-uikit';

const SimpleAutoSuggestExample = ({ setAddress, data, iconData, title }) => {
  const [value, setValue] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  // const [addressSelected, setAddresSelected] = useState('')

  useEffect(() => {
    if (data) {
      setValue(data)
    }
  }, [data])

  console.log(value, 'value')
  console.log(data, 'DATA')

  // Autosuggest will call this function every time you need to update suggestions.
  // It will also be called when the input is cleared. The value would be an empty string in this case.
  const handleSuggestionsFetchRequested = async (result) => {
    const newValue = result.value;
    setValue(newValue);

    const response = await fetch(`https://discover.search.hereapi.com/v1/autosuggest?at=48.13642,11.57755&q=${value}&apiKey=_w4q3_TddR6It0de7z8BvFdTMZ44rPF3bx2cSVZ_3_8`);
    const data = await response.json();
    if (data?.items?.length > 0) {

      setSuggestions(data.items);
    }

  };

  const handleSelectAddress = (i) => {
    console.log(i, 'I QUANDO CLICADO')
    setAddress(i)
    setValue(i.address.label)
  }

  // Use your imagination to render suggestions.
  // const renderSuggestion = suggestion => <span>{suggestion?.address?.label}</span>;

  const renderSuggestion = (suggestion) => {
    return (
      <span>
        <span className={iconData} /> {suggestion?.address?.label}
      </span>
    );
  }

  const inputProps = {
    placeholder: title,
    value,
    icon: iconData
  };

  return (
    <div className='row'>
      <div className='col-sm-12 form-group'>
        <AutoSuggest
          inputProps={inputProps}
          suggestions={suggestions}
          onSuggestionsFetchRequested={handleSuggestionsFetchRequested}
          renderSuggestion={renderSuggestion}
          closeOnSelect={true}
          onSuggestionSelected={(e, i) => handleSelectAddress(i.suggestion)}
        />
      </div>
    </div>
  );
};

export default SimpleAutoSuggestExample;