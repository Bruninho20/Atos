package listener.cloud.rio.latam_routefence.config

import org.hibernate.EmptyInterceptor
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.EnableAspectJAutoProxy
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import routefence_common.cloud.rio.latam_routefence.config.JpaInterceptorConfigBase
import javax.sql.DataSource

@Configuration
@EnableAspectJAutoProxy
class JpaInterceptorConfig() : JpaInterceptorConfigBase() {

    @Bean
    override fun hibernateInterceptor(): EmptyInterceptor? {
        return super.hibernateInterceptor()
    }

    @Bean
    override fun entityManagerFactory(
        factory: EntityManagerFactoryBuilder,
        dataSource: DataSource?,
        jpaProperties: JpaProperties?
    ): LocalContainerEntityManagerFactoryBean? {
        val jpaPropertiesMap: MutableMap<String, Any?> = HashMap(jpaProperties?.properties)
        jpaPropertiesMap["hibernate.ejb.interceptor"] = hibernateInterceptor()
        return factory.dataSource(dataSource).packages(
            "listener.cloud.rio.latam_routefence","routefence_common.cloud.rio.latam_routefence"
        ).properties(jpaPropertiesMap).build()
    }
}