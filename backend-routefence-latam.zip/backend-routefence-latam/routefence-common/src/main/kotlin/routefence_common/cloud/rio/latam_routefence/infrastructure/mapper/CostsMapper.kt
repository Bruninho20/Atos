package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.CostsRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.CostsResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.CostsEntity

fun CostsRequest.mapToEntity(): CostsEntity {
    return CostsEntity(
        tollValue = this.tollValue!!.toFloat(),
        operativeCosts = this.operativeCosts!!.toFloat(),
        totalCosts = this.totalCosts!!.toFloat(),
        fuelAverageCosts = this.fuelAverageCosts!!.toFloat(),
        averageConsume = this.averageConsume!!.toFloat()
    )
}

fun CostsEntity.mapToResponse(): CostsResponse {
    return CostsResponse(
        id = this.id,
        tollValue = this.tollValue?.toString(),
        operativeCosts = this.operativeCosts?.toString(),
        totalCosts = this.totalCosts?.toString(),
        fuelAverageCosts = this.fuelAverageCosts?.toString(),
        averageConsume = this.averageConsume?.toString()
    )
}

fun CostsEntity?.copyFromRequest(req: CostsRequest?): CostsEntity? {
    req?.tollValue?.let { this?.tollValue = it.toFloat() }
    req?.operativeCosts?.let { this?.operativeCosts = it.toFloat() }
    req?.totalCosts?.let { this?.totalCosts = it.toFloat() }
    req?.fuelAverageCosts?.let { this?.fuelAverageCosts = it.toFloat() }
    req?.averageConsume?.let { this?.averageConsume = it.toFloat() }

    return this
}

fun CostsRequest.mapToDuplicatedEntity(costsEntity: CostsEntity?): CostsEntity {
    return CostsEntity(
        tollValue = this.tollValue?.toFloat() ?: costsEntity?.tollValue,
        operativeCosts = this.operativeCosts?.toFloat() ?: costsEntity?.operativeCosts,
        totalCosts =  this.totalCosts?.toFloat() ?: costsEntity?.totalCosts,
        fuelAverageCosts =  this.fuelAverageCosts?.toFloat() ?: costsEntity?.fuelAverageCosts,
        averageConsume = this.averageConsume?.toFloat() ?: costsEntity?.averageConsume,
        accountId = costsEntity?.accountId ?: ""
    )
}