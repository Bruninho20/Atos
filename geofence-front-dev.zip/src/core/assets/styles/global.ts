import { createGlobalStyle } from 'styled-components'

import { colors } from './'

export const GlobalStyle = createGlobalStyle`

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  html, body {
    margin: 0;
    padding: 0;
    font-family: "Source Sans Pro";
    font-weight: normal;
    font-size: 10px;
    font-style: normal;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  h1 {
    font-family: "Source Sans Pro";
    font-size: 1.25rem;
    margin-top: 0;
  }

  p {
    font-family: "Source Sans Pro";
    font-size: 1.4rem;
    font-weight: normal;
  }

  .fluid {
    width: 100%;
  }

  .modal-body {
    font-size: 14px;
  }

  .module-content { padding: 0!important; }

  .notification {
    font-size: 1.4rem !important;
  }

  .ApplicationLayoutSidebar {
    .panel {
      border: 0;
    }
  }

  .tooltip-btn__config {
    top: 65px !important;
  }

  #atlwdg-trigger {
    position: fixed;
    z-index: 99999;
    border: 0;
  }

  @media screen and (max-width: 900px) {
    .module-content {
      min-width: 100% !important;
    }
  }

  @media screen and (max-width: 768px) {
    .resize {
      flex-direction: column !important;
    }
  }

  code {
    font-family: source-code-pro, Menlo, Monaco, Consolas, "Courier New", monospace;
  }

  ::-webkit-scrollbar {
    height: 5px;
    width: 5px;
  }

  ::-webkit-scrollbar-track {
    background: transparent;
  }

  ::-webkit-scrollbar-thumb {
    background: ${colors.scrollGray};
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: ${colors.blackMedium};
  }
`
