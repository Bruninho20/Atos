import isEmpty from 'lodash/fp/isEmpty';

export const sanitizeTagsList = (items, intl) => {
  const tags = items.map((item) => ({ id: item.id, name: item.name }));
  return [
    ...tags,
    {
      id: 'empty',
      name: intl.formatMessage({
        id: 'assetsTree.unassignedVehicles'
      })
    }
  ];
};

export const sanitizeAssetsList = (items) => {
  const assets = items.map((item) => {
    const { items } = item._embedded.tags;
    const groups = items.map((groups) => groups.id);
    const groupIds = isEmpty(groups) ? ['empty'] : groups;

    return { id: item.id, name: item.name, type: item.type, groupIds };
  });
  return assets;
};

export const createAssetsList = ({ groups, items, trucks }) => {

  const res = groups.find((item) => item === 'empty')
    ? [
      ...new Set([
        ...items,
        ...trucks
          .reduce((acc, curr) => {
            const assetId =
              curr.groupIds.find((group) => group === 'empty') && curr.id;
            return acc.concat(assetId);
          }, [])
          .filter((item) => item !== undefined)
      ])
    ]
    : items;
  return res
}

