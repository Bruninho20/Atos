export default {
  baseFontWeight: '600',
  baseMargin: '1.5rem', // 15px
  baseMediumMargin: '1.6rem', // 16px
  baseSmallMargin: '1rem', // 10px
  baseLargeMargin: '2rem', // 20px
  basePadding: '1rem', // 10px
  baseMediumPadding: '1.6rem', // 16px
  baseRadius: '3px',
  baseSmallPadding: '1rem', // 10px
  fontSizeDefault: '1.4rem', // 14px
  fontSizeMedium: '1.6rem', // 16px
  fontSizeLarge: '2.5rem', // 25px
  fontSizeXLarge: '4rem', // 40px
  fontSizeXXLarge: '4.5rem', // 45px
  fontSizeSmall: '1.2rem', // 12px
  fontSizeSubTitle: '1.8rem', // 18px
  fontSizeTitle: '2rem' // 20px
}
