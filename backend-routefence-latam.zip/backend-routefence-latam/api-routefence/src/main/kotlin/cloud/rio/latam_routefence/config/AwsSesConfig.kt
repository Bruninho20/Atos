package cloud.rio.latam_routefence.config

import com.amazonaws.auth.AWSStaticCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.regions.Regions
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder
import com.project.custom.services.AwsEmailService
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Profile
import org.springframework.stereotype.Component

@Component
class AwsSesConfig {

    @Value("\${send-mail.from}")
    private lateinit var from: String

    @Bean
    @Profile("prod")
    fun amazonSimpleEmailService(): AwsEmailService {
        val client = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.EU_WEST_1).build()
        return AwsEmailService(client, from)
    }

    @Bean
    @Profile("vm")
    fun amazonSimpleEmailServiceVm(): AwsEmailService {
        val client = AmazonSimpleEmailServiceClientBuilder
            .standard()
            .withCredentials(basicCredential())
            .withRegion(Regions.EU_WEST_1).build()

        return AwsEmailService(client, from)
    }

    @Profile("local")
    @Bean
    fun awsEmailService(): AwsEmailService {
        val client = AmazonSimpleEmailServiceClientBuilder
            .standard()
            .withCredentials(basicCredential())
            .withRegion(Regions.EU_WEST_1).build()

        return AwsEmailService(client, from)
    }

    private fun basicCredential(): AWSStaticCredentialsProvider {
        val credentials =
            BasicAWSCredentials(
                System.getenv().getOrDefault("AWS_SES_ACCESS_KEY_LOCAL", ""),
                System.getenv().getOrDefault("AWS_SES_SECRET_LOCAL", ""))
        return AWSStaticCredentialsProvider(credentials)
    }

}