package cloud.rio.latam_routefence.domain.response

import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse

data class SummaryResponse(
    val dateTimeLastPosition: String?,
    val assetName: String?,
    val chassi: String?,
    val driverName: String?,
    var latLongLastPosition: GeoPointResponse?,
    val remainDistance: Double?,
    val speed: Double?,
    val driverActivity: String?,
    val remainTimeSeconds: Double?,
    val mileage: Double?
)
