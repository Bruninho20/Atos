package cloud.rio.latam_routefence.utils

import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.data.domain.Sort
import routefence_common.cloud.rio.latam_routefence.domain.enums.SortFieldsEnum
import javax.persistence.Query

object PageableUtils {

    fun getPageable(page: Int, pageSize: Int, order: List<String>, sortFieldsEnum: Array<out SortFieldsEnum>) =
        PageRequest.of(
            page,
            pageSize,
            buildSortParam(order, sortFieldsEnum)
        )

    fun setQueryParametersPageable(query: Query, pageable: Pageable) {
        query.setParameter("pageSize", pageable.pageSize)
        query.setParameter("page", pageable.pageNumber)
    }

    fun addPageable(pageable: Pageable, sql: StringBuilder) {
        if (!pageable.sort.isUnsorted)
            setSortPageable(sql, pageable.sort.iterator())

        sql.append("limit :pageSize ")
        sql.append("offset(:page) * :pageSize ")

    }

    private fun setSortPageable(sql: StringBuilder, orderIterator: Iterator<Sort.Order>) {
        orderIterator.forEachRemaining { order ->
            sql
                .append("ORDER BY ")
                .append(order.property).append(" ")
                .append("${order.direction.name} ")
        }
    }

    private fun buildSortParam(order: List<String>, sortFieldsEnum: Array<out SortFieldsEnum>): Sort {
        val orderParams: MutableList<Sort.Order> = mutableListOf()

        if (order.isNotEmpty()) {
            order.forEach {
                val field = getEntityEquivalentByName(it.removePrefix("-"), sortFieldsEnum)

                if (field != null) {
                    if (it.startsWith("-")) {
                        orderParams.add(field.let { fieldName -> Sort.Order.desc(fieldName) })
                    } else {
                        orderParams.add(field.let { fieldName -> Sort.Order.asc(fieldName) })
                    }
                }
            }

            return Sort.by(orderParams)
        } else {
            return Sort.unsorted()
        }
    }

    private fun getEntityEquivalentByName(name: String, values: Array<out SortFieldsEnum>): String? {
        values.forEach {
            if (name.equals(it.name, true))
                return it.entityEquivalent
        }
        return null
    }
}