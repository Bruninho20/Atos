package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.StateApi
import cloud.rio.latam_routefence.domain.request.LiveStateRequest
import cloud.rio.latam_routefence.domain.response.LiveStateResponse
import cloud.rio.latam_routefence.services.AssetIotEventService
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest

@RestController
class StateController(private val iotEventEventService: AssetIotEventService) : StateApi {

    override fun liveState(request: HttpServletRequest, liveStateRequest: LiveStateRequest): List<LiveStateResponse> {
        return iotEventEventService.getLiveState(request, liveStateRequest)
    }
}