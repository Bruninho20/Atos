import styled from 'styled-components'

export const DateFormGroup = styled.div`
  margin-bottom: 15px;
  width: 300px;
`
