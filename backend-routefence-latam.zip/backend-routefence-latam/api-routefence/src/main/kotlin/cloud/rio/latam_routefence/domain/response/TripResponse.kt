package cloud.rio.latam_routefence.domain.response

import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.InfringementResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse

data class TripResponse(
    val id: String,
    val driver: String?,
    val asset: String,
    val route: RouteResponse,
    val infringements: Collection<InfringementResponse>?,
    val status: TripStatusEnum,
    val startDateTime: String,
    val startedAt: String?,
    val finishedAt: String?,
    val deletedAt: String?
)
