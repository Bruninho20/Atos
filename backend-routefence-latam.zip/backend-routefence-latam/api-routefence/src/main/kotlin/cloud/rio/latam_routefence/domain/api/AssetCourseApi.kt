package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.domain.response.AssetCourseResponse
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RequestMapping("/asset-course")
interface AssetCourseApi {
    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/{id}", produces = ["application/json"])
    fun getAssetCourse(@PathVariable(value="id") id: String): Collection<AssetCourseResponse>
}