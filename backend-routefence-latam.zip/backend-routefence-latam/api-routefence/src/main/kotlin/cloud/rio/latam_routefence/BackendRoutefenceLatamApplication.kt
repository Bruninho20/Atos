package cloud.rio.latam_routefence

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.boot.runApplication
import org.springframework.context.annotation.ComponentScan
import org.springframework.scheduling.annotation.EnableScheduling

@EnableScheduling
@SpringBootApplication
@EntityScan("routefence_common.cloud.rio.latam_routefence.infrastructure.entity","cloud.rio.latam_routefence.infrastructure.entity")
@ComponentScan("routefence_common.cloud.rio.latam_routefence.*","cloud.rio.latam_routefence.*")
class BackendRoutefenceLatamApplication

fun main(args: Array<String>) {
	runApplication<BackendRoutefenceLatamApplication>(*args)
}