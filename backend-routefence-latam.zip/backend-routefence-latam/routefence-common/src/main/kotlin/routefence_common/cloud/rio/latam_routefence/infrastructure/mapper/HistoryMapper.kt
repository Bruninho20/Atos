package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.response.HistoryResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.LocationData
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

fun mapToHistory(assetCourses: List<AssetCourseEntity>, route: RouteEntity?): HistoryResponse {
    val locationData = assetCourses.map {
        LocationData(
            lat = it.lat.toString(),
            long = it.lng.toString(),
            occurredAt = it.occurredAt.atOffset(ZoneOffset.UTC).toString()
        )
    }.sortedBy { it.occurredAt }

    val firstAssetCourse = assetCourses.first()
    val duration = calculateDurationString(locationData)
    return HistoryResponse(
        routeId = route!!.id,
        routeName = route.routeName,
        tripId = firstAssetCourse.trip.id!!,
        startedAt = firstAssetCourse.trip.startedAt.toString(),
        finishedAt = firstAssetCourse.trip.finishedAt.toString(),
        driverId = firstAssetCourse.trip.driverId,
        locationData = locationData,
        duration = duration
    )
}


fun mapForTripsWithoutHistory(trip:TripEntity): HistoryResponse {

    return HistoryResponse(
        routeId = trip.route.id,
        routeName = trip.route.routeName,
        tripId = trip.id!!,
        startedAt =trip.startedAt.toString(),
        finishedAt =trip.finishedAt.toString(),
        driverId =trip.driverId,
        locationData = listOf(),
        duration = null
    )
}

fun calculateDurationString(locationData: List<LocationData>): String? {
    if (locationData.isEmpty()) {
        return null
    }
    val firstLocation = locationData.first()
    val lastLocation = locationData.last()

    if (firstLocation == lastLocation) {
        return "0 h 0 min"
    }

    val startTime = LocalDateTime.parse(firstLocation.occurredAt, DateTimeFormatter.ISO_DATE_TIME)
    val endTime = LocalDateTime.parse(lastLocation.occurredAt, DateTimeFormatter.ISO_DATE_TIME)

    val duration = Duration.between(startTime, endTime)
    val hours = duration.toHours()
    val minutes = duration.minusHours(hours).toMinutes()

    return "$hours h $minutes min"
}

