import React from 'react'

import { ReactComponent as Breakdown } from './breakdown.svg'
import { ReactComponent as Empty } from './empty.svg'
import { ReactComponent as Welcome } from './welcome.svg'

export type IconItemProp = 'breakdown' | 'empty' | 'welcome'

export const IconItem = (icon: IconItemProp) =>
  ({
    breakdown: <Breakdown />,
    empty: <Empty />,
    welcome: <Welcome />
  }[icon])
