package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.domain.response.TripResumeResponse
import cloud.rio.latam_routefence.infrastructure.mapper.mapToEntity
import cloud.rio.latam_routefence.infrastructure.mapper.mapToNewEntity
import cloud.rio.latam_routefence.infrastructure.repositories.RouteRepository
import cloud.rio.latam_routefence.infrastructure.repositories.TripRepository
import cloud.rio.latam_routefence.infrastructure.repositories.TripStopRepository
import cloud.rio.latam_routefence.utils.PageableUtils
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripSortFields
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.domain.request.TripRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteStopEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripStopEntity
import routefence_common.cloud.rio.latam_routefence.utils.DateFormatter
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.*

@Service
@Transactional
class TripService(
    private val tripRepository: TripRepository,
    private val routeRepository: RouteRepository,
    private val tripStopRepository: TripStopRepository
)
{
    @Transactional(readOnly = false)
    fun save(trips: Collection<TripRequest>): Collection<TripEntity> {
        var tripEntities = mutableListOf<TripEntity>()

        trips.forEach {
            tripEntities.add(save(it))
        }
        return tripEntities
    }

    @Transactional(readOnly = false)
    fun save(tripRequest: TripRequest): TripEntity {

        tripRequest.routeId ?: throw RoutefenceException.RoutefenceNotFoundException("#ERROR# RouteId required and not informed ${tripRequest.id}")

        val routeOptional = routeRepository.findById(tripRequest.routeId!!).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(tripRequest.routeId!!))
        }

        val savedTrip = tripRepository.save(tripRequest.mapToNewEntity(routeOptional))

        routeOptional.stops?.forEach { stop ->
            val tripStopOptional = tripStopRepository.findByTripAndRouteStop(savedTrip, stop)
            if (!tripStopOptional.isPresent) {
                if(stop.type == StopTypeEnum.STOPOVER) {
                    tripStopRepository.save(
                        TripStopEntity(
                            routeStop = stop,
                            trip = savedTrip,
                            checkIn = null,
                            checkOut = null
                        )
                    )
                }
            }
        }

        return savedTrip
    }

    fun findTripById(id: String): TripEntity {
        val tripOptional = tripRepository.getTripById(id).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(id))
        }
        return tripOptional
    }

    fun findTripByRouteId(routeId: String): Collection<TripEntity?>{
        return tripRepository.getTripsByRouteId(routeId)
    }

    fun findAllResume(
        orderBy: String?,
        search: String?,
        page: Int?,
        pageSize: Int?,
        status: TripStatusEnum?
    ): List<TripResumeResponse> {

        val pageable = PageableUtils.getPageable(
            page = page ?: 0,
            pageSize = pageSize ?: 50,
            order = listOf(orderBy ?: "-createdAt"),
            sortFieldsEnum = TripSortFields.values()
        )
        return tripRepository.listResume(search, status, pageable)
    }

    @Transactional(readOnly = false)
    fun updateTrip(tripId: String, tripRequest: TripRequest): TripEntity? {
        tripRequest.id = tripId

        val tripOptional = tripRepository.findById(tripId).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(tripId))
        }

        if (tripRequest.routeId == tripOptional.route.id) {
            return tripRepository.save(tripRequest.mapToEntity(tripOptional.route))
        }

        val routeOptional = routeRepository.findById(tripRequest.routeId!!).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(tripRequest.routeId!!))
        }

        return tripRepository.save(tripRequest.mapToEntity(routeOptional))
    }

    fun deleteTrip(tripId: String) {
        val tripOptional = tripRepository.findById(tripId)
        if (!tripOptional.isPresent) {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(tripId))
        }
        val trip = tripOptional.get()
        if (trip.deletedAt == null) {
            trip.status = TripStatusEnum.DELETED
            trip.deletedAt = LocalDateTime.now()
        }
    }

    @Transactional(readOnly = false)
    fun createTrips(
        trips: Collection<TripRequest>?,
        savedRoute: RouteEntity,
        routeStopListSaved: List<RouteStopEntity>?
    ) {
        trips?.forEach { trip ->
            val tripSaved = tripRepository.save(trip.mapToNewEntity(savedRoute))

            routeStopListSaved?.forEach {
                if(it.type == StopTypeEnum.STOPOVER) {
                    tripStopRepository.save(
                        TripStopEntity(
                            UUID.randomUUID().toString(),
                            it,
                            tripSaved,
                            null,
                            null
                        )
                    )
                }
            }
        }
    }

    fun getActiveTrips(assetId: String): Collection<TripEntity> {
        return tripRepository.getActiveTrips(assetId)
    }

    fun deleteTripsByRoute(route: RouteEntity) {
        route.trips?.forEach {
            when (it.status) {
                TripStatusEnum.SCHEDULED -> {
                    deleteTrip(it.id!!)
                }
                TripStatusEnum.DELETED -> {
                    it.deletedAt = it.deletedAt

                }
                else -> {
                    throw RoutefenceException.RoutefenceInvalidPayloadException("Invalid.deletion.route")
                }
            }
        }
    }

    //TODO Chamar no momento em que o veículo atingir a velocidade de inicio (acima de 20 km/h)
    // https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-362
    @Transactional(readOnly = false)
    fun startTrip(trip: TripEntity): TripEntity {
        if (trip.deletedAt != null) {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(trip.id.toString()))
        }

        var tripsByAsset = getActiveTrips(trip.assetId).filter { it.status == TripStatusEnum.STARTED }
        if (tripsByAsset.isNotEmpty()) {
            throw RoutefenceException.RoutefenceNotFoundException(
                "Asset.already.at.started.trip",
                arrayOf(trip.id.toString())
            )
        }

        when (trip.status) {
            TripStatusEnum.STARTED -> {
                throw RoutefenceException.RoutefenceBusinessException(
                    "Trip.started.cant.started.again", arrayOf(
                        trip.startedAt?.atOffset(ZoneOffset.UTC).toString()
                    )
                )
            }

            TripStatusEnum.SCHEDULED,
            TripStatusEnum.DELAYED,
            TripStatusEnum.INTERRUPTED -> {
                trip.startedAt = DateFormatter.formatUTC(OffsetDateTime.now())
                trip.status = TripStatusEnum.STARTED
                tripRepository.save(trip)
            }

            TripStatusEnum.FINISHED -> {
                throw RoutefenceException.RoutefenceBusinessException(
                    "Trip.finished.cant.started.again", arrayOf(
                        trip.finishedAt?.atOffset(ZoneOffset.UTC).toString()
                    )
                )
            }

            TripStatusEnum.DELETED -> {
                throw RoutefenceException.RoutefenceBusinessException(
                    "Trip.deleted.cant.started.again", arrayOf(
                        trip.deletedAt?.atOffset(ZoneOffset.UTC).toString()
                    )
                )
            }
        }

        return trip
    }
}
