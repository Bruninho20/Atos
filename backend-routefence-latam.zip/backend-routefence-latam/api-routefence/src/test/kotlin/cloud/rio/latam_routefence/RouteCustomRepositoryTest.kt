package cloud.rio.latam_routefence

import cloud.rio.latam_routefence.services.RouteService
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext

@SpringBootTest
class RouteCustomRepositoryTest(
    @Autowired private val repo: RouteService
) {

    @Test
    fun findRouteById() {
        AccountContext.set("d87f9f41-5950-45b1-9044-ecb5d32039d8")
        val id = "11747dd1-18d9-432d-9dfa-18c3b421e7f1"

        repo.findById(id)
    }
}