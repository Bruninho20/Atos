import styled, { css } from 'styled-components';

const getStyles = ({
  alignItems = 'stretch',
  direction = 'row',
  flex = '0 1 auto',
  justify = 'space-between',
  minHeight = '1px',
  overflow = 'visible',
  padding = '10px 0',
  width = 'auto'
}) => css`
  align-items: ${alignItems};
  flex: ${flex};
  flex-direction: ${direction};
  justify-content: ${justify};
  min-height: ${minHeight};
  overflow: ${overflow};
  padding: ${padding};
  position: relative;
  width: ${width};
`;

const Section = styled.section`
  display: flex;
  ${getStyles}
`;

export default Section;
