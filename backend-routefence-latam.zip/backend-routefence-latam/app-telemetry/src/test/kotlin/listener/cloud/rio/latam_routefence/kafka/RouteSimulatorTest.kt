package listener.cloud.rio.latam_routefence.kafka

import listener.cloud.rio.latam_routefence.services.InfringementDetection
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.time.OffsetDateTime
import java.util.*

@SpringBootTest
class RouteSimulatorTest(@Autowired val infringementDetection: InfringementDetection) {

    @Test
    fun testRouteSimulador() {

        val listRotaMetalurgico = listOf(
            DataAsset(
            occurred_at= OffsetDateTime.parse("2023-02-24T14:28:11.614754500Z"),
            latitude= -23.601274490356445,
            longitude= -46.3992805480957,
            speed= 0.0
        ),

            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:28:21.614754500Z"),
                latitude= -23.601200103759766,
                longitude= -46.399383544921875,
                speed= 11.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:28:31.614754500Z"),
                latitude= -23.599117279052734,
                longitude= -46.40202713012695,
                speed= 103.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:28:41.614754500Z"),
                latitude= -23.59877586364746,
                longitude= -46.40243148803711,
                speed= 54.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:29:01.614754500Z"),
                latitude= -23.597719192504883,
                longitude= -46.403602600097656,
                speed= 83.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:29:21.614754500Z"),
                latitude= -23.59648323059082,
                longitude= -46.40481185913086,
                speed= 115.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:29:41.614754500Z"),
                latitude= -23.59589958190918,
                longitude= -46.40511703491211,
                speed= 40.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:30:01.614754500Z"),
                latitude= -23.594615936279297,
                longitude= -46.405799865722656,
                speed= 53.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:30:21.614754500Z"),
                latitude= -23.593225479125977,
                longitude= -46.4065055847168,
                speed= 17.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:30:41.614754500Z"),
                latitude= -23.59309196472168,
                longitude= -46.40658950805664,
                speed= 71.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:31:01.614754500Z"),
                latitude= -23.59177589416504,
                longitude= -46.4072265625,
                speed= 114.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:31:21.614754500Z"),
                latitude= -23.59037208557129,
                longitude= -46.40790557861328,
                speed= 83.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:31:41.614754500Z"),
                latitude= -23.589048385620117,
                longitude= -46.408573150634766,
                speed= 117.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:32:01.614754500Z"),
                latitude= -23.588258743286133,
                longitude= -46.40890884399414,
                speed= 46.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:32:21.614754500Z"),
                latitude= -23.588232040405273,
                longitude= -46.408931732177734,
                speed= 101.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:32:41.614754500Z"),
                latitude= -23.587669372558594,
                longitude= -46.40909957885742,
                speed= 27.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:33:01.614754500Z"),
                latitude= -23.5864200592041,
                longitude= -46.40925979614258,
                speed= 29.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:33:21.614754500Z"),
                latitude= -23.586030960083008,
                longitude= -46.40924072265625,
                speed= 55.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:33:41.614754500Z"),
                latitude= -23.585206985473633,
                longitude= -46.409122467041016,
                speed= 16.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:34:01.614754500Z"),
                latitude= -23.58449935913086,
                longitude= -46.408912658691406,
                speed= 116.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:34:21.614754500Z"),
                latitude= -23.584312438964844,
                longitude= -46.40884780883789,
                speed= 89.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:34:41.614754500Z"),
                latitude= -23.584150314331055,
                longitude= -46.40883255004883,
                speed= 17.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:35:01.614754500Z"),
                latitude= -23.584150314331055,
                longitude= -46.40883255004883,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:35:21.614754500Z"),
                latitude= -23.583717346191406,
                longitude= -46.408878326416016,
                speed= 26.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:35:41.614754500Z"),
                latitude= -23.58323860168457,
                longitude= -46.409034729003906,
                speed= 106.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:36:01.614754500Z"),
                latitude= -23.583192825317383,
                longitude= -46.408348083496094,
                speed= 51.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:36:21.614754500Z"),
                latitude= -23.58333969116211,
                longitude= -46.40792465209961,
                speed= 38.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:36:41.614754500Z"),
                latitude= -23.583410263061523,
                longitude= -46.40766906738281,
                speed= 63.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:37:01.614754500Z"),
                latitude= -23.583492279052734,
                longitude= -46.40740966796875,
                speed= 114.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:37:21.614754500Z"),
                latitude= -23.583316802978516,
                longitude= -46.40657424926758,
                speed= 81.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:37:41.614754500Z"),
                latitude= -23.582469940185547,
                longitude= -46.407440185546875,
                speed= 11.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:38:01.614754500Z"),
                latitude= -23.582874298095703,
                longitude= -46.408782958984375,
                speed= 11.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:38:21.614754500Z"),
                latitude= -23.582897186279297,
                longitude= -46.408809661865234,
                speed= 116.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:38:41.614754500Z"),
                latitude= -23.582897186279297,
                longitude= -46.408809661865234,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:39:01.614754500Z"),
                latitude= -23.58298110961914,
                longitude= -46.408966064453125,
                speed= 108.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:39:21.614754500Z"),
                latitude= -23.582134246826172,
                longitude= -46.41006088256836,
                speed= 42.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:39:41.614754500Z"),
                latitude= -23.580488204956055,
                longitude= -46.41124725341797,
                speed= 19.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:40:01.614754500Z"),
                latitude= -23.57977294921875,
                longitude= -46.41226577758789,
                speed= 94.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:40:21.614754500Z"),
                latitude= -23.58047866821289,
                longitude= -46.41340637207031,
                speed= 27.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:40:41.614754500Z"),
                latitude= -23.58108139038086,
                longitude= -46.41441345214844,
                speed= 43.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:41:01.614754500Z"),
                latitude= -23.581554412841797,
                longitude= -46.41506576538086,
                speed= 11.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:41:21.614754500Z"),
                latitude= -23.581554412841797,
                longitude= -46.41506576538086,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:41:41.614754500Z"),
                latitude= -23.58160972595215,
                longitude= -46.41514587402344,
                speed= 44.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:42:01.614754500Z"),
                latitude= -23.58281898498535,
                longitude= -46.415130615234375,
                speed= 28.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:42:21.614754500Z"),
                latitude= -23.583757400512695,
                longitude= -46.4150276184082,
                speed= 67.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:42:41.614754500Z"),
                latitude= -23.58536720275879,
                longitude= -46.41487503051758,
                speed= 25.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:43:01.614754500Z"),
                latitude= -23.58705711364746,
                longitude= -46.41489791870117,
                speed= 16.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:43:21.614754500Z"),
                latitude= -23.58745765686035,
                longitude= -46.41499328613281,
                speed= 115.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:43:41.614754500Z"),
                latitude= -23.589210510253906,
                longitude= -46.41565704345703,
                speed= 108.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:44:01.614754500Z"),
                latitude= -23.589759826660156,
                longitude= -46.41638946533203,
                speed= 82.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:44:21.614754500Z"),
                latitude= -23.589859008789062,
                longitude= -46.416481018066406,
                speed= 117.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:44:41.614754500Z"),
                latitude= -23.590085983276367,
                longitude= -46.4166374206543,
                speed= 94.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:45:01.614754500Z"),
                latitude= -23.590085983276367,
                longitude= -46.4166374206543,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:45:21.614754500Z"),
                latitude= -23.590133666992188,
                longitude= -46.416656494140625,
                speed= 79.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:45:41.614754500Z"),
                latitude= -23.590253829956055,
                longitude= -46.416709899902344,
                speed= 78.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:46:01.614754500Z"),
                latitude= -23.59038734436035,
                longitude= -46.41675567626953,
                speed= 20.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:46:21.614754500Z"),
                latitude= -23.59038734436035,
                longitude= -46.41675567626953,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:46:41.614754500Z"),
                latitude= -23.59044647216797,
                longitude= -46.41678237915039,
                speed= 15.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:47:01.614754500Z"),
                latitude= -23.590559005737305,
                longitude= -46.41682052612305,
                speed= 27.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:47:21.614754500Z"),
                latitude= -23.59058380126953,
                longitude= -46.41682815551758,
                speed= 71.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:47:41.614754500Z"),
                latitude= -23.59061622619629,
                longitude= -46.416831970214844,
                speed= 116.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:48:01.614754500Z"),
                latitude= -23.590797424316406,
                longitude= -46.41688919067383,
                speed= 82.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:48:21.614754500Z"),
                latitude= -23.591129302978516,
                longitude= -46.417022705078125,
                speed= 102.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:48:41.614754500Z"),
                latitude= -23.59122657775879,
                longitude= -46.41706085205078,
                speed= 66.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:49:01.614754500Z"),
                latitude= -23.59141731262207,
                longitude= -46.417144775390625,
                speed= 90.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:49:21.614754500Z"),
                latitude= -23.591594696044922,
                longitude= -46.41722869873047,
                speed= 72.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:49:41.614754500Z"),
                latitude= -23.591707229614258,
                longitude= -46.41728973388672,
                speed= 77.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:50:01.614754500Z"),
                latitude= -23.591861724853516,
                longitude= -46.41740417480469,
                speed= 90.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:50:21.614754500Z"),
                latitude= -23.59218978881836,
                longitude= -46.41765213012695,
                speed= 88.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:50:41.614754500Z"),
                latitude= -23.592416763305664,
                longitude= -46.41783905029297,
                speed= 97.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:51:01.614754500Z"),
                latitude= -23.59246253967285,
                longitude= -46.41788101196289,
                speed= 35.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:51:21.614754500Z"),
                latitude= -23.592578887939453,
                longitude= -46.417964935302734,
                speed= 79.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:51:41.614754500Z"),
                latitude= -23.592987060546875,
                longitude= -46.41826248168945,
                speed= 55.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:52:01.614754500Z"),
                latitude= -23.5931396484375,
                longitude= -46.41837692260742,
                speed= 17.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:52:21.614754500Z"),
                latitude= -23.593608856201172,
                longitude= -46.418731689453125,
                speed= 78.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:52:41.614754500Z"),
                latitude= -23.593643188476562,
                longitude= -46.41875457763672,
                speed= 72.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:53:01.614754500Z"),
                latitude= -23.59390640258789,
                longitude= -46.419036865234375,
                speed= 26.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:53:21.614754500Z"),
                latitude= -23.594009399414062,
                longitude= -46.42090606689453,
                speed= 76.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:53:41.614754500Z"),
                latitude= -23.594022750854492,
                longitude= -46.42219924926758,
                speed= 39.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:54:01.614754500Z"),
                latitude= -23.59421730041504,
                longitude= -46.423545837402344,
                speed= 65.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:54:21.614754500Z"),
                latitude= -23.594274520874023,
                longitude= -46.42395782470703,
                speed= 18.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:54:41.614754500Z"),
                latitude= -23.594404220581055,
                longitude= -46.42506790161133,
                speed= 111.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:55:01.614754500Z"),
                latitude= -23.594554901123047,
                longitude= -46.42612075805664,
                speed= 73.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:55:21.614754500Z"),
                latitude= -23.594688415527344,
                longitude= -46.426937103271484,
                speed= 112.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:55:41.614754500Z"),
                latitude= -23.59483528137207,
                longitude= -46.42790985107422,
                speed= 67.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:56:01.614754500Z"),
                latitude= -23.595104217529297,
                longitude= -46.429622650146484,
                speed= 89.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:56:21.614754500Z"),
                latitude= -23.595054626464844,
                longitude= -46.43148422241211,
                speed= 89.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:56:41.614754500Z"),
                latitude= -23.595197677612305,
                longitude= -46.43343734741211,
                speed= 25.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:57:01.614754500Z"),
                latitude= -23.595447540283203,
                longitude= -46.43409729003906,
                speed= 119.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:57:21.614754500Z"),
                latitude= -23.595684051513672,
                longitude= -46.43461990356445,
                speed= 101.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:57:41.614754500Z"),
                latitude= -23.59572410583496,
                longitude= -46.434722900390625,
                speed= 79.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:58:01.614754500Z"),
                latitude= -23.595746994018555,
                longitude= -46.43476867675781,
                speed= 29.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:58:21.614754500Z"),
                latitude= -23.59575843811035,
                longitude= -46.4348030090332,
                speed= 92.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:58:41.614754500Z"),
                latitude= -23.595956802368164,
                longitude= -46.435203552246094,
                speed= 28.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:59:01.614754500Z"),
                latitude= -23.596086502075195,
                longitude= -46.435482025146484,
                speed= 71.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:59:21.614754500Z"),
                latitude= -23.59609603881836,
                longitude= -46.43558120727539,
                speed= 64.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T14:59:41.614754500Z"),
                latitude= -23.59609603881836,
                longitude= -46.43558120727539,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T15:00:01.614754500Z"),
                latitude= -23.596099853515625,
                longitude= -46.43573760986328,
                speed= 80.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T15:00:21.614754500Z"),
                latitude= -23.5960693359375,
                longitude= -46.436038970947266,
                speed= 67.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T15:00:41.614754500Z"),
                latitude= -23.596017837524414,
                longitude= -46.43617248535156,
                speed= 65.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T15:01:01.614754500Z"),
                latitude= -23.596017837524414,
                longitude= -46.43617248535156,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T15:01:21.614754500Z"),
                latitude= -23.595966339111328,
                longitude= -46.436309814453125,
                speed= 35.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:15:41.614754500Z"),
                latitude= -23.547677993774414,
                longitude= -46.603153228759766,
                speed= 52.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:16:01.614754500Z"),
                latitude= -23.546567916870117,
                longitude= -46.60422897338867,
                speed= 40.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:16:21.614754500Z"),
                latitude= -23.54631233215332,
                longitude= -46.60529708862305,
                speed= 81.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:16:41.614754500Z"),
                latitude= -23.546428680419922,
                longitude= -46.6054801940918,
                speed= 74.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:17:01.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 80.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:17:21.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:17:41.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:18:01.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:18:21.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:18:41.614754500Z"),
                latitude= -23.54644012451172,
                longitude= -46.60548400878906,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:19:01.614754500Z"),
                latitude= -23.54647445678711,
                longitude= -46.60554885864258,
                speed= 30.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:19:21.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 37.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:19:41.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:20:01.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:20:21.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:20:41.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:21:01.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:21:21.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:21:41.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:22:01.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:22:21.614754500Z"),
                latitude= -23.546485900878906,
                longitude= -46.605567932128906,
                speed= 0.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:22:41.614754500Z"),
                latitude= -23.546493530273438,
                longitude= -46.60558319091797,
                speed= 36.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:23:01.614754500Z"),
                latitude= -23.546566009521484,
                longitude= -46.60575866699219,
                speed= 12.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:23:21.614754500Z"),
                latitude= -23.54669189453125,
                longitude= -46.60590744018555,
                speed= 42.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:23:41.614754500Z"),
                latitude= -23.54723358154297,
                longitude= -46.606895446777344,
                speed= 107.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:24:01.614754500Z"),
                latitude= -23.547340393066406,
                longitude= -46.60708999633789,
                speed= 74.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:24:21.614754500Z"),
                latitude= -23.547550201416016,
                longitude= -46.60712814331055,
                speed= 35.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:24:41.614754500Z"),
                latitude= -23.548419952392578,
                longitude= -46.60639572143555,
                speed= 98.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:25:01.614754500Z"),
                latitude= -23.549325942993164,
                longitude= -46.605594635009766,
                speed= 64.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:25:21.614754500Z"),
                latitude= -23.5493221282959,
                longitude= -46.6055908203125,
                speed= 57.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:25:41.614754500Z"),
                latitude= -23.5493221282959,
                longitude= -46.6055908203125,
                speed= 0.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-24T16:26:01.614754500Z"),
                latitude= -23.54652,
                longitude= -46.60548,
                speed= 0.0
            )
        )

        listRotaMetalurgico.forEach {

            val iotMessage = AssetIotEventMessage(
                assetId = UUID.fromString("5353be13-d35a-4531-a6e8-83c61b4fb2a8"),
                accountId =  AccountContext.set("d87f9f41-5950-45b1-9044-ecb5d32039d8").toString(),
                deviceId = UUID.fromString("8664cbbb-ff0b-4332-89dc-1aa283f1856d"),
                deviceType = "tbm3",
                driverIdentification = null,
                driverIdentificationType = null,
                eid = "tbm:2006290118/67/1675694409761/394/state/d9010aed-3df8-432f-bdc2-b4f0bd7d9949",
                occurredAt = it.occurred_at,
                trigger = "timer",
                position = AssetPositionMessage(
                    it.latitude,
                    it.longitude,
                    altitude = 739.2000122070312,
                    accuracy = 3.200000047683716,
                    altitudeAccuracy = null,
                    heading = 51.9900016784668,
                    speed = it.speed                ),
                state = AssetStateMessage(
                    mileage = 212191.5625,
                    ignitionOn = false,
                    fuelLevel = 71.19999694824219,
                    stateOfCharge = null,
                    electricRange = null,
                    engineSpeed = 1566.0,
                    wheelSpeed = 27.8984375,
                    tachoSpeed = 28.0,
                    fuelConsumption = null,
                    acceleratorPedal = null,
                    weightTotal = null,
                    ptoInformation = null,
                    electronicRetarderState = null,
                    driveState = null,
                    fuelRate = null,
                    instantaneousFuelEconomy = null,
                    engineOperationTime = null                ),
                driverInfo = null,
                driverState = null            )

            infringementDetection.start(iotMessage)
        }
    }
}
data class DataAsset(
    val latitude: Double,
    val longitude: Double,
    val occurred_at: OffsetDateTime,
    val speed: Double,
    val mileage_in_km: Double = 0.0,
    )
