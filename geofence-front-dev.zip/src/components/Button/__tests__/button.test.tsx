import React from 'react'
import { cleanup, fireEvent, render } from '@testing-library/react'
import '@testing-library/jest-dom'
import { Button } from 'components'

afterEach(cleanup)

it('should trigger the function after click on <Button />', () => {
  const handleClick = jest.fn()
  const { getByText } = render(
    <Button label="Button Ok" onClick={handleClick} />
  );
  expect(handleClick).not.toHaveBeenCalled()
  fireEvent.click(getByText('Button Ok'));
  expect(handleClick).toHaveBeenCalled()
});
