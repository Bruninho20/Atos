import {
  DEFAULT_LANG,
  DEFAULT_LOCALE,
  extractLanguage,
  supportedLocaleMap
} from './lang';

describe('features/lang/lang', () => {
  it('should export the suitable default language', () => {
    expect(DEFAULT_LANG).toEqual('pt');
  });

  it('should export the suitable default locale', () => {
    expect(DEFAULT_LOCALE).toEqual('pt-BR');
  });

  it('should provide a map of the supported locales', () => {
    expect(supportedLocaleMap).toEqual({
      'bg-BG': 'bg-BG',
      'cs-CZ': 'cs-CZ',
      'da-DK': 'da-DK',
      'el-GR': 'el-GR',
      'en-GB': 'en-GB',
      'es-ES': 'es-ES',
      'et-EE': 'et-EE',
      'fi-FI': 'fi-FI',
      'fr-FR': 'fr-FR',
      'hr-HR': 'hr-HR',
      'hu-HU': 'hu-HU',
      'it-IT': 'it-IT',
      'lt-LT': 'lt-LT',
      'lv-LV': 'lv-LV',
      'nb-NO': 'nb-NO',
      'nl-NL': 'nl-NL',
      'pl-PL': 'pl-PL',
      'pt-BR': 'pt-BR',
      'pt-PT': 'pt-PT',
      'ro-RO': 'ro-RO',
      'sk-SK': 'sk-SK',
      'sl-SI': 'sl-SI',
      'sv-SE': 'sv-SE',
      'de-DE': 'de-DE',

      bg: 'bg-BG',
      cs: 'cs-CZ',
      da: 'da-DK',
      el: 'el-GR',
      en: 'en-GB',
      es: 'es-ES',
      et: 'et-EE',
      fi: 'fi-FI',
      fr: 'fr-FR',
      hr: 'hr-HR',
      hu: 'hu-HU',
      it: 'it-IT',
      lt: 'lt-LT',
      lv: 'lv-LV',
      nb: 'nb-NO',
      nl: 'nl-NL',
      pl: 'pl-PL',
      pt: 'pt-BR',
      ro: 'ro-RO',
      sk: 'sk-SK',
      sl: 'sl-SI',
      sv: 'sv-SE',
      de: 'de-DE'
    });
  });

  describe('the "extractLanguage" helper', () => {
    /* eslint-disable no-undefined */

    it('should return the language part of a locale', () => {
      expect(extractLanguage('fr-FR')).toEqual('fr');
    });

    it('should return the default language', () => {
      expect(extractLanguage(null)).toEqual('pt');
      expect(extractLanguage(undefined)).toEqual('pt');
    });

    it('should be ok when the structure does not match what is expected', () => {
      expect(extractLanguage('cs')).toEqual('cs');
    });
  });
});

// import {
//   DEFAULT_LANG,
//   DEFAULT_LOCALE,
//   extractLanguage,
//   supportedLocaleMap
// } from './lang';

// describe(`features/lang/lang`, () => {
//   it(`should export the suitable default language`, () => {
//     expect(DEFAULT_LANG).toEqual('en');
//   });

//   it(`should export the suitable default locale`, () => {
//     expect(DEFAULT_LOCALE).toEqual('en-GB');
//   });

//   it(`should provide a map of the supported locales`, () => {
//     expect(supportedLocaleMap).toEqual({
//       de: 'de-DE',
//       'de-DE': 'de-DE',
//       en: 'en-GB',
//       'en-GB': 'en-GB',
//       pt: 'pt-BR',
//       'pt-BR': 'pt-BR'
//     });
//   });

//   describe(`the "extractLanguage" helper`, () => {
//     /* eslint-disable no-undefined */

//     it(`should return the language part of a locale`, () => {
//       expect(extractLanguage('fr-FR')).toEqual('fr');
//     });

//     it(`should return the default language`, () => {
//       expect(extractLanguage(null)).toEqual('en');
//       expect(extractLanguage(undefined)).toEqual('en');
//     });

//     it(`should be ok when the structure does not match what is expected`, () => {
//       expect(extractLanguage('cs')).toEqual('cs');
//     });
//   });
// });
