package cloud.rio.latam_routefence.auth

import com.fasterxml.jackson.annotation.JsonProperty

class InternalAuthResponse(
    @JsonProperty("access_token")
    val accessToken: String = "",
    @JsonProperty("scope")
    val scope: String = "",
    @JsonProperty("iss")
    val iss: String = "",
    @JsonProperty("token_type")
    val tokenType: String = "",
    @JsonProperty("exp")
    val exp: String = "",
    @JsonProperty("expires_in")
    val expiresIn: String = "",
    @JsonProperty("iat")
    val iat: String = "",
    @JsonProperty("jti")
    val jti: String = ""
)