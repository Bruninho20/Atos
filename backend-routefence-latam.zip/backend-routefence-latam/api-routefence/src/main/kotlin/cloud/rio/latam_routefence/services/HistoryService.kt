package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.repositories.HistoryRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.response.HistoryResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapForTripsWithoutHistory
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToHistory
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

@Service
@Transactional
class HistoryService(private val historyRepository: HistoryRepository,
 private val  tripService: TripService) {
    lateinit var route: RouteEntity

    //TODO Melhorar lógica e/ou nome de variáveis
    fun findTripByTripAndPeriod(tripId: String, startDateTime: String?, endDateTime: String?): HistoryResponse {
        try {
            val assetCourses: List<AssetCourseEntity>

            var newStartDateTime = startDateTime
            var newEndDateTime = endDateTime

            val assetCourse = historyRepository.findAssetByTrip(tripId).sortedBy { it.occurredAt }

            if ((!newStartDateTime.isNullOrBlank() && newStartDateTime != "null") || (!newEndDateTime.isNullOrBlank() && newEndDateTime != "null")) {
                if (newStartDateTime != null && newStartDateTime != "null") {
                    val startDateTimeParsed = LocalDateTime.parse(newStartDateTime, DateTimeFormatter.ISO_DATE_TIME)
                    if (startDateTimeParsed < assetCourse.first().occurredAt || startDateTimeParsed > assetCourse.last().occurredAt ) {
                        newStartDateTime = assetCourse.first().occurredAt.format(DateTimeFormatter.ISO_DATE_TIME)
                    }
                }

                if (newEndDateTime != null && newEndDateTime != "null") {
                    val endDateTimeParsed = LocalDateTime.parse(newEndDateTime, DateTimeFormatter.ISO_DATE_TIME)
                    if (endDateTimeParsed > assetCourse.last().occurredAt || endDateTimeParsed < assetCourse.first().occurredAt) {
                        newEndDateTime = assetCourse.last().occurredAt.format(DateTimeFormatter.ISO_DATE_TIME)
                    }
                }
            } else {
                newStartDateTime = assetCourse.first().occurredAt.format(DateTimeFormatter.ISO_DATE_TIME)
                newEndDateTime =  assetCourse.last().occurredAt.format(DateTimeFormatter.ISO_DATE_TIME)
            }

            if (!newStartDateTime.isNullOrBlank() && !newEndDateTime.isNullOrBlank()) {
                val startTime = LocalDateTime.parse(newStartDateTime, DateTimeFormatter.ISO_DATE_TIME).atOffset(ZoneOffset.UTC)
                val endTime = LocalDateTime.parse(newEndDateTime, DateTimeFormatter.ISO_DATE_TIME).atOffset(ZoneOffset.UTC)
                assetCourses = historyRepository.findAssetByTripAndPeriod(tripId, startTime.toLocalDateTime(), endTime.toLocalDateTime())
            } else {
                assetCourses = historyRepository.findAssetByTrip(tripId)
            }

            val route = assetCourses.first().trip.route
            return mapToHistory(assetCourses, route)

        } catch (e: Exception) {
            val trip = tripService.findTripById(tripId)
            return mapForTripsWithoutHistory(trip)
        }
    }
}
