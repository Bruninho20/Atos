package cloud.rio.latam_routefence.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.support.ResourceBundleMessageSource
import org.springframework.http.HttpHeaders
import org.springframework.web.servlet.LocaleResolver
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver
import java.util.*
import javax.servlet.http.HttpServletRequest

@Configuration
class LocaleConfig {
    @Bean
    fun messageSource(): ResourceBundleMessageSource {
        return ResourceBundleMessageSource().apply {
            setBasenames("locale/messages", "messages")
            setDefaultEncoding("UTF-8")
            setUseCodeAsDefaultMessage(true)
            setFallbackToSystemLocale(false)
        }
    }

    @Bean
    fun localeResolver(): LocaleResolver {
        return SmartLocaleResolver()
    }

    class SmartLocaleResolver : AcceptHeaderLocaleResolver() {
        override fun resolveLocale(request: HttpServletRequest): Locale {
            val languageHeader = request.getHeader(HttpHeaders.ACCEPT_LANGUAGE) ?: ""
            if (languageHeader.isNotBlank()) {
                val locale = languageHeader.split("-".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                if (locale.size == 2) {
                    return Locale(locale[0], locale[1])
                }
            }
            return Locale.getDefault()
        }
    }
}