import styled from 'styled-components'
import { metrics } from 'core/assets/styles';

export const CustomDialogText = styled.div`
  p {
    font-size: ${metrics.fontSizeMedium}
  }
`