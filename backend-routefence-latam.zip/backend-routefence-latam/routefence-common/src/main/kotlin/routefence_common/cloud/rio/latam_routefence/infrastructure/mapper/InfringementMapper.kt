package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.InfringementResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.InfringementEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity

fun InfringementRequest.mapToNewEntity(tripEntity: TripEntity): InfringementEntity {
    return InfringementEntity(
        type = this.type,
        note = this.note,
        startDateTime = this.startDateTime,
        endDateTime = this.endDateTime,
        location = this.location.mapToEntity(),
        trip = tripEntity
    )
}

fun InfringementRequest.mapToEntity(tripEntity: TripEntity): InfringementEntity{
    return InfringementEntity(
        id = this.id,
        type = this.type,
        note = this.note,
        startDateTime = this.startDateTime,
        endDateTime = this.endDateTime,
        location = this.location.mapToEntity(),
        trip = tripEntity
    )
}

fun InfringementEntity.mapToResponse(): InfringementResponse{
    return InfringementResponse(
        id = this.id!!,
        type = this.type.toString(),
        note = this.note,
        startDateTime = this.startDateTime.toString(),
        endDateTime = this.endDateTime.toString(),
        location = this.location.mapToResponse(),
        trip = this.trip?.id //trip = this.trip?.mapToResponse()
    )
}