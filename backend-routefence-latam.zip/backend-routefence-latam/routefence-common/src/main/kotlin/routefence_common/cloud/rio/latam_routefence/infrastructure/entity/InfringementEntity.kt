package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import com.fasterxml.jackson.annotation.JsonBackReference
import com.fasterxml.jackson.annotation.JsonIgnore
import org.hibernate.annotations.DynamicUpdate
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_INFRINGEMENT")
data class InfringementEntity(
    @Id
    @Column(name = "ID")
    val id: String? = UUID.randomUUID().toString(),

    @Column(name = "TYPE")
    @Enumerated(EnumType.STRING)
    val type: InfringementTypeEnum,

    @Column(name = "NOTE")
    var note: String?,

    @Column(name = "VIEWED")
    var viewed: Boolean = false,

    @Column(name = "START_DATETIME")
    val startDateTime: LocalDateTime? = LocalDateTime.now(),

    @Column(name = "END_DATETIME")
    var endDateTime: LocalDateTime?,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "location_id", referencedColumnName = "ID")
    val location: GeoPointEntity,

    @JsonBackReference
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TRIP_ID", referencedColumnName = "ID")
    @JsonIgnore
    var trip: TripEntity?
){
    override fun toString(): String {
        val sb = StringBuilder()
        sb.append("id: $id, ")
            .append("type: $type, ")
            .append("note: $note, ")
            .append("startDateTime: ${startDateTime.toString()}, ")
            .append("endDateTime: ${endDateTime.toString()}")
        return sb.toString()
    }
}