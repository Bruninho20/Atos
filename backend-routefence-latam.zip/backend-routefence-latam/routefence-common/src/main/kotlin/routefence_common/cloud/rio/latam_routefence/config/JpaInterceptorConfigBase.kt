package routefence_common.cloud.rio.latam_routefence.config

import org.hibernate.EmptyInterceptor
import org.hibernate.type.Type
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AccountTenantEntity
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.io.Serializable
import javax.sql.DataSource

open class JpaInterceptorConfigBase {

    open fun hibernateInterceptor(): EmptyInterceptor? {
        return object : EmptyInterceptor() {
            override fun onDelete(
                entity: Any?,
                id: Serializable?,
                state: Array<Any>?,
                propertyNames: Array<String>?,
                types: Array<Type>?
            ) {
                if (entity is AccountTenantEntity) {
                    addAccountId(state, propertyNames)
                }
            }

            override fun onFlushDirty(
                entity: Any?,
                id: Serializable?,
                state: Array<Any>?,
                previousState: Array<Any>?,
                propertyNames: Array<String>?,
                types: Array<Type?>?
            ): Boolean {
                if (entity is AccountTenantEntity) {
                    addAccountId(state, propertyNames)
                }
                return false
            }

            override fun onSave(
                entity: Any,
                id: Serializable?,
                state: Array<Any>?,
                propertyNames: Array<String>?,
                types: Array<Type?>?
            ): Boolean {
                if (entity is AccountTenantEntity) {
                    addAccountId(state, propertyNames)
                }
                return false
            }

            override fun onLoad(
                entity: Any?,
                id: Serializable?,
                state: Array<Any>?,
                propertyNames: Array<String>?,
                types: Array<Type>?
            ): Boolean {
                if (entity is AccountTenantEntity) {
                    addAccountId(state, propertyNames)
                }
                return false
            }

            private fun addAccountId(state: Array<Any>?, propertyNames: Array<String>?) {
                if (propertyNames != null && AccountContext.get() != "SYS") {
                    for ((index, value) in propertyNames.withIndex()) {
                        if (value == AccountContext.ACCOUNT_ID_PARAM) {
                            state?.set(index, AccountContext.get())
                            break
                        }
                    }
                }
            }
        }
    }

    open fun entityManagerFactory(
        factory: EntityManagerFactoryBuilder,
        dataSource: DataSource?,
        jpaProperties: JpaProperties?
    ): LocalContainerEntityManagerFactoryBean? {
        val jpaPropertiesMap: MutableMap<String, Any?> = HashMap(jpaProperties?.properties)
        jpaPropertiesMap["hibernate.ejb.interceptor"] = hibernateInterceptor()
        return factory.dataSource(dataSource).packages(
            "routefence_common.cloud.rio.latam_routefence"
        ).properties(jpaPropertiesMap).build()
    }
}