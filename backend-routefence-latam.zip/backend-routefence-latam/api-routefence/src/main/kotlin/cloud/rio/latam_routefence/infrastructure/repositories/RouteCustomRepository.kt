package cloud.rio.latam_routefence.infrastructure.repositories

import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse

interface RouteCustomRepository {
    fun findByRoutId(id: String): RouteResponse?
}