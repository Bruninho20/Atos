import React, { FC, useEffect, useState } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
import { format } from 'date-fns'

import useCustomSWRInfinite from 'core/utils/useCustomSWRInfinite'
import useDebounce from 'core/utils/use-debounce'

import { Pagination, Table } from 'components'
import { SortDirection } from 'rio-uikit'

import { Row, Sort } from 'components/Table'
import { Period } from 'components/DateTimeFilter'
import FaultCodesDetailsSidesheet, { CustomFaultCodesModel } from './FaultCodesDetailsSidesheet'

export interface FaultCodeModel {
  date: string
  fmi: string
  fmiDescription: string
  lampStatus: string
  latitude: string
  longitude: string
  sourceAddress: string
  spn: string
  spnDescription: string
  vehicle: string
  description: string
}

interface FaultCodesData extends Row {
  data: FaultCodeModel[]
  total: number
}

interface FaultCodesProps {
  assetsId: string[]
  tagsId: string[]
  dateTime: Period
  intl: Intl
}

const FaultCodes: FC<FaultCodesProps> = ({ assetsId, tagsId, dateTime, intl }) => {
  const [faultCodesDetails, setFaultCodesDetails] = useState<{ isOpen: boolean; data?: CustomFaultCodesModel }>({
    isOpen: false,
    data: undefined
  })
  const [sort, setSort] = useState({ sortBy: '', sortDirection: SortDirection.ASCENDING })

  const [search, setSearch] = useState('')
  const debouseSearch = useDebounce(search, 1000)

  const pageSize = 50
  const [propsData, setProps] = useState({})

  const { data: faultCodes = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<FaultCodesData[]>(
    '/faultCodes',
    'POST',
    propsData,
    pageSize
  )

  const getFaultCodes = (
    assetsId: string[],
    tagsId: string[],
    startAt: string,
    endAt: string,
    search: string,
    order: string
  ) => {
    let propsData: Record<string, unknown> = {
      assetIds: assetsId,
      tagIds: tagsId,
      pageSize,
      startAt,
      endAt,
      search
    }

    if (order !== '[]' && order !== '') {
      propsData = {
        ...propsData,
        order: [order]
      }
    }

    setProps(propsData)
  }

  const order = sort.sortBy ? `${sort.sortDirection === SortDirection.ASCENDING ? '' : '-'}${sort.sortBy}` : ''

  const handleChangeSort = (sortBy: Sort['sortBy'], sortDirection: Sort['sortDirection']) =>
    setSort({ sortBy, sortDirection })

  const handleSearch = (search: string) => {
    setSearch(search)
  }

  const handleFetchMore = () => {
    setSize(size + 1)
  }

  const handleLineClick = (data: CustomFaultCodesModel) => {
    setFaultCodesDetails({
      isOpen: true,
      data
    })
  }

  const rowsPagineted = faultCodes.map((faultCodesPage: FaultCodesData) => {
    return faultCodesPage
      ? faultCodesPage.data.map((faultCodesRow, index) => {
          const dateTimeZoneZero = format(new Date(faultCodesRow.date), "yyyy-MM-dd'T'HH:mm:ss.SSS") + '-00:00'

          return {
            ...faultCodesRow,
            index: index.toString(),
            date: format(new Date(dateTimeZoneZero), 'dd/MM/yyyy HH:mm:ss'),
            geolocation: `${faultCodesRow.latitude} / ${faultCodesRow.longitude}`
          }
        })
      : []
  })

  useEffect(() => {
    getFaultCodes(assetsId, tagsId, dateTime.from, dateTime.to, debouseSearch, order)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assetsId, tagsId, dateTime.from, dateTime.to, debouseSearch, order])

  useEffect(() => {
    setSize(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [propsData])

  return (
    <>
      <FaultCodesDetailsSidesheet
        isOpen={faultCodesDetails.isOpen}
        data={faultCodesDetails.data}
        onClose={() => setFaultCodesDetails({ isOpen: false })}
      />
      <Table
        name='faultCodesTable2'
        status={status}
        rowsPagineted={rowsPagineted}
        rowsCount={pageSize}
        disabledColumns={[]}
        columnsStyle={{
          date: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          sourceAddress: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          spn: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          spnDescription: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          fmi: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          fmiDescription: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          lampStatus: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          geolocation: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          vehicle: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          }
        }}
        columnLabels={{
          date: <FormattedMessage id='date' />,
          sourceAddress: <FormattedMessage id='sourceAddress' />,
          spn: <FormattedMessage id='spn' />,
          spnDescription: <FormattedMessage id='spnDescription' />,
          fmi: <FormattedMessage id='fmi' />,
          fmiDescription: <FormattedMessage id='fmiDescription' />,
          lampStatus: <FormattedMessage id='lampStatus' />,
          geolocation: <FormattedMessage id='geolocation' />,
          vehicle: <FormattedMessage id='vehicle' />
        }}
        defaultColumnOrder={[
          'date',
          'sourceAddress',
          'spn',
          'spnDescription',
          'fmi',
          'fmiDescription',
          'lampStatus',
          'geolocation',
          'vehicle'
        ]}
        sort={sort}
        settingsCloseButtonText={<FormattedMessage id='settingsCloseButtonText' />}
        settingsNotFoundMessage={<FormattedMessage id='settingsNotFoundMessage' />}
        settingsResetButtonText={<FormattedMessage id='settingsResetButtonText' />}
        settingsSearchPlaceholder={intl.formatMessage({ id: 'settingsSearchPlaceholder' })}
        settingsTitle={<FormattedMessage id='settingsTitle' />}
        searchLabel={intl.formatMessage({ id: 'searchLabel' }, { value: intl.formatMessage({ id: 'failures' }) })}
        search={search}
        lineClickName='allColumns'
        onLineClick={(handleLineClick as unknown) as (row: Row) => void}
        onChangeSearch={handleSearch}
        onChangeSort={handleChangeSort}
      />
      {status === 'success' && faultCodes && faultCodes[0].total > 0 && (
        <Pagination
          paginationDescription={intl.formatMessage({ id: 'paginationDescription' })}
          buttonLoadMoreLabel={<FormattedMessage id='buttonLoadMoreLabel' />}
          buttonEverythingLoadedLabel={<FormattedMessage id='buttonEverythingLoadedLabel' />}
          lenghtPerPage={pageSize || 50}
          page={size || 1}
          onLoadmore={handleFetchMore}
          size={faultCodes[0].total || 50}
        />
      )}
    </>
  )
}

export default injectIntl(FaultCodes)
