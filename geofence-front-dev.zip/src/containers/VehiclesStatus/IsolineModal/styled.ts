import styled from 'styled-components'

export const Container = styled.div`
  width: auto;
  border: solid;
  border-color: gray;
  border-radius: 8px;
  padding: 0px;

  .class-title {
    color: #000;
    font-weight: 700;
    font-size: 4vh;
    margin-bottom: 20px;
  }
  .class-subtitle {
      font-size: 2vh;
      font-weight: 600;
      margin-bottom: 10px;
  }
`
