import React from 'react';
import PropTypes from 'prop-types';

import { Marker, Map as RioMap, SingleMapMarker } from 'rio-uikit-map';

const Map = ({
  labelName,
  height,
  apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw',
  latitude,
  longitude
}) => {
  const markerIcon = (
    <SingleMapMarker
      iconNames={['geofence']}
      name={labelName}
      markerColor={'bg-map-marker-poi'}
    />
  );

  return (
    <div style={{ height: '100%' }}>
      <RioMap
        credentials={{
          apikey:
            typeof apiKey === 'string'
              ? apiKey
              : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
        }}
        center={{ lat: latitude, lng: longitude }}
        zoom={15}
        hideMapSettings
        style={{ borderRadius: '3px' }}
        height={height}
      >
        <Marker
          position={{ lat: latitude, lng: longitude }}
          icon={markerIcon}
        />
      </RioMap>
    </div>
  );
};

Map.propTypes = {
  labelName: PropTypes.string.isRequired,
  height: PropTypes.string.isRequired,
  apiKey: PropTypes.string,
  latitude: PropTypes.oneOfType(PropTypes.string, PropTypes.number).isRequired,
  longitude: PropTypes.oneOfType(PropTypes.string, PropTypes.number).isRequired
};

export default Map;
