package listener.cloud.rio.latam_routefence.services

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import listener.cloud.rio.latam_routefence.infrastructure.mapper.mapToBusinessObject
import routefence_common.cloud.rio.latam_routefence.utils.DateFormatter
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import java.util.UUID

@Service
@Transactional
class InfringementDetection(
    private val tripService: TripService,
    private val assetCourseService: AssetCourseService,
    routeDeviation: RouteDeviation,
    speeding: Speeding,
    unscheduledStop: UnscheduledStop,
    stopOverTime: StopOverTime,
    private val hereService: HereService,
    startOfTrip: StartOfTrip,
    finishedTrip: FinishedTrip,
    private val infringementRegistration: InfringementRegistration
) {
    private val listRules = mutableListOf<IInfringible>()
    private val logger = LoggerFactory.getLogger(this.javaClass)

    init {
        listRules.add(stopOverTime)
        listRules.add(routeDeviation)
        listRules.add(speeding)
        listRules.add(unscheduledStop)
        listRules.add(startOfTrip)
        listRules.add(finishedTrip)

    }

    fun start(iotMessage: AssetIotEventMessage) {

        //TODO https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-368
        // Detalhes na descrição da task
        val activeTrips = assetsHasActiveTrips(iotMessage.assetId.toString())
        if (activeTrips.isNotEmpty()) {
            activeTrips.forEach { trip ->

                assetCourseService.save(
                    AssetCourseEntity(
                        UUID.randomUUID().toString(),
                        iotMessage.position!!.latitude,
                        iotMessage.position!!.longitude,
                        iotMessage.position!!.heading,
                        iotMessage.position!!.speed,
                        iotMessage.state?.mileage,
                        DateFormatter.formatUTC(iotMessage.occurredAt),
                        trip
                    )
                )

                val tripBO = trip.mapToBusinessObject()
                val poiList = hereService.loadData(tripBO.id, iotMessage)
                val trafficViolationList = hereService.checkTrafficViolation(tripBO.id, iotMessage)
                logger.debug("poiList -> $poiList")
                logger.debug("trafficViolationList -> $trafficViolationList")
                listRules.forEach {
                    val infringementReq = it.check(tripBO, iotMessage, poiList, trafficViolationList)
                    infringementRegistration.new(infringementReq)
                }
            }
        }
    }

    private fun assetsHasActiveTrips(assetId: String): Collection<TripEntity> {
        return tripService.getActiveTrips(assetId)
    }
}