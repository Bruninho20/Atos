package listener.cloud.rio.latam_routefence

import listener.cloud.rio.latam_routefence.kafka.Topics
import listener.cloud.rio.latam_routefence.kafka.onError
import listener.cloud.rio.latam_routefence.kafka.onSuccessSend
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import java.io.File

@SpringBootTest
class KafkaListennerTest : TestBase(){

    @Test
    fun listenValues(){
        val basePath = "C:\\Projetos\\vwco\\back\\backend-routefence-latam"
        val projPath = "\\src\\test\\kotlin\\cloud\\rio\\latam_routefence\\resources"
//        val basePath = "C:\\Users\\a800472\\OneDrive - Atos\\General\\Documentos Técnicos\\Testes\\KafkaMessages"
        val fileName = "kafkalist230307"

        val jsonFile = File("${basePath}\\${projPath}\\${fileName}.json")

        val content = jsonFile.readLines()
        var counter = 1

        for (s in content){
            println("MSG_${counter++}\t${s}")
            val future = kafkaTemplate.send(Topics.ASSET_IOTEVENT_TOPIC, s)
            future.addCallback({result -> onSuccessSend(result)}, {ex -> onError(ex)})
        }
    }
    @Test
    fun listenMessage(){
        val msgState = """
            {
                "asset_id": "2224ec16-b4ee-4e3e-92f3-879ba5a918e9",
                "account_id": "d87f9f41-5950-45b1-9044-ecb5d32039d8",
                "device_id": "b799444b-0f75-4452-946f-d2984f38439b",
                "device_type": "tbm3",
                "eid": "tbm:1907110256/67/1678221567769/361/state/344bc2a7-216a-4835-bf0c-334e1a88970a",
                "occurred_at": "2023-03-07T20:39:27.769Z",
                "trigger": "timer",
                "state": {
                    "mileage": 251124.609375,
                    "ignition_on": true,
                    "fuel_level": 43.599998474121094,
                    "engine_speed": 1370,
                    "wheel_speed": 9.69921875,
                    "tacho_speed": 9.8984375
                }
            }
        """.trimIndent()
        val msgPairing = """
            {
            	"asset_id":"1ee87810-dc39-4a60-ab5b-b1eae1611d8b",
            	"account_id":"40ccb35f-f2bb-4e50-b121-6f7b366b9408",
            	"device_id":"66d8ca32-f791-4640-9f7d-9eaf8983b78e",
            	"device_type":"tbm3",
            	"driver_identification":"BR 0000011817892900",
            	"driver_identification_type":"country_specific_driver_license",
            	"eid":"tbm:2110040123/72/1678386471761/35/d5e68762-786f-4d88-8ba8-5264f62ebd95",
            	"occurred_at":"2023-03-09T18:27:51.717Z",
            	"trigger":"driver_login"
            }
        """.trimIndent()


        val msg = msgPairing

        println("MSG_\t${msg}")
        val future = kafkaTemplate.send(Topics.ASSET_IOTEVENT_TOPIC, msg)
        future.addCallback({result -> onSuccessSend(result)}, {ex -> onError(ex)})
    }





/*
    @Test
    fun findRouteById() {
        AccountContext.set("d87f9f41-5950-45b1-9044-ecb5d32039d8")
        val id = "11747dd1-18d9-432d-9dfa-18c3b421e7f1"

        repo.findById(id)
    }
*/

}