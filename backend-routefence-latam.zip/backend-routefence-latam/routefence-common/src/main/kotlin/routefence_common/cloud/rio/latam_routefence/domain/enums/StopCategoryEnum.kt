package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class StopCategoryEnum {
    DEALER, LUNCH_REST, END_OF_DAY, LOAD_UNLOAD
}