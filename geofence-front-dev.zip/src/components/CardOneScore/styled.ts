import styled from 'styled-components'

import colors from 'core/assets/styles/colors'

export const Score = styled.p`
  color: ${colors.primary};
  font-size: 8.5rem;
  padding: 0 20px 0 30px;
`
export const BodyText = styled.p`
  font-size: 2.5rem;
  max-width: 250px;
`

export const ScoreSpan = styled.span`
  color: ${colors.primary};
  font-size: 3rem;
  font-weight: bold;
`
