import React from 'react';
// import { FormattedMessage } from 'react-intl';


import {
  StyledCard,
  TotalCounter,
  TotalInfractions
} from './styled';

interface MiniCardProps {
  title: any;
  description: any
}


const InfringementCard: React.FC<MiniCardProps> = ({
  title,
  description
}) => {
  return (
    <StyledCard
    // action={action}
    title={title}
    // justify={justifyTitle}
    className="card-title"
  >
    <TotalInfractions>
      <TotalCounter>{description}</TotalCounter>
    </TotalInfractions>    
  </StyledCard>
);
};

export default InfringementCard;
