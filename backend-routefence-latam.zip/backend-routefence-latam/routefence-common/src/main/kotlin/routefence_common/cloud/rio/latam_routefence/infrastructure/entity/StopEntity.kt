package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopCategoryEnum
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_STOPS")
data class StopEntity(
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "NAME")
    var name: String?,

    @Column(name = "CATEGORY")
    @Enumerated(EnumType.STRING)
    var category: StopCategoryEnum?,

    @JoinColumn(name = "GEO_POINT_ID", referencedColumnName = "ID")
    @OneToOne(cascade = [CascadeType.ALL])
    var position: GeoPointEntity?,

    override var accountId: String = "",

    @Column(name = "NOTE")
    var note: String?,

    @OneToMany(mappedBy = "stop")
    var route: Set<RouteStopEntity>?
): AccountTenantEntity(accountId)