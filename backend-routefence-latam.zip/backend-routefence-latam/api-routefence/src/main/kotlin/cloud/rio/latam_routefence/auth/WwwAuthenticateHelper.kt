package cloud.rio.latam_maintenance.auth

import java.util.stream.Collectors

object WwwAuthenticateHelper {
    private const val BEARER = "Bearer"
    fun computeWWWAuthenticateHeaderValue(parameters: Map<String, String>): String {
        var wwwAuthenticate = BEARER
        if (parameters.isEmpty()) {
            wwwAuthenticate += parameters.entries.stream()
                    .map { attribute: Map.Entry<String, String> ->
                        """
                    ${attribute.key}="${attribute.value}
                    
                    """.trimIndent()
                    }
                    .collect(Collectors.joining(", ", " ", ""))
        }
        return wwwAuthenticate
    }
}