import React from 'react'
import { injectIntl } from 'react-intl'

const Resume: React.FC = () => {

  return (
    <div>
    </div>
  )
}

export default injectIntl(Resume)
