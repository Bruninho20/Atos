import axios from 'axios';
import defaultsDeep from 'lodash/defaultsDeep';
import { onResponseError, validateRequest } from '../interceptor';
import { accessToken } from 'configuration/tokenHandling/accessToken';

export const TOKEN = null;

export const customBaseApi = (token) => {
  const customAcessToken = TOKEN ?? token ?? accessToken.getAccessToken();

  const BaseApi = axios.create({
    baseURL: process.env.REACT_APP_ENVIRONMENT_CONFIG,
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  });

  BaseApi.interceptors.request.use(validateRequest);
  BaseApi.interceptors.response.use(null, onResponseError);

  BaseApi.request = (path, options) => {
    const mergedOptions = defaultsDeep(options, tokenResolved);

    return BaseApi(path, mergedOptions).then((resp) => resp.data);
  };

  localStorage.setItem('acessToken', tokenResolved);

  return BaseApi;
};
