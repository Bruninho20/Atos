package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import com.fasterxml.jackson.annotation.JsonProperty
import com.vladmihalcea.hibernate.type.json.JsonBinaryType
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.Fetch
import org.hibernate.annotations.FetchMode
import org.hibernate.annotations.TypeDef
import routefence_common.cloud.rio.latam_routefence.domain.bo.BoundingBoxBO
import routefence_common.cloud.rio.latam_routefence.domain.response.routing.ResponseHere
import routefence_common.cloud.rio.latam_routefence.utils.AvoidAreaConverter
import routefence_common.cloud.rio.latam_routefence.utils.ResponseHereConverter
import java.sql.Timestamp
import java.time.Instant
import java.time.LocalDateTime
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_ROUTE")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType::class)
data class RouteEntity(
    @Id
    @Column(name = "ID")
    @JsonProperty("id")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "ID_LAYER_HERE")
    var idLayer: Long = Timestamp.from(Instant.now()).time,

    override var accountId: String = "",

    @Column(name = "ROUTE_NAME")
    var routeName: String,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "geo_point_destiny_id", referencedColumnName = "ID")
    var geoPointDestiny: GeoPointEntity,

    @Column(name = "CREATION_DATE")
    var creationDate: LocalDateTime,

    @Column(name = "RANGE_TOLERANCE_LIMIT")
    var rangeToleranceLimit: Int?,

    @Column(name = "DELETION_DATE")
    var deletionDate: LocalDateTime?,

    @Column(name = "LAST_CHANGE_DATE")
    var lastChangeDate: LocalDateTime?,

    @Column(name = "ROUTE_PARENT_ID")
    var routeParentId: String?,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "costs_id", referencedColumnName = "ID")
    var costs: CostsEntity?,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "range_id", referencedColumnName = "ID")
    var range: RangeEntity?,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "vehicle_vocational_info_id", referencedColumnName = "ID")
    var vehicleVocationalInfo: VehicleVocationalInfoEntity?,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "geo_point_origin_id", referencedColumnName = "ID")
    var geoPointOrigin: GeoPointEntity,

    @OneToMany(mappedBy = "route", fetch = FetchType.EAGER)
    var stops: List<RouteStopEntity>?,

    @OneToMany(mappedBy = "route", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    var trips: List<TripEntity>?,

    @Convert(converter = AvoidAreaConverter::class)
    @Column(name = "AVOID_AREA", columnDefinition = "jsonb")
    var avoidArea: List<BoundingBoxBO>?,

    @Convert(converter = ResponseHereConverter::class)
    @Column(name = "RESPONSE_HERE", columnDefinition = "jsonb")
    var responseHere: ResponseHere?
): AccountTenantEntity(accountId) {

    override fun hashCode(): Int {
        return Objects.hash(id)
    }

    override fun toString(): String {
        val sb = StringBuilder()
        sb.append("id: $id, ")
            .append("idLayer: $idLayer, ")
            .append("accountId: $accountId")
            .append("routeName: $routeName")
        return ""
    }
}