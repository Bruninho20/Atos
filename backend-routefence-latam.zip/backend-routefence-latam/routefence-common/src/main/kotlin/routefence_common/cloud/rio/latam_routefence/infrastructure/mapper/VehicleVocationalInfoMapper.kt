package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.VehicleVocationalInfoRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleVocationalInfoResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.VehicleVocationalInfoEntity

fun VehicleVocationalInfoRequest.mapToEntity(): VehicleVocationalInfoEntity {
    return VehicleVocationalInfoEntity (
        vehicleType = this.type,
        comTotal = this.comTotal!!.toFloat(),
        height = this.height!!.toFloat(),
        width = this.width!!.toFloat(),
        maxWeight = this.maxWeight!!.toFloat(),
        maxWeightAxle = this.maxWeightAxle!!.toFloat(),
        numberAxle = this.numberAxle!!.toInt(),
        trailerAxle = this.trailerAxle!!.toInt(),
        pollutantClass = this.pollutantClass,
        dangerClassification = this.dangerClassification
    )
}

fun VehicleVocationalInfoEntity.mapToResponse() : VehicleVocationalInfoResponse {
    return VehicleVocationalInfoResponse(
        id = this.id,
        type = this.vehicleType.toString().uppercase(),
        comTotal = this.comTotal?.toString(),
        height = this.height?.toString(),
        width = this.width?.toString(),
        maxWeight = this.maxWeight?.toString(),
        maxWeightAxle = this.maxWeightAxle?.toString(),
        numberAxle = this.numberAxle?.toString(),
        trailerAxle = this.trailerAxle?.toString(),
        pollutantClass = this.pollutantClass,
        dangerClassification = this.dangerClassification
    )
}

fun VehicleVocationalInfoEntity?.copyFromRequest(req: VehicleVocationalInfoRequest?) : VehicleVocationalInfoEntity? {
    req?.id?.let { this?.id = it }
    req?.type?.let { this?.vehicleType = it }
    req?.comTotal?.let { this?.comTotal = it.toFloat() }
    req?.height?.let { this?.height = it.toFloat() }
    req?.width?.let { this?.width = it.toFloat() }
    req?.maxWeight?.let { this?.maxWeight = it.toFloat() }
    req?.maxWeightAxle?.let { this?.maxWeightAxle = it.toFloat() }
    req?.numberAxle?.let { this?.numberAxle = it.toInt() }
    req?.trailerAxle?.let { this?.trailerAxle = it.toInt() }
    req?.pollutantClass?.let { this?.pollutantClass = it }
    req?.dangerClassification?.let { this?.dangerClassification = it }

    return this
}

fun VehicleVocationalInfoRequest.mapToDuplicatedEntity(vehicleVocationalInfoEntity: VehicleVocationalInfoEntity?): VehicleVocationalInfoEntity{
    return VehicleVocationalInfoEntity(
        vehicleType = this.type,
        width = this.width?.toFloat() ?: vehicleVocationalInfoEntity?.width,
        height = this.height?.toFloat() ?: vehicleVocationalInfoEntity?.height,
        comTotal = this.comTotal?.toFloat() ?: vehicleVocationalInfoEntity?.comTotal,
        numberAxle = this.numberAxle?.toInt() ?: vehicleVocationalInfoEntity?.numberAxle,
        trailerAxle = this.trailerAxle?.toInt() ?: vehicleVocationalInfoEntity?.trailerAxle,
        maxWeight = this.maxWeight?.toFloat() ?: vehicleVocationalInfoEntity?.maxWeight,
        pollutantClass = this.pollutantClass ?: vehicleVocationalInfoEntity?.pollutantClass,
        maxWeightAxle = this.maxWeightAxle?.toFloat() ?: vehicleVocationalInfoEntity?.maxWeightAxle,
        dangerClassification = this.dangerClassification ?: vehicleVocationalInfoEntity?.dangerClassification
    )
}