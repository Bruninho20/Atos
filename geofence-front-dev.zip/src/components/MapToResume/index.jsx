import React, { useEffect, useState, useRef, useContext } from 'react';
import { Map as RioMap, EventUtils, Route, Marker, SingleMapMarker, MapSettings, MapTypeSettings, ContextMenu, ContextMenuItem } from 'rio-uikit-map';
import axios from 'axios'
import { decode } from 'core/utils/flexiblePolyline'
import { ColumnTripleEdit } from 'styled-icons/fluentui-system-filled';
import { accessToken } from 'configuration/tokenHandling/accessToken'
import DashboardContext from 'core/DashboardContext';

const MapToResume = ({ data, handleOpenSidesheet, openedSidesheet }) => {
  const { mapSize, setMapSize, centerMap, setCenterMap, zoomMap, setZoomMap } = useContext(DashboardContext)
  const [initialPosition, setInitialPosition] = useState([
    {
      lat: -23.5475,
      lng: -46.63611
    }
  ])
  const [arrayInfractions, setArrayInfractions] = useState([])
  const [infractionsData, setInfractionsData] = useState([])
  // const infractions = [
  //   {
  //     endDateTime: "string",
  //     id: "string",
  //     location: {
  //       address: {
  //         city: "string",
  //         countryCode: "string",
  //         countryName: "string",
  //         district: "string",
  //         houseNumber: "string",
  //         id: "string",
  //         label: "string",
  //         postalCode: "string",
  //         state: "string",
  //         stateCode: "string",
  //         street: "string"
  //       },
  //       id: "string",
  //       lat: -23.5059,
  //       lng: -46.7199
  //     },
  //     note: "Acima da Velocidade",
  //     startDateTime: "string",
  //     trip: "d894a014-9588-4c53-9f9f-4aeab0d1ded7",
  //     assetId: "bc0d2386-90b1-476d-9870-8a5884dc4443",
  //     type: "string"
  //   },
  //   {
  //     endDateTime: "string",
  //     id: "string",
  //     location: {
  //       address: {
  //         city: "string",
  //         countryCode: "string",
  //         countryName: "string",
  //         district: "string",
  //         houseNumber: "string",
  //         id: "string",
  //         label: "string",
  //         postalCode: "string",
  //         state: "string",
  //         stateCode: "string",
  //         street: "string"
  //       },
  //       id: "string",
  //       lat: -23.5189,
  //       lng: -46.6145
  //     },
  //     note: "Muito tempo parado",
  //     startDateTime: "string",
  //     trip: "d894a014-9588-4c53-9f9f-4aeab0d1ded7",
  //     assetId: "bc0d2386-90b1-476d-9870-8a5884dc4443",
  //     type: "string"
  //   },
  //   {
  //     endDateTime: "string",
  //     id: "string",
  //     location: {
  //       address: {
  //         city: "string",
  //         countryCode: "string",
  //         countryName: "string",
  //         district: "string",
  //         houseNumber: "string",
  //         id: "string",
  //         label: "string",
  //         postalCode: "string",
  //         state: "string",
  //         stateCode: "string",
  //         street: "string"
  //       },
  //       id: "string",
  //       lat: -23.4244,
  //       lng: -46.748
  //     },
  //     note: "Acima da Velocidade",
  //     startDateTime: "string",
  //     assetId: "bc0d2386-90b1-476d-9870-8a5884dc4443",
  //     trip: "d894a014-9588-4c53-9f9f-4aeab0d1ded7",
  //     type: "string"
  //   },
  //   {
  //     endDateTime: "string",
  //     id: "string",
  //     location: {
  //       address: {
  //         city: "string",
  //         countryCode: "string",
  //         countryName: "string",
  //         district: "string",
  //         houseNumber: "string",
  //         id: "string",
  //         label: "string",
  //         postalCode: "string",
  //         state: "string",
  //         stateCode: "string",
  //         street: "string"
  //       },
  //       id: "string",
  //       lat: -23.4605,
  //       lng: -46.6214
  //     },
  //     note: "Acima da Velocidade",
  //     startDateTime: "string",
  //     assetId: "cb88359b-1fd4-4c05-87ed-15025abbbbdf",
  //     trip: "095a4775-a56f-4c1c-a9ed-8cd87beb7a75",
  //     type: "string"
  //   },
  // ]

  const [contextMenuData, setContextMenuData] = useState({});
  const [dataToShowRoute, setDataToShowRoute] = useState([])
  const [refreshAssetId, setRefreshAssetsId] = useState(false)
  const [assetToFilter, setAssetToFilter] = useState('')
  const [routeData, setRouteData] = useState([])
  const [showInfractions, setShowInfractions] = useState(false)

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  }

  useEffect(() => {
    if (dataToShowRoute?.originRouteData?.lat) {
      setInitialPosition([{ lat: dataToShowRoute?.originRouteData?.lat, lng: dataToShowRoute?.originRouteData.long }])
    }
  }, [dataToShowRoute])

  useEffect(() => {
    if (openedSidesheet === false) {
      setDataToShowRoute([])
    }
  }, [openedSidesheet])

  const countRef = useRef({})

  useEffect(() => {
  }, [countRef.current]);

  const handleGetRouteData = () => {
    if (assetToFilter) {
      const getAssetId = data?.arrayGeolocation?.find(item => String(item.vehicle?.vehicle?.trim()).toLowerCase() === assetToFilter.trim().toLowerCase())
    }
  }

  const markerEventListenerMap = {
    [EventUtils.TAP]: event => {
      // Note: if there is a "TAP" event defined make sure to block the event for right mouse button otherwise
      // the right click will also trigger the tap callback and may cause unwanted selection
    },
    [EventUtils.MAP_VIEW_CHANGE_END]: (event) => {
      const target = event.currentTarget;
      const updatedCenter = target.getCenter();
      const newZoom = target.getZoom();

      setInitialPosition([
        {
          lat: updatedCenter.lat,
          lng: updatedCenter.lng,
        }
      ])
    },
    [EventUtils.CONTEXTMENU]: event => {
      handleGetRouteData()
      setAssetToFilter(event?.originalEvent?.target?.outerText)
      setRefreshAssetsId(!refreshAssetId)

      // "target" is used to decide what context menu items shall be shown
      // "event" is used to add the menu items to it
      // "targetPosition" is used to return a fixed position on context menu open or in the item callback


      // setInitialPosition([{ lat: event.target.a.lat, lng: event.target.a.lng }])
      setContextMenuData({ target: 'marker', event });

    },
  };

  const getRouteData = async (id) => {
    const resRoute = await axios.get(`${baseURL}/routes/${id}`, head)
    setRouteData([resRoute.data])
  }

  const getInfractionsData = async (id) => {
    const resInfractions = await axios.get(`${baseURL}/infringements/${id}`, head)
    setInfractionsData([resInfractions.data])
    setArrayInfractions(resInfractions.data)
  }

  const getCountInfraction = async (id) => {
    const countInfraction = await axios.get(`${baseURL}/infringements/count/${id}`, head)
    return countInfraction.data
  }

  useEffect(() => {
    if (refreshAssetId === true) {

      const getAssetId = data?.arrayGeolocation?.find(item => (item.vehicle?.vehicle?.trim()).split(' ')[0] === assetToFilter)

      if (data?.rowsPagineted[0]?.length >= 1) {
        alert('tem uma rota ou mais')
        const getDataToSidesheet = data?.rowsPagineted[0]?.find(
          (item) => item.assetId === getAssetId?.assetId)

        getInfractionsData(getDataToSidesheet?.tripId)
        // getCountInfraction(getDataToSidesheet?.tripId)
        getRouteData(getDataToSidesheet?.routeId)
        setDataToShowRoute([getDataToSidesheet])
        // setInitialPosition([{ lat: getDataToSidesheet?.originRouteData?.lat, lng: getDataToSidesheet?.originRouteData.long }])
        handleOpenSidesheet(true, getDataToSidesheet)
        setShowInfractions(true)

        if (routeData.length >= 1) {

        }

        setRefreshAssetsId(false)
      }
    }

  }, [refreshAssetId])

  const stopsWaypoint = data?.allStops?.length > 0 ? data?.allStops?.map((item, index) => {
    return (
      `waypoint${index + 1}=geo!${item?.position?.lat},${item?.position?.lng}&`
    )
  }) : ''

  const destinyWaypoint = `waypoint${dataToShowRoute?.allStops?.length + 1}=geo!${dataToShowRoute?.destinyRouteData?.position?.lat},${dataToShowRoute?.destinyRouteData?.position?.lng}`

  const handleGetRoute = () => {
    axios
      .get(`https://route.ls.hereapi.com/routing/7.2/calculateroute.json?apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&mode=fastest;car&waypoint0=geo!${dataToShowRoute?.originRouteData?.position?.lat},${dataToShowRoute?.originRouteData?.position?.lng}&${stopsWaypoint.length >= 1 ? stopsWaypoint[0] : '&'}${stopsWaypoint.length === 2 ? stopsWaypoint[1] : ''}${stopsWaypoint.length === 3 ? stopsWaypoint[2] : ''}${stopsWaypoint.length === 4 ? stopsWaypoint[3] : ''}${stopsWaypoint.length === 5 ? stopsWaypoint[4] : ''}${destinyWaypoint}&height=5&routeattributes=sh,bb,gr, lg`)
      .then(result => {

        const resultData = result?.data?.response?.route[0]
        const getPoints = resultData.shape.map((value) => {
          const [lat, lng] = value.split(',')
          return { lat, lng }
        })
        setInitialPosition(getPoints)
      })
  }
  let ArrayOfShape = []

  const newData = routeData?.map((item) => {

    const getPolylineArray = item?.responseHere?.routes[0]?.sections?.map((item) => {
      return {
        shape: decode(item?.polyline)
      }
    })

    const shapeArray = getPolylineArray?.map((item) => {
      return (
        ArrayOfShape.push(item?.shape?.polyline)
      )
    })

    const concatArrays = ArrayOfShape?.flat()

    const getPoints = concatArrays?.map((value) => {
      return {
        lat: (value[0]),
        lng: (value[1])
      }
    })

    const stops = item?.stops?.map((item) => {
      return {
        stopName: item?.name,
        positions: {
          lat: item?.position?.lat,
          lng: item?.position?.lng,
        }
      }
    })

    return {
      destinyRoute: item?.destinyRoute,
      originRoute: item?.destinyRoute,
      shape: getPoints,
      stops: stops,
      geolocation: item?.geolocation,
      name: item?.route?.routeName
    }
  })

  useEffect(() => {
    if (data?.destinyRouteData?.position?.lat !== undefined && dataToShowRoute.length >= 1) {
      handleGetRoute()
    }
  }, [data?.destinyRouteData, data?.allStops])

  const position = { lat: initialPosition[0]?.lat, lng: initialPosition[0]?.lng };

  const offset = 0.3;

  const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'

  const getRandomValueToForceRerender = () => Math.random();

  const Routes = () => {
    const [activeRouteId, setActiveRouteId] = useState(1);
    const isActive = id => activeRouteId === id;
    const isFirstRouteActive = isActive(1);
    const isSecondRouteActive = isActive(2);

    return (
      <React.Fragment>
        {newData?.map((value, index) => {
          const position = value?.shape
          return (
            <Route
              key={getRandomValueToForceRerender()}
              positions={position}
              startIcon={<SingleMapMarker eventListenerMap={markerEventListenerMap} iconNames={['start']} markerColor='bg-map-marker-asset' />}
              endIcon={<SingleMapMarker iconNames={['finish']} markerColor='bg-map-marker-asset' />}
              isRouteAlternative={!isFirstRouteActive}
              eventListenerMap={markerEventListenerMap}
              hasArrows={true}
              markers={value?.stops?.map((item, index) => {
                return (
                  <>
                    <Marker
                      key={index}
                      customData={{ id: index }}
                      position={item?.positions}
                      icon={
                        <SingleMapMarker
                          iconNames={['route']}
                          name={item.stopName}
                          markerColor='bg-map-marker-route'
                          active={isSecondRouteActive}
                          fixed
                        />
                      }
                    />
                  </>

                )
              })}
            />
          )
        })}
      </React.Fragment>
    );
  };

  const [coordLabel, setCoordLabel] = useState();

  const formatCoordinates = coordinates => {
    return [
      Math.abs(coordinates.lat.toFixed(4)) + (coordinates.lat > 0 ? 'N' : 'S'),
      Math.abs(coordinates.lng.toFixed(4)) + (coordinates.lng > 0 ? 'E' : 'W'),
    ].join(' ');
  };


  const handleOpenContextMenu = contextMenuCoordinates => {

    setCoordLabel(formatCoordinates(contextMenuCoordinates));

  };

  const contextMenuItems = [
    <ContextMenuItem
      className='bg-lightest text-color-dark'
      labelClassName='text-medium'
      label={coordLabel}
      icon='rioglyph-map-marker'
    />
  ];

  const getMiddlePos = positions => positions[Math.floor(positions.length / 2)];

  return (
    <>
      <RioMap
        credentials={{
          apikey:
            typeof apiKey === 'string'
              ? apiKey
              : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
        }}
        center={position}
        eventListenerMap={markerEventListenerMap}
        zoom={11}
        height={900}
        width={mapSize}
        mapSettings={<MapSettings options={[<MapTypeSettings tooltip='Change map type' />]} />}
      >
        <Routes />
        {/* {newData?.map((item, index) => {
          const position = item?.shape
          return (
            <Marker
              key={index}
              customData={{ id: index }}
              position={getMiddlePos(position)}
              eventListenerMap={markerEventListenerMap}
              icon={
                <SingleMapMarker
                  iconNames={['stop']}
                  name={item.name}
                  markerColor='bg-map-marker-poi'
                  moving
                />
              }
            />
          )
        })} */}
        {data.arrayGeolocation.length >= 1 ? data.arrayGeolocation
          ?.map((item, index) => {
            const geolocation = { lat: item?.position?.latitude, lng: item?.position?.longitude }
            return (
              <Marker
                key={index}
                customData={{ id: index }}
                position={geolocation}
                icon={
                  <SingleMapMarker
                    eventListenerMap={markerEventListenerMap}
                    name={item.vehicle?.vehicle}
                    iconNames={['truck']}
                    exceptionCount={getCountInfraction(item.assetId)}
                    markerColor='bg-map-marker-asset'
                    moving
                  />
                }
              />
            )
          }) : null}

        {showInfractions ? arrayInfractions
          ?.map((item, index) => {
            const position = { lat: item?.location?.lat, lng: item?.location?.lng }
            return (
              <Marker
                key={index}
                customData={{ id: index }}
                position={position}
                icon={
                  <SingleMapMarker
                    eventListenerMap={markerEventListenerMap}
                    name={item.note}
                    iconNames={['dangerousgoods']}
                    markerColor='bg-map-marker-poi'
                    active
                  />
                }
              />
            )
          }) : null}
        <ContextMenu
          onOpen={handleOpenContextMenu}
          menuItems={contextMenuItems}
        // contextMenuEvent={contextMenuData.event}
        // targetPosition={contextMenuData.targetPosition}
        />
        <div style={{ height: 200, width: 200, position: 'relative', zIndex: 99, backgroundColor: 'white' }}></div>
      </RioMap>
    </>

  );
};

export default MapToResume;