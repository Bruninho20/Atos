package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Route(
    @JsonProperty("mode") var mode: Mode?,
    @JsonProperty("boatFerry") var boatFerry: Boolean?,
    @JsonProperty("railFerry") var railFerry: Boolean?,
    @JsonProperty("waypoint") var waypoint: Collection<Waypoint>?,
    @JsonProperty("leg") var leg: Collection<Leg>?,
    @JsonProperty("summary") var summary: Summary?,
    @JsonProperty("boundingBox") var boundingBox: BoundingBox?,
    @JsonProperty("cost") var cost: Costs?,
    @JsonProperty("matchedVehicleType") var matchedVehicleType: Collection<MatchedVehicleType>?,
    @JsonProperty("shape") var shape: Collection<String>?,
    @JsonProperty("summaryByCountry") var summaryByCountry: Collection<RouteSummaryByCountry>?,
    @JsonProperty("tollCost") var tollCost: TCResponse?
)