package routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity.Geometries
import routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity.Meta

@JsonIgnoreProperties(ignoreUnknown = true)
data class Response(
    @JsonProperty("geometries") var geometries: Collection<Geometries>?,
    @JsonProperty("meta") var meta: Collection<Meta>?,
    @JsonProperty("response_code") var responseCode: String?
)