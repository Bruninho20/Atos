package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.MappedPosition
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.OriginalPosition

@JsonIgnoreProperties(ignoreUnknown = true)
data class Waypoint(
    @JsonProperty("linkId") var linkId: String?,
    @JsonProperty("mappedPosition") var mappedPosition: MappedPosition?,
    @JsonProperty("originalPosition") var originalPosition: OriginalPosition?,
    @JsonProperty("spot") var spot: Double?,
    @JsonProperty("confidenceValue") var confidenceValue: Double?,
    @JsonProperty("elevation") var elevation: Double?,
    @JsonProperty("headingDegreeNorthClockwise") var headingDegreeNorthClockwise: Double?,
    @JsonProperty("headingMatched") var headingMatched: Double?,
    @JsonProperty("matchDistance") var matchDistance: Double?,
    @JsonProperty("minError") var minError: Double?,
    @JsonProperty("routeLinkSeqNrMatched") var routeLinkSeqNrMatched: Int?,
    @JsonProperty("speedMps") var speedMps: Double?,
    @JsonProperty("timestamp") var timestamp: Double?,
    @JsonProperty("globalWayPointSeqNr") var globalWayPointSeqNr: Int?,
    @JsonProperty("mappedRoadName") var mappedRoadName: String?,
    @JsonProperty("seqNrOnRoute") var seqNrOnRoute: Int?,
    @JsonProperty("shapeIndex") var shapeIndex: Int?,
    @JsonProperty("sideOfStreet") var sideOfStreet: String?,
    @JsonProperty("type") var type: String?,
    @JsonProperty("userLabel") var userLabel: String?,
    @JsonProperty("waypointType") var waypointType: String?
)