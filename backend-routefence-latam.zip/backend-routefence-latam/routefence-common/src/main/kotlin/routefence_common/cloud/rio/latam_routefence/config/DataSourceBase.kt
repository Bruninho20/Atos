package routefence_common.cloud.rio.latam_routefence.config

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.springframework.core.env.Environment
import java.util.HashMap
import javax.sql.DataSource

open class DataSourceBase {
    companion object {
        private const val PRIMARY_DATA_SOURCE_PREFIX = "spring.primary.data_source"
        private const val REPLICA_DATA_SOURCE_PREFIX = "spring.replica.data_source"
    }

    open fun dataSource(environment: Environment): DataSource {
        val routingDataSource = RoutingDataSource()
        val primaryDataSource = buildDataSource(environment, "PrimaryHikariPool",
            PRIMARY_DATA_SOURCE_PREFIX
        )
        val replicaDataSource = buildDataSource(environment, "ReplicaHikariPool",
            REPLICA_DATA_SOURCE_PREFIX
        )
        val targetDataSources: MutableMap<Any, Any> = HashMap()

        targetDataSources[RoutingDataSource.Route.PRIMARY] = primaryDataSource
        targetDataSources[RoutingDataSource.Route.REPLICA] = replicaDataSource
        routingDataSource.setTargetDataSources(targetDataSources)
        routingDataSource.setDefaultTargetDataSource(primaryDataSource)

        return routingDataSource
    }

    private fun buildDataSource(environment: Environment, poolName: String, dataSourcePrefix: String): DataSource {
        val hikariConfig = HikariConfig()

        hikariConfig.poolName = poolName
        hikariConfig.jdbcUrl = environment.getProperty("$dataSourcePrefix.url")
        hikariConfig.username = environment.getProperty("$dataSourcePrefix.username")
        hikariConfig.password = environment.getProperty("$dataSourcePrefix.password")
        hikariConfig.driverClassName = environment.getProperty("$dataSourcePrefix.driver")
        hikariConfig.connectionTimeout = 30000

        return HikariDataSource(hikariConfig)
    }
}
