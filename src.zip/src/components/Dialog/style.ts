import styled from 'styled-components';

export const BodyWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
`;
