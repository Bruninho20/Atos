import React, { FC } from 'react'
import { FormattedMessage } from 'react-intl'
import { SideSheet } from 'components'
import { FaultCodeModel, StopModel, RangeModel, VehicleModel, CostsModel, RouteModel } from './PdisTable'

import {
  InfractionDetailsTable,
  InfractionDetailsTableColumnLeft,
  InfractionDetailsTableColumnRight,
  InfractionDetailsTableRow,
  InfractionDetailsTableRowLast,
  SideSheetContentWrapper,
  StyledExpanderPanel
} from 'components/SidesheetTable/styled'

export type CustomFaultCodesModel = Pick<
  FaultCodeModel,
  | 'stops'
  | 'roadParameters'
  | 'name'
  | 'vehicle'
  | 'date'
  | 'description'
  | 'spn'
  | 'spnDescription'
  | 'fmi'
  | 'fmiDescription'
  | 'latitude'
  | 'longitude'
  | 'lampStatus'
  | 'sourceAddress'
  | 'routeName'
  | 'originRoute'
  | 'destinyRoute'
  | 'rangeToleranceLimit'
  | 'status'
  | 'roles'
  | 'stopName'
  | 'stopCategorya'
  | 'addressStop'
  | 'rangeLimitMeters'
  | 'stayTime'
  | 'trafficConditions'
  | 'avoidToll'
  | 'avoidRoad'
  | 'ignoreTrafficRestrictions'
  | 'type'
  | 'comTotal'
  | 'height'
  | 'width'
  | 'maxWeight'
  | 'maxWeightAxle'
  | 'numberAxle'
  | 'trailerAxle'
  | 'pollutantClass'
  | 'dangerClassification'
  | 'tollValue'
  | 'operativeCosts'
  | 'fuelAverageCosts'
  | 'averageConsume'
  | 'totalCosts'
> & {
  geolocation: string
}

export type RouteModelDetails = Pick<
  RouteModel,
  'roles' | 'status' | 'date' | 'routeName' | 'originRoute' | 'destinyRoute' | 'rangeToleranceLimit'
> & {
  geolocation: string
}

export type StopModelDetail = Pick<
  StopModel,
  'name' | 'category' | 'addressStop' | 'rangeLimitMeters' | 'stayTime'
> & {
  geolocation: string
}

export type RangeModelDetail = Pick<
  RangeModel,
  'trafficConditions' | 'avoidToll' | 'avoidRoad' | 'ignoreTrafficRestrictions'
> & {
  geolocation: string
}

export type VehicleModelDetail = Pick<
  VehicleModel,
  | 'type'
  | 'comTotal'
  | 'height'
  | 'width'
  | 'maxWeight'
  | 'maxWeightAxle'
  | 'numberAxle'
  | 'trailerAxle'
  | 'pollutantClass'
  | 'dangerClassification'
> & {
  geolocation: string
}

export type CostsModelDetail = Pick<
  CostsModel,
  'tollValue' | 'operativeCosts' | 'fuelAverageCosts' | 'averageConsume' | 'totalCosts'
> & {
  geolocation: string
}

const FaultCodesDetailsSidesheet: FC<{
  isOpen: boolean
  data?: CustomFaultCodesModel
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, data, onClose }) => {
  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  console.log('data NO SIDESHEET DE ROTAS', data)

  const renderTable = (
    faultCodes: Pick<
      RouteModelDetails,
      'roles' | 'status' | 'date' | 'routeName' | 'originRoute' | 'destinyRoute' | 'rangeToleranceLimit'
    >
  ) => (
    <InfractionDetailsTable>
      {Object.entries(faultCodes).map(faultCode => (
        <InfractionDetailsTableRow key={faultCode[0]}>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id={faultCode[0]} />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{faultCode[1]}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const renderRangeTable = (
    faultCodes: Pick<RangeModelDetail, 'trafficConditions' | 'avoidToll' | 'avoidRoad' | 'ignoreTrafficRestrictions'>
  ) => (
    <InfractionDetailsTable>
      {Object.entries(faultCodes).map(faultCode => (
        <InfractionDetailsTableRow key={faultCode[0]}>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id={faultCode[0]} />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{faultCode[1] === 'false' ? 'NÂO' : 'SIM'}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const renderVehicleTable = (
    faultCodes: Pick<
      VehicleModelDetail,
      | 'type'
      | 'comTotal'
      | 'height'
      | 'width'
      | 'maxWeight'
      | 'maxWeightAxle'
      | 'numberAxle'
      | 'trailerAxle'
      | 'pollutantClass'
      | 'dangerClassification'
    >
  ) => (
    <InfractionDetailsTable>
      {Object.entries(faultCodes).map(faultCode => (
        <InfractionDetailsTableRow key={faultCode[0]}>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id={faultCode[0]} />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{faultCode[1]}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const renderCostsTable = (
    faultCodes: Pick<
      CostsModelDetail,
      'tollValue' | 'operativeCosts' | 'fuelAverageCosts' | 'averageConsume' | 'totalCosts'
    >
  ) => (
    <InfractionDetailsTable>
      {Object.entries(faultCodes).map(faultCode => (
        <InfractionDetailsTableRow key={faultCode[0]}>
          <InfractionDetailsTableColumnLeft>
            <FormattedMessage id={faultCode[0]} />
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{faultCode[1]}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const detailsRoute: Pick<
    CustomFaultCodesModel,
    'routeName' | 'originRoute' | 'destinyRoute' | 'rangeToleranceLimit' | 'status' | 'roles' | 'date'
  > = {
    routeName: data?.routeName || '',
    originRoute: data?.originRoute || '',
    destinyRoute: data?.destinyRoute || '',
    rangeToleranceLimit: data?.rangeToleranceLimit || '',
    status: data?.status || '',
    roles: data?.roles || '',
    date: data?.date || ''
  }

  // const detailsStop: Pick<
  //   StopModelDetail,
  //   'name' | 'category' | 'addressStop' | 'rangeLimitMeters' | 'stayTime'
  // > = {
  //   name: data?.routeName || '',
  //   category: data?.stopCategorya || '',
  //   addressStop: data?.addressStop || '',
  //   rangeLimitMeters: data?.rangeLimitMeters || '',
  //   stayTime: data?.stayTime || ''
  // }

  const detailsRange: Pick<
    RangeModelDetail,
    'trafficConditions' | 'avoidToll' | 'avoidRoad' | 'ignoreTrafficRestrictions'
  > = {
    trafficConditions: data?.trafficConditions || '',
    avoidToll: data?.avoidToll || '',
    avoidRoad: data?.avoidRoad || '',
    ignoreTrafficRestrictions: data?.avoidRoad || ''
  }

  const detailsVehicle: Pick<
    VehicleModelDetail,
    | 'type'
    | 'comTotal'
    | 'height'
    | 'width'
    | 'maxWeight'
    | 'maxWeightAxle'
    | 'numberAxle'
    | 'trailerAxle'
    | 'pollutantClass'
    | 'dangerClassification'
  > = {
    type: data?.type || '',
    comTotal: data?.comTotal || '',
    height: data?.height || '',
    width: data?.width || '',
    maxWeight: data?.maxWeight || '',
    maxWeightAxle: data?.maxWeightAxle || '',
    numberAxle: data?.numberAxle || '',
    trailerAxle: data?.trailerAxle || '',
    pollutantClass: data?.pollutantClass || '',
    dangerClassification: data?.dangerClassification || ''
  }

  const detailsCosts: Pick<
    CostsModelDetail,
    'tollValue' | 'operativeCosts' | 'fuelAverageCosts' | 'averageConsume' | 'totalCosts'
  > = {
    tollValue: `R$ ${data?.tollValue}` || '',
    operativeCosts: `R$ ${data?.operativeCosts}` || '',
    fuelAverageCosts: data?.fuelAverageCosts || '',
    averageConsume: data?.averageConsume || '',
    totalCosts: `R$ ${data?.totalCosts}` || ''
  }

  return (
    <>
      <SideSheet
        modal
        width='445px'
        padding='0'
        open={isOpen}
        title={`Detalhes da Rota`}
        onClick={() => handleOnClose(false)}>
        <SideSheetContentWrapper>
          <StyledExpanderPanel title='Rota' open={true}>
            {detailsRoute && renderTable(detailsRoute)}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Paradas' open={true}>
          {data?.stops?.map((item: any) => {
              return (
                <>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stopName' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>
                        {String(item?.name).toUpperCase()}
                      </InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stopCategorya' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{item?.category}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='addressStop' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>
                        {item?.position?.addressStop?.label}
                      </InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRow>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='rangeLimitMeters' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{data?.rangeToleranceLimit}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRow>
                  </InfractionDetailsTable>
                  <InfractionDetailsTable>
                    <InfractionDetailsTableRowLast>
                      <InfractionDetailsTableColumnLeft>
                        <FormattedMessage id='stayTime' />
                      </InfractionDetailsTableColumnLeft>
                      <InfractionDetailsTableColumnRight>{item?.stayTime}</InfractionDetailsTableColumnRight>
                    </InfractionDetailsTableRowLast>
                  </InfractionDetailsTable>
                  
                </>
              )
            })}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Faixa' open={true}>
            {detailsRange && renderRangeTable(detailsRange)}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Veículo' open={true}>
            {detailsVehicle && renderVehicleTable(detailsVehicle)}
          </StyledExpanderPanel>
          <StyledExpanderPanel title='Custos' open={true}>
            {detailsCosts && renderCostsTable(detailsCosts)}
          </StyledExpanderPanel>
          <div style={{ height: 80 }}></div>
        </SideSheetContentWrapper>
      </SideSheet>
    </>
  )
}

export default FaultCodesDetailsSidesheet
