package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Action(
    @JsonProperty("action") val action: String?,
    @JsonProperty("duration") val duration: Long?,
    @JsonProperty("length") val length: Long?,
    @JsonProperty("instruction") val instruction: String?,
    @JsonProperty("offset") val offset: Long?,
    @JsonProperty("direction") val direction: String?,
    @JsonProperty("severity") val severity: String?
)
