import styled from 'styled-components';
import { metrics } from 'core/assets/styles';

export const Wrapper = styled.section`
  display: flex;
`;

export const Content = styled.div<{ bg?: string }>`
  background: ${({ bg }) => (bg ? bg : 'transparent')};
  border-radius: ${metrics.baseRadius};
  padding: 30px;
  width: 100%;
`;
