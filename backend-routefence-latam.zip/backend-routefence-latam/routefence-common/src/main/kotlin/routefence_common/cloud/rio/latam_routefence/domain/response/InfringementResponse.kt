package routefence_common.cloud.rio.latam_routefence.domain.response

data class InfringementResponse(
    val id: String,
    val type: String,
    val note: String?,
    val startDateTime: String,
    val endDateTime: String,
    val location: GeoPointResponse,
    val trip: String?
)

data class TripResumeReportResponse(

    val type: String,
    val routeName: String,
    val note: String?,
    val startDateTime: String,
    val endDateTime: String,
)
