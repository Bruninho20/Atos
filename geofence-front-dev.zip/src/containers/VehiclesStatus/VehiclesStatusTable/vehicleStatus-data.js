const dataVehicleStatus = {
	data: [{
		data: [{
			vehicleId: "MN51 - P25",
			chassis: "9539B8TJ2LR999284",
			batteryLevel: "92%",
			autonomy: "664km",
			statusOfCharging: "CONECTADO",
			lastUpdate: "2021-01-26 19:01:50",
			status: "OPERANDO NORMALMENTE",
			statusWorking: "EM ATIVIDADE"
		}, {
			vehicleId: "17-230 OD - BEPOBUS CITTA",
			chassis: "9532G82WXLR028369",
			batteryLevel: "98%",
			autonomy: "754km",
			statusOfCharging: "DESCONECTADO",
			lastUpdate: "2021-01-27 19:28:09",
			status: "OPERANDO NORMALMENTE",
			statusWorking: "EM ATIVIDADE"
		}, {
			vehicleId: "17-230 OD",
			chassis: "536T8274FR501273",
			batteryLevel: "54%",
			autonomy: "386km",
			statusOfCharging: "CONECTADO",
			lastUpdate: "2021-01-08 22:47:47",
			status: "OPERANDO NORMALMENTE",
			statusWorking: "EM ATIVIDADE"
		}, {
			vehicleId: "M67",
			chassis: "95311111111111112",
			batteryLevel: "28%",
			autonomy: "188km",
			statusOfCharging: "DESCONECTADO",
			lastUpdate: "2021-01-19 20:16:59",
			status: "OPERANDO NORMALMENTE",
			statusWorking: "FORA DE ATIVIDADE"
		}, {
			vehicleId: "C787",
			chassis: "539B8TJ1KR999274",
			batteryLevel: "14%",
			autonomy: "99km",
			statusOfCharging: "CONECTADO",
			lastUpdate: "2021-01-20 18:57:06",
			status: "OPERANDO NORMALMENTE",
			statusWorking: "EM ATIVIDADE"
		}],
		total: 5,
	}],
	status: "success",
	size: 1,
	setSize: function (arg) {console.log(arg)}
}

export default dataVehicleStatus