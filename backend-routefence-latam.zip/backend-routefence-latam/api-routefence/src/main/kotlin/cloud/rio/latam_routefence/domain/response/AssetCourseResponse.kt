package cloud.rio.latam_routefence.domain.response

data class AssetCourseResponse(
    val id: String,
    val lat: Double,
    val lng: Double,
    val heading: Double?,
    val speed: Double?,
    val occurredAt: String,
    val tripId: String?
)
