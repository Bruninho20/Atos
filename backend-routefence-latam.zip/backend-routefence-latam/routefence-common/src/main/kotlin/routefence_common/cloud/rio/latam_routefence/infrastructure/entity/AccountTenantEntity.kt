package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.Filter
import org.hibernate.annotations.FilterDef
import org.hibernate.annotations.ParamDef
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.persistence.Column
import javax.persistence.MappedSuperclass

//TODO verificar se não será preciso add as deps de jakarta e hibernate no pom do common
@MappedSuperclass
@FilterDef(name = AccountContext.ACCOUNT_FILTER,
           parameters = [ParamDef(name = AccountContext.ACCOUNT_ID_PARAM, type = "string")])
@Filter(name = AccountContext.ACCOUNT_FILTER, condition = "${AccountContext.ACCOUNT_ID_COLUMN} = :${AccountContext.ACCOUNT_ID_PARAM}")

open class AccountTenantEntity (
    @Column(name = AccountContext.ACCOUNT_ID_COLUMN, updatable = false)
    open var accountId: String = ""
)
