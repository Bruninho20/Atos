(function() {
    var root = document.getElementById('root');
    var LOADER_ID = 'pageLoader';

    root.innerHTML =
        '<div id="' +
        LOADER_ID +
        '">' +
        '<div class="pageLoaderCenter">' +
        '<div class="pageLoaderAnimation">' +
        '<span></span><span></span><span></span><span></span>' +
        '<div class="pageLoaderLogo">' +
        '<svg width="50" height="50" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path fill="#FFF" d="M0 0h50v50H0z"/><path d="M45.3 26.05c0 4.55-3.7 8.25-8.25 8.25s-8.25-3.7-8.25-8.25 3.7-8.25 8.25-8.25 8.25 3.7 8.25 8.25zm-23.6 7.8h5.05V18.2H21.7v15.65zm-8-15.65c2.7 0 4.9 2.2 4.9 4.9 0 1.5-.7 2.9-1.8 3.8-.3.3-.7.55-1.15.7l4.1 6.25H14.4l-4.25-6.25v6.25h-4.9V18.2h8.45zM0 50h50V0H0v50z" fill="#000"/></g></svg>' +
        '</div>' +
        '</div>' +
        '<div class="pageLoaderText">loading</div>' +
        '</div>' +
        '</div>';

    // Timeouts in millisec
    var INITIAL_WAITING_TIME = 60000; // 60000
    var INTERVAL_TIME = 5000; // 5000

    var headlineEN = 'Sorry, something seems to be wrong';
    var messageEN =
        'Please try again later. If the problem persists, ' + 'please contact the RIO Support Hotline 00800/22550746.';

    var headlineDE = 'Entschuldigung, etwas scheint nicht zu klappen';
    var messageDE =
        'Bitte versuchen Sie es später nochmal. ' +
        'Wenn das Problem weiterhin besteht, kontaktieren Sie bitte die RIO Support Hotline 00800/22550746.';

    var reloadEN = 'Reload';
    var reloadDE = 'Neu laden';

    var reloadLink = 'javascript:window.location.reload(true)';

    // Initially wait some time in order to have bundle.js loaded etc.
    setTimeout(function() {
        // Check periodically wheather the app is rendered into the root element.
        // If nothing is rendered, the error message will be shown
        setInterval(function() {
            if (!root.children.length || root.firstChild.id === LOADER_ID) {
                root.innerHTML =
                    '<div class="errorWrapper">' +
                    '<div class="errorMessage">' +
                    '<div class="errorHeadline">' +
                    headlineEN +
                    '</div>' +
                    '<div class="errorText">' +
                    messageEN +
                    '</div>' +
                    '<a class="reloadLink" href="' + reloadLink + '">' +
                    reloadEN +
                    '</a>' +
                    '<hr class="errorDivider"/>' +
                    '<div class="errorHeadline">' +
                    headlineDE +
                    '</div>' +
                    '<div class="errorText">' +
                    messageDE +
                    '</div>' +
                    '<a class="reloadLink" href="' + reloadLink + '">' +
                    reloadDE +
                    '</a>' +
                    '</div>' +
                    '</div>';

                if (window.dataLayer) {
                    window.dataLayer.push({
                        event: 'ga_event',
                        eventCategory: document.title + ', error',
                        eventAction: 'Page Loader Error Displayed',
                        eventLabel: 'Displayed Page Loader Error'
                    });
                }
            }
        }, INTERVAL_TIME);
    }, INITIAL_WAITING_TIME);
})();
