package routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Meta (
    @JsonProperty("layerId") var layerId: String?,
    @JsonProperty("lastUpdateTimeStamp") var lastUpdateTimeStamp: Double?
)