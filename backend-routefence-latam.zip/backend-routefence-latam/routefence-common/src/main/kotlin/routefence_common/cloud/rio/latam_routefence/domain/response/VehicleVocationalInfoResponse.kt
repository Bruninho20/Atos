package routefence_common.cloud.rio.latam_routefence.domain.response

data class VehicleVocationalInfoResponse (
    var id: String? = null,
    var type: String?,
    var comTotal: String? = null,
    var height: String? = null,
    var width: String? = null,
    var maxWeight: String? = null,
    var maxWeightAxle: String? = null,
    var numberAxle: String? = null,
    var trailerAxle: String? = null,
    var pollutantClass: String? = null,
    var dangerClassification: String? = null
)
