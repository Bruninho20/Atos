import styled, { css } from 'styled-components'

import colors from 'core/assets/styles/colors'

import { Button } from 'components'
import { ScoreTypes } from '.'

export const getScoreColor = (type: string): string => {
  const colorsObject: Record<ScoreTypes, string> = {
    CRITICAL: colors.infoRed,
    NORMAL: colors.infoGreen,
    ATTENTION: colors.infoOrange,
    default: colors.black
  }

  return colorsObject[(type as ScoreTypes) || 'default']
}

export const ScoreWrapper = styled.div<{ firstScore: boolean }>`
  ${({ firstScore }) =>
    !firstScore &&
    css`
      border-left: 1px solid gray;
    `}
  padding: 0 15px 0 15px;
`

export const Score = styled(Button)<{ bsStyle: string; clicked: boolean }>`
  background: transparent !important;
  border: 0;
  border-radius: 0;
  color: ${({ bsStyle }) => `${getScoreColor(bsStyle)} !important`};
  font-size: 8.5rem;
  margin: 0;
  padding: 20px 10px 20px 10px;

  ${({ clicked }) =>
    clicked &&
    css`
      opacity: 0.4;
    `}

  :hover {
    background: transparent !important;
    color: ${({ bsStyle }) => getScoreColor(bsStyle)} !important;
  }
  transition: opacity 0.3s ease-in-out;
`

export const FooterText = styled.p<{ type?: ScoreTypes; loading: boolean }>`
  font-size: 2.5rem;
  padding-top: 20px;
  width: 300px;
  ${({ loading }) =>
    loading &&
    css`
      margin: 0;
      padding-top: 0;
    `}

  span {
    color: ${({ type }) => type && getScoreColor(type)};
    font-weight: bold;
  }
`

export const BodyWrapper = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  text-align: center;
`
