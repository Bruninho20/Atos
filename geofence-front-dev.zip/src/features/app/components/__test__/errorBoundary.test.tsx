import React from 'react'
import '@testing-library/jest-dom'
import { cleanup, render } from '@testing-library/react'

import { ErrorBoundary } from '../ErrorBoundary'

const Child = () => {
  throw new Error('error')
}

const pauseErrorLogging = (codeToRun: () => void) => {
  const logger = console.error
  console.error = () => null
  codeToRun()
  console.error = logger
}

afterEach(cleanup)

// TODO: Should expect the frindely message, but not exist yeat :(
it("should throw error then show a frindely message error (don't have yeat)", () => {
  pauseErrorLogging(() => {
    const { queryByText } = render(
      <ErrorBoundary>
        <p>My awesome content</p>
        <Child />
      </ErrorBoundary>
    )

    expect(queryByText('My awesome content')).not.toBeInTheDocument()
  })
})

it('should show the content in the children', () => {
  pauseErrorLogging(() => {
    const { getByText } = render(
      <ErrorBoundary>
        <p>My awesome content</p>
      </ErrorBoundary>
    )

    expect(getByText('My awesome content'))
  })
})
