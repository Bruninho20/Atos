package routefence_common.cloud.rio.latam_routefence.domain.request

import org.springframework.format.annotation.DateTimeFormat
import java.time.OffsetDateTime

data class TripRequest(
    var id: String? = null,
    val driverId: String?,
    val assetId: String,
    var routeId: String?,

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    val startDateTime: OffsetDateTime
)
