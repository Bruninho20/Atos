package cloud.rio.latam_routefence.infrastructure.job

import cloud.rio.latam_routefence.infrastructure.job.services.AwsSns
import cloud.rio.latam_routefence.infrastructure.repositories.ScheduledMessagesWithLinkRepository
import cloud.rio.latam_routefence.services.SendEmailService
import org.joda.time.DateTime
import org.springframework.stereotype.Component
import routefence_common.cloud.rio.latam_routefence.domain.enums.ScheduleLinkSendingTypeEnum
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.time.LocalDateTime

@Component
class SendLinkPairingJob(
    private val sendEmailService: SendEmailService,
    private val scheduledMessagesWithLinkRepository: ScheduledMessagesWithLinkRepository
) :Runnable {
    override fun run() {
        try {
            AccountContext.set("ROUTEFENCE")
            val unsentMessages = scheduledMessagesWithLinkRepository.getAllUnsentScheduledMessages()

            if(unsentMessages.isNotEmpty()) {
                for (unsent in unsentMessages) {
                    try {
                        when(unsent.type){
                            ScheduleLinkSendingTypeEnum.EMAIL ->
                                //TODO Remover e-mail e telefone fixados no código antes de lançar em prod
                                sendEmailService.sendEmail(
                                    listOf(unsent.recipient?:""),
                                    "ROUTEFENCE",
                                    unsent.message?:""
                                )

                            ScheduleLinkSendingTypeEnum.SMS ->
                                AwsSns().sendNotification(
                                    unsent.message?:"",
                                    unsent.recipient?:""
                                )
                        }
                        unsent.sent = true
                        unsent.tries++
                        unsent.sentDateTime = LocalDateTime.now()
                    }
                    catch (ex: Exception){
                        unsent.tries++
                        unsent.sent = false
                        unsent.lastTryDateTime = LocalDateTime.now()
                        println("Erro ao processar envio de link ${unsent.id} por ${unsent.type} - ${ex.message}")
                    }
                    finally {
                        scheduledMessagesWithLinkRepository.save(unsent)
                    }
                }
            }
        }
        catch (ex: Exception){
            println("Erro ao processar envio de link - ${ex.message}")
        }
        finally {
            println("SendLinkJob Runned: ${DateTime.now()}")
        }
    }
}
