package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class TripStatusEnum {
    SCHEDULED, DELAYED, STARTED, INTERRUPTED,FINISHED,DELETED
}