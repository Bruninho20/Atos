package cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.StopRequest
import cloud.rio.latam_routefence.domain.response.StopResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.StopEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

fun StopRequest.mapToEntity(accountId: String) = StopEntity(
    name = this.name,
    category = this.category,
    position = this.position!!.mapToEntity(),
    accountId = accountId,
    note = this.note,
    route = null
)