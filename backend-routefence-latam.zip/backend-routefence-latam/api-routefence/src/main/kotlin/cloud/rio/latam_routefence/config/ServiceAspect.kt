
package cloud.rio.latam_routefence.config

import org.aspectj.lang.JoinPoint
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Before
import org.springframework.stereotype.Component
import routefence_common.cloud.rio.latam_routefence.tenant.ServiceAspectBase
import javax.persistence.EntityManager

@Aspect
@Component
class ServiceAspect(em: EntityManager): ServiceAspectBase(em) {

    @Before("execution (* cloud.rio.latam_routefence.services..*.*(..))")
    @Throws(Throwable::class)
    override fun filter(pjp: JoinPoint) {
        super.filter(pjp)
    }
}
