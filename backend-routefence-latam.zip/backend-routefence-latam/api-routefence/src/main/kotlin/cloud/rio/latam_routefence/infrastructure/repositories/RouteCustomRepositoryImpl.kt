package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.domain.bo.BoundingBoxBO
import routefence_common.cloud.rio.latam_routefence.domain.response.routing.ResponseHere
import routefence_common.cloud.rio.latam_routefence.domain.response.AddressResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.CostsResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.RangeResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleVocationalInfoResponse
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query

@Repository
class RouteCustomRepositoryImpl : RouteCustomRepository {

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun findByRoutId(id: String): RouteResponse? {
        val sql = StringBuilder()

        sql.append(
            """
                SELECT 
                    r.id, 
                    r.routeName,
                    r.creationDate,
                    r.deletionDate,
                    r.rangeToleranceLimit,
                    r.accountId,
                    
                    r.geoPointOrigin.id,
                    gpo.lat as originLat,
                    gpo.long as originLong,
                    gpo.address.id as gpoAddressId,
                    tao.city as taoCity,
                    tao.countryCode as taoCountryCode,
                    tao.countryName as taoCountryName,
                    tao.district as taoDistrict,
                    tao.houseNumber as taoHouseNumber,
                    tao.label as taoLabel,	
                    tao.postalCode as taoPostalCode,
                    tao.state as taoState,
                    tao.stateCode as taoStateCode,
                    tao.street as taoStreet,
                    
                    r.geoPointDestiny.id, 
                    gpd.lat as destinyLat,
                    gpd.long as destinyLong,
                    gpd.address.id as gpdAddressId,
                    tad.city as tadCity,
                    tad.countryCode as tadCountryCode,
                    tad.countryName as tadCountryName,
                    tad.district as tadDistrict,
                    tad.houseNumber as tadHouseNumber,
                    tad.label as tadLabel,	
                    tad.postalCode as tadPostalCode,
                    tad.state as tadState,
                    tad.stateCode as tadStateCode,
                    tad.street as tadStreet,
                    
                    r.costs.id,
                    tc.averageConsume,	
                    tc.fuelAverageCosts,
                    tc.operativeCosts,
                    tc.tollValue,
                    tc.totalCosts,
                    
                    r.range.id,
                    tr.avoidRoad,
                    tr.avoidToll,
                    tr.ignoreTrafficRestrictions,
                    tr.trafficConditions,
                    
                    r.vehicleVocationalInfo.id,
                    tvvi.vehicleType,
                    tvvi.width,
                    tvvi.height,
                    tvvi.comTotal,
                    tvvi.numberAxle,
                    tvvi.trailerAxle,
                    tvvi.maxWeightAxle,
                    tvvi.maxWeight,
                    tvvi.pollutantClass,
                    tvvi.dangerClassification,
                      
                    r.idLayer,
    (select case WHEN x.total > 0 then true else false end
		from (
			select count(*) as total
			from tb_trip tt 		
			where 
				tt.route_id = :id
				and tt.status in ('STARTED', 'SCHEDULED')
		) 
	x) as status,
                    r.responseHere,
                    r.avoidArea
                    
                FROM 
                    RouteEntity r 
                left join GeoPointEntity gpo on
                     r.geoPointOrigin.id = gpo.id
                left join AddressEntity tao on
	                 gpo.address.id = tao.id
                left join GeoPointEntity gpd on
                     r.geoPointDestiny.id = gpd.id
                left join AddressEntity tad on
	                 gpd.address.id = tad.id
                left join CostsEntity tc on
	                 r.costs.id = tc.id 
                left join RangeEntity tr on
	                 r.range.id = tr.id            
                left join VehicleVocationalInfoEntity tvvi on
	                 r.vehicleVocationalInfo.id = tvvi.id 
                WHERE 
                    r.id = :id 
                AND 
                    r.accountId = :accountId 
        """.trimIndent()
        )

        val query = entityManager.createQuery(sql.toString())

        setQueryParameters(query, id)

        return getResultList(query)
    }

    private fun getResultList(query: Query): RouteResponse? {

        val route: MutableList<RouteResponse> = mutableListOf()

        query.resultList?.forEach {
            val objArray = it as Array<*>

            route.add(
                RouteResponse(
                    id = objArray[0].toString(),
                    routeName = objArray[1].toString(),
                    creationDate = objArray[2].toString(),
                    deletionDate = objArray[3].toString(),
                    rangeToleranceLimit = objArray[4].toString(),
                    accountId = objArray[5].toString(),
                    originRoute = GeoPointResponse(
                        id = objArray[6].toString(),
                        lat = objArray[7] as Float,
                        lng = objArray[8] as Float,
                        address = AddressResponse(
                            id = objArray[9].toString(),
                            city = objArray[10].toString(),
                            countryCode = objArray[11].toString(),
                            countryName = objArray[12].toString(),
                            district = objArray[13].toString(),
                            houseNumber = objArray[14].toString(),
                            label = objArray[15].toString(),
                            postalCode = objArray[16].toString(),
                            state = objArray[17].toString(),
                            stateCode = objArray[18].toString(),
                            street = objArray[19].toString()
                        )
                    ),
                    destinyRoute = GeoPointResponse(
                        id = objArray[20].toString(),
                        lat = objArray[21] as Float,
                        lng = objArray[22] as Float,
                        address = AddressResponse(
                            id = objArray[23].toString(),
                            city = objArray[24].toString(),
                            countryCode = objArray[25].toString(),
                            countryName = objArray[26].toString(),
                            district = objArray[27].toString(),
                            houseNumber = objArray[28].toString(),
                            label = objArray[29].toString(),
                            postalCode = objArray[30].toString(),
                            state = objArray[31].toString(),
                            stateCode = objArray[32].toString(),
                            street = objArray[33].toString()
                        )
                    ),
                    costs = CostsResponse(
                        id = objArray[34].toString(),
                        averageConsume = objArray[35].toString(),
                        fuelAverageCosts = objArray[36].toString(),
                        operativeCosts = objArray[37].toString(),
                        tollValue = objArray[38].toString(),
                        totalCosts = objArray[39].toString()
                    ),
                    roadParameters = RangeResponse(
                        id = objArray[40].toString(),
                        avoidRoad = objArray[41].toString(),
                        avoidToll = objArray[42].toString(),
                        ignoreTrafficRestrictions = objArray[43].toString(),
                        trafficConditions = objArray[44].toString()
                    ),
                    vehicleVocationalInfo = VehicleVocationalInfoResponse(
                        id = objArray[45].toString(),
                        type = objArray[46].toString(),
                        width = objArray[47].toString(),
                        height = objArray[48].toString(),
                        comTotal = objArray[49].toString(),
                        numberAxle = objArray[50].toString(),
                        trailerAxle = objArray[51].toString(),
                        maxWeightAxle = objArray[52].toString(),
                        maxWeight = objArray[53].toString(),
                        pollutantClass = objArray[54].toString(),
                        dangerClassification = objArray[55].toString()
                    ),
                    idLayer = objArray[56].toString(),
                    responseHere = objArray[57] as ResponseHere?,
                    avoidArea = objArray[58] as List<BoundingBoxBO>?,
                    status = false,
                    stops = listOf()
                )
            )
        }
        return if (route.isEmpty()) null else route.first()
    }

    private fun setQueryParameters(query: Query, id: String?) {
        query.setParameter("id", id)
        query.setParameter("accountId", AccountContext.get())
    }
}