package cloud.rio.latam_routefence.domain.response

import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopCategoryEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse

data class StopResponse (
    var id: String? = null,
    var name: String? = null,
    var category: StopCategoryEnum? = null,
    var position: GeoPointResponse? = null,

    @JsonProperty("order")
    var stopQueueOrder: Int? = 0
)