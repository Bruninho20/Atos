import React, { FC, useState } from 'react'
import { useHistory } from 'react-router-dom'
import { TableSearch, TableSearchProperties, TableSettingsDialogProps, TableToolbar, TableViewToggles } from 'rio-uikit'
import { Button, Dialog2 } from 'components'
import Settings from './Settings'
import { Container } from './styled'

type SettingsProps = Pick<
  TableSettingsDialogProps,
  | 'columnLabels'
  | 'onColumnChange'
  | 'defaultColumnOrder'
  | 'columnOrder'
  | 'disabledColumns'
  | 'hiddenColumns'
  | 'columnsDetails'
  | 'onColumnDetailsChange'
>

export interface ToolbarProps extends SettingsProps {
  search?: TableSearchProperties['value']
  searchLabel?: string
  settingsCloseButtonText: TableSettingsDialogProps['closeButtonText']
  settingsNotFoundMessage: TableSettingsDialogProps['notFoundMessage']
  settingsResetButtonText: TableSettingsDialogProps['resetButtonText']
  settingsSearchPlaceholder: TableSettingsDialogProps['searchPlaceholder']
  settingsTitle: TableSettingsDialogProps['title']
  onChangeSearch?: TableSearchProperties['onChange']
  onDownloadClick?: () => void
  onViewTypeChange: (viewType: 'SINGLE_CARD' | 'MULTI_CARDS' | 'TABLE') => void
  onChange?: any
  resetCalc?: any
  valueOdometer?: any
  handleChangeOdometer?: any
  showResumeButton?: boolean
}

export const Toolbar: FC<ToolbarProps> = ({
  resetCalc,
  onChange,
  columnLabels,
  columnOrder,
  columnsDetails,
  defaultColumnOrder,
  disabledColumns,
  hiddenColumns,
  search,
  searchLabel,
  settingsCloseButtonText,
  settingsNotFoundMessage,
  settingsResetButtonText,
  settingsSearchPlaceholder,
  settingsTitle,
  onChangeSearch,
  onViewTypeChange,
  onColumnChange,
  onDownloadClick,
  onColumnDetailsChange,
  showResumeButton,
  valueOdometer,
  handleChangeOdometer
}) => {
  const history = useHistory()
  const [showTableSettingsDialog, setShowTableSettingsDialog] = useState(false)
  const [showDialogMaintenance, setShowDialogMaintenance] = useState({
    isOpen: false
  })

  const handleDialogOpen = () => setShowTableSettingsDialog(!showTableSettingsDialog)

  const handleGoToMap = () => {
    history.push({
      pathname: `/resume-map`
    })
  }

  const handleGoToList = () => {
    history.push({
      pathname: `/resume`
    })
  }

  return (
    <Container>
      <TableToolbar>
        <div className='table-toolbar-container'>
          <div className='table-toolbar-group-right'>
            {onChangeSearch && (
              <div className='table-toolbar-column'>
                <TableSearch value={search} onChange={onChangeSearch} placeholder={'Pesquisar por rota'} />
              </div>
            )}
            <div className='table-toolbar-column' style={{ display: 'none' }}>
              <Button icon='download' onlyIcon onClick={() => console.log('ok')} />
            </div>
            <div className='table-toolbar-column'></div>
            <div className='table-toolbar-column'>
              <TableViewToggles onViewTypeChange={onViewTypeChange} />
            </div>
            <div className='table-toolbar-column'>
              <button className='btn btn-default btn-icon-only' onClick={handleDialogOpen}>
                <span className='rioglyph rioglyph-cog'></span>
              </button>
            </div>
            {showResumeButton === true ? (
              <div className='btn-toolbar' style={{ marginLeft: 16 }}>
                <div className='TableViewToggles btn-group display-flex flex-row'>
                  <button
                    className='btn btn-default btn-icon-only active'
                    style={{ width: 50 }}
                    onClick={handleGoToList}>
                    <span>Lista</span>
                  </button>
                  <button className='btn btn-default btn-icon-only' style={{ width: 50 }} onClick={handleGoToMap}>
                    <span>Mapa</span>
                  </button>
                </div>
              </div>
            ) : null}
          </div>
          {showTableSettingsDialog && (
            <Settings
              columnLabels={columnLabels}
              columnOrder={columnOrder}
              columnsDetails={columnsDetails}
              defaultColumnOrder={defaultColumnOrder}
              disabledColumns={disabledColumns}
              hiddenColumns={hiddenColumns}
              show={showTableSettingsDialog}
              closeButtonText={settingsCloseButtonText}
              notFoundMessage={settingsNotFoundMessage}
              resetButtonText={settingsResetButtonText}
              searchPlaceholder={settingsSearchPlaceholder}
              title={settingsTitle}
              onColumnChange={onColumnChange}
              onColumnDetailsChange={onColumnDetailsChange}
              onHide={handleDialogOpen}
            />
          )}
          {showDialogMaintenance && (
            <Dialog2
              title='Ajustar cálculo de CO2 e Diesel evitado'
              isOpen={showDialogMaintenance.isOpen}
              onClose={() => setShowDialogMaintenance({ isOpen: false })}
              onChange={onChange}
              resetCalc={resetCalc}
              valueOdometer={valueOdometer}
              handleChangeOdometer={handleChangeOdometer}
              // columnLabels={columnLabels}
              //   columnOrder={columnOrder}
              //   columnsDetails={columnsDetails}
              //   defaultColumnOrder={defaultColumnOrder}
              //   disabledColumns={disabledColumns}
              //   hiddenColumns={hiddenColumns}
              //   // show={showTableSettingsDialog}
              //   // closeButtonText={settingsCloseButtonText}
              //   // notFoundMessage={settingsNotFoundMessage}
              //   // resetButtonText={settingsResetButtonText}
              //   // searchPlaceholder={settingsSearchPlaceholder}
              //   onColumnChange={onColumnChange}
              //   onColumnDetailsChange={onColumnDetailsChange}
              //   // onHide={handleDialogOpen}
            />
          )}
        </div>
      </TableToolbar>
    </Container>
  )
}
