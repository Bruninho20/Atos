package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity

@Repository
interface RouteRepository : JpaRepository<RouteEntity, String>, RouteCustomRepository {
    @Query(value = "SELECT CASE WHEN COUNT(*)> 0 THEN true ELSE false END FROM RouteEntity r WHERE r.accountId= :accountId AND r.routeName= :routeName AND r.deletionDate = null")
    fun existsRouteNameByAccountId (@Param("accountId") accountId: String,@Param("routeName") routeName: String): Boolean

    @Query(value = "SELECT r FROM RouteEntity r WHERE r.routeName= :routeName AND r.accountId= :accountId AND r.deletionDate = null")
    fun findRouteByRouteName(pageable: Pageable,@Param("routeName") routeName: String,@Param("accountId") accountId: String): Page<RouteEntity>

    @Query(value = "SELECT t FROM RouteEntity t WHERE t.accountId = :accountId AND t.deletionDate = null")
    fun findRoutes(pageable: Pageable, @Param("accountId") accountId: String): Page<RouteEntity>
}