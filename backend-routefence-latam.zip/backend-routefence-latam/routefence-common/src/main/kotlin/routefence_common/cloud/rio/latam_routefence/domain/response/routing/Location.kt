package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Location(
    @JsonProperty("lat") val lat: Double?,
    @JsonProperty("lng") val lng: Double?
)
