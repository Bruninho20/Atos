package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize

data class AssetStateMessage(
    @JsonProperty("mileage")
    val mileage: Double?,
    @JsonProperty("ignition_on")
    val ignitionOn: Boolean?,
    @JsonProperty("fuel_level")
    val fuelLevel: Double?,
    @JsonProperty("state_of_charge")
    val stateOfCharge: Double?,
    @JsonProperty("electric_range")
    val electricRange: Double?,
    @JsonProperty("engine_speed")
    val engineSpeed: Double?,
    @JsonProperty("wheel_speed")
    val wheelSpeed: Double?,
    @JsonProperty("tacho_speed")
    val tachoSpeed: Double?,
    @JsonProperty("fuel_consumption")
    val fuelConsumption: Double?,
    @JsonProperty("accelerator_pedal")
    val acceleratorPedal: Double?,
    @JsonProperty("weight_total")
    val weightTotal: Double?,
    @JsonProperty("pto_information")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val ptoInformation: String?,
    @JsonProperty("electronic_retarder_state")
    val electronicRetarderState: Int?,
    @JsonProperty("drive_state")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val driveState: String?,
    @JsonProperty("fuel_rate")
    val fuelRate: Double?,
    @JsonProperty("instantaneous_fuel_economy")
    val instantaneousFuelEconomy: Double?,
    @JsonProperty("engine_operation_time")
    val engineOperationTime: Double?
)