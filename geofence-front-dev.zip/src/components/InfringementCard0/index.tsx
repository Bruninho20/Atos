import React, { FC } from 'react';
import { FormattedMessage } from 'react-intl'

import {
  Driver,
  DriverInformation,
  DriverInformationLeft,
  DriverTotal,
  StyledCard,
  TotalCounter,
  TotalCounter2,
  TotalInfractions
} from './styled';

interface ICardsProps {
  title: any;
  quantity: number;
  description: any;
  quantityOfDescription: number;
  cardFilter: string;
  cardType: string;
  handleFilterClick: any;
}

const InfringementCard: FC<ICardsProps> = ({ title, quantity, description, quantityOfDescription, cardFilter, handleFilterClick, cardType }) => {

  return (
    <StyledCard
      title={title}
      className="card-title"
    >
      <div onClick={() => handleFilterClick({filter: cardFilter, card: cardType})} >
        <TotalInfractions>
          <TotalCounter>{quantity}</TotalCounter>
          <TotalCounter2>{<FormattedMessage id='vehicle' />}</TotalCounter2>
        </TotalInfractions>
        <Driver>
          <DriverInformation>
            <DriverInformationLeft>
              <p>{description}</p>
            </DriverInformationLeft>
            <DriverTotal>
              <p>{quantityOfDescription}</p>
            </DriverTotal>
          </DriverInformation>
        </Driver>
      </div>
    </StyledCard>
  );
};

export default InfringementCard;



 