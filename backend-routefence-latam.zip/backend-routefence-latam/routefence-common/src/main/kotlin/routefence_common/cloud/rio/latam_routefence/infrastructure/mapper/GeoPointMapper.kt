package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.GeoPointEntity

fun GeoPointRequest.mapToEntity(): GeoPointEntity {
    return GeoPointEntity (
        lat = this.lat!!.toFloat(),
        long = this.lng!!.toFloat(),
        address = this.address?.mapToEntity()
    )
}

fun GeoPointEntity.mapToResponse() : GeoPointResponse {
    return GeoPointResponse(
        id = this.id,
        lat = this.lat,
        lng = this.long,
        address = this.address?.mapToResponse()
    )
}

fun GeoPointEntity?.copyFromRequest(req: GeoPointRequest?): GeoPointEntity? {
    req?.lat?.let { this?.lat = it }
    req?.lng?.let { this?.long = it }
    req?.address?.let { this?.address?.copyFromRequest(it) }

    return this
}

fun GeoPointRequest.mapToDuplicateEntity(geoPointEntity: GeoPointEntity): GeoPointEntity{
    return GeoPointEntity(
        lat = this.lat ?: geoPointEntity.lat,
        long = this.lng ?: geoPointEntity.long,
        address = null
    )
}