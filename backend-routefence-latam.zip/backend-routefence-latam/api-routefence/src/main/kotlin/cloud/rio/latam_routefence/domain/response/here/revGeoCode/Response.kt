package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class Response(
    val items: Collection<Item?>
)
