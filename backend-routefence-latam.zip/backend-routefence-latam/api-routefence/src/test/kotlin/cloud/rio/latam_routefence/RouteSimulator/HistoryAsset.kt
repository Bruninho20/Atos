package cloud.rio.latam_routefence.RouteSimulator

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.readValue
import org.springframework.boot.autoconfigure.SpringBootApplication
import java.io.File
import java.time.LocalDateTime
import java.time.OffsetDateTime

@SpringBootApplication
class HistoryAsset
fun main(args: Array<String>) {

    data class DataAsset(
        val occurred_at: OffsetDateTime,
        val latitude: Double,
        val longitude: Double,
        val speed: Double
    )

    fun convertJsonToDataAsset(jsonFile: File): List<DataAsset> {
        val mapper = ObjectMapper().registerModule(JavaTimeModule())
        var previousLat: Double? = null
        var previousLong: Double? = null
        val jsonList = mapper.readValue<List<Map<String, Any>>>(jsonFile)
        return jsonList.map { jsonObj ->
            val latitude = jsonObj["latitude"] as Double
            val longitude = jsonObj["longitude"] as Double
            val occurredAt = OffsetDateTime.parse(jsonObj["occurred_at"] as String)
            var speed = (10..120).random().toDouble()
            if (latitude == previousLat && longitude == previousLong) {
                speed = 0.0
            } else {
                previousLat = latitude
                previousLong = longitude
            }
            DataAsset(occurredAt, latitude, longitude, speed)
        }
    }

    fun writeDataAssetToFile(dataAssetList: List<DataAsset>, outputFile: String) {
        var currentOccurredAt = LocalDateTime.now()

        val dataAssetStringList = dataAssetList.joinToString(",\n") { dataAsset ->
            val occurredAtString = currentOccurredAt.toString()
            currentOccurredAt = currentOccurredAt.plusSeconds(20)

            var speedString = dataAsset.speed.toString()
            if (dataAsset.speed == 0.0) {
                "\n//parada\n"
            } else {
                ""
            } + """
        DataAsset(
            occurred_at= OffsetDateTime.parse("${occurredAtString}Z"),
            latitude= ${dataAsset.latitude},
            longitude= ${dataAsset.longitude},
            speed= $speedString
        )
        """.trimIndent()
        }
        File(outputFile).writeText(dataAssetStringList)
    }

    val jsonFile = File("C:\\projeto\\vw\\routefence\\backend-routefence-latam\\src\\test\\kotlin\\cloud\\rio\\latam_routefence\\RouteSimulator\\json\\data.json")
    val dataAssets = convertJsonToDataAsset(jsonFile)

    val outputFile = "C:\\projeto\\vw\\routefence\\backend-routefence-latam\\src\\test\\kotlin\\cloud\\rio\\latam_routefence\\RouteSimulator\\data_assets.txt"

    writeDataAssetToFile(dataAssets, outputFile)
    println("Pronto")
}
