package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import java.util.Optional

@Repository
interface TripRepository : PagingAndSortingRepository<TripEntity, String>, TripCustomRepository {

    @Query(value = "SELECT t FROM TripEntity t INNER JOIN RouteEntity r ON t.route.id = r.id WHERE t.id = :tripId AND t.deletedAt = null")
    fun getTripById(@Param("tripId") tripId: String): Optional<TripEntity>

    @Query(value = "SELECT t FROM TripEntity t WHERE t.assetId = :assetId AND t.startDateTime < NOW() AND t.status <> 'FINISHED' AND t.status <> 'INTERRUPTED' AND t.deletedAt = null ORDER BY t.startDateTime ASC")
    fun getActiveTrips(@Param("assetId") assetId: String): Collection<TripEntity>

    @Query(value = "SELECT t FROM TripEntity t INNER JOIN RouteEntity r ON t.route = r.id WHERE r.id = :routeId AND t.deletedAt = null ORDER BY t.startDateTime ASC")
    fun getTripsByRouteId(@Param("routeId") routeId: String): Collection<TripEntity?>
}