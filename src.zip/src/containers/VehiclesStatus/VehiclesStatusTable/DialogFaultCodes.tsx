import React, { FC } from 'react'
import { format, subHours } from 'date-fns'
import { FormattedMessage } from 'react-intl';

import FaultCodes from 'containers/Dashboard/FaultCodes'

import { Dialog } from 'rio-uikit'

interface DialogtFaultCodesProps {
  assetId: string
  chassis: string
  isOpen: boolean
  onClose: () => void
}

const DialogFaultCodes: FC<DialogtFaultCodesProps> = ({ assetId, chassis, isOpen = false, onClose }) => {
  const UTCHours = new Date().getHours() - new Date().getUTCHours()
  const dateTime = {
    from: format(subHours(new Date(), 24 + UTCHours), "yyyy-MM-dd'T'HH:mm:ss.SSS") + '-00:00',
    to: format(subHours(new Date(), UTCHours), "yyyy-MM-dd'T'HH:mm:ss.SSS") + '-00:00'
  }

  return (
    <Dialog
      show={isOpen}
      title={
        <div>
          {<FormattedMessage id='failuresLast24Hours' />}
        </div>
      }
      body={<FaultCodes assetsId={[assetId]} tagsId={[]} dateTime={dateTime} />}
      footer={
        <button type='button' className='btn btn-default' onClick={onClose}>
          Voltar
        </button>
      }
      bsSize={Dialog.SIZE_FULL}
      onHide={onClose}
      showCloseButton={true}
    />
  )
}
  

export default DialogFaultCodes
