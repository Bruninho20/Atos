import styled from 'styled-components'

export const TableStyled = styled.table`
  font-size: 14px;
`

export const StyledButton = styled.button`
  background-color: transparent;
  border: 0;
  outline: none;
  width: 100%;
`;

export const Container = styled.div`
  .first-button {
    font-family: Arial, Helvetica, sans-serif;
    padding: 5px;
    margin-right: 10px;  
    margin-top: -4px;
  }
`;
