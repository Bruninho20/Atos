package cloud.rio.latam_routefence.services
import cloud.rio.latam_routefence.infrastructure.repositories.TripRepository
import cloud.rio.latam_routefence.utils.PageableUtils
import com.opencsv.CSVWriter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripSortFields
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.TripResumeReportResponse
import java.io.ByteArrayOutputStream
import java.io.StringWriter

@Service
@Transactional
class TripReportService(

    private val infringementRepository: TripRepository
) {

    fun findAllResumeReport(
        tripId:String,
        orderBy: String?,
        search: String?,
        page: Int?,
        pageSize: Int?,
        status: TripStatusEnum?
    ): List<TripResumeReportResponse> {

        val pageable = PageableUtils.getPageable(
            page = page ?: 0,
            pageSize = pageSize ?: 50,
            order = listOf(orderBy ?: "-createdAt"),
            sortFieldsEnum = TripSortFields.values()
        )
        return infringementRepository.listResumeReport(tripId,search, status, pageable)
    }

    fun getCsvDataForDownload(
        tripId:String,
        orderBy: String?,
        search: String?,
        status: TripStatusEnum?
    ): String {
        val data = findAllResumeReport(tripId,orderBy, search, null, null, status)
        val writer = StringWriter()
        val csvWriter = CSVWriter(writer)
        csvWriter.writeNext(arrayOf("type", "routeName", "note", "startDateTime", "endDateTime"))
        data.forEach {
            csvWriter.writeNext(arrayOf( it.type, it.routeName, it.note ?: "", it.startDateTime, it.endDateTime))
        }
        csvWriter.close()
        return writer.toString()
    }



    fun getXlsxDataForDownload(
        tripId: String,
        orderBy: String?,
        search: String?,
        status: TripStatusEnum?
    ): String {
        val data = findAllResumeReport(tripId, orderBy, search, null, null, status)
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Report")

        val headerRow = sheet.createRow(0)
        headerRow.createCell(0).setCellValue("type")
        headerRow.createCell(1).setCellValue("routeName")
        headerRow.createCell(2).setCellValue("note")
        headerRow.createCell(3).setCellValue("startDateTime")
        headerRow.createCell(4).setCellValue("endDateTime")

        var rowNum = 1
        for (report in data) {
            val row = sheet.createRow(rowNum++)
            row.createCell(0).setCellValue(report.type)
            row.createCell(1).setCellValue(report.routeName)
            row.createCell(2).setCellValue(report.note ?: "")
            row.createCell(3).setCellValue(report.startDateTime)
            row.createCell(4).setCellValue(report.endDateTime)
        }

        for (i in 0..5) {
            sheet.autoSizeColumn(i)
        }

        val outputStream = ByteArrayOutputStream()
        workbook.write(outputStream)
        val byteArray = outputStream.toByteArray()
        outputStream.close()

        return String(byteArray)
    }

}