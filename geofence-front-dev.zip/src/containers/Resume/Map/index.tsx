import React, { useState, useEffect, useContext } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container } from './styled'
// import useCustomSWRInfinite from 'core/utils/useCustomSWRInfinite'
import { MapToResume } from '../../../components'
import { Row } from 'components/Table'
import { PdisDetailsModel } from '../interfaces/index'
import DashboardContext from 'core/DashboardContext'
import ResumeSidesheet from '../Sidesheet/index'
import { useHistory } from 'react-router-dom'
// import useDebounce from 'core/utils/use-debounce'
// import { Period } from 'components/DateTimeFilter'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import moment from 'moment'

interface PdisData extends Row {
  data: { data: PdisDetailsModel[] }
  total: number
}

const MapDash: React.FC = () => {
  const history = useHistory()
  const { assets, tags } = useContext(DashboardContext)

  // const [dateTime, setDateTime] = useState<Period>({
  //   from: '',
  //   to: ''
  // })

  // const handleChangeDateTime = (period: Period) => {
  //   setDateTime(period)
  // }

  // console.log(handleChangeDateTime)

  const [sidesheetDetais, setSidesheetDetails] = useState<{ isOpen: boolean; data?: PdisDetailsModel }>({
    isOpen: false,
    data: undefined
  })

  // const [search, setSearch] = useState('')
  // console.log(setSearch)
  // const debouseSearch = useDebounce(search, 1000)

  const pageSize = 50
  // const [propsData, setProps] = useState({})
  const [data, setData] = useState<any>([])
  const [refreshLocations, setRefreshLocations] = useState(false)
  const [statusCurrent, setStatusCurrent] = useState('')
  console.log(setStatusCurrent)

  // const { data: faultCodes = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   'api/perla-tests/vehicleStatus/faultCodes',
  //   'POST',
  //   propsData,
  //   pageSize
  // )

  // const { data: pdisData = [{ data: [], total: 0 }], status, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   '/trips/',
  //   'GET',
  //   propsData,
  //   pageSize
  // )
  const pageNo = 0

  // const baseURL = 'https://api.geo.latam-maintenance.rio.cloud/rio-routefence'
  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer ${customAcessToken}`
    }
  }

  const getTrips = async () => {
    if (statusCurrent === '') {
      const res = await axios.get(`${baseURL}/trips/resume?${pageSize}=&pageNo=${pageNo}&orderBy=ASC`, head)

      setData([res])

      if (res?.status === 200 || res?.status === 201) {
        setData([res])
      } else {
        console.log('error')
      }
    } else {
      const res = await axios.get(`${baseURL}/trips/resume?${pageSize}=&pageNo=${pageNo}&status=${statusCurrent}`, head)

      if (res.status === 200 || res.status === 201) {
        setData([res])
      } else if (res.statusText !== 'OK') {
        console.log('vazio')
      } else {
        console.log('ERROOOOOOOOOOOOOO')
      }
    }
  }

  useEffect(() => {
    getTrips()
  }, [statusCurrent])

  // const order = sort.sortBy ? `${sort.sortDirection === SortDirection.ASCENDING ? '' : '-'}${sort.sortBy}` : ''

  const convertStatusRoute = (status: string): string => {
    switch (status) {
      case 'STARTED':
        return 'Em Andamento'
      case 'SCHEDULED':
        return 'Programada'
      case 'FINISHED':
        return 'Finalizada'
      default:
        return 'Programada'
    }
  }

  const [arrayGeolocation, setArrayGeolocation] = useState<any>([])

  const getGeolocationDriver = async () => {
    if (tags.length >= 1) {
      const res = await axios.post(`${baseURL}/live-state`, { assetIds: [], tagIds: tags }, head)
      if (res?.data[0]?.position) {
        setArrayGeolocation(res?.data)
      } else {
        setArrayGeolocation([])
      }
    } else if (assets.length >= 1 && tags.length >= 1) {
      const res = await axios.post(`${baseURL}/live-state`, { assetIds: [], tagIds: [] }, head)
      if (res?.data[0]?.position) {
        setArrayGeolocation(res?.data)
      } else {
        setArrayGeolocation([])
      }
    } else {
      const res = await axios.post(`${baseURL}/live-state`, { assetIds: assets, tagIds: [] }, head)
      if (res?.data[0]?.position) {
        setArrayGeolocation(res?.data)
      } else {
        setArrayGeolocation([])
      }
    }
  }

  useEffect(() => {
    getGeolocationDriver()
  }, [assets, tags, refreshLocations])

  // useEffect(() => {
  //   console.log('bateu no tags')
  //   if (tags.length >= 1) {
  //     getGeolocationDriver()
  //     setTagIds(tags)
  //   } else {
  //     getGeolocationDriver()
  //     setTagIds([])
  //   }
  // }, [tags])

  setTimeout(() => {
    setRefreshLocations(!refreshLocations)
  }, 20000)

  useEffect(() => {
    if (data[0]?.data?.data?.length >= 1) {
      getGeolocationDriver()
    }
  }, [data])

  const rowsPagineted = data?.map((pdisDataPage: PdisData) => {
    return pdisDataPage
      ? pdisDataPage?.data?.data?.map((pdisDataRow: any, index: any) => {
          return {
            ...pdisDataRow,
            index: index.toString(),
            startedAt: moment(pdisDataRow.startedAt).format('DD/MM/yyyy HH:MM'),
            startDateTime: moment(pdisDataRow.startDateTime).format('DD/MM/yyyy HH:MM'),
            originRoute: pdisDataRow?.positionOrigin?.address?.label,
            destinyRoute: pdisDataRow?.positionDestiny?.address?.label,
            routeName: pdisDataRow?.route?.routeName,
            triId: pdisDataRow?.tripId,
            assetId: pdisDataRow?.assetId,
            driverId: pdisDataRow?.driverId,
            routeId: pdisDataRow?.route.routeId,
            status: convertStatusRoute(pdisDataRow?.status),
            originRouteData: pdisDataRow?.positionOrigin,
            destinyRouteData: pdisDataRow?.positionDestiny
          }
        })
      : []
  })

  // useEffect(() => {
  //   setSize(1)
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [propsData])

  const handleGoToMap = () => {
    history.push({
      pathname: `/resume-map`
    })
  }

  const handleGoToList = () => {
    history.push({
      pathname: `/resume`
    })
  }

  const handleOpenSidesheet = (open: boolean, data: any) => {
    setSidesheetDetails({
      isOpen: true,
      data
    })
  }

  // const arrayGeoTest = [
  //   {
  //     position: {
  //       latitude: -23.543,
  //       longitude: -46.5369
  //     },
  //     vehicle: {
  //       vehicle: 'TRUCKZERO'
  //     },
  //     assetId: 'bc0d2386-90b1-476d-9870-8a5884dc4443'
  //   },
  //   {
  //     position: {
  //       latitude: -23.4669,
  //       longitude: -46.6412
  //     },
  //     vehicle: {
  //       vehicle: '26T'
  //     },
  //     assetId: 'cb88359b-1fd4-4c05-87ed-15025abbbbdf'
  //   }
  // ]

  // useEffect(() => {
  //   setArrayGeolocation(arrayGeoTest)
  // }, [])

  return (
    <div>
      <ResumeSidesheet
        isOpen={sidesheetDetais.isOpen}
        data={sidesheetDetais.data}
        onClose={() => setSidesheetDetails({ isOpen: false })}
      />
      <Container>
        <MapWrapper>
          <div className='btn-toolbar' style={{ marginLeft: 16, position: 'absolute', right: 55, top: 60, zIndex: 99 }}>
            <div className='TableViewToggles btn-group display-flex flex-row'>
              <button className='btn btn-default btn-icon-only' style={{ width: 50 }} onClick={handleGoToList}>
                <span>Lista</span>
              </button>
              <button className='btn btn-default btn-icon-only active' style={{ width: 50 }} onClick={handleGoToMap}>
                <span>Mapa</span>
              </button>
            </div>
          </div>
          <MapToResume
            data={{ rowsPagineted, arrayGeolocation }}
            handleOpenSidesheet={handleOpenSidesheet}
            openedSidesheet={sidesheetDetais.isOpen}
          />
        </MapWrapper>
      </Container>
    </div>
  )
}

export default injectIntl(MapDash)
