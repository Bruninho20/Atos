import styled from 'styled-components'

export const WelcomeStyled = styled.div`
  align-items: center;
  background: white;
  border: 1px solid #aaa;
  display: flex;
  flex-direction: column;
  height: calc(100% - 200px);
  justify-content: center;
  padding: 50px;

  h2,
  p {
    max-width: 500px;
    width: 100%;
  }

  svg {
    display: block;
    height: auto;
    max-height: 450px;
    max-width: 800px;
    width: 100%;
  }
`
