export interface AppState {
  sessionExpiredAcknowledged: boolean
}
