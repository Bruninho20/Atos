import React, { FC, useRef, useState } from 'react'

import useOutsideClick from 'core/utils/useOutsideClick'

import { ButonMoreList, StyledButton } from './styled'

export interface List {
  icon: string
  description: string
  checked: boolean
  onClick: (list: List) => void
}

interface ButtonMoreProps {
  disabled?: boolean
  list: List[]
}

const ButtonMore: FC<ButtonMoreProps> = ({disabled, list}) => {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useOutsideClick(ref, () => {
    if (open) {
      setOpen(false)
    }
  })

  return (
    <div>
      <StyledButton
        onClick={() => {
          setOpen(!open)
        }}
        onlyIcon
        disabled={disabled}
        icon='option-vertical'
      />
      <ButonMoreList open={open} ref={ref}>
        {list.map(item => (
          <li key={item.description}>
            <span>
              <span className={`rioglyph rioglyph-${item.icon}`} style={{ paddingRight: '10px' }}></span>
              {item.description}
            </span>
          </li>
        ))}
      </ButonMoreList>
    </div>
  )
}

export default ButtonMore
