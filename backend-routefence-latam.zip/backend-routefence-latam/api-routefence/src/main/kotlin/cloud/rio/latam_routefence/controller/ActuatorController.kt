package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.RoutefenceBaseApi
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import javax.servlet.http.HttpServletRequest

@RestController
class ActuatorController() {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/actuator/health", produces = ["application/json"])
    fun health(request: HttpServletRequest): String {
        return """{
	"status": "UP"
}"""
    }
}