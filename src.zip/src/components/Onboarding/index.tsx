import React, { FC, useEffect, useState } from 'react'
import { OnboardingTip, tooltipPlacement, tooltipWidth } from 'rio-uikit'

import { useLocalStorage, writeStorage } from '@rehooks/local-storage'

interface OnboardingProps {
  children: React.ReactNode
  content: string | React.ReactElement
  placement?: tooltipPlacement
  onChangeShowTip?(): void
  showTip?: boolean
  storageTip?: string
  title: string | React.ReactElement
  width?: tooltipWidth
}

const Onboarding: FC<OnboardingProps> = ({
  showTip = true,
  children,
  content,
  onChangeShowTip = null,
  placement = 'right',
  storageTip = '',
  title,
  width = 300
}) => {
  const [localTips] = useLocalStorage(storageTip)
  const [show, setShowTip] = useState<boolean>(false)

  const handleHide = () => {

    if (onChangeShowTip) {

      if (storageTip) {
        writeStorage(storageTip, false)
      }
      return onChangeShowTip()
    }

    if (storageTip) {
      writeStorage(storageTip, false)
    }
    setShowTip(!show)
  }

  useEffect(() => {
    if (storageTip && !!localStorage.getItem(storageTip)) {
      const conditional = !!localStorage.getItem(storageTip) === showTip ? !!localTips : showTip
      writeStorage(storageTip, conditional)
      return setShowTip(conditional)
    }

    if (storageTip && localTips === undefined) {
      writeStorage(storageTip, showTip)
      return setShowTip(localTips)
    }

    return setShowTip(showTip)
  }, [storageTip, showTip, localTips])

  return (
    <OnboardingTip show={show} placement={placement} width={width} title={title} content={content} onHide={handleHide}>
      {children}
    </OnboardingTip>
  )
}

export default Onboarding
