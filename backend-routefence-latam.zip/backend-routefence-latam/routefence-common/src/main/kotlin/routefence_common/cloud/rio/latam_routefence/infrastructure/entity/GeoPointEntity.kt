package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_GEOPOINTS")
data class GeoPointEntity (
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "LAT")
    var lat: Float,

    @Column(name = "LONG")
    var long: Float,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "address_id", referencedColumnName = "ID")
    var address: AddressEntity? = null
) {
    fun acceptNewValues(geoPoint: GeoPointEntity) {
        this.lat = geoPoint.lat
        this.long = geoPoint.long
        geoPoint.address?.let { this.address?.acceptNewValues(it) }
    }
}