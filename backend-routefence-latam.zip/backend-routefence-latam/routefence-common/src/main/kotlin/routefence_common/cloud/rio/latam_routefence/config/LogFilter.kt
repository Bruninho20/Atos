package routefence_common.cloud.rio.latam_routefence.config

import ch.qos.logback.classic.spi.ILoggingEvent
import ch.qos.logback.core.filter.Filter
import ch.qos.logback.core.spi.FilterReply

class LogFilter:Filter<ILoggingEvent>() {

    companion object{
        var filterStatus = false
    }

    override fun decide(event: ILoggingEvent): FilterReply {
        val logMessages = listOf("Received a kafka message on topic")
        return if(filterStatus){
            logMessages.any {
                event.message.contains(it)
            }
            FilterReply.DENY
        }else FilterReply.ACCEPT
    }
}

