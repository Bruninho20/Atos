package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class StreetInfo(
    val baseName: String?,
    val streetType: String?,
    val streetTypePrecedes: Boolean?,
    val streetTypeAttached: Boolean?,
    val prefix: String?,
    val suffix: String?,
    val direction: String?,
    val language: String?
)
