import React from 'react';
import { cleanup } from '@testing-library/react';
import '@testing-library/jest-dom';
import { InfringementCard } from 'components';
import renderWithReactIntl from 'renderWithReactIntl';

afterEach(cleanup);

it('check if the contente is rendered', () => {
  const { getByText } = renderWithReactIntl(
    <InfringementCard
      action={() => null}
      infraction={{
        total: 80,
        infractionType: 'IT_KICKDOWN',
        offenders: [
          {
            name: 'Driver offender',
            plate: 'XYZ-5678',
            total: 70
          }
        ]
      }}
    />
  );

  expect(getByText('Principal infrator'));
  expect(getByText('Kickdown'));
  expect(getByText('Driver offender'));
  expect(getByText('XYZ-5678'));
  expect(getByText('70'));
  expect(getByText('Total de infrações'));
  expect(getByText('80'));
});
