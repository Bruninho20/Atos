package cloud.rio.latam_routefence.infrastructure.consumedapi.assets

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonProperty
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
data class AssetDTO(
    @JsonProperty("id")
    val id: String? = "",
    @JsonProperty("account_id")
    val account_id: String? = "",
    @JsonProperty("name")
    val name: String? = "",
    @JsonProperty("status")
    val status: String? = "",
    @JsonProperty("type")
    val type: String? = "",
    @JsonProperty("identification")
    val identification: String? = "",
    @JsonProperty("identification_type")
    val identification_type: String? = "",
    @JsonProperty("brand")
    val brand: String? = "",
    @JsonProperty("_embedded")
    var _embedded: TagDTO? = null
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class TagDTO(
    @JsonProperty("tags")
    var tags: ItemsDTO = ItemsDTO()
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class ItemsDTO(
    @JsonProperty("items")
    var items: List<IdDTO> = emptyList()
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class IdDTO(
    @JsonProperty("id")
    var id: String = ""
)

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
data class AssetsDTO(
    @JsonProperty("items")
    var items: MutableList<AssetDTO> = mutableListOf()
)