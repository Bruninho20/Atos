import 'react-app-polyfill/stable'
import 'react-app-polyfill/ie11'
import 'regenerator-runtime/runtime'

import 'classlist-polyfill'
import 'custom-event-polyfill'
import 'unorm'
