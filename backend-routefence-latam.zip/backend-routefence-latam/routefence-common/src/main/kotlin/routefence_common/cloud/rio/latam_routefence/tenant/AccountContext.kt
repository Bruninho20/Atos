package routefence_common.cloud.rio.latam_routefence.tenant

class AccountContext() {
    companion object{
        private val currentAccount: ThreadLocal<String> = InheritableThreadLocal()
        const val ACCOUNT_ID_PARAM = "accountId"
        const val ACCOUNT_ID_COLUMN = "ACCOUNT_ID"
        const val ACCOUNT_FILTER = "accountFilter"

        fun get(): String = currentAccount.get()

        fun set(accountId: String) {
            currentAccount.set(accountId)
        }

        fun clear() {
            currentAccount.set(null)
        }
    }
}