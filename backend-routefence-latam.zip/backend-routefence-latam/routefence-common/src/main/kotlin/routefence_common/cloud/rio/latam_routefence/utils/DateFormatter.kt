package routefence_common.cloud.rio.latam_routefence.utils

import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

class DateFormatter {
    companion object {
        const val DATETIME = "yyyy-MM-dd HH:mm:ss"

        fun parse(sDate: String, pattern: String? = null): LocalDateTime {
            val formatter = DateTimeFormatter.ofPattern(pattern ?: DATETIME)
            try {
                return LocalDateTime.parse(sDate, formatter)
            } catch (e: Exception) {
                throw IllegalArgumentException("date.format.exception ${arrayOf(sDate, pattern?: DATETIME).toString()}")
            }
        }

        fun format(date: LocalDateTime, pattern: String? = DATETIME): String {
            val formatter = DateTimeFormatter.ofPattern(pattern ?: DATETIME)
            try {
                return date.format(formatter)
            } catch (e: Exception) {
                throw IllegalArgumentException("date.format.exception ${arrayOf(date.toString(), pattern ?: DATETIME).toString()}")
            }
        }

        fun formatUTC(dateTime: OffsetDateTime): LocalDateTime = dateTime.toInstant().atOffset(ZoneOffset.UTC).toLocalDateTime()
    }
}