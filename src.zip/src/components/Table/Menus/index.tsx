import React from 'react'
import * as S from './styles'

interface MenuProps {
  handleMenu: any
}

const Menus: React.FC<MenuProps> = ({ handleMenu }) => {
  const onMenuClick = (value: any) => {
    handleMenu(value)

    let el = document.getElementsByClassName('invoice')
    Array.prototype.filter.call(el, function (el) {
      el.style.fontWeight = el.id === value ? '500' : '100'
      el.style.color = el.id === value ? '#000' : '#a5a4a4'
      el.style.borderBottom = el.id === value ? 'solid 2px #000' : 'none'
    })
  }

  React.useEffect(() => onMenuClick(''), [])

  return (
    <S.Wrapper>
      <S.Button id='SCHEDULED' onClick={() => onMenuClick('SCHEDULED')} className='invoice'>
        Programadas
      </S.Button>
      <S.Button id='STARTED' onClick={() => onMenuClick('STARTED')} className='invoice'>
        Em Andamento
      </S.Button>
      <S.Button id='FINISHED' onClick={() => onMenuClick('FINISHED')} className='invoice'>
        Finalizada
      </S.Button>
      <S.Button id='' onClick={() => onMenuClick('')} className='invoice'>
        Todos
      </S.Button>
    </S.Wrapper>
  )
}

export default Menus
