import React, { FC } from 'react'
import { Map, CardMapDialog } from 'components'
import { FormattedMessage } from 'react-intl'
import { Dialog } from 'rio-uikit'

import { Container } from './styled'

interface DialogtFaultCodesProps {
  apiKey: any
  lat: any;
  lng: any;
  points: any;
  vehicle: any;
  assetId: string;
  chassis: string;
  batteryLevel: any;
  autonomy: any;
  statusNow: any;
  isOpen: boolean;
  onClose: () => void
}

const DialogFaultCodes: FC<DialogtFaultCodesProps> = ({ statusNow, batteryLevel, autonomy, apiKey, lat, lng, points, vehicle, assetId, chassis, isOpen = false, onClose }) => {



  return (
    <div style={{ width: '740px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={
          <div>
            Chassis: <b>{chassis}</b>
          </div>
        }
        body={
          <Container>
            <Map
                    height='80vh'
                    apiKey={apiKey}
                    labelName={vehicle}
                    latitude={lat}
                    longitude={lng}
                  />
                  <div 
                  style={{ 
                    display: 'flex', 
                    position: 'absolute', 
                    right: '70px', 
                    bottom: '60px'
                    }}>
                      <CardMapDialog
                        status={statusNow}
                        vehicle={vehicle}
                        chassis={chassis}
                        batteryLevel={batteryLevel}
                        autonomy={autonomy === '0.0' ? (batteryLevel * 200 / 100).toLocaleString().split(',', 1) : autonomy}
                      />
                </div>
          </Container>  
        }
        footer={
          <button type='button' className='btn btn-default' onClick={onClose}>
            {<FormattedMessage id='close'/>}
          </button>
        }
        bsSize={Dialog.SIZE_FULL}
        onHide={onClose}
        showCloseButton={true}
      />
    </div>
  )
}

export default DialogFaultCodes
