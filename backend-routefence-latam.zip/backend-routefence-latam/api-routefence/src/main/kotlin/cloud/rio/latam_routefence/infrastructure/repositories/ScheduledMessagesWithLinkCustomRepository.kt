package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.ScheduledMessagesWithLinkEntity
import java.util.*

interface ScheduledMessagesWithLinkCustomRepository : JpaRepository<ScheduledMessagesWithLinkEntity, UUID> {
    @Query(value = "SELECT * FROM TB_SCHEDULED_MESSAGES_WITH_LINK s WHERE s.sent = false AND s.tries <= 5", nativeQuery = true)
    fun getAllUnsentScheduledMessages(): List<ScheduledMessagesWithLinkEntity>
}