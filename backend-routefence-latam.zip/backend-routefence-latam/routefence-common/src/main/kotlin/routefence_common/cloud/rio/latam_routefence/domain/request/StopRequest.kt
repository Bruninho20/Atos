package routefence_common.cloud.rio.latam_routefence.domain.request

import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopCategoryEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException

data class StopRequest(
    var id: String? = null,
    var name: String? = null,
    var category: StopCategoryEnum? = null,
    var rangeLimitMeters: String? = null,
    var position: GeoPointRequest? = null,
    var stayTime: String? = null,
    var note: String?,
    var type: StopTypeEnum?,

    @JsonProperty("order")
    var stopQueueOrder: Int = 0
) {
    init {
        if (type == null) {
            throw RoutefenceException.RoutefenceInvalidPayloadException("Stop.type.undefined")
        } else {
            if (type == StopTypeEnum.STOPOVER) {
                if (name == null)
                    throw RoutefenceException.RoutefenceInvalidPayloadException("Stop.not.named")

                if (category == null)
                    throw RoutefenceException.RoutefenceInvalidPayloadException("Stop.not.categorized")
            }
        }
    }
}


