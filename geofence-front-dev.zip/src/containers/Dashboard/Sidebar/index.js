import React, { useCallback, useContext, useEffect, useState } from 'react'
import { injectIntl } from 'react-intl'
import { withRouter } from 'react-router-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import useSWR from 'swr'

import isEmpty from 'lodash/fp/isEmpty'

import DashboardContext from 'core/DashboardContext'
import useDebounce from 'core/utils/use-debounce'

import { getUserAccount } from 'configuration/login/selectors'
import { getAccessToken } from 'configuration/tokenHandling/selectors'

import { AssetTree, TreeCategory } from 'rio-uikit'
import { Onboarding, Spinner } from 'components'

import { fetcherGet } from 'core/utils/fetch'
import { createAssetsList, sanitizeAssetsList, sanitizeTagsList } from './helper'

import { StyledTree } from './styled'

const CATEGORY_TRUCKS = 'trucks'

const defaultExpandedTruckTags = []

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const AssetTreeExample = ({ account, accessToken, location, intl }) => {
  const { setAssets, setTags, setSidesheetIsOpen, sidesheetIsOpen, setMapSize } = useContext(DashboardContext)
  const [showTip, setShowTip] = useState(true)
  const [trucks, setTrucks] = useState()
  const [truckTags, setTruckTags] = useState({})
  const [selectedTruckTagsIds, setSelectedTruckTagsIds] = useState([])
  const [selectedTruckIds, setSelectedTruckIds] = useState([])
  const [expandedTruckTags, setExpandedTruckTags] = useState()
  const [currentCategoryId, setCurrentCategoryId] = useState(CATEGORY_TRUCKS)
  const [isTreeOpen, setIsTreeOpen] = useState(false)
  const debouncedCallVehicles = useDebounce(selectedTruckIds, 1000)

  useEffect(() => {
    if (sidesheetIsOpen === true) {
      setIsTreeOpen(true)
      setMapSize('126%')
    }
    if (sidesheetIsOpen === false) {
      setIsTreeOpen(false)
      setMapSize('100%')
    }
  }, [sidesheetIsOpen])

  const getTags = async url => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const getAssets = async url => {
    const { items } = await fetcherGet(url)
    return [...items]
  }

  const { data: tags, error: statusTags } = useSWR('https://api.tags.rio.cloud/tags', getTags)
  const { data: assets, error: statusAssets } = useSWR('https://api.assets.rio.cloud/assets?embed=(tags)', getAssets)

  useEffect(() => {
    async function initialData() {
      if (!statusAssets && !isEmpty(assets)) {
        setTrucks(sanitizeAssetsList(assets))
      }
      if (!statusTags && !isEmpty(tags)) {
        setTruckTags(sanitizeTagsList(tags, intl))
      }

      setExpandedTruckTags(defaultExpandedTruckTags)
    }
    initialData()
  }, [assets, statusAssets, statusTags, intl, tags])

  useEffect(() => {
    if (debouncedCallVehicles) {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      getData()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedCallVehicles])

  const getData = useCallback(() => {
    const tags = selectedTruckTagsIds.filter(item => item !== 'empty')

    setTags(tags)
    setAssets(selectedTruckIds)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTruckIds, selectedTruckTagsIds])

  const handleSelectTruck = ({ items, groups }) => {

    const assetsList = createAssetsList({ items, groups, trucks })


    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    handleTip()
    setSelectedTruckIds(assetsList)
    setSelectedTruckTagsIds(groups)
  }

  const handleExpandTruckGroups = expandedTruckGroups => {
    setExpandedTruckTags(expandedTruckGroups)
  }

  const handleChangeCategories = currentCategoryId => {
    setCurrentCategoryId(currentCategoryId)
  }

  const handleToggleTree = toggle => {
    setIsTreeOpen(toggle)
    setSidesheetIsOpen(toggle)
  }

  const handleTip = () => {
    setShowTip(false)
  }

  return (
    <div className={'display-flex'}>
      <Onboarding
        title={intl.formatMessage({
          id: 'sidebarLeft.assetTree.onboarding.title'
        })}
        content={intl.formatMessage({
          id: 'sidebarLeft.assetTree.onboarding.content'
        })}
        showTip={showTip}
        onChangeShowTip={handleTip}
        storageTip='GROUPS_ASSETS_TIPS'>
        <AssetTree
          bordered
          minWidth={300}
          maxWidth={450}
          currentCategoryId={currentCategoryId}
          onCategoryChange={handleChangeCategories}
          height={'calc(100vh - 50px)'}
          isOpen={isTreeOpen}
          onToggleTree={handleToggleTree}>
          <TreeCategory
            key={CATEGORY_TRUCKS}
            id={CATEGORY_TRUCKS}
            label={'Trucks'}
            icon={'rioglyph-truck'}
            hasSelection={!isEmpty(selectedTruckIds) || !isEmpty(selectedTruckTagsIds)}>
            <Spinner show={statusAssets === 'loading' && statusTags === 'loading'} fullscreen={false} />

            {truckTags && trucks && (
              <StyledTree
                groups={truckTags}
                items={trucks}
                expandedGroups={expandedTruckTags}
                onExpandGroupsChange={handleExpandTruckGroups}
                selectedGroups={selectedTruckTagsIds}
                selectedItems={selectedTruckIds}
                onSelectionChange={handleSelectTruck}
                searchPlaceholder={intl.formatMessage({
                  id: 'sidebarLeft.assetTree.search.vehicle'
                })}
                hasMultiselect={true}
              />
            )}
          </TreeCategory>
        </AssetTree>
      </Onboarding>
    </div>
  )
}

const mapStateToProps = state => {
  return {
    account: getUserAccount(state),
    accessToken: getAccessToken(state)
  }
}

AssetTreeExample.propTypes = {
  account: PropTypes.string,
  accessToken: PropTypes.string,
  location: PropTypes.shape({
    pathname: PropTypes.string
  }),
  intl: PropTypes.shape({
    formatMessage: PropTypes.any
  })
}

export default withRouter(injectIntl(connect(mapStateToProps)(AssetTreeExample)))
