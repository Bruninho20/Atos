package routefence_common.cloud.rio.latam_routefence.config

import org.aspectj.lang.ProceedingJoinPoint
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.transaction.annotation.Transactional

open class ReadOnlyRouteInterceptorBase() {

    open fun proceed(proceedingJoinPoint: ProceedingJoinPoint, transactional: Transactional): Any? {
        return try {
            if (transactional.readOnly) {
                RoutingDataSource.setReplicaRoute()
            }
            proceedingJoinPoint.proceed()
        } finally {
            RoutingDataSource.clearReplicaRoute()
        }
    }
}