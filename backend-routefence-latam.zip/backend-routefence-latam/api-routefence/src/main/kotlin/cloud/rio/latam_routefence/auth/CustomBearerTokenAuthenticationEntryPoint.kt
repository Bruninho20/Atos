package cloud.rio.latam_maintenance.auth

import com.nimbusds.jose.RemoteKeySourceException
import org.apache.commons.lang3.exception.ExceptionUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.security.core.AuthenticationException
import org.springframework.security.oauth2.core.OAuth2AuthenticationException
import org.springframework.security.oauth2.server.resource.BearerTokenError
import org.springframework.security.web.AuthenticationEntryPoint
import java.io.IOException
import java.util.*
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class CustomBearerTokenAuthenticationEntryPoint : AuthenticationEntryPoint {
    private val logger: Logger = LoggerFactory.getLogger(javaClass)

    @Throws(IOException::class, ServletException::class)
    override fun commence(httpServletRequest: HttpServletRequest, httpServletResponse: HttpServletResponse, e: AuthenticationException) {
        val exceptionParameters = extractExceptionParameters(e)
        val wwwAuthenticate = WwwAuthenticateHelper.computeWWWAuthenticateHeaderValue(exceptionParameters)
        httpServletResponse.addHeader(HttpHeaders.WWW_AUTHENTICATE, wwwAuthenticate)
        httpServletResponse.status = HttpStatus.UNAUTHORIZED.value()
        if (ExceptionUtils.indexOfThrowable(e, RemoteKeySourceException::class.java) !== -1) {
            logger.error("Could not retrieve JWK from jwk-set-uri", e)
        } else logger.debug("Access was denied because of {}", e)
    }

    private fun extractExceptionParameters(authException: AuthenticationException?): LinkedHashMap<String, String> {
        val parameters = LinkedHashMap<String, String>()
        if (authException is OAuth2AuthenticationException) {
            val error = authException.error
            parameters["error"] = error.errorCode
            parameters["error_description"] = error.description
            parameters["error_uri"] = error.uri
            if (error is BearerTokenError) {
                parameters["scope"] = error.scope ?: ""
            }
        }
        return parameters
    }
}
