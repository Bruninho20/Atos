package cloud.rio.latam_routefence.infrastructure.job

import cloud.rio.latam_routefence.auth.InternalAuthService
import cloud.rio.latam_routefence.infrastructure.repositories.AssetIotEventPairingRepository
import cloud.rio.latam_routefence.infrastructure.repositories.ScheduledMessagesWithLinkRepository
import cloud.rio.latam_routefence.services.DriverService
import cloud.rio.latam_routefence.services.LinkTripService
import cloud.rio.latam_routefence.services.TripService
import org.joda.time.DateTime
import org.springframework.stereotype.Component
import routefence_common.cloud.rio.latam_routefence.domain.enums.ScheduleLinkSendingTypeEnum
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.ScheduledMessagesWithLinkEntity
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext

@Component
class CreateLinkToSendPairingSchedulingJob(
    private val internalAuthService: InternalAuthService,
    private val linkTripService: LinkTripService,
    private val pairingRepository: AssetIotEventPairingRepository,
    private val tripService: TripService,
    private val driverService: DriverService,
    private val scheduledMessagesWithLinkRepository: ScheduledMessagesWithLinkRepository
    ) :Runnable {
    override fun run() {
        try {
            val unprocessedPairings = pairingRepository.getAllPairingUnprocessed()

            if(unprocessedPairings.isNotEmpty()) {
                val token = internalAuthService.getAuthToken()

                unprocessedPairings.forEach { pairing ->
                    try {
                        AccountContext.set(pairing.accountId)

                        val allTripsScheduled = tripService.getActiveTrips(pairing.assetId)
                        if (allTripsScheduled.isNotEmpty()) {
                            val trip = allTripsScheduled.first()

                            val pairedDriver = driverService.getById(pairing.driverIdentification, token)

                            val schedulingMessages = mutableListOf<ScheduledMessagesWithLinkEntity>()

                            ScheduleLinkSendingTypeEnum.values().forEach { type ->
                                val schedulingMessage = ScheduledMessagesWithLinkEntity(
                                    accountId = pairing.accountId,
                                    tripId = trip.id.toString(),
                                    type = type,
                                    message = null,
                                    recipient = null,
                                    tries = 0,
                                    lastTryDateTime = null,
                                    sendDateTime = null,
                                    sentDateTime = null,
                                    sent = false
                                )

                                when (type) {
                                    ScheduleLinkSendingTypeEnum.SMS ->
                                        schedulingMessage.recipient = pairedDriver.phone_number

                                    ScheduleLinkSendingTypeEnum.EMAIL ->
                                        schedulingMessage.recipient = pairedDriver.email
                                }

                                if (!schedulingMessage.recipient.isNullOrEmpty())
                                    schedulingMessages.add(schedulingMessage)
                            }

                            var messageBody = "ROUTEFENCE: "

                            if(
                                trip.driverId.isNullOrEmpty() ||
                                (!trip.driverId.isNullOrEmpty() && pairedDriver.id == trip.driverId)
                            ){
                                val link = linkTripService.createLinkTrip(trip)
                                messageBody += "Siga sua rota! $link"

                            } else {
                                messageBody += "Este veículo não pode ser utilizado no momento. Por favor, informe o recebimento desta mensagem ao seu gestor."
                                // Todo implementar mensagem de alerta para o driver pareado
                                //  informando que este asset não pode ser utilizado
                                //  SUGESTÃO: Criar Exception personalizada e tratar no catch
                                //  P.S.: Esta mensagem não é mencionada no BRD. Foi uma solicitação
                                //  posterior, à partir de uma conversa com João Santos.
                                //  https://my-rio.slack.com/archives/C04JM1W46FQ/p1680116497796349.
                            }

                            schedulingMessages.forEach{schedulingMessage ->
                                schedulingMessage.message = messageBody
                            }

                            scheduledMessagesWithLinkRepository.saveAll(schedulingMessages)

                            pairing.processed = true
                            pairingRepository.save(pairing)
                        }
                    } catch (ex: Exception) {
                        println("Erro ao agendar envio de link - ${ex.message}")
                    }
                }
            }
        }
        catch (ex: Exception){
            println("Erro ao agendar envio de link - ${ex.message}")
        }
        finally {
            println("SendLinkSchedulerJob Runned: ${DateTime.now()}")
        }
    }
}