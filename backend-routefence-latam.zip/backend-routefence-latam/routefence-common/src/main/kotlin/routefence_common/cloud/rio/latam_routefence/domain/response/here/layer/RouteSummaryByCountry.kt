package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class RouteSummaryByCountry(
    @JsonProperty("baseTime") var baseTime: Int?,
    @JsonProperty("country") var country: String?,
    @JsonProperty("distance") var distance: Int?,
    @JsonProperty("tollRoadDistance") var tollRoadDistance: Int?,
    @JsonProperty("trafficTime") var trafficTime: Int?,
    @JsonProperty("travelTime") var travelTime: Int?
)