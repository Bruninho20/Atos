package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseStatus
import javax.servlet.http.HttpServletRequest

@RequestMapping()
interface AssetApi {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/assets", produces = ["application/json"])
    fun assetsList(request: HttpServletRequest,): List<AssetDTO>

}