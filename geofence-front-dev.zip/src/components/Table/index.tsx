import React, { CSSProperties, FC, Fragment, MouseEvent, useEffect, useState, useContext } from 'react'
import { SortArrows, SortDirection, TableSettingsDialogProps, SimpleButtonDropdown, Notification } from 'rio-uikit'
import { useLocalStorage } from '@rehooks/local-storage'
import ContentLoader from 'react-content-loader'
import { Intl, injectIntl } from 'react-intl'
import { useHistory } from 'react-router-dom'
import { StyledButton, TableStyled } from './styled'
import { Toolbar, ToolbarProps } from './Toolbar'
import Placeholder from 'components/Placeholder'
import { Link } from 'react-router-dom'
import Menus from './Menus'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import DashboardContext from 'core/DashboardContext'

export type Row = {
  [K: string]:
    | string
    | number
    | React.ReactNode
    | {
        [K: string]: string | number
      }[]
}

export interface Sort {
  sortBy: any
  sortDirection: SortDirection.ASCENDING | SortDirection.DESCENDING
}

interface TableProps {
  intl: Intl
  name: string
  disabledColumns: ToolbarProps['disabledColumns']
  rowsPagineted: Row[][]
  rowsCount: number
  lineClickName?: string | 'allColumns'
  defaultColumnOrder: ToolbarProps['defaultColumnOrder']
  columnsStyle: ToolbarProps['columnsDetails']
  columnLabels: ToolbarProps['columnLabels']
  search?: ToolbarProps['search']
  settingsCloseButtonText: TableSettingsDialogProps['closeButtonText']
  settingsNotFoundMessage: TableSettingsDialogProps['notFoundMessage']
  settingsResetButtonText: TableSettingsDialogProps['resetButtonText']
  settingsSearchPlaceholder: TableSettingsDialogProps['searchPlaceholder']
  settingsTitle: TableSettingsDialogProps['title']
  searchLabel?: ToolbarProps['searchLabel']
  onChangeSearch?: ToolbarProps['onChangeSearch']
  onLineClick?: (row: Row) => void
  sort: Sort
  status: 'success' | 'error' | 'loading'
  onDownloadClick?: () => void
  onChangeSort: (sortBy: Sort['sortBy'], sortDirection: Sort['sortDirection']) => void
  onChange?: () => void
  resetCalc?: () => void
  valueOdometer?: any
  handleChangeOdometer?: any
  typeTable?: string
  handleMenu?: any
  showResumeButton?: boolean
  handleLinkVehicle: (data: any) => void
}

const Table: FC<TableProps> = ({
  intl,
  name,
  columnLabels,
  columnsStyle,
  defaultColumnOrder,
  disabledColumns,
  onChangeSearch,
  onLineClick,
  handleLinkVehicle,
  rowsCount,
  rowsPagineted,
  search,
  searchLabel,
  settingsCloseButtonText,
  settingsNotFoundMessage,
  settingsResetButtonText,
  settingsSearchPlaceholder,
  settingsTitle,
  sort,
  lineClickName,
  status,
  onChangeSort,
  onDownloadClick,
  onChange,
  resetCalc,
  valueOdometer,
  handleChangeOdometer,
  typeTable,
  handleMenu,
  showResumeButton
}) => {
  const {
    setAllStopsContext,
    setOriginRouteContext,
    setDestinyRouteContext,
    setRoadParametersContext,
    setResponseHereContext,
    setVehicleVocacionalContext,
    setCostsContext,
    setRouteContext
  } = useContext(DashboardContext)
  const history = useHistory()
  const [viewType, setNewView] = useState<'SINGLE_CARD' | 'MULTI_CARDS' | 'TABLE'>('TABLE')
  const [sortBy, setSortBy] = useState<Sort['sortBy']>(sort.sortBy)
  const [sortDirection, setSortDirection] = useState<Sort['sortDirection']>(sort.sortDirection)
  const [columnsDetails, setColumnsDetails] = useLocalStorage<ToolbarProps['columnsDetails']>(
    `columnDetails-${name}`,
    columnsStyle
  )
  const [hiddenColumns, setHiddenColumns] = useLocalStorage<string[]>(`hiddenColumns-${name}`, [])
  const [columnOrder, setColumnOrder] = useLocalStorage(`columnOrder-${name}`, defaultColumnOrder)

  const columns: ToolbarProps['defaultColumnOrder'] =
    columnOrder && columnOrder.length ? columnOrder.filter(name => !hiddenColumns.includes(name)) : []

  const handleColumnChange = (columnOrder: string[], hiddenColumns: string[]) => {
    setColumnOrder(columnOrder)
    setHiddenColumns(hiddenColumns)
  }

  const typeTableSelected = typeTable === 'resume' ? '/trips/' : '/routes/'

  const handleColumnDetailsChange = (column: string, columnDetails: ToolbarProps['columnsDetails']) => {
    /*
      columnDetails already have the right values to setColumnsDetails. But for
     some reason, this code just work if I do updatedColumnsDetails[column] = columnDetails.
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updatedColumnsDetails: any = { ...columnsDetails }
    updatedColumnsDetails[column] = columnDetails
    setColumnsDetails(updatedColumnsDetails)
  }

  const handleSortChange = (event: MouseEvent) => {
    const newSortBy = event.currentTarget.getAttribute('data-sortby') || ''

    const newSortDirection =
      newSortBy === sortBy
        ? sortDirection === SortDirection.DESCENDING
          ? SortDirection.ASCENDING
          : SortDirection.DESCENDING
        : SortDirection.DESCENDING

    setSortBy(newSortBy)
    setSortDirection(newSortDirection)
  }

  const handleViewTypeChange = (newView: 'SINGLE_CARD' | 'MULTI_CARDS' | 'TABLE') => {
    setNewView(newView)
  }

  const handleDeleteRow = async (data: any) => {
    const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

    const customAcessToken = accessToken.getAccessToken()
    console.log(customAcessToken)

    var head = {
      headers: {
        Authorization: `Bearer ${customAcessToken}`
      }
    }
    const res = await axios.delete(`${baseURL}${typeTableSelected}${data.id}`, head)
    console.log(res, 'RESPONSE QUANDO EDITAR ')
    Notification.success('Viagem excluida com sucesso. Atualizar a página.')
    window.location.reload()
  }

  const handleShowDetails = (data: any, type: string) => {
    setRouteContext({
      id: data.routeId,
      routeName: data.routeName,
      rangeToleranceLimit: data.rangeToleranceLimit
    })
    console.log(data, 'TENTEEEE')
    setCostsContext({
      tollValue: Number(data.tollValue),
      operativeCosts: Number(data.operativeCosts),
      fuelAverageCosts: Number(data.fuelAverageCosts),
      averageConsume: Number(data.averageConsume),
      totalCosts: Number(data.totalCosts),
      kmTotal: data?.responseHere?.routes[0]?.sections
        .map((item: any) => item.summary.length)
        .reduce((prev: number, next: number) => prev + next)
    })
    setVehicleVocacionalContext({
      type: data.type,
      comTotal: data.comTotal,
      height: data.height,
      width: data.width,
      maxWeight: data.maxWeight,
      maxWeightAxle: data.maxWeightAxle,
      numberAxle: data.numberAxle,
      trailerAxle: data.trailerAxle,
      pollutantClass: data.pollutantClass,
      dangerClassification: data.dangerClassification
    })
    setOriginRouteContext({
      address: data.originRouteData.addressStop,
      addressStop: data.originRouteData.addressStop,
      lat: data.originRouteData.lat,
      lng: data.originRouteData.lng
    })
    setAllStopsContext(data.stops)
    setDestinyRouteContext({
      address: data.destinyRouteData.addressStop,
      addressStop: data.destinyRouteData.addressStop,
      lat: data.destinyRouteData.lat,
      lng: data.destinyRouteData.lng
    })
    setRoadParametersContext(data.roadParameters)
    setResponseHereContext(data.responseHere)

    const body = { ...data, allStops: data.stops }
    if (type === 'linkVehicle') {
      handleLinkVehicle(body)
    } else if (typeTable === 'resume') {
      history.push({
        pathname: `/resume-edit`,
        state: { body }
      })
    } else if (type === 'duplicate') {
      history.push({
        pathname: `/routefence-pdis/duplicate`,
        state: 'duplicate'
      })
    } else {
      history.push({
        pathname: `/routefence-pdis/edit`,
        state: 'edit'
      })
    }
  }

  const handleCreateRoute = () => {
    history.push({
      pathname: `/routefence-pdis/create`
    })
  }

  useEffect(() => {
    onChangeSort(sortBy, sortDirection)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortBy, sortDirection])

  const renderTableCol = (column: string, columnDetails: { width: CSSProperties['width'] }) => (
    <col
      key={column}
      style={{
        minWidth: columnDetails?.width ? columnDetails?.width : 'auto',
        width: columnDetails?.width ? columnDetails?.width : 'auto'
      }}
    />
  )

  const renderTableHead = (column: string, label: string, sortBy: string, sortDirection: SortDirection) => (
    <th
      key={column}
      className='user-select-none sort-column'
      onClick={handleSortChange}
      data-field={column}
      data-sortby={column}
      title={label}>
      <span>
        {sortBy === column ? <SortArrows direction={sortDirection} /> : <SortArrows />}
        <span>{label}</span>
      </span>
    </th>
  )

  const renderTableRow = (
    row: Row,
    columns: string[],
    columnLabels: ToolbarProps['columnLabels'],
    sortDirection: any
  ) => (
    <tr key={row.index as string} data-key={row.index}>
      {columns.map(col => (
        <td key={col} data-field={intl.formatMessage({ id: col })}>
          {onLineClick && (lineClickName === col || lineClickName === 'allColumns') ? (
            <StyledButton onClick={() => onLineClick(row)}>{row[col]}</StyledButton>
          ) : (
            row[col]
          )}
        </td>
      ))}
      <td className='table-action'>
        <span>
          <SimpleButtonDropdown
            title={<span className='rioglyph rioglyph-option-vertical' />}
            bsStyle='link'
            iconOnly
            items={
              typeTable !== 'resume'
                ? [
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-pencil margin-right-10' />
                          <span>Editar</span>
                        </div>
                      ),
                      onSelect: value => handleShowDetails(row, 'edit')
                    },
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-duplicate margin-right-10' />
                          <span>Duplicar</span>
                        </div>
                      ),
                      onSelect: value => handleShowDetails(row, 'duplicate')
                    },
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-duplicate margin-right-10' />
                          <span>Vincular Veículo</span>
                        </div>
                      ),
                      onSelect: value => handleShowDetails(row, 'linkVehicle')
                    },
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-trash margin-right-10' />
                          <span>Deletar</span>
                        </div>
                      ),
                      onSelect: value => handleDeleteRow(row)
                    }
                  ]
                : [
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-pencil margin-right-10' />
                          <span>Editar</span>
                        </div>
                      ),
                      onSelect: value => handleShowDetails(row, 'edit')
                    },
                    {
                      value: (
                        <div>
                          <span className='rioglyph rioglyph-trash margin-right-10' />
                          <span>Deletar</span>
                        </div>
                      ),
                      onSelect: value => handleDeleteRow(row)
                    }
                  ]
            }
          />
        </span>
      </td>
    </tr>
  )

  const renderTableSkeletonRows = () =>
    [...Array(rowsCount)].map(rowNumber => (
      <tr key={rowNumber}>
        {[...Array(columns.length)].map(columnNumber => (
          <td key={columnNumber}>
            <ContentLoader width='50%' height='13px' style={{ borderRadius: '3px' }}>
              <rect width='100%' height='100%' />
            </ContentLoader>
          </td>
        ))}
      </tr>
    ))

  const newNameToButton = (
    <div>
      <span className={'rioglyph rioglyph-plus'} />
      <span> Novo</span>
    </div>
  )

  return (
    <div className={`table-wrapper`}>
      {typeTable === 'routefence-pdis' ? (
        <div className='table-toolbar-column' style={{ marginBottom: -35 }}>
          <SimpleButtonDropdown
            title={newNameToButton}
            bsStyle='primary'
            items={[
              {
                value: (
                  <div>
                    <span className='rioglyph rioglyph-pencil margin-right-10' />
                    <Link to={'/routefence-pdis/create'}>Nova Rota</Link>
                  </div>
                ),
                onSelect: value => handleCreateRoute()
              }
            ]}
          />
        </div>
      ) : (
        <div></div>
      )}

      <Toolbar
        valueOdometer={valueOdometer}
        columnOrder={columnOrder}
        hiddenColumns={hiddenColumns}
        columnsDetails={columnsDetails}
        disabledColumns={disabledColumns}
        columnLabels={columnLabels}
        defaultColumnOrder={defaultColumnOrder}
        search={search}
        searchLabel={searchLabel}
        settingsCloseButtonText={settingsCloseButtonText}
        settingsNotFoundMessage={settingsNotFoundMessage}
        settingsSearchPlaceholder={settingsSearchPlaceholder}
        settingsResetButtonText={settingsResetButtonText}
        settingsTitle={settingsTitle}
        onColumnDetailsChange={handleColumnDetailsChange}
        onColumnChange={handleColumnChange}
        onChangeSearch={onChangeSearch}
        onDownloadClick={onDownloadClick}
        onViewTypeChange={handleViewTypeChange}
        onChange={onChange}
        resetCalc={resetCalc}
        handleChangeOdometer={handleChangeOdometer}
        showResumeButton={showResumeButton}
      />
      {typeTable === 'resume' ? <Menus handleMenu={handleMenu} /> : ''}
      <Placeholder
        status={status}
        isEmpty={rowsPagineted && rowsPagineted.length && !rowsPagineted[0].length}
        contentsName='dados'>
        <TableStyled
          className={`table table-bordered table-hover table-layout-fixed table-column-overflow-hidden table-bordered table-sticky table-head-filled
          ${viewType === 'SINGLE_CARD' ? 'table-cards table-single-card' : ''}
          ${viewType === 'MULTI_CARDS' ? 'table-cards table-multi-cards' : ''}`}>
          <colgroup>{columns.map(column => renderTableCol(column, columnsDetails[column]))}</colgroup>
          <thead>
            <tr>
              <>
                {columns.map(column => (
                  <Fragment key={column}>
                    {renderTableHead(column, columnLabels[column] as string, sortBy, sortDirection)}
                  </Fragment>
                ))}
                <th>
                  <span></span>
                </th>
              </>
            </tr>
          </thead>
          <tbody>
            {rowsPagineted && rowsPagineted[0] && rowsPagineted[0].length
              ? rowsPagineted.map(rows =>
                  rows.map(row => (
                    <Fragment key={row.index as string}>
                      {renderTableRow(row, columns, columnLabels, sortDirection)}
                    </Fragment>
                  ))
                )
              : renderTableSkeletonRows()}
          </tbody>
        </TableStyled>
      </Placeholder>
    </div>
  )
}

export default injectIntl(Table)
