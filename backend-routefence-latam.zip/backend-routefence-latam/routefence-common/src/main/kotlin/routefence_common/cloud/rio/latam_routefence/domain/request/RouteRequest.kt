package routefence_common.cloud.rio.latam_routefence.domain.request

import routefence_common.cloud.rio.latam_routefence.domain.response.routing.ResponseHere
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.bo.BoundingBoxBO

data class RouteRequest (
    var id: String? = null,
    var accountId: String? = null,
    var routeName: String? = null,
    var originRoute: GeoPointRequest? = null,
    var destinyRoute: GeoPointRequest? = null,
    var stops: Collection<StopRequest>? = null,
    var rangeToleranceLimit: Int,
    var roadParameters: RangeRequest? = null,
    var vehicleVocationalInfo: VehicleVocationalInfoRequest? = null,
    var costs: CostsRequest? = null,
    val tripToEdit: TripRequest?,
    val avoidArea: List<BoundingBoxBO>?,

    @JsonProperty("linkedVehicles")
    var trips: Collection<TripRequest>? = null,

    var responseHere: ResponseHere? = null
)
