package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.repositories.AssetCourseRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity

@Service
@Transactional
class AssetCourseService(
    private val assetCourseRepository: AssetCourseRepository
) {
    fun save(assetCourseEntity: AssetCourseEntity): AssetCourseEntity {
        return assetCourseRepository.save(assetCourseEntity)
    }

    @Transactional(readOnly = true)
    fun findByTripId(tripId: String): Collection<AssetCourseEntity> {
        val assetCourseList = assetCourseRepository.getAssetCourseByTrip(tripId)
        if (assetCourseList.isNullOrEmpty())
            throw RoutefenceException.RoutefenceNotFoundException("Asset.course.not.found", arrayOf(tripId))
        return assetCourseList
    }
}