package routefence_common.cloud.rio.latam_routefence.domain.enums

interface SortFieldsEnum {
    val entityEquivalent: String
    val name: String
}

enum class TripSortFields(override val entityEquivalent: String) : SortFieldsEnum {
    ROUTE_NAME("r.route_name"),
    STATUS("t.status"),
    START_DATETIME("t.start_datetime")
}