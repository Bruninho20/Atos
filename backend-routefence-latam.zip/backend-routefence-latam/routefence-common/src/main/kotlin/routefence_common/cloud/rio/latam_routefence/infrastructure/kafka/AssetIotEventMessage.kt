package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventPositionEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventStateEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventPairingEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.DriverInfoMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.DriverStateMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.EnumStringConsistencyDeserializer
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import org.springframework.format.annotation.DateTimeFormat
import java.time.OffsetDateTime
import java.util.*

data class AssetIotEventMessage(
    @JsonProperty("asset_id")
    val assetId: UUID,

    @JsonProperty("account_id")
    val accountId: String,

    @JsonProperty("device_id")
    val deviceId: UUID,

    @JsonProperty("device_type")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val deviceType: String?,

    @JsonProperty("driver_identification")
    val driverIdentification: String?,

    @JsonProperty("driver_identification_type")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val driverIdentificationType: String?,

    @JsonProperty("eid")
    val eid: String,

    @JsonProperty("occurred_at")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    val occurredAt: OffsetDateTime,

    @JsonProperty("trigger")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val trigger: String,


    @JsonProperty("position")
    val position: AssetPositionMessage? = null,
    @JsonProperty("state")
    val state: AssetStateMessage? = null,
    @JsonProperty("driver_info")
    val driverInfo: DriverInfoMessage? = null,
    @JsonProperty("driver_state")
    val driverState: DriverStateMessage? = null // enum mapping of nested value
) {
    fun mapToAssetIotPosition() = AssetIotEventPositionEntity(
        accountId = accountId,
        assetId = assetId.toString(),
        deviceId = deviceId.toString(),
        deviceType = deviceType,
        driverIdentification = driverIdentification,
        driverIdentificationType = driverIdentificationType,
        eid = eid,
        occurredAt =  occurredAt.toLocalDateTime(),
        trigger = trigger,
        latitude = position!!.latitude,
        longitude = position.longitude,
        altitude = position.altitude,
        accuracy =  position.accuracy,
        altitudeAccuracy = position.altitudeAccuracy,
        heading = position.heading,
        speed = position.speed
    )

    fun mapToAssetIotState() = AssetIotEventStateEntity(
        accountId = accountId,
        assetId = assetId.toString(),
        deviceId = deviceId.toString(),
        deviceType = deviceType,
        driverIdentification = driverIdentification,
        driverIdentificationType = driverIdentificationType,
        eid = eid,
        occurredAt = occurredAt.toLocalDateTime(),
        trigger = trigger,
        mileage = state!!.mileage,
        ignitionOn = state.ignitionOn,
        fuelLevel = state.fuelLevel,
        stateOfCharge = state.stateOfCharge,
        electricRange = state.electricRange,
        engineSpeed = state.engineSpeed,
        wheelSpeed = state.wheelSpeed,
        tachoSpeed = state.tachoSpeed,
        fuelConsumption = state.fuelConsumption,
        acceleratorPedal = state.acceleratorPedal,
        weightTotal = state.weightTotal,
        ptoInformation = state.ptoInformation,
        electronicRetarderState = state.electronicRetarderState,
        driveState = state.driveState,
        fuelRate = state.fuelRate,
        instantaneousFuelEconomy = state.instantaneousFuelEconomy,
        engineOperationTime = state.engineOperationTime
    )

    fun mapToAssetIotPairing() = AssetIotEventPairingEntity(
        accountId = accountId,
        assetId = assetId.toString(),
        deviceId = deviceId.toString(),
        deviceType = deviceType,
        driverIdentification = driverIdentification!!, //Only on this case, this information surely comes
        driverIdentificationType = driverIdentificationType,
        eid = eid,
        occurredAt = occurredAt.toLocalDateTime(),
        trigger = trigger,
        processed = false
    )
}
