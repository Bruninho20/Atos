package listener.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity

fun TripEntity.mapToBusinessObject(): TripBO {
    return TripBO(
        id = this.id!!,
        status = this.status,
        driverId = this.driverId,
        assetId = this.assetId,
        routeId = this.route.id,
        hasStop = this.route.stops?.isNotEmpty() ?: false
    )
}