package routefence_common.cloud.rio.latam_routefence.domain.response

data class LocationData(
    val lat: String,
    val long: String,
    val occurredAt: String
)

data class HistoryResponse(
    val routeId: String,
    val routeName: String,
    val tripId: String,
    val startedAt: String,
    val finishedAt: String?,
    val driverId: String?,
    val locationData: List<LocationData>,
    val duration: String?
)