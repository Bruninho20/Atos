package routefence_common.cloud.rio.latam_routefence.domain.response

import routefence_common.cloud.rio.latam_routefence.domain.response.routing.ResponseHere
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.bo.BoundingBoxBO

data class RouteResponse (
    var id: String? = null,

    @JsonProperty("date")
    var creationDate: String? = null,
    var deletionDate: String? = null,
    var status:Boolean,
    var idLayer: String? = null,
    var accountId: String? = null,
    var routeName: String? = null,
    var originRoute: GeoPointResponse? = null,
    var destinyRoute: GeoPointResponse? = null,
    var rangeToleranceLimit: String? = null,
    var stops: Collection<RouteStopResponse>? = null,
    var roadParameters: RangeResponse? = null,
    var vehicleVocationalInfo: VehicleVocationalInfoResponse? = null,
    var costs: CostsResponse? = null,
    val avoidArea: List<BoundingBoxBO>?,
    val responseHere: ResponseHere?
)