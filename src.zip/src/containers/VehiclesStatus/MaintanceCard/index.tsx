import React, { FC } from 'react'
import { FormattedMessage } from 'react-intl'
import useSWR from 'swr'
import { isEmpty } from 'lodash'

import { fetcherPost } from 'core/utils/fetch'

import { CardFilter, FilterType } from '..'

import { CardOneScore, Placeholder } from 'components'
import { PlaceholderProps } from 'components/Placeholder'
import { ScoreTypes } from 'components/CardMultipleScores'

export type ScoreObject = {
  id: string
  score: number
  type: ScoreTypes
}

interface OperativeCardData {
  link: string
  more: {
    description: string
    id: string
  }[]
  scores: ScoreObject[]
}

interface MaintanceCardProps {
  assetsId: string[]
  tagsId: string[]
  filter: FilterType
  onFilterClick: (filter: CardFilter) => void
}

const MaintanceCard: FC<MaintanceCardProps> = ({ assetsId, tagsId, filter, onFilterClick }) => {
  const { data, error, isValidating } = useSWR<OperativeCardData>(
    ['/api/perla-tests/vehicleStatus/vehicleStatus/maintenanceCard', assetsId, tagsId],
    url => fetcherPost(url, { assetIds: assetsId, tagIds: tagsId, vehicleOperationCondition: 'DEFAULT' })
  )

  const handleLinkClick = (id: string) => {
    onFilterClick({
      card: 'maintance',
      filter: id
    })
  }

  const isEmptyData = isEmpty(data)

  return (
    <div style={{ minHeight: '215px', width: '100%', marginLeft: '15px' }}>
      <Placeholder
        short
        contentsName={<FormattedMessage id='vehiclesStatus.maintance.placeholder.contentsName' />}
        isEmpty={isEmptyData && !isValidating}
        status={error ? 'error' : ('success' as PlaceholderProps['status'])}>
        <>
          <CardOneScore
            title={<FormattedMessage id='vehiclesStatus.maintance.card.title' />}
            loading={isEmptyData}
            description={<FormattedMessage id='vehiclesStatus.maintance.card.description' />}
            score={!isEmptyData ? data?.scores[0] : undefined}
            descriptionScore={!isEmptyData ? data?.scores[1] : undefined}
            descriptionScoreUnit={<FormattedMessage id='vehiclesStatus.maintance.card.scoreUnit' />}
            footerTitle={<FormattedMessage id='vehiclesStatus.maintance.card.footer' />}
            hasFooterClick={true}
            footerClicked={filter === 'maintance'}
            onFooterClick={() => handleLinkClick(data?.link || '')}

          />
        </>
      </Placeholder>
    </div>
  )
}

export default MaintanceCard
