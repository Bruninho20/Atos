import styled from 'styled-components';

import { Layout } from 'components';

export const DashboardWrapper = styled(Layout.Content)``;
