package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class TollStructure(
    @JsonProperty("conditionId") var conditionId: Int?,
    @JsonProperty("languageCode") var languageCode: String?,
    @JsonProperty("latitude") var latitude: Double?,
    @JsonProperty("linkIds") var linkIds: Collection<Int>?,
    @JsonProperty("longitude") var longitude: Double?,
    @JsonProperty("name") var name: String?,
    @JsonProperty("topologySegmentIds") var topologySegmentIds: Collection<Int>?
)
