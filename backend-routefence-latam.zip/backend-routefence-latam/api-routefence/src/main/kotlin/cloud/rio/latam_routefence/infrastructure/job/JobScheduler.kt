package cloud.rio.latam_routefence.infrastructure.job

import org.springframework.beans.factory.annotation.Value
import org.springframework.context.ApplicationContext
import org.springframework.scheduling.TaskScheduler
import org.springframework.scheduling.support.CronTrigger
import org.springframework.stereotype.Component
import java.util.*
import javax.annotation.PostConstruct

@Component
class JobScheduler constructor(
    private val taskScheduler: TaskScheduler,
    private val appContext: ApplicationContext
) {
    @Value("\${job.cron.every-minute}")
    private lateinit var everyMinute: String

    @PostConstruct
    fun schedule() {
        val utcEveryMinuteCron = CronTrigger(everyMinute, TimeZone.getTimeZone("UTC"))
        taskScheduler.schedule(appContext.getBean(CreateLinkToSendPairingSchedulingJob::class.java), utcEveryMinuteCron)
        taskScheduler.schedule(appContext.getBean(SendLinkPairingJob::class.java), utcEveryMinuteCron)
    }
}