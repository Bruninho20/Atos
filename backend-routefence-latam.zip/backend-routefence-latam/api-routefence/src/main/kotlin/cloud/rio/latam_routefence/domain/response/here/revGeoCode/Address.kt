package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class Address(
    val label: String?,
    val countryCode: String?,
    val countryName: String?,
    val stateCode: String?,
    val state: String?,
    val countyCode: String?,
    val county: String?,
    val city: String?,
    val district: String?,
    val subdistrict: String?,
    val street: String?,
    val block: String?,
    val subblock: String?,
    val postalCode: String?,
    val houseNumber: String?,
    val building: String?
)
