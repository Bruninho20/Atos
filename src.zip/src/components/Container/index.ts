import styled, { css } from 'styled-components'

import { colors } from 'core/assets/styles'

const getStyles = ({
  alignItems = 'stretch',
  direction = 'row',
  flex = '0 1 auto',
  justify = 'flex-start',
  minHeight = '1px',
  overflow = 'visible',
  padding = '0',
  width = 'auto'
}) => css`
  align-items: ${alignItems};
  background: ${colors.white};
  flex: ${flex};
  flex-direction: ${direction};
  height: 100%;
  justify-content: ${justify};
  min-height: ${minHeight};
  overflow: ${overflow};
  padding: ${padding};
  position: relative;
  width: ${width};
`

const ContainerStyled = styled.div`
  display: flex;

  ${getStyles}
`

export default ContainerStyled
