package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.RouteApi
import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import cloud.rio.latam_routefence.services.AssetIotEventService
import cloud.rio.latam_routefence.services.RouteService
import org.springframework.web.bind.annotation.RestController
import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

@RestController
class RouteController(private val routeService: RouteService): RouteApi {

    override fun saveRoute(route: RouteRequest): RouteResponse {
        val routeCreated = routeService.save(route)
        return routeCreated.mapToResponse()
    }

    override fun getOneRoute(id: String): RouteResponse {
        return routeService.findById(id).mapToResponse()
    }

    override fun getAll(
        page: Int,
        pageSize: Int,
        orderBy: String,
        routeName:String?
    ): BaseCollectionResponse<RouteResponse> {
        val routes = routeService.findAll(page, pageSize, orderBy,routeName).map { it.mapToResponse() }
        return BaseCollectionResponse(routes, routes.size)
    }

    override fun updateRoute(id: String, routeRequest: RouteRequest): RouteResponse{
        val routeEdited = routeService.update(id, routeRequest)
        return routeEdited.mapToResponse()
    }

    override fun delete(id: String){
         return routeService.delete(id)
    }
}
