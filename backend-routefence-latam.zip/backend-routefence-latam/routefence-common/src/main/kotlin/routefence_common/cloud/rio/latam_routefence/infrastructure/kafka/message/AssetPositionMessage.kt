package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message

import com.fasterxml.jackson.annotation.JsonProperty

data class AssetPositionMessage(
    @JsonProperty("latitude")
    val latitude: Double,
    @JsonProperty("longitude")
    val longitude: Double,
    @JsonProperty("altitude")
    val altitude: Double?,
    @JsonProperty("accuracy")
    val accuracy: Double?,
    @JsonProperty("altitude_accuracy")
    val altitudeAccuracy: Double?,
    @JsonProperty("heading")
    val heading: Double?,
    @JsonProperty("speed")
    val speed: Double?
)