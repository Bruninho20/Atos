import styled from 'styled-components';
import { colors } from 'core/assets/styles';

export const CarouselWrapper = styled.div`
  display: flex;
  justify-content: center;
  position: block;
  transition: all 0.3s;
  width: 100%;

  &:hover {
    .arrowLeft,
    .arrowRight {
      opacity: 0.3;

      &:hover {
        opacity: 1;
      }
    }
  }

  .arrowLeft {
    left: 0;
  }
  .arrowRight {
    right: 0;
  }
`;

export const StyledCarousel = styled.div`
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
  padding-bottom: 12px;
  position: relative;

  section {
    flex: 0 0 auto;
    margin-right: 10px;
  }
`;

export const StyledButton = styled.button`
  background: transparent;
  border: 0;
  color: ${colors.black};
  cursor: pointer;
  opacity: 0;
  position: absolute;
  top: 50%;

  transform: translateY(-50%);
  transition: all 0.3s;
  width: 50px;
`;
