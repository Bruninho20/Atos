package listener.cloud.rio.latam_routefence.services

import listener.cloud.rio.latam_routefence.infrastructure.repositories.TripRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import java.time.LocalDateTime

@Service
@Transactional
class TripService(
    private val tripRepository: TripRepository
) {
    fun getActiveTrips(assetId: String): Collection<TripEntity> {
        return tripRepository.getActiveTrips(assetId)
    }

    fun finishedTrip( tripId: String){
        val trip = tripRepository.getTripById(tripId).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(tripId))
        }
        trip.finishedAt = LocalDateTime.now()
        trip.status = TripStatusEnum.FINISHED

       tripRepository.save(trip)
    }

    fun startedTrip( tripId: String){

        val trips = tripRepository.getTripById(tripId).orElseThrow {
            throw RoutefenceException.RoutefenceNotFoundException("Trip.not.found", arrayOf(tripId))
        }

        trips.startedAt = LocalDateTime.now()
        trips.status = TripStatusEnum.STARTED

        tripRepository.save(trips)
    }
}
