package cloud.rio.latam_routefence.infrastructure.repositories

import cloud.rio.latam_routefence.domain.response.LiveStateResponse
import cloud.rio.latam_routefence.domain.response.PositionResponse
import cloud.rio.latam_routefence.domain.response.VehicleInfoResponse
import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query

@Repository
class AssetIotEventPositionRepositoryImpl : AssetIotEventPositionCustomRepository {

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun getLiveSate(assetsIds: HashMap<String, AssetDTO>): List<LiveStateResponse> {

        val query = StringBuilder()
        query.append("select\n");
        query.append("      ac.id,\n");
        query.append("      ac.occurred_at,\n");
        query.append("      tt.asset_id,\n");
        query.append("      ac.latitude,\n");
        query.append("      ac.longitude,\n");
        query.append("      ac.latitude as altitude,\n");
        query.append("      ac.latitude as accuracy,\n");
        query.append("      ac.latitude as altitude_accuracy,\n");
        query.append("      ac.heading,\n");
        query.append("      ac.speed_kmh as speed,\n");
        query.append("      ac.mileage as mileage\n");
        query.append("  from tb_asset_course ac\n");
        query.append(" inner join tb_trip tt on ac.trip_id = tt.id\n");
        query.append(" where ac.occurred_at = (\n");
        query.append("                          select MAX(ac_1.occurred_at)\n");
        query.append("                            from tb_asset_course ac_1\n");
        query.append("                           inner join tb_trip tr on ac_1.trip_id = tr.id\n");
        query.append("                           where tr.asset_id = tt.asset_id\n");
        query.append("                             and tr.status = tt.status\n");
        query.append("                             and tr.asset_id = tt.asset_id\n");
        query.append("                             and ac_1.occurred_at >= tr.created_at)\n");
        query.append("   and tt.account_id = :accountId\n");
        query.append("   and tt.status = :state\n");
        query.append("   and ac.account_id = tt.account_id \n");
        query.append("   and ac.occurred_at >= tt.created_at\n");

        if (assetsIds.isNotEmpty()){
            query.append("     and tt.asset_id in(:assetIds)\n")
        }

        val queryManager = entityManager.createNativeQuery(query.toString())
        setQueryParameters(queryManager, assetsIds)

        return getResultList(queryManager, assetsIds)
    }

    private fun getResultList(query: Query, assetsIds: HashMap<String, AssetDTO>): List<LiveStateResponse> {

        val response: MutableList<LiveStateResponse> = mutableListOf()

        query.resultList.forEach {
            val objArray = it as Array<*>
            val vehicle = assetsIds[objArray[2].toString()]

            response.add(
                LiveStateResponse(
                    id = objArray[0].toString(),
                    occurredAt = objArray[1].toString(),
                    assetId = objArray[2].toString(),
                    position = PositionResponse(
                        latitude = objArray[3] as Double,
                        longitude = objArray[4] as Double,
                        altitude = objArray[5].toString().toDouble(),
                        accuracy = objArray[6]as Double?,
                        altitudeAccuracy = objArray[7] as Double?,
                        heading = objArray[8] as Double?,
                        speed = objArray[9] as Double?,
                        mileage = objArray[9] as Double?
                    ),
                    vehicle = VehicleInfoResponse(
                        vehicleId = objArray[2].toString(),
                        vehicle = vehicle?.name ?: vehicle?.identification ?: "unidentified",
                        identification = vehicle?.identification ?: "unidentified",
                        identificationType = vehicle?.identification_type ?: "unidentified",
                        brand = vehicle?.brand ?: "unidentified",
                        type = vehicle?.type ?: "unidentified",
                    )
                )
            )
        }

        return response
    }

    private fun setQueryParameters(query: Query, assetsIds: HashMap<String, AssetDTO>) {
        if(assetsIds.isNotEmpty()) {
            query.setParameter("assetIds", assetsIds.keys)
        }

        query.setParameter("state", "STARTED")
        query.setParameter("accountId", AccountContext.get())
    }
}