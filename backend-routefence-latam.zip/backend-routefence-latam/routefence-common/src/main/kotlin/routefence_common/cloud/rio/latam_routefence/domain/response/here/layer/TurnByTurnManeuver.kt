package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.ManeuverPosition

@JsonIgnoreProperties(ignoreUnknown = true)
data class TurnByTurnManeuver(
    @JsonProperty("action") var action: String?,
    @JsonProperty("direction") var direction: String?,
    @JsonProperty("distanceToNextManeuver") var distanceToNextManeuver: Int?,
    @JsonProperty("firstPoint") var firstPoint: Int?,
    @JsonProperty("id") var id: String?,
    @JsonProperty("instruction") var instruction: String?,
    @JsonProperty("instructionAfter") var instructionAfter: String?,
    @JsonProperty("instructionBefore") var instructionBefore: String?,
    @JsonProperty("lanes") var lanes: String?,
    @JsonProperty("lastPoint") var lastPoint: Int?,
    @JsonProperty("length") var length: Int?,
    @JsonProperty("nextRoadName") var nextRoadName: Collection<RoadName>?,
    @JsonProperty("orientation") var orientation: String?,
    @JsonProperty("position") var position: ManeuverPosition?,
    @JsonProperty("roadName") var roadName: Collection<RoadName>?,
    @JsonProperty("routeLinkIndex") var routeLinkIndex: Int?,
    @JsonProperty("travelTime") var travelTime: Int?
)