/* eslint-disable jsx-a11y/label-has-associated-control */
import React, { FC, useEffect, useState } from 'react'
import moment, { Moment } from 'moment'

import { DateRangePicker } from 'rio-uikit'

import { Onboarding } from 'components'

import { DateFormGroup } from './styled'

export interface Period {
  from: string
  to: string
}

interface DateTimeFilterProps {
  label: string | React.ReactElement
  locale: string
  textApply: string | React.ReactElement
  textCancel: string | React.ReactElement
  textCustom: string | React.ReactElement
  textLastMonth: string | React.ReactElement
  textLastWeek: string | React.ReactElement
  textToday: string | React.ReactElement
  onBoarding: { title: string; content: string }
  minDate?: any,
  onChangeDate: (date: Period) => void
}

const DateTimeFilter: FC<DateTimeFilterProps> = ({
  label,
  minDate,
  locale,
  textToday,
  textLastWeek,
  textLastMonth,
  textCustom,
  textApply,
  textCancel,
  onBoarding: { title, content },
  onChangeDate
}) => {
  const [showTip, setShowTip] = useState(true)
  const [startDay, setStartDay] = useState<Moment>(moment().startOf('day'))
  const [endDay, setEndDay] = useState<Moment>(moment().endOf('day'))

  useEffect(() => {
    onChangeDate({
      from: moment(startDay).format('YYYY-MM-DD[T]HH:mm:ss.SSSZ'),
      to: moment(endDay).format('YYYY-MM-DD[T]HH:mm:ss.SSSZ')
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startDay, endDay])

  const handleRange = (startValue: Moment, endValue: Moment) => {
    handleTip()
    setStartDay(startValue)
    setEndDay(endValue)
  }

  const handleTip = () => {
    setShowTip(false)
  }

  return (
    <DateFormGroup>
      <label htmlFor='date-range-picker'>{label}</label>
      <Onboarding
        showTip={showTip}
        title={title}
        content={content}
        onChangeShowTip={handleTip}
        storageTip='PERIOD_TIPS'>
        <DateRangePicker
          minValue={minDate}
          locale={locale}
          textToday={textToday}
          textLastWeek={textLastWeek}
          textLastMonth={textLastMonth}
          textCustom={textCustom}
          textApply={textApply}
          textCancel={textCancel}
          hasTimePicker
          startValue={startDay}
          endValue={endDay}
          maxValue={moment().endOf('day')}
          onRangeChange={handleRange}
        />
      </Onboarding>
    </DateFormGroup>
  )
}

export default DateTimeFilter
