package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.services.InfringementService
import org.springframework.web.bind.annotation.*
import routefence_common.cloud.rio.latam_routefence.domain.response.InfringementResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

@RequestMapping("/infringements")
@RestController
class InfringementController(private val infringementService: InfringementService) {

    @GetMapping("/{tripId}")
    fun findByTrip(
        @PathVariable tripId: String,
        @RequestParam("startDateTime") startDateTime: String?,
        @RequestParam("endDateTime") endDateTime: String?
    ): List<InfringementResponse>
    {
        return infringementService.findByTrip(tripId, startDateTime, endDateTime).map{it.mapToResponse()}
    }

    @GetMapping("/count/{tripId}")
    fun getUnseenInfringementsCount(@PathVariable tripId: String): Int{
        return infringementService.getUnseenInfringementsCount(tripId)
    }

    @GetMapping("/unviewed/{tripId}")
    fun getUnseenInfringementsList(@PathVariable tripId: String): List<InfringementResponse>{
        return infringementService.getUnseenInfringementsList(tripId).map { it.mapToResponse() }
    }

    @PostMapping("/viewed/{tripId}")
    fun markUnseenInfringementsAsViewed(@PathVariable tripId: String){
        return infringementService.markUnseenInfringementsAsViewed(tripId)
    }
}