package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Route(
    @JsonProperty("id") val id: String,
    @JsonProperty("sections") val sections: List<Section>,
    @JsonProperty("routeHandle") val routeHandle: String
)
