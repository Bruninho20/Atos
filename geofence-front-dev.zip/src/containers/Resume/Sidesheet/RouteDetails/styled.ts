import styled from 'styled-components'

export const Container = styled.div`
  padding: 30px;
`

export const Card = styled.div``
