package listener.cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripStopEntity
import java.util.*

interface TripStopRepository : JpaRepository<TripStopEntity, String> {
    @Query(
        "SELECT * FROM tb_stop_check ts WHERE ts.route_has_stop_id = :routeStop AND ts.trip_id = :trip",
        nativeQuery = true
    )
    fun getByRouteStopAndTrip(@Param("routeStop") routeStopId: String, @Param("trip") tripId: String): TripStopEntity?


    @Query(
        "SELECT * FROM tb_stop_check ts WHERE ts.trip_id = :tripId AND ts.check_in IS NOT NULL AND ts.check_out IS NULL",
        nativeQuery = true
    )
    fun getByTripIdAndCheckInAndCheckOut(tripId: String): TripStopEntity?
}