import styled, { css } from 'styled-components'

import colors from 'core/assets/styles/colors'

import Button from 'components/Button'

export const StyledButton = styled(Button)`
  border-color: transparent;

  &:focus {
    background-color: transparent;
    border-color: transparent;
    span {
      color: ${colors.primaryDark};
    }
  }

  &:hover {
    background-color: transparent;
    border-color: transparent;
    span {
      color: ${colors.primaryDark};
    }
  }
`

export const ButonMoreList = styled.ul<{ open: boolean }>`
  background-color: white;
  border: 1px solid ${colors.borderDefault};
  border-radius: 3px;
  padding: 15px 0;
  position: absolute;
  z-index: 999;

  ${({ open }) =>
    open
      ? css`
          display: block;
        `
      : css`
          display: none;
        `}

  li {
    align-items: center;
    display: flex;
    font-size: 1.7rem;
    justify-content: space-between;
    padding: 5px 20px;
    width: 225px;
  }
`
