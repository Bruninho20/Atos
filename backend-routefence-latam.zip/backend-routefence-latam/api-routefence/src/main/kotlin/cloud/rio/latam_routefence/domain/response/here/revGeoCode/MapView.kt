package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class MapView(
    val west: Long?,
    val south: Long?,
    val east: Long?,
    val north: Long?
)
