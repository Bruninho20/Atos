package cloud.rio.latam_routefence.infrastructure.repositories

import cloud.rio.latam_routefence.domain.response.PositionDestinyResumeResponse
import cloud.rio.latam_routefence.domain.response.PositionOriginResumeResponse
import cloud.rio.latam_routefence.domain.response.RouteResumeResponse
import cloud.rio.latam_routefence.domain.response.TripResumeResponse
import cloud.rio.latam_routefence.services.AssetService
import cloud.rio.latam_routefence.services.DriverService
import cloud.rio.latam_routefence.utils.PageableUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.*
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query


@Repository
class TripCustomRepositoryImpl : TripCustomRepository {
    @Autowired
    lateinit var driverService:DriverService
    @Autowired
    lateinit var assetService: AssetService

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun listResume(search: String?, status: TripStatusEnum?, pageable: Pageable): List<TripResumeResponse> {

        val sql = StringBuilder()

        sql.append(
            """         
            SELECT
            	r.id as route_id,
            	r.route_name,	
            	t.id as trip_id,
            	t.status,
            	t.start_datetime,	
            	t.driver_id,
            	t.asset_id,            	
            	t.started_at,
            	t.finished_at,
            
            	gpo.lat as originLat,
                gpo.long as originLong,
                gpo.address_id as gpoAddressId,
                tao.city as taoCity,
                tao.country_code as taoCountryCode,
                tao.country_name as taoCountryName,
                tao.district as taoDistrict,
                tao.house_number as taoHouseNumber,
                tao.label as taoLabel,	
                tao.postal_code as taoPostalCode,
                tao.state as taoState,
                tao.state_code as taoStateCode,
                tao.street as taoStreet, 
                
            	gpd.lat as destinyLat,
                gpd.long as destinyLong,
                gpd.address_id as gpdAddressId,
                tad.city as tadCity,
                tad.country_code as tadCountryCode,
                tad.country_name as tadCountryName,
                tad.district as tadDistrict,
                tad.house_number as tadHouseNumber,
                tad.label as tadLabel,	
                tad.postal_code as tadPostalCode,
                tad.state as tadState,
                tad.state_code as tadStateCode,
                tad.street as tadStreet            
            
            FROM
            	tb_route r
            JOIN tb_trip t ON
            	t.route_id = r.id
            	
            JOIN tb_geopoints gpo ON
            	gpo.id = r.geo_point_origin_id
            left join tb_addresses tao on
	            gpo.address_id = tao.id
            
            JOIN tb_geopoints gpd ON
            	gpd.id = r.geo_point_destiny_id 
            left join tb_addresses tad on
	            gpd.address_id = tad.id           
             
            WHERE 
                r.account_id = :accountId 
                and (t.status <> 'DELETED' and t.deleted_at is null)
            """
        )

        addFilter(sql, status, search)
        PageableUtils.addPageable(pageable, sql)

        val query = entityManager.createNativeQuery(sql.toString())

        setQueryParameters(query, status, search)
        PageableUtils.setQueryParametersPageable(query, pageable)

        return getResultList(query)
    }

    private fun getResultList(query: Query): MutableList<TripResumeResponse> {
        val tripResume: MutableList<TripResumeResponse> = mutableListOf()

        query.resultList.forEach {
            val objArray = it as Array<*>

            tripResume.add(
                TripResumeResponse(
                    tripId = objArray[2].toString(),
                    status = TripStatusEnum.valueOf(objArray[3].toString()),
                    startDateTime = objArray[4].toString(),
                    driver = driverService.getById( driverId = objArray[5].toString()),
                    asset = assetService.get( id = objArray[6].toString()),
                    startedAt = objArray[7].toString(),
                    finishedAt = objArray[8].toString(),
                    route = RouteResumeResponse(
                        routeId = objArray[0].toString(),
                        routeName = objArray[1].toString()
                    ) ,
                    positionOrigin = PositionOriginResumeResponse(
                        lat = objArray[9] as Float,
                        long = objArray[10] as Float,
                        address = AddressResponse(
                            id = objArray[11].toString(),
                            city = objArray[12].toString(),
                            countryCode = objArray[13].toString(),
                            countryName = objArray[14].toString(),
                            district = objArray[15].toString(),
                            houseNumber = objArray[16].toString(),
                            label = objArray[17].toString(),
                            postalCode = objArray[18].toString(),
                            state = objArray[19].toString(),
                            stateCode = objArray[20].toString(),
                            street = objArray[21].toString()
                        )
                    ),
                    positionDestiny = PositionDestinyResumeResponse(
                        lat = objArray[22] as Float,
                        long = objArray[23] as Float,
                        address = AddressResponse(
                            id = objArray[24].toString(),
                            city = objArray[25].toString(),
                            countryCode = objArray[26].toString(),
                            countryName = objArray[27].toString(),
                            district = objArray[28].toString(),
                            houseNumber = objArray[29].toString(),
                            label = objArray[30].toString(),
                            postalCode = objArray[31].toString(),
                            state = objArray[32].toString(),
                            stateCode = objArray[33].toString(),
                            street = objArray[34].toString()
                        )
                    )
                )
            )
        }

        return tripResume
    }
    private fun addFilter(sql: StringBuilder, status: TripStatusEnum?, search: String?) {
        if (status != null)
            sql.append("AND t.status = :status ")

        if (!search.isNullOrEmpty())
            sql.append("AND r.route_name ILIKE :search ")
    }

    private fun setQueryParameters(query: Query, status: TripStatusEnum?, search: String?) {
        query.setParameter("accountId", AccountContext.get())

        if (status != null)
            query.setParameter("status", status.toString())

        if (!search.isNullOrEmpty())
            query.setParameter("search", "%$search%")
    }

    override fun listResumeReport(
        tripId: String,
        search: String?,
        status: TripStatusEnum?,
        pageable: Pageable
    ): List<TripResumeReportResponse> {

        val sql = StringBuilder()

        sql.append(
            """
               select
                   
                    ing.type,
                    ing.note,
                    ing.start_datetime,
                    ing.end_datetime,
                    tr.route_name
                from
                    TB_INFRINGEMENT ing
                inner join tb_trip t on
                    t.id = ing.trip_id
                inner join tb_route tr on
                    tr.id = t.route_id
                where
                    ing.trip_id = :tripId
                       
            """
        )

        val query = entityManager.createNativeQuery(sql.toString())

        setQueryParameterss(query, tripId)


        return getResultLists(query)
    }
    private fun getResultLists(query: Query): MutableList<TripResumeReportResponse> {
        val tripResume: MutableList<TripResumeReportResponse> = mutableListOf()
        query.resultList.forEach {
            val objArray = it as Array<*>

            tripResume.add(
                TripResumeReportResponse(

                    type = objArray[0].toString(),
                    note = objArray[1].toString(),
                    startDateTime = objArray[2].toString(),
                    endDateTime = objArray[3].toString(),
                    routeName = objArray[4].toString()
                )
            )
        }
        return tripResume
    }

    private fun setQueryParameterss(query: Query, id: String) {
        query.setParameter("tripId", id)
    }
}





