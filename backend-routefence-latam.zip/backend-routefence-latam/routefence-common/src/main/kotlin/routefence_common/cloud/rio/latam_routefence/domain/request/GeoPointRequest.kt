package routefence_common.cloud.rio.latam_routefence.domain.request

import com.fasterxml.jackson.annotation.JsonAlias
import com.fasterxml.jackson.annotation.JsonProperty

data class GeoPointRequest (
    var id: String? = null,
    var lat: Float? = 0F,
    var lng: Float? = 0F,

    @JsonProperty("addressStop")
    @JsonAlias("address")
    var address: routefence_common.cloud.rio.latam_routefence.domain.request.AddressRequest? = null
)

