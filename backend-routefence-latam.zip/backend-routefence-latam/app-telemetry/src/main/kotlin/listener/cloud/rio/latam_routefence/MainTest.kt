package listener.cloud.rio.latam_routefence

fun main(args: Array<String>) {
    Telemetry().initScan(args)
}