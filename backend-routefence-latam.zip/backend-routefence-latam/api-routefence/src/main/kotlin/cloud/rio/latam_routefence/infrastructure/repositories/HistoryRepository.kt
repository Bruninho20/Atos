package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AssetCourseEntity
import java.time.LocalDateTime

interface HistoryRepository : JpaRepository<AssetCourseEntity, String> {

    @Query("SELECT ac FROM AssetCourseEntity ac WHERE ac.trip.id = :tripId AND ac.occurredAt BETWEEN :startDateTime AND :endDateTime")
    fun findAssetByTripAndPeriod(
        @Param("tripId") tripId: String,
        @Param("startDateTime") startDateTime: LocalDateTime,
        @Param("endDateTime") endDateTime: LocalDateTime
    ): List<AssetCourseEntity>

    @Query("SELECT ac FROM AssetCourseEntity ac WHERE ac.trip.id= :tripId")
    fun findAssetByTrip(@Param("tripId") tripId: String): List<AssetCourseEntity>
}