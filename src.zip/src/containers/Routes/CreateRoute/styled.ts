import styled from 'styled-components'

export const Container = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
`

export const MapWrapper = styled.div`
  height: 100%;
  width: 77%;
`

export const SidesheetWrapper = styled.div`
  z-index: 99;
  height: 100%;
  width: 23%;
  border-color: black;
  border-width: 2px;
`
