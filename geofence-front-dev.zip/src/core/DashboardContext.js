import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

const DashboardContext = React.createContext();

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const DashboardProvider = ({ value, children }) => {
  const [loader, setLoader] = useState(false);
  const [assets, setAssets] = useState([]);
  const [avoidContext, setAvoidContext] = useState([])
  const [zoomMap, setZoomMap] = useState(10)
  const [centerMap, setCenterMap] = useState([
    {
      lat: -23.5475,
      lng: -46.63611
    }
  ])
  console.log(centerMap, 'centerMap centerMap centerMap ')
  const [originRouteContext, setOriginRouteContext] = useState({});
  const [routeContext, setRouteContext] = useState({
    routeName: '',
    rangeToleranceLimit: 0
  });
  const [roadParametersContext, setRoadParametersContext] = useState({
    trafficConditions: false,
    avoidToll: false,
    avoidRoad: false,
    ignoreTrafficRestrictions: false
  });
  const [destinyRouteContext, setDestinyRouteContext] = useState({});
  const [responseHereContext, setResponseHereContext] = useState({});
  const [originGeolocationContext, setOriginGeolocationContext] = useState({});
  const [costsContext, setCostsContext] = useState({
    tollValue: 0,
    operativeCosts: 0,
    fuelAverageCosts: 0,
    averageConsume: 0,
    totalCosts: 0,
    kmTotal: 0
  });
  const [vehicleVocacionalContext, setVehicleVocacionalContext] = useState({
    type: '',
    comTotal: '',
    height: '',
    width: '',
    maxWeight: '',
    maxWeightAxle: '',
    numberAxle: '',
    trailerAxle: '',
    pollutantClass: '',
    dangerClassification: ''
  });
  const [destinyGeolocationContext, setDestinyGeolocationContext] = useState({});
  const [mapSize, setMapSize] = useState('100%')
  const [avoidPointsContext, setAvoidPointsContext] = useState([{
    lat: -23.5475,
    lng: -46.63611
  }]);
  const [linkedVehiclesContext, setLinkedVehiclesContext] = useState([])
  const [allStopsContext, setAllStopsContext] = useState([])
  const [tags, setTags] = useState([]);
  const [totalSelected, setTotalSelected] = useState();
  const [disabledButtons, setDisabledButtons] = useState();
  const [sidesheetIsOpen, setSidesheetIsOpen] = useState(false)

  useEffect(() => {
    setTotalSelected(assets.length > 0 || tags.length > 0);
    setDisabledButtons(
      !(assets.length === 1 && tags.length === 0) &&
      !(tags.length === 1 && assets.length === 0)
    );
  }, [assets, tags]);

  return (
    <DashboardContext.Provider
      value={{
        loader,
        centerMap,
        setCenterMap,
        mapSize,
        setMapSize,
        zoomMap,
        setZoomMap,
        roadParametersContext,
        vehicleVocacionalContext,
        routeContext,
        setRouteContext,
        setVehicleVocacionalContext,
        costsContext,
        setCostsContext,
        setRoadParametersContext,
        originRouteContext,
        setOriginRouteContext,
        sidesheetIsOpen,
        setSidesheetIsOpen,
        responseHereContext,
        setResponseHereContext,
        avoidContext,
        setAvoidContext,
        avoidPointsContext,
        setAvoidPointsContext,
        linkedVehiclesContext,
        setLinkedVehiclesContext,
        originGeolocationContext,
        setOriginGeolocationContext,
        destinyGeolocationContext,
        setDestinyGeolocationContext,
        destinyRouteContext,
        setDestinyRouteContext,
        allStopsContext,
        setAllStopsContext,
        setLoader,
        assets,
        tags,
        setAssets,
        setTags,
        totalSelected,
        disabledButtons
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
};

DashboardProvider.propTypes = {
  children: PropTypes.node.isRequired,
  value: PropTypes.arrayOf([PropTypes.array, PropTypes.object]).isRequired
};

export default DashboardContext;
export { DashboardProvider };
