import React, { FC, useEffect, useState } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
// import useCustomSWRInfinite from 'core/utils/useCustomSWRInfinite'
// import useDebounce from 'core/utils/use-debounce'
import { AddVehicleDialog, Pagination, TableResume } from 'components'
import { SortDirection } from 'rio-uikit'
import { Row, Sort } from 'components/Table'
import { Period } from 'components/DateTimeFilter'
import ResumeSidesheet from './Sidesheet/index'

import { DashboardWrapper } from './styled'
import axios from 'axios'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import moment from 'moment'

export interface Points {
  start: {
    latitude: number
    longitude: number
  }
  end: {
    latitude: number
    longitude: number
  }
}

export interface FaultCodeModel {
  name: string
  date: string
  fmi: string
  fmiDescription: string
  lampStatus: string
  latitude: string
  longitude: string
  sourceAddress: string
  spn: string
  spnDescription: string
  description: string
  roles: string
  status: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
  stop: StopModel
  stopName: string
  stopCategory: string
  addressStop: string
  rangeLimitMeters: string
  category: string
  stayTime: string
  // }
  range: RangeModel
  trafficConditions: string
  avoidToll: string
  avoidRoad: string
  ignoreTrafficRestrictions: string
  // }
  vehicleVocationalInfo: VehicleModel
  type: string
  comTotal: string
  height: string
  width: string
  maxWeight: string
  maxWeightAxle: string
  numberAxle: string
  trailerAxle: string
  pollutantClass: string
  dangerClassification: string
  stops: any
  // }
  costs: CostsModel
  tollValue: string
  operativeCosts: string
  fuelAverageCosts: string
  averageConsume: string
  totalCosts: string
  responseHere: any
  // }
}

export interface Route {
  address: any
  id: string
  lat: string
  lng: string
  addressStop: any
}

export interface PdisDetailsModel {
  addressStop: any
  roles: string
  status: string
  date: string
  routeName: string
  originRoute: Route
  destinyRoute: Route
  rangeToleranceLimit: string
  stops: StopModel
  range: RangeModel
  vehicleVocationalInfo: VehicleModel
  costs: CostsModel
  linkedVehicles: any
  startDateTime: string
  rangeToleranceLimite: string
  responseHere: any
}

export interface RouteModel {
  status: string
  date: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
}

export interface StopModel {
  id: string
  position: any
  name: string
  category: any
  addressStop: any
  rangeLimitMeters: string
  stayTime: string
  order: number
}

export interface RangeModel {
  id: string
  trafficConditions: string
  avoidToll: string
  avoidRoad: string
  ignoreTrafficRestrictions: string
}

export interface VehicleModel {
  type: string
  comTotal: string
  height: string
  width: string
  maxWeight: string
  maxWeightAxle: string
  numberAxle: string
  trailerAxle: string
  pollutantClass: string
  dangerClassification: string
}

export interface CostsModel {
  tollValue: string
  operativeCosts: string
  fuelAverageCosts: string
  averageConsume: string
  totalCosts: string
}

export interface PdisModel {
  roles: string
  status: string
  date: string
  routeName: string
  originRoute: string
  destinyRoute: string
  rangeToleranceLimit: string
  stops: StopModel
  range: RangeModel
  vehicle: VehicleModel
  costs: CostsModel
}

interface PdisData extends Row {
  data: { data: PdisDetailsModel[] }
  total: number
}

interface FaultCodesProps {
  assetsId: string[]
  tagsId: string[]
  dateTime: Period
  intl: Intl
}

const Resume: FC<FaultCodesProps> = ({ intl }) => {
  const [faultCodesDetails, setFaultCodesDetails] = useState<{ isOpen: boolean; data?: FaultCodeModel }>({
    isOpen: false,
    data: undefined
  })
  const [sort, setSort] = useState({ sortBy: 'route_name', sortDirection: SortDirection.ASCENDING })
  const [data, setData] = useState<any>([])
  const [search, setSearch] = useState('')
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const pageSize = 50
  const [pageNo, setPageNo] = useState(0)
  const [statusCurrent, setStatusCurrent] = useState('')
  const [tripIdEdit, setTripIdEdit] = useState('')

  // const { data: faultCodes = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   'api/perla-tests/vehicleStatus/faultCodes',
  //   'POST',
  //   propsData,
  //   pageSize
  // )

  // const { data: pdisData = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<PdisData[]>(
  //   '/trips/',
  //   'GET',
  //   propsData,
  //   pageSize
  // )

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }

  const getTrips = async () => {
    // const baseURL = 'https://api.geo.latam-maintenance.rio.cloud/rio-routefence'

    if (statusCurrent === '') {
      const res = await axios.get(
        `${baseURL}/trips/resume?pageSize=${pageSize}&page=${pageNo}&orderBy=${sort.sortBy}`,
        head
      )

      setData([res])

      if (res?.status === 200 || res?.status === 201) {
        setData([res])
      } else {
        console.log('error')
      }
    } else {
      const res = await axios.get(
        `${baseURL}/trips/resume?pageSize=${pageSize}&page=${pageNo}&orderBy=${sort.sortBy}&status=${statusCurrent}`,
        head
      )

      if (res.status === 200 || res.status === 201) {
        setData([res])
      } else if (res.statusText !== 'OK') {
        console.log('vazio')
      } else {
        console.log('ERROOOOOOOOOOOOOO')
      }
    }
  }

  useEffect(() => {
    getTrips()
  }, [statusCurrent, pageNo])

  // const order = sort.sortBy ? `${sort.sortDirection === SortDirection.ASCENDING ? '' : '-'}${sort.sortBy}` : ''

  const handleChangeSort = async (sortBy: Sort['sortBy'], sortDirection: Sort['sortDirection']) => {
    console.log(sortDirection, 'sortDirection')
    if (sortDirection === 'desc') sortBy = `-${sortBy}`
    setSort({ sortBy, sortDirection })
    const res = await axios.get(`${baseURL}/trips/resume?pageSize=${pageSize}&page=${pageNo}&orderBy=${sortBy}`, head)

    setData([res])

    if (res?.status === 200 || res?.status === 201) {
      setData([res])
    } else {
      console.log('error')
    }
  }

  const handleSearch = async (search: string) => {
    setSearch(search)
    const res = await axios.get(
      `${baseURL}/trips/resume?pageSize=${pageSize}&page=${pageNo}&search=${search}&orderBy=${sort.sortBy}`,
      head
    )

    setData([res])

    if (res?.status === 200 || res?.status === 201) {
      setData([res])
    } else {
      console.log('error')
    }
  }

  const handleFetchMore = () => {
    setPageNo(pageNo + 1)
  }

  const handleLineClick = (data: FaultCodeModel) => {
    setFaultCodesDetails({
      isOpen: true,
      data
    })
  }

  const convertStatusRoute = (status: string): string => {
    switch (status) {
      case 'STARTED':
        return 'Em Andamento'
      case 'SCHEDULED':
        return 'Programada'
      case 'FINISHED':
        return 'Finalizada'
      default:
        return 'Programada'
    }
  }

  const rowsPagineted = data?.map((pdisDataPage: PdisData) => {
    return pdisDataPage
      ? pdisDataPage?.data?.data?.map((pdisDataRow: any, index: any) => {
          console.log(pdisDataRow, 'pdisDataRow na tabela')
          const correctlyDate =
            pdisDataRow?.status === 'SCHEDULED'
              ? moment(pdisDataRow.startDateTime).format('DD/MM/yyyy HH:mm')
              : moment(pdisDataRow.startedAt).format('DD/MM/yyyy HH:mm')
          return {
            ...pdisDataRow,
            index: index.toString(),
            startedAt: moment(pdisDataRow.startedAt).format('DD/MM/yyyy HH:mm'),
            startDateTime: pdisDataRow.startedAt,
            start_datetime: correctlyDate,
            originRoute:
              pdisDataRow?.positionOrigin?.address?.street === 'null'
                ? `${pdisDataRow?.positionOrigin.lat}, ${pdisDataRow?.positionOrigin.long}`
                : pdisDataRow?.positionOrigin?.address?.label,
            destinyRoute:
              pdisDataRow?.positionDestiny?.address?.street === 'null'
                ? `${pdisDataRow?.positionDestiny.lat}, ${pdisDataRow?.positionDestiny.long}`
                : pdisDataRow?.positionDestiny?.address?.label,
            routeName: pdisDataRow?.route?.routeName,
            route_name: pdisDataRow?.route?.routeName,
            triId: pdisDataRow?.tripId,
            assetData: pdisDataRow?.asset,
            asset: pdisDataRow?.asset?.name?.trim(),
            driver: pdisDataRow?.driver?.display_name,
            driverData: pdisDataRow?.driver,
            routeId: pdisDataRow?.route.routeId,
            status: convertStatusRoute(pdisDataRow?.status),
            originRouteData: pdisDataRow?.positionOrigin,
            destinyRouteData: pdisDataRow?.positionDestiny
          }
        })
      : []
  })

  const handleMenu = (item: string) => {
    setStatusCurrent(item)
  }

  const handleLinkVehicle = (id: string) => {
    setOpenAddVehicleDialog(true)
    setTripIdEdit(id)
  }

  return (
    <>
      <ResumeSidesheet
        isOpen={faultCodesDetails.isOpen}
        data={faultCodesDetails.data}
        onClose={() => setFaultCodesDetails({ isOpen: false })}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type={'linkVehicleOut'}
        typeToTrip={'/resume-edit'}
        data={tripIdEdit}
      />
      <DashboardWrapper>
        <TableResume
          handleLinkVehicle={handleLinkVehicle}
          name='resumeTable'
          rowsPagineted={rowsPagineted}
          rowsCount={pageSize}
          disabledColumns={[]}
          columnsStyle={{
            route_name: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 100
            },
            originRoute: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 150
            },
            destinyRoute: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 150
            },
            status: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 50
            },
            start_datetime: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 100
            },
            asset: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 50
            },
            driver: {
              width: 0,
              maxWidth: 500,
              defaultWidth: 100
            }
          }}
          columnLabels={{
            route_name: 'Nome',
            originRoute: 'Inicio da Rota',
            destinyRoute: 'Término da Rota',
            status: 'Status',
            start_datetime: 'Data',
            asset: 'Veículo',
            driver: 'Motorista'
          }}
          defaultColumnOrder={[
            'route_name',
            'originRoute',
            'destinyRoute',
            'status',
            'start_datetime',
            'asset',
            'driver'
          ]}
          sort={sort}
          settingsCloseButtonText={<FormattedMessage id='settingsCloseButtonText' />}
          settingsNotFoundMessage={<FormattedMessage id='settingsNotFoundMessage' />}
          settingsResetButtonText={<FormattedMessage id='settingsResetButtonText' />}
          settingsSearchPlaceholder={intl.formatMessage({ id: 'settingsSearchPlaceholder' })}
          settingsTitle={<FormattedMessage id='settingsTitle' />}
          searchLabel={intl.formatMessage({ id: 'searchLabel' }, { value: intl.formatMessage({ id: 'failures' }) })}
          search={search}
          lineClickName='allColumns'
          onLineClick={(handleLineClick as unknown) as (row: Row) => void}
          onChangeSearch={handleSearch}
          onChangeSort={handleChangeSort}
          typeTable='resume'
          handleMenu={handleMenu}
          showResumeButton={true}
        />
        {data && data.total > 0 && (
          <Pagination
            paginationDescription={intl.formatMessage({ id: 'paginationDescription' })}
            buttonLoadMoreLabel={<FormattedMessage id='buttonLoadMoreLabel' />}
            buttonEverythingLoadedLabel={<FormattedMessage id='buttonEverythingLoadedLabel' />}
            lenghtPerPage={pageSize || 50}
            page={pageNo || 1}
            onLoadmore={handleFetchMore}
            size={data[0].total || 50}
          />
        )}
      </DashboardWrapper>
    </>
  )
}

export default injectIntl(Resume)
