package routefence_common.cloud.rio.latam_routefence.domain.bo

import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum

data class TripBO(
    val id: String,
    val status: TripStatusEnum,
    val driverId: String?,
    val assetId: String,
    val routeId: String,
    val hasStop: Boolean
)
