package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class ResponseIssue(
    @JsonProperty("code") var code: Int?,
    @JsonProperty("duration") var duration: Int?,
    @JsonProperty("isoCountryCode") var isoCountryCode: String?,
    @JsonProperty("message") var message: String?,
    @JsonProperty("operation") var operation: String?,
    @JsonProperty("plannedWayPointSeqNum") var plannedWayPointSeqNum: Int?,
    @JsonProperty("routeLinkSeqNum") var routeLinkSeqNum: Int?,
    @JsonProperty("toTracePointSeqNum") var toTracePointSeqNum: Int?,
    @JsonProperty("tracePointSeqNum") var tracePointSeqNum: Int?,
    @JsonProperty("truckRestrictionCategoryCode") var truckRestrictionCategoryCode: Int?,
    @JsonProperty("wayPointSeqNum") var wayPointSeqNum: Int?
)