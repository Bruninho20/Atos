package routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AccountTenantEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.*
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Id
import javax.persistence.Table

@Entity
@Table(name = "TB_ASSET_IOT_EVENT_PAIRING")
data class AssetIotEventPairingEntity(
    @Id
    @Column(name = "ID")
    val id: String = UUID.randomUUID().toString(),

    @Column(name = "ASSET_ID")
    val assetId: String,

    override var accountId: String = "",

    @Column(name = "DEVICE_ID")
    val deviceId: String,

    @Column(name = "DEVICE_TYPE")
    val deviceType: String?,

    @Column(name = "EID")
    val eid: String,

    @Column(name = "OCCURRED_AT")
    val occurredAt: LocalDateTime,

    @Column(name = "TRIGGER")
    val trigger: String,

    @Column(name = "DRIVER_IDENTIFICATION")
    val driverIdentification: String,

    @Column(name = "DRIVER_IDENTIFICATION_TYPE")
    val driverIdentificationType: String?,

    @Column(name = "PROCESSED")
    var processed: Boolean

): AccountTenantEntity(accountId) {}



