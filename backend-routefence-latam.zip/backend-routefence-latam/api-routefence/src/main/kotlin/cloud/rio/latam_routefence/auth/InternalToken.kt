package cloud.rio.latam_routefence.auth

data class InternalToken(
    val token: InternalAuthResponse,
    val accountId: String
)