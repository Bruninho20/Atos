package listener.cloud.rio.latam_routefence.services

import listener.cloud.rio.latam_routefence.infrastructure.repositories.RouteRepository
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.*
import org.springframework.stereotype.Service
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.PointOfInterestEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.VehicleTypesEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteStopResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.ResponseHereLayer
import routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity.Response
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse

@Service
class HereService(
    private val routeRepository: RouteRepository,
) {
    @Value("\${here.api-key}")
    private lateinit var apiKey: String

    @Value("\${here.endpoint.search-proximity}")
    private lateinit var urlSearchProximity: String

    @Value("\${here.endpoint.calculate-route}")
    private lateinit var urlCalculateRoute: String

    private val logger = LoggerFactory.getLogger(this.javaClass)

    private fun isOnPointOfInterest(
        layerId: String?,
        position: AssetPositionMessage?,
        stops: Collection<RouteStopResponse>?,
        tripRange: Int,
        largestRange: Int
    ): Collection<PointOfInterestBO> {
        val lat = position?.latitude
        val lng = position?.longitude

        if (layerId.isNullOrEmpty()) throw HttpClientErrorException(
            HttpStatus.BAD_REQUEST, "Parametros obrigatorios"
        )

        val proximityUrl =
            "${urlSearchProximity}?layer_ids=R${layerId},S${layerId}&apiKey=${apiKey}&proximity=${lat},${lng},${largestRange}&key_attribute=POSTCODE"
        val onPointOfInterestList: MutableList<PointOfInterestBO> = mutableListOf()

        logger.debug("Check layer [$layerId] proximity url: $proximityUrl")

        try {
            val proximityResponse = RestTemplate().getForObject(
                proximityUrl, Response::class.java
            )
            logger.debug("Check layer [$layerId] proximity response: $proximityResponse")
            proximityResponse?.geometries?.forEach {
                if (it.attributes?.name == "ORIGIN") {
                    logger.debug("range do ponto de origem: ${tripRange} | distancia do ponto: ${it.distance}")
                    logger.debug("esta no ponto de partida")
                    if (tripRange >= it.distance!!) onPointOfInterestList.add(
                        PointOfInterestBO(
                            "1", PointOfInterestEnum.ORIGIN, it.distance!!
                        )
                    )
                } else if (it.attributes?.name == "DESTINATION") {
                    logger.debug("range do ponto de destino: ${tripRange} | distancia do ponto: ${it.distance}")
                    logger.debug("esta no ponto final")
                    if (tripRange >= it.distance!!) onPointOfInterestList.add(
                        PointOfInterestBO(
                            "2", PointOfInterestEnum.DESTINATION, it.distance!!
                        )
                    )
                } else if (it.attributes?.name == "R$layerId") {
                    logger.debug("range da rota: ${tripRange} | distancia do ponto: ${it.distance}")
                    logger.debug("dentro rota")
                    if (tripRange >= it.distance!!) onPointOfInterestList.add(
                        PointOfInterestBO(
                            "3", PointOfInterestEnum.ROUTE, it.distance!!
                        )
                    )
                } else {
                    stops?.forEach { stop ->
                        logger.debug("range do ponto: ${stop.rangeLimitMeters} | distancia do ponto: ${it.distance}")
                        if (stop.id == it.attributes?.name) {
                            if (stop.rangeLimitMeters!!.toDouble() >= it.distance!!) {
                                logger.debug("esta no ponto de parada: ${it.attributes?.name}")
                                onPointOfInterestList.add(
                                    PointOfInterestBO(
                                        stop.id.toString(), PointOfInterestEnum.STOP, it.distance!!
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } catch (e: HttpClientErrorException) {
            logger.error("Erro na checagem de proximidade com a layer [$layerId]: ${e.localizedMessage}")
        }
        return onPointOfInterestList
    }

    fun loadData(tripId: String, asset: AssetIotEventMessage): Collection<PointOfInterestBO>? {
//        val tripRoute = routeService.findByTripId(tripId).mapToResponse()
        val tripRoute = routeRepository.getRouteByTripId(tripId)?.mapToResponse() ?:
            throw RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(tripId))

        try {
            val tripRange = tripRoute.rangeToleranceLimit?.toInt() ?: 1
            val stops = tripRoute.stops
            var largestStopRange: Int
            var largestRange = tripRange
            if (stops != null) {
                if (stops.isNotEmpty()) {
                    if (stops.size > 1) {
                        largestStopRange = (stops.reduce(RouteStopResponse.Compare::max).rangeLimitMeters?.toInt()) ?: 0
                        largestRange = if (tripRange > largestStopRange) tripRange else largestStopRange
                    } else largestRange =
                        if (tripRange > (stops.last().rangeLimitMeters?.toInt() ?: 0))
                            tripRange
                        else
                            (stops.last().rangeLimitMeters?.toInt() ?: 0)
                }
            }
            return isOnPointOfInterest(tripRoute.idLayer, asset.position, stops, tripRange, largestRange)
        } catch (e: NumberFormatException) {
            logger.error(e.localizedMessage)
        }
        return null
    }

    fun checkTrafficViolation(
        tripId: String, asset: AssetIotEventMessage
    ): Collection<TrafficViolationBO> {

        val tripRoute = routeRepository.getRouteByTripId(tripId) ?:
            throw RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(tripId))

        val vehicleType = tripRoute.vehicleVocationalInfo?.vehicleType
        val lat = asset.position?.latitude
        val lng = asset.position?.longitude
        val speed = asset.position?.speed
        val heading = asset.position?.heading ?:0

        var speeding = false;
        val calculateRouteUrl = if (vehicleType!! == VehicleTypesEnum.CAR) {
            "${urlCalculateRoute}?routeMatch=1&mode=fastest;car;traffic:disabled&apiKey=${apiKey}&attributes=SPEED_LIMITS_FCn(FROM_REF_SPEED_LIMIT,TO_REF_SPEED_LIMIT)"
        } else {
            "${urlCalculateRoute}?routeMatch=1&mode=fastest;truck;traffic:disabled&apiKey=${apiKey}&attributes=TRUCK_SPEED_LIMITS_FCn(FROM_REF_SPEED_LIMIT,TO_REF_SPEED_LIMIT)"
//            "${urlCalculateRoute}?routeMatch=1&mode=fastest;truck;traffic:disabled&apiKey=${apiKey}&attributes=TRUCK_SPEED_LIMITS_FCn(FROM_REF_SPEED_LIMIT,TO_REF_SPEED_LIMIT)"
        }




        val headers = HttpHeaders()
        headers.contentType = MediaType.TEXT_PLAIN

        val bodyContent = "LATITUDE,LONGITUDE,HEADING\n$lat,$lng,$heading"

        val requestEntity = HttpEntity<String>(bodyContent, headers)
        val trafficViolationList: MutableList<TrafficViolationBO> = mutableListOf()
        var speedNote = ""

        try {
            val response = RestTemplate().postForEntity(calculateRouteUrl, requestEntity, ResponseHereLayer::class.java)
            logger.debug("check traffic para trip [$tripId] com response: $response")
            val responseHere: ResponseHereLayer? = response.body

            responseHere?.response?.route?.forEach { route ->
                route.leg?.forEach { leg ->
                    leg.link?.forEach { link ->
                        val ref = if (link.linkId!!.toInt() > 0) "FROM_REF_SPEED_LIMIT" else "TO_REF_SPEED_LIMIT"
                        if(vehicleType == VehicleTypesEnum.CAR) {
                            if (link.attributes?.speedLimitsFcn.isNullOrEmpty()) logger.debug("Sem informacao do limite de velocidade da via na HERE api")
                            link.attributes?.speedLimitsFcn?.forEach {
                                for (key in it.keys) {
                                    speeding = (it[ref]?.toDouble() ?: 0.0) < speed!!
                                    speedNote = "Velocidade da via = ${it[ref]} | Velocidade do veículo: $speed"
                                    logger.debug("Velocidade da via: ${it[ref]} | Velocidade do asset: $speed")
                                }
                            }
                        }else{
                            if (link.attributes?.truckSpeedLimitsFcn.isNullOrEmpty()) logger.debug("Sem informacao do limite de velocidade da via na HERE api")
                            link.attributes?.truckSpeedLimitsFcn?.forEach {
                                for (key in it.keys) {
                                    speeding = (it[ref]?.toDouble() ?: 0.0) < speed!!
                                    speedNote = "Velocidade da via = ${it[ref]} | Velocidade do veículo: $speed"
                                    logger.debug("Velocidade da via: ${it[ref]} | Velocidade do asset: $speed")
                                }
                            }
                        }//Velocidade na lat/long: -22.948838/-45.397748 = 90  | Velocidade do veículo: 120.0
                    }
                }
            }

            responseHere?.response?.warnings?.forEach {
                if (it.code == 3) {
                    trafficViolationList.add(
                        TrafficViolationBO(
                            InfringementTypeEnum.FORBIDDEN_DIRECTION, it.message
                        )
                    )
                }
            }
            if (speeding) {
                trafficViolationList.add(TrafficViolationBO(InfringementTypeEnum.SPEEDING, speedNote))
            }
        } catch (e: HttpClientErrorException) {
            logger.error("Erro de checagem de infrações [tripId:$tripId] ${e.localizedMessage}")
        }

        return trafficViolationList
    }
}