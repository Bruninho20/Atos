import React, { FC, useContext, useState } from 'react'
import { FormattedMessage } from 'react-intl'
import { isEmpty } from 'lodash'
import useSWR from 'swr'

import { fetcherPost } from 'core/utils/fetch'

import DashboardContext from 'core/DashboardContext'

import VehiclesStatusTable from './VehiclesStatusTable/index'

import { Welcome } from 'components'

import { DashboardWrapper, Container } from './styled'

import InfringementCard from '../../components/InfringementCard0'
import AvoidedCard from '../../components/AvoidedCard'
import Carousel from '../../components/CarouselDashboard'

export type FilterType = 'operative' | 'faultCodes' | 'maintance' | ''

export interface CardFilter {
  card: FilterType
  filter: string
}

interface VehiclesStatusData {
  totalOdometer: any
  connected: any
  disconnected: any
  batteryAboveMaxThreshold: any
  batteryBellowMinThreshold: any
  attention: any
  outOfOperation: any
  outOfOperationAboveThreshold: any
}

interface VehiclesStatusTableProps {
  assetsId: string[]
  tagsId: string[]
}

export interface CardFilter {
  card: FilterType
  filter: string
}

const Dashboard: FC<VehiclesStatusTableProps> = ({ assetsId, tagsId }) => {
  const { assets, tags } = useContext(DashboardContext)

  const { data } = useSWR<VehiclesStatusData>(['/api/perla-tests/vehicleStatus/summary', assets, tags], url => {
    return fetcherPost(url, {
      assetIds: assets,
      tagIds: tags
    })
  })

  const [cardFilter, setCardFilter] = useState<CardFilter>({ card: '', filter: '' })

  const handleFilterClick = (filter: CardFilter) => {
    // if (!isEqual(cardFilter, filter)) {
    if (cardFilter.card !== filter.card) {
      setCardFilter({
        card: filter.card,
        filter: filter.filter
      })
    } else {
      setCardFilter({ card: '', filter: '' })
    }
  }

  const [newOdometer, setNewOdometer] = useState('')
  const [calcOdometer, setCalcOdometer] = useState('')

  const handleChangeOdometer = (e: any) => {
  e.preventDefault();
  setNewOdometer(e.target.value)
  }

  const newCalculateOdometer = Number(calcOdometer === "" ? "4.7" : calcOdometer.replace(',', '.'))

  const co2Avoided = Number(((data?.totalOdometer / 1000 / newCalculateOdometer) * 2.62)).toFixed(2)

  const exatCo2Avoided = co2Avoided.length === 7 ? co2Avoided.slice(0, 1) 
    : co2Avoided.length === 8 ? co2Avoided.slice(0, 2) 
    : co2Avoided.length === 9 ? co2Avoided.slice(0, 3) 
    : co2Avoided.length <= 6 ? co2Avoided : co2Avoided
  

  const quantityOfAvoided = exatCo2Avoided.length >= 6  ? "Kg" : 'Ton'

  const dieselAvoided = Number((data?.totalOdometer / 1000 / newCalculateOdometer)).toFixed(0)

  const handleResetCalc = (e: any) => {
    e.preventDefault();
    setCalcOdometer("")
  }

  return (
    <Container>
      <DashboardWrapper>
        {!isEmpty(tags) || !isEmpty(assets) ? (
          <>
            <div style={{ display: 'flex', maxHeight: '240px', marginBottom: '25px' }}>
              <Carousel>
                <InfringementCard
                  handleFilterClick={handleFilterClick}
                  cardType='statusOfCharging'
                  cardFilter='CARREGANDO'
                  title={<FormattedMessage id='vehiclesStatus.connected' />}
                  quantity={data && data.connected}
                  description={<FormattedMessage id='vehiclesStatus.batteryAboveMaxThreshold' />}
                  quantityOfDescription={data && data.batteryAboveMaxThreshold}
                />
                <InfringementCard
                  handleFilterClick={handleFilterClick}
                  cardType='statusOfCharging'
                  cardFilter='NÃO CARREGANDO'
                  title={<FormattedMessage id='vehiclesStatus.disconnected' />}
                  quantity={data && data.disconnected}
                  description={<FormattedMessage id='vehiclesStatus.batteryBellowMinThreshold' />}
                  quantityOfDescription={data && data.batteryBellowMinThreshold}
                />
                <InfringementCard
                  handleFilterClick={handleFilterClick}
                  cardFilter='true'
                  cardType='hasAlert'
                  title={<FormattedMessage id='vehiclesStatus.attention' />}
                  quantity={data && data.attention}
                  description={<FormattedMessage id='vehiclesStatus.criticalAlert' />}
                  quantityOfDescription={0}
                />
                <InfringementCard
                  handleFilterClick={handleFilterClick}
                  cardType='status'
                  cardFilter='NÃO OPERANDO'
                  title={<FormattedMessage id='vehiclesStatus.outOfOperation' />}
                  quantity={data && data.outOfOperation}
                  description={<FormattedMessage id='vehiclesStatus.outOfOperationAboveThreshold' />}
                  quantityOfDescription={data && data.outOfOperationAboveThreshold}
                />
                <AvoidedCard 
                  title={<FormattedMessage id='vehiclesStatus.co2Avoided' />} 
                  content={exatCo2Avoided} 
                  unity={quantityOfAvoided} 
                  description={<FormattedMessage id='referenceFuel' />} />
                <AvoidedCard
                  title={<FormattedMessage id='vehiclesStatus.dieselAvoided' />}
                  content={dieselAvoided}
                  unity={<FormattedMessage id='vehiclesStatus.liters' />}
                  description={`*Ref. ${newCalculateOdometer} km/l`}
                />
              </Carousel>
            </div>

            <div style={{ marginTop: '30px' }}>
            <VehiclesStatusTable 
                assetsId={assets} 
                tagsId={tags} 
                cardFilterRow={cardFilter} 
                onChange={() => setCalcOdometer(newOdometer)} 
                resetCalc={handleResetCalc}
                valueOdometer={newOdometer} 
                handleChangeOdometer={handleChangeOdometer} />
            </div>
          </>
        ) : (
          <Welcome
            title={<FormattedMessage id='welcome.title' />}
            description=''
          />
        )}
      </DashboardWrapper>
    </Container>
  )
}

export default Dashboard
