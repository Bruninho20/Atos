import React, { FC, useEffect, useState } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
import { format } from 'date-fns'
import useCustomSWRInfinite from 'core/utils/useCustomSWRInfinite'

import DiagnosticDataSidesheet from '../DiagnosticDataSidesheet'

import { SortDirection } from 'rio-uikit'
import { Pagination, Table } from 'components'
import { Row, Sort } from 'components/Table'

export type Status = 'OPERATING_NORMALLY' | ''

interface VehiclesStatusDataData {
  vehicleId: any;
  name: any;
  chassis: any;
  batteryLevel: any;
  autonomy: any;
  statusOfCharging: any;
  lastUpdate: any;
  status: any;
  statusOfWorking: any;  
  avgPowerAvailability: any
  accountId: any;
  statusTitle: any;
  
}

interface VehiclesStatusData extends Row {
  data: VehiclesStatusDataData[];
  total: number
}

interface VehiclesStatusTableProps {
  assetsId: string[];
  tagsId: string[];
  filter: string;
  intl: Intl;
  cardFilterRow: any;
  onChange: () => void;
  resetCalc: () => void;
  valueOdometer?: any;
  handleChangeOdometer: any
}

const VehiclesStatusTable: FC<VehiclesStatusTableProps> = ({ assetsId, tagsId, filter, intl, cardFilterRow, onChange, resetCalc, valueOdometer, handleChangeOdometer }) => {
  const [diagnosticDataSidesheetData, setDiagnosticDataSidesheetData] = useState<{
    assetId: string,
    chassis: string,
    isOpen: boolean,
    onClose: () => void
  }>({
    assetId: '',
    chassis: '',
    isOpen: false,
    onClose: () => null
  })

  const [sort, setSort] = useState({ sortBy: '', sortDirection: SortDirection.ASCENDING })
  const order = sort.sortBy ? `${sort.sortDirection === SortDirection.ASCENDING ? '' : '-'}${sort.sortBy}` : ''

  const pageSize = 50
  const [propsData, setProps] = useState({})

  const { data: vehiclesStatus = [{ data: [], total: 0 }], status, size, setSize } = useCustomSWRInfinite<
    VehiclesStatusData[]
  >('/api/perla-tests/vehicleStatus/newefleet', 'POST', propsData, pageSize)  

  const getVehiclesStatus = (assetsId: string[], tagsId: string[], filter: string, order: string) => {
    let propsData: {
      assetIds: string[]
      tagIds: string[]
      order: string[]
      pageSize: number
      filterType?: string
    } = {
      assetIds: assetsId,
      tagIds: tagsId,
      order: order === '' ? [] : [order],
      pageSize
    }

    if (filter && filter !== '') {
      propsData = {
        ...propsData,
        filterType: filter
      }
    }
    setProps(propsData)
  }

  const handleChangeSort = (sortBy: Sort['sortBy'], sortDirection: Sort['sortDirection']) =>
    setSort({ sortBy, sortDirection })

  const handleFetchMore = () => {
    setSize(size + 1)
  }

  const handleLineClick = (data: VehiclesStatusDataData) => {
    setDiagnosticDataSidesheetData({
      assetId: data.vehicleId,
      chassis: data.chassis,
      isOpen: true,
      onClose: () => setDiagnosticDataSidesheetData({ ...diagnosticDataSidesheetData, isOpen: false })
    })
  }

  const filterByCard = (row: any) => {
    switch(filter){
      case 'CHARGING':
        return row.statusOfCharging === "NÃO CARREGANDO"
      case 'NOT_CHARGING':
        return row.statusOfCharging !== "NÃO CARREGANDO"
      case 'OUT_OF_OPERATION':
        return row.status === "OPERANDO"
      default:
        return false
    }
  }

  const rowsPagineted = vehiclesStatus.map((vehiclesStatusPage: VehiclesStatusData) => {
    return vehiclesStatusPage
      ? vehiclesStatusPage.data.map((vehiclesStatusRow, index) => {
        if(filterByCard(vehiclesStatusRow)) return {}
          const averageConsuption = vehiclesStatusRow.autonomy === '0.0' ? String(((vehiclesStatusRow.batteryLevel * 200) / 100)) : vehiclesStatusRow.autonomy;
          return {
            ...vehiclesStatusRow,
            index: index.toString(),
            status: intl.formatMessage({ id: vehiclesStatusRow.status }),
            statusOfCharging: intl.formatMessage({ id: vehiclesStatusRow.statusOfCharging }),
            statusOfWorking: intl.formatMessage({ id: vehiclesStatusRow.statusOfWorking }),
            lastUpdate: format(new Date(vehiclesStatusRow.lastUpdate), 'dd/MM/yyyy HH:mm'),
            autonomy: `${averageConsuption} km`,
            batteryLevel: `${vehiclesStatusRow.batteryLevel} %`               
          }
        })
      : []
  })

  const rowPaginetedFiltered = cardFilterRow.card !== "" ? rowsPagineted.map((value: any) => value.filter((item: any) => item[cardFilterRow.card] === cardFilterRow.filter )) : rowsPagineted;

  useEffect(() => {
    getVehiclesStatus(assetsId, tagsId, filter, order)
  }, [assetsId, tagsId, filter, order])

  useEffect(() => {
    setSize(1)
  }, [propsData])

  return (
    <>
      <DiagnosticDataSidesheet
        chassis={diagnosticDataSidesheetData.chassis}
        assetId={diagnosticDataSidesheetData.assetId}
        isOpen={diagnosticDataSidesheetData.isOpen}
        onClose={diagnosticDataSidesheetData.onClose}
      />
      <Table
        name='vehiclesStatusTable'
        status={status}
        rowsPagineted={rowPaginetedFiltered}
        rowsCount={pageSize}
        resetCalc={resetCalc}
        onChange={onChange}
        handleChangeOdometer={handleChangeOdometer}
        valueOdometer={valueOdometer}
        disabledColumns={[]}
        columnsStyle={{
          name: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          chassis: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          batteryLevel: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          autonomy: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          statusOfCharging: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          avgPowerAvailability: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          lastUpdate: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          status: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          },
          statusOfWorking: {
            width: 0,
            maxWidth: 500,
            defaultWidth: 100
          }   
        }}
        columnLabels={{
          name: <FormattedMessage id='vehicle' />,
          chassis: <FormattedMessage id='chassis' />,          
          batteryLevel: <FormattedMessage id='sidesheet.batteryLevel' />,
          autonomy: <FormattedMessage id='sidesheet.autonomy' />,          
          statusOfCharging: <FormattedMessage id='vehiclesStatus.statusOfCharging' />,
          avgPowerAvailability: <FormattedMessage id='avgPowerAvailability' />,
          lastUpdate: <FormattedMessage id='vehiclesStatus.lastUpdate' />,
          status: <FormattedMessage id='vehiclesStatus.status' />,
          statusOfWorking: <FormattedMessage id='vehiclesStatus.statusOfWorking' />,
        }}
        defaultColumnOrder={[
          'name',
          'chassis',
          'batteryLevel',
          'autonomy',
          'statusOfCharging',
          'avgPowerAvailability',
          'lastUpdate',
          'status',
          'statusOfWorking',
        ]}
        sort={sort}
        settingsCloseButtonText={<FormattedMessage id='settingsCloseButtonText' />}
        settingsNotFoundMessage={<FormattedMessage id='settingsNotFoundMessage' />}
        settingsResetButtonText={<FormattedMessage id='settingsResetButtonText' />}
        settingsSearchPlaceholder={intl.formatMessage({id: 'settingsSearchPlaceholder'})}
        settingsTitle={<FormattedMessage id='settingsTitle' />}
        searchLabel={intl.formatMessage({ id: 'searchLabel' }, { value: 'veículos' })}
        onLineClick={(handleLineClick as unknown) as (row: Row) => void}
        lineClickName='allColumns'
        onChangeSort={handleChangeSort}
      />
      {status === 'success' && vehiclesStatus && vehiclesStatus[0].total > 0 && (
        <Pagination
          paginationDescription={intl.formatMessage({ id: 'faultCodes.paginationDescription' })}
          buttonLoadMoreLabel={<FormattedMessage id='buttonLoadMoreLabel' />}
          buttonEverythingLoadedLabel={<FormattedMessage id='buttonEverythingLoadedLabel' />}
          lenghtPerPage={pageSize || 50}
          page={size || 1}
          onLoadmore={handleFetchMore}
          size={vehiclesStatus[0].total || 50}
        />
      )}
    </>
  )
}

export default injectIntl(VehiclesStatusTable)
