import { AccessToken, IdToken, LanguageDataInterface } from '../../../configuration'

export interface AppPropertiesFromDispatch {
  hideSessionDialog: () => void
}

export interface AppPropertiesFromState {
  accessToken: AccessToken
  homeRoute: string
  idToken: IdToken
  languageData: LanguageDataInterface
  showSessionExpired: boolean
  userLocale: string
}
