import Card, { CardProps } from 'components/Card'
import React, { FC } from 'react'
import ContentLoader from 'react-content-loader'

import { ScoreObject } from 'containers/VehiclesStatus/OperativeCard'

import { BodyText, Score, ScoreSpan } from './styled'

interface CardOneScoreProps extends CardProps {
  score: ScoreObject | undefined
  description: string | React.ReactElement
  descriptionScore: ScoreObject | undefined
  descriptionScoreUnit?: string | React.ReactElement
  footerClicked?: boolean
}

const CardOneScore: FC<CardOneScoreProps> = ({
  title,
  score,
  description,
  descriptionScore,
  loading,
  titleMoreLinks,
  hasMoreLinks,
  footerClicked,
  hasFooterClick,
  descriptionScoreUnit,
  footerTitle,
  onFooterClick
}) => {
  return (
    <Card
      title={title}
      loading={loading}
      footerTitle={footerTitle}
      footerClicked={footerClicked}
      hasMoreLinks={hasMoreLinks}
      titleMoreLinks={titleMoreLinks}
      hasFooterClick={hasFooterClick}
      onFooterClick={onFooterClick}>
      <>
        {!loading && score ? (
          <Score>{score.score}</Score>
        ) : (
          <ContentLoader width='78px' height='84px' style={{ borderRadius: '3px' }}>
            <rect width='100%' height='100%' />
          </ContentLoader>
        )}
        <div>
          <BodyText>
            {description}
            {descriptionScore && score && !loading ? (
              <ScoreSpan>{' '}{descriptionScore.score}</ScoreSpan>
            ) : (
              <>
                <ContentLoader width='50px' height='36px' style={{ borderRadius: '3px' }}>
                  <rect width='100%' height='100%' />
                </ContentLoader>
              </>
            )}
            &nbsp;{descriptionScoreUnit}
          </BodyText>
        </div>
      </>
    </Card>
  )
}

export default CardOneScore
