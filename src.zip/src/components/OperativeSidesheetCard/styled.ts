import styled from 'styled-components'

import { metrics } from 'core/assets/styles'
import CardEfleetSidesheet from '../CardEfleetSidesheet'

export const StyledCard = styled(CardEfleetSidesheet)`
  height: 415px;
  justify-content: space-between;
  padding: 0;
  text-align: center;
  align-items: center;
  width: 429px;
  margin-right: 8px;
  margin-bottom: 15px;
  transition: box-shadow 10ms linear 0s;
  box-shadow: rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;
  cursor: pointer;
  border: 1px solid rgb(208, 216, 222);
  border-radius: 3px;

  @media (max-width: 980px) {
  height: 780px;
  width: 330px;
}

  &.card-title {
    font-size: ${metrics.fontSizeDefault};
    color: 'black';
    font-family: 'Antonio';
    font-weight: normal;

    > div {
      margin-top: 5px;
      text-align: center;
      h1 {
        color: rgb(105, 122, 139);
        font-size: 1.3rem;
        font-family: 'Antonio';
        font-weight: normal;
        margin: 0;
        text-transform: none;
      }
      p {
        font-family: 'Roboto', 'sans-serif';
        font-weight: 500;
      }
    }
  }
`

export const OperativeCard = styled(CardEfleetSidesheet)`
  height: 80px;
  padding: 0;
  text-align: center;
  align-items: center;
  width: 180px;
  margin-right: 6px;
  margin-left: 6px;
  margin-bottom: 10px;
  color: #000;
  transition: box-shadow 10ms linear 0s;
  box-shadow: rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;
  cursor: pointer;
  border: 1px solid rgb(208, 216, 222);
  border-radius: 3px;

  &.mini-card-title {
    font-size: ${metrics.fontSizeDefault};
    color: 'black';

    > div {
      margin-top: 3px;
      text-align: center;
      h1 {
        color: rgb(105, 122, 139);
        font-size: 1.3rem;
        font-family: 'Antonio';
        font-weight: normal;
        margin: 0;
        text-transform: none;
      }
    }
  }

  &.mini-card-green {
    font-size: ${metrics.fontSizeDefault};
    color: #32CD32;
;

    > div {
      margin-top: 3px;
      text-align: center;
      h1 {
        color: rgb(105, 122, 139);
        font-size: 1.3rem;
        font-family: 'Antonio';
        font-weight: normal;
        margin: 0;
        text-transform: none;
      }
    }
  }

  &.mini-card-red {
    font-size: ${metrics.fontSizeDefault};
    color: #FF0000;

    > div {
      margin-top: 3px;
      text-align: center;
      h1 {
        color: rgb(105, 122, 139);
        font-size: 1.3rem;
        font-family: 'Antonio';
        font-weight: normal;
        margin: 0;
        text-transform: none;
      }
    }
  }
`
