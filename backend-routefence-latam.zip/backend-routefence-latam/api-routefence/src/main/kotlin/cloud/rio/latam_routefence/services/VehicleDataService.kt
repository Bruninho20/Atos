package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.repositories.VehicleDataCustomRepository
import cloud.rio.latam_routefence.infrastructure.repositories.VehicleDataRepository
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleDataResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.maptoResponse
import javax.transaction.Transactional

@Service
@Transactional
class VehicleDataService(private val repository: VehicleDataRepository,private val vehicleDataCustomRepository: VehicleDataCustomRepository) {

    fun decodeChassis(chassis: String, emissionType: String?): VehicleResponse {
        val geographicArea = chassis.substring(0, 1)
        val country = chassis.substring(1, 2)
        val manufacturer = chassis.substring(2, 3)
        val bodywork = chassis.substring(3, 4)
        val engine = chassis.substring(4, 5)
        val safetySystem = chassis.substring(5, 6)
        val vehicleClass = chassis.substring(6, 8)
        val controlDigit = chassis.substring(8, 9)
        val modelYear = chassis.substring(9, 10)
        val assemblyLocation = chassis.substring(10, 11)
        val serialNumber = chassis.substring(11, 17)

        val geographicAreaStr = when (geographicArea) {
            "9" -> "América do Sul"
            "3" -> "América Central"
            else -> "unknown geographical area"

        }
        val countryStr = when(country){
            "5" -> "Brasil"
            "M" -> "México"
            else -> "unknown country"
        }
        val manufacturerStr = when(manufacturer){
            "3" -> "Volkswagen Caminhões e Ônibus"
            "N" -> "MAN Truck and Bus Mexico"
            else -> "unknown manufacturer"
        }
        val bodyworkStr = when (bodywork) {

            "1" -> "DELIVERY ANTIGO"
            "2" -> "ÔNIBUS // MICRO-ÔNIBUS // CAMINHÕES MAN - TGX 6X4"
            "3" -> "WORKER"
            "4" -> "LOW CENTER - Ônibus e Micro Ônibus"
            "5" -> "PHEVOS (NEW DELIVERY)"
            "6" -> "CONSTELLATION"
            "7" -> "ÔNIBUS ARTICULADO"
            "8" -> "CAMINHÕES MAN - TGX 6X2"
            "9" -> "PERSEU"
            "A" -> "TAURUS (MICROÔNIBUS)"
            "B" -> "ÔNIBUS 6X2"
            else -> "unknown bodywork"

        }
        val engineStr = when(emissionType) {
            null -> ""
            "EURO II", "EURO III", "EURO IV" -> {
                when (engine) {
                    "1" -> "MWM 6.10 TCA EURO III - 127 Kw / 600Nm Code 1"
                    "2" -> "MWM TCE Euro III 150cv"
                    "3" -> ""
                    "4" -> "MWM 4.10 TCA EURO III"
                    "5" -> ""
                    "6" -> "MWM 4.12 TCAE EURO III 180cv"
                    "7" -> "CUMMINS C8.3 215 P5-0"
                    "8" -> "MWM 4.12 TCAE 185cv EURO III Code 1"
                    "9" -> "MWM 4.08 TCE 140cv Euro3"
                    "A" -> "Cummins ISBe 150cv-P5-3"
                    "B" -> "MWM 6.12 TCAE EURO III 260cv Code 1"
                    "C" -> "MWM 4.3L 120cv"
                    "D" -> "MWM 4.3L 145cv"
                    "E" -> "MWM 6.10L 180cv"
                    "F" -> "MWM 6.10L 207cv"
                    "G" -> "MWM 6.10L 240cv"
                    "H" -> "Cummins ISBe 170cv // Cummins 3.8l EURO III"
                    "J" -> "Cummins ISC 320cv"
                    "K" -> "Cummins 6B 214cv"
                    "L" -> "MWM 6.12 TCE EURO III 225cv Code 1"
                    "M" -> "Cummins 218cv"
                    "N" -> "CUMMINS ISBe 250cv P5-0/ CUMMINS 250cv 12v"
                    "P" -> "MWM 6.12 TCAE EURO III 206cv // Cummins ISBe"
                    "R" -> "Cummins 303cv"
                    "S" -> "Cummins 190cv"
                    "T" -> "Cummins 260cv"
                    "U" -> "MAN D08 150cv - EURO IV - COLÔMBIA/MÉXICO"
                    "V" -> "Cummins ISC 280cv (Paquistão)"
                    "W" -> "INTERNATIONAL 370cv"
                    "Y" -> ""
                    else -> "Unknown engine with emission type EURO III, EURO III, EURO IV"
                }
            }

            "EURO V" -> {
                when (engine) {
                    "1" -> ""
                    "2" -> ""
                    "3" -> "CUMMINS ISL 8,9 420cv"
                    "4" -> ""
                    "5" -> "MAN D0836 (280cv) (LOH10 / LF13 / LOF03)"
                    "6" -> ""
                    "7" -> ""
                    "8" -> "I/MAN D2676 LF28 440cv"
                    "9" -> "MAN D26 460cv (PERSEU)"
                    "A" -> "I/MAN D2676 LF23 480CV"
                    "B" -> "MAN D26 520cv (PERSEU)"
                    "C" -> "Cummins 2,8-155cv (SCR)"
                    "D" -> ""
                    "E" -> "MAN D0834 (190cv) (LOF 01/LF 02)"
                    "F" -> ""
                    "G" -> "MAN D0834 (230cv) (LOF 02/ LF 05)"
                    "H" -> "CUMMINS 3,8-165 cv/600Nm-(SCR)"
                    "J" -> "MAN D0836 LF13"
                    "K" -> "MAN D0836 (260cv) (LF14 / LOF01)"
                    "L" -> "MAN D0834 LOH10 (230cv) - OT"
                    "M" -> "CUMMINS ISF 3,8 => 150/160cv"
                    "N" -> ""
                    "P" -> "Cummins ISF 2.8L - 150cv (EGR)"
                    "R" -> "CUMMINS ISL 8,9 (360cv)"
                    "S" -> "MAN D0834 (230cv)"
                    "T" -> "CUMMINS ISL 8,9 (380 - 390 - 400cv)"
                    "U" -> ""
                    "V" -> "CUMMINS 3,8-175 cv/600Nm-(SCR)"
                    "W" -> ""
                    "Y" -> "CUMMINS ISL 8,9 (330cv) "
                    else -> "Unknown engine with EURO V emission type"
                }
            }

            "EURO VI" -> {
                when (engine) {
                    "1" -> "MAN D0834 LOH67 (MEX EVI - Huracan)"
                    "2" -> "MAN D0834 LFLAO (MEX EVI - Phevos)"
                    "3" -> "MAN D0834 LOH66 (MEX EVI - Taurus)"
                    "4" -> "MAN D0834 220cv (MEX EVI - Constellation)"
                    "5" -> "FPT F1C 3.0L 160cv (360Nm@1300-2900rpm) TRUCK REG2023"
                    "6" -> "FPT F1C 3.0L 170cv (430Nm@1400-2700rpm) TRUCK REG2023"
                    "7" -> "MAN D0834 4.6L 195cv (750Nm@1200-1800rpm) TRUCK REG2023"
                    "8" -> "MAN D0834 4.6L 225cv (850Nm@1300-1800rpm) TRUCK REG2023"
                    "9" -> "MAN D0834 4.6L 195cv (750Nm@1200-1800rpm) BUS REG2023"
                    "A" -> "MAN D0834 4.6L 225cv (850Nm@1300-1800rpm) BUS REG2023"
                    "B" -> "MAN D0836 6.9L 260cv (950Nm@1000-1800rpm) TRUCK REG2023"
                    "C" -> "MAN D0836 6.9L 315cv (1200Nm@1200-1700rpm) TRUCK REG2023"
                    "D" -> "CUMMINS ISF 3.8L 175cv (600Nm@1100-1800rpm) BUS REG2023"
                    "E" -> "CUMMINS ISF 3.8L 175cv (600Nm@1100-1800rpm) TRUCK REG2023"
                    "F" -> "MAN D0836 6.9L 260cv (950Nm@1000-1800rpm) BUS REG2023"
                    "G" -> "MAN D0836 6.9L 315cv (1200Nm@1200-1700rpm) BUS REG2023"
                    "H" -> "CUMMINS ISL 9L 360cv (1600Nm@1100-1500rpm) TRUCK REG2023"
                    "J" -> "MAN D26 480cv (2400Nm@930-1350rpm) TRUCK REG2023"
                    "K" -> "MAN D26 520cv (2500Nm@1000-1400rpm) TRUCK REG2023"
                    else -> "Unknown engine with EURO VI emission type"
                }
            }

            "ELÉTRICO" -> {
                when (engine) {
                    "1" -> "WEG / AL160 - 80kW / 109cv (PROTOTIPO)"
                    "2" -> "SCANIA / P160 - 220kW / 300cv (PROTOTIPO)"
                    "3" -> "WEG / W160 - 220 kW / 300cv (PROTOTIPO)"
                    "4" -> "WEG / W280 - 220 kW / 300cv e VOLKSWAGEN / TSI 1.4 TSI Flex / 150 cv (Hibrido)(PROTOTIPO)"
                    "5" -> "WEG / 209 kW - 284,1 cv"
                    "6" -> "HINO / G1100846B0 – 45kW / 60cv (PROTOTIPO)"
                    "7" -> "WEG / W280 - 220 kW / 300cv (PROTOTIPO)"
                    "8" -> "WEG / 124 kW - 168,5 cv (PROTOTIPO)"

                    else -> "Unknown engine with ELECTRICAL emission type"
                }
            }
            else -> "Invalid issue type"
        }

        val safetySystemStr = when (safetySystem){

            "F" -> "DE  3.175 à 3.629 kg"
            "G" -> "DE  3.629 à 4.082 kg"
            "H" -> "DE 4.082 à 4.536 kg"
            "3" -> "DE 4.536 à 6.350 kg"
            "4" -> "DE 6.350 à 7.256 kg"
            "5" -> "DE  7.256 à 8.845 kg"
            "6" -> "DE  8.845 à 11.793 kg (4x2)"
            "7" -> "DE 11.793 à 14.968 kg (6x2)"
            "8" -> "Acima de 14.968 kg"
            "X" -> "EXCLUSIVO PARA TGX"
            else -> "unknown security system"

        }
        val vehicleClassStr = when (vehicleClass){

            "2P" -> "FAMILIA DELIVERY (ANTIGO)"
            "TB" -> "PHEVOS 8/9/11/13 ton"
            "TC" -> "PHEVOS 4/6 ton"
            "TE" -> "PHEVOS 3,5 ton"
            "TF" -> "TAURUS (MICROÔNIBUS)"
            "TP" -> "DELIVERY COM PROPULSÃO ELÉTRICA"
            "EL" -> "PROTÓTIPOS COM PROPULSÃO ELÉTRICA OU HÍBRIDA"
            "23" -> "CAMINHÃO MEDIO ATÉ 15t"
            "U3" -> "CAMINHÃO MEDIO ATÉ 15t (ROBUST)"
            "2W" -> "ÔNIBUS MOTOR DIANTEIRO"
            "24" -> "CAMINHÃO RIGIDO PESADO"
            "U4" -> "CAMINHÃO RIGIDO PESADO (ROBUST)"
            "S4" -> "ÔNIBUS MOTOR TRASEIRO LOW ENTRY"
            "26" -> "CAMINHÃO RIGIDO 6X4"
            "2K" -> "CAMINHÃO P23 PHASE I"
            "2Z" -> "ÔNIBUS MOTOR TRASEIRO"
            "27" -> "CAMINHÃO TRATOR"
            "ZZ" -> "CAMINHÃO TRATOR - TGX - 440cv"
            "AZ" -> "CAMINHÃO TRATOR - TGX - 480cv"
            "TH" -> "PERSEU P25 6X2"
            "TJ" -> "PERSEU P25 6X4"
            "TK" -> "PERSEU P23 6X4 e 6X2"
            else -> "unknown vehicle class"

        }
        val modelYearStr = when (modelYear){

            "A" -> "2010"
            "B" -> "2011"
            "C" -> "2012"
            "D" -> "2013"
            "E" -> "2014"
            "F" -> "2015"
            "G" -> "2016"
            "H" -> "2017"
            "J" -> "2018"
            "K" -> "2019"
            "L" -> "2020"
            "M" -> "2021"
            "N" -> "2022"
            "P" -> "2023"
            "R" -> "2024"
            "S" -> "2025"
            "T" -> "2026"
            "V" -> "2027"
            else -> "unknown model year"

        }
        val assemblyLocationStr = when(assemblyLocation){

            "R" -> "Planta de Resende/RJ => Veículos VWCO"
            "E" -> "Planta de Resende/RJ => Veículos MAN (TGX)"
            "D" -> "Planta de Querétero/México=> Veículos VWCO"
            "G" -> "Planta de Dubai/Emirados Árabes(GCC) => Veículos VWCO"
            else -> "unknown mount location"
        }

        return VehicleResponse(
            geographicArea = geographicAreaStr,
            country= countryStr,
            manufacturer= manufacturerStr,
            bodywork = bodyworkStr,
            engine = engineStr,
            safetySystem = safetySystemStr,
            vehicleClass = vehicleClassStr,
            controlDigit = controlDigit,
            modelYear = modelYearStr,
            factoryCode = assemblyLocationStr,
            sequentialProd = serialNumber

        )
    }

    fun findVehicleByCode(chassis: String): VehicleDataResponse? {
        val decodeChassis = decodeChassis(chassis,null)
        val newChassis = chassis.substring(0, 8) + chassis.substring(10,11)
        return vehicleDataCustomRepository.findVehicleByChassis(newChassis)?.maptoResponse(decodeChassis)
    }
}