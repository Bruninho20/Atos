package cloud.rio.latam_routefence

import cloud.rio.latam_routefence.services.RouteService
import cloud.rio.latam_routefence.services.TripService
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance
import org.springframework.beans.factory.annotation.Autowired
import routefence_common.cloud.rio.latam_routefence.domain.request.TripRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import java.time.OffsetDateTime
import java.util.*

//@SpringBootTest

//    (webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class InfringementDetectionTest : TestBase (
) {
   // @Autowired private lateinit var infringementDetection: InfringementDetection
    @Autowired private lateinit var routeService: RouteService
    @Autowired private lateinit var tripService: TripService

    val assetId = "9e0d6aae-c7f0-4393-afa2-7e6c46e3624b"//48194
    val driverId = "f019b9f6-bce1-41b7-ba21-733bec0ed46e"


    val routeId = "6933c82a-e438-4229-bf12-9f39620eba51"
    val tripId = "00a71085-e5d7-4ac9-90e1-da06e15f2fef"

    fun getIotMessage() : AssetIotEventMessage {
        return AssetIotEventMessage(
            assetId = UUID.fromString(assetId),
            accountId = "d87f9f41-5950-45b1-9044-ecb5d32039d8",
            deviceId = UUID.fromString("8664cbbb-ff0b-4332-89dc-1aa283f1856d"),
            deviceType = "tbm3",
            driverIdentification = null,
            driverIdentificationType = null,
            eid = "tbm:2006290118/67/1675694409761/394/state/d9010aed-3df8-432f-bdc2-b4f0bd7d9949",
            occurredAt = OffsetDateTime.parse("2023-02-06T14:40:09.761Z"),
//            OffsetDateTime.now(),
            trigger = "timer",
            position = AssetPositionMessage(
                latitude = -23.56156,
                longitude = -46.41994,
                altitude = 739.2000122070312,
                accuracy = 3.200000047683716,
                altitudeAccuracy = null,
                heading = 51.9900016784668,
                speed = 0.0
            ),
            state = AssetStateMessage(
                mileage = 212191.5625,
                ignitionOn = true,
                fuelLevel = 71.19999694824219,
                stateOfCharge = null,
                electricRange = null,
                engineSpeed = 1566.0,
                wheelSpeed = 27.8984375,
                tachoSpeed = 28.0,
                fuelConsumption = null,
                acceleratorPedal = null,
                weightTotal = null,
                ptoInformation = null,
                electronicRetarderState = null,
                driveState = null,
                fuelRate = null,
                instantaneousFuelEconomy = null,
                engineOperationTime = null            ),
            driverInfo = null,
            driverState = null
        )
    }

//    @Autowired
//    private lateinit var objectMapper: ObjectMapper

    fun createTripRequest(payload: String): Collection<TripRequest>{
        val mapper = jacksonObjectMapper()
        mapper.registerModule(JavaTimeModule())
        var o = mapper.readValue<Collection<TripRequest>>(payload)
        return o
    }

    //Each
    @Test
    fun prepareRoute(){
        setAccountContext()

        val payloadRoute = getPayload("trip/trip.json").replace("route_name", "Rota TESTE ATOS ${java.time.LocalDateTime.now()}")

        val routeEntity = routeService.save(createRouteRequest(payloadRoute))

        val routeId = routeEntity.id
        val payloadTrip =
            """
            [
                {
                    "assetId": "${assetId}",
                    "driverId": "${driverId}",
                    "startDateTime": "2023-02-09T09:30:00.00000Z",
                    "routeId": "${routeId}"
                }
            ]
            """

//"${startDateTimeTrip}",

        val tripEntities = tripService.save(createTripRequest(payloadTrip))
    }

    @Test
    fun testVelocity() {
        val original = getIotMessage()
        val m = original.copy(
            position = original.position?.copy(
                latitude = -23.58144,
                longitude = -46.4421,
                speed = 400.0
            )
        )

        //infringementDetection.start(m)
    }

    @Test
    fun testStartUnscheduleStop() {
        val original = getIotMessage()
        val m = original.copy(
            occurredAt = OffsetDateTime.parse("2023-02-10T19:50:00.761Z"),
            position = original.position?.copy(
//                ORIGINAL P12
//                latitude = -23.58144,
//                longitude = -46.4421,

//                Alteração
                latitude = -23.58087,
                longitude = -46.44238,
                speed = 0.0
            )
        )

        //infringementDetection.start(m)
    }
    @Test
    fun testStayUnscheduleStop() {
        val original = getIotMessage()
        val m = original.copy(
            occurredAt = OffsetDateTime.parse("2023-02-10T19:55:00.761Z"),
            position = original.position?.copy(
//                ORIGINAL P12
//                latitude = -23.58144,
//                longitude = -46.4421,

//                Alteração
                latitude = -23.58087,
                longitude = -46.44238,
                speed = 0.0
            )
        )

        //infringementDetection.start(m)
    }


    @Test
    fun testEndUnscheduleStop() {
        val original = getIotMessage()
        val m = original.copy(
            occurredAt = OffsetDateTime.parse("2023-02-10T19:57:00.761Z"),
            position = original.position?.copy(
//                ORIGINAL P12
//                latitude = -23.58144,
//                longitude = -46.4421,

//                Alteração
                latitude = -23.58073,
                longitude = -46.44241,
                speed = 15.0
            )
        )

        //infringementDetection.start(m)
    }


//    @Test
//    fun testRouteDeviation() {
//        val original = getIotMessage()
//        val m = original.copy(
//            position = original.position?.copy(
//                latitude = -23.58144,
//                longitude = -46.4421,
//                speed = 60.0
//            )
//        )
//
//        infringementDetection.start(m)
//    }



}