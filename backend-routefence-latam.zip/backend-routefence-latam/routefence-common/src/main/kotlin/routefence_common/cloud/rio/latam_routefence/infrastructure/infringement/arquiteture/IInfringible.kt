package routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture

import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO

interface IInfringible {
    fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest?
}