package cloud.rio.latam_routefence.domain.api

interface RoutefenceBaseApi {
    companion object {
        const val testCrossOriginURL = "http://localhost:3000"
        const val prodCrossOriginURL = "https://geo.latam-maintenance.rio.cloud"
        const val prodCrossOriginURL2 = "https://api.geo.latam-maintenance.rio.cloud"
    }
}