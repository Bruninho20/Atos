/**
 * This file is empty, but necessery to 'src/__mocks_/rio-uikit.js' work
 */
import '@testing-library/jest-dom/extend-expect';
import IntlPolyfill from 'intl';
import './features/translations/pt-BR.json';

const setupTests = () => {
  // https://formatjs.io/guides/runtime-environments/#server
  if (global.Intl) {
    Intl.NumberFormat = IntlPolyfill.NumberFormat;
    Intl.DateTimeFormat = IntlPolyfill.DateTimeFormat;
  } else {
    global.Intl = IntlPolyfill;
  }
};

setupTests();
