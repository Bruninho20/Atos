package routefence_common.cloud.rio.latam_routefence.domain.response.here.calculateRoute

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Warnings(
    @JsonProperty("code") var code: Int?,
    @JsonProperty("message") var message: String?,
    @JsonProperty("routeLinkSeqNum") var routeLinkSeqNum: Int?,
    @JsonProperty("tracePointSeqNum") var tracePointSeqNum: Int?,
    @JsonProperty("toTracePointSeqNum") var toTracePointSeqNum: Int?,
    @JsonProperty("duration") var duration: Int?
)