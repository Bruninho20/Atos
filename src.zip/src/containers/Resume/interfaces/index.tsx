export interface Route {
    addressStop: any
    address: any
    id: string
    lat: string
    lng: string
  }

  export interface Geolocation {
    lat: string
    lng: string
  }
  
  export interface PdisDetailsModel {
    data: any
    geolocation: Geolocation,
    shape: any
    vehicleVocationalInfo: any
    address: any
    addressStop: any
    roles: string
    status: string
    date: string
    routeName: string
    originRoute: Route
    destinyRoute: Route
    rangeToleranceLimit: string
    stops: StopModel
    range: RangeModel
    vehicle: VehicleModel
    costs: CostsModel
    linkedVehicles: any
    startTime: string
    rangeToleranceLimite: string
    responseHere: any
  }
  
  export interface RouteModel {
    roles: string
    status: string
    date: string
    routeName: string
    originRoute: string
    destinyRoute: string
    rangeToleranceLimit: string
  }
  
  export interface StopModel {
    addressStop: any
    id: string
    position: any
    stopName: string
    stopCategory: string
    address: any
    rangeLimitMeters: string
    stayTime: string
  }
  
  export interface RangeModel {
    id: string
    trafficConditions: string
    avoidToll: string
    avoidRoad: string
    ignoreTrafficRestrictions: string
  }
  
  export interface VehicleModel {
    type: string
    comTotal: string
    height: string
    width: string
    maxWeight: string
    maxWeightAxle: string
    numberAxle: string
    trailerAxle: string
    pollutantClass: string
    dangerClassification: string
  }
  
  export interface CostsModel {
    tollValue: string
    operativeCosts: string
    fuelAverageCosts: string
    averageConsume: string
    totalCosts: string
  }

  export interface FaultCodeModel {
    name: string
    date: string
    fmi: string
    fmiDescription: string
    lampStatus: string
    latitude: string
    longitude: string
    sourceAddress: string
    spn: string
    spnDescription: string
    description: string
    roles: string
    status: string
    routeName: string
    originRoute: string
    destinyRoute: string
    rangeToleranceLimit: string
    stop: StopModel
    stopName: string
    stopCategory: string
    addressStop: string
    rangeLimitMeters: string
    stayTime: string
    category: string
    // }
    roadParameters: RangeModel
    trafficConditions: string
    avoidToll: string
    avoidRoad: string
    ignoreTrafficRestrictions: string
    // }
    vehicle: VehicleModel
    type: string
    comTotal: string
    height: string
    width: string
    maxWeight: string
    maxWeightAxle: string
    numberAxle: string
    trailerAxle: string
    pollutantClass: string
    dangerClassification: string
    // }
    costs: CostsModel
    tollValue: string
    operativeCosts: string
    fuelAverageCosts: string
    averageConsume: string
    totalCosts: string
    // }
  }