import styled, { css } from 'styled-components';
import { colors, metrics } from 'core/assets/styles';

import { EmptyState, ErrorState } from 'rio-uikit';

const StyledState = css`
  display: flex;
  justify-content: center;
  h3 {
    font-size: ${metrics.fontSizeLarge};
  }
  p {
    font-size: ${metrics.fontSizeDefault};
    margin: 0;
  }
`;

export const EmptyStateStyled = styled(EmptyState || 'div')`
  ${StyledState}
`;
export const ErrorStateStyled = styled(ErrorState || 'div')`
  ${StyledState}
`;

export const Content = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  height: auto;
  padding: ${metrics.basePadding};

  & p {
    color: ${colors.blackMedium};
    font-size: ${metrics.fontSizeTitle};
    text-align: center;
  }

  & svg {
    fill: ${colors.lightGray};
    margin-bottom: ${metrics.baseSmallPadding};
  }
`;

export const ShortPlaceholder = styled.div`
  align-items: center;
  background-color: ${colors.white};
  border-color: ${colors.borderDefault};
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  height: auto;
  padding: ${metrics.basePadding};

  & p {
    color: ${colors.blackMedium};
    font-size: ${metrics.fontSizeTitle};
    text-align: center;
  }

  & svg {
    fill: ${colors.lightGray};
    margin-bottom: ${metrics.baseSmallPadding};
  }
`;
