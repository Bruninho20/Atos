package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import routefence_common.cloud.rio.latam_routefence.domain.response.here.calculateRoute.Response
import com.fasterxml.jackson.annotation.JsonProperty

data class ResponseHereLayer(
    @JsonProperty("response") var response: Response?
)
