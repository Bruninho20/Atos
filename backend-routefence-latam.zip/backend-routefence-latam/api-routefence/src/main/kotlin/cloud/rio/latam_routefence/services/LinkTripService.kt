package cloud.rio.latam_routefence.services

import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.GeoPointEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.TripEntity
import java.net.URLEncoder
import java.nio.charset.Charset

@Component
@Transactional
class LinkTripService {
    fun createLinkTrip(trip: TripEntity): String {
        val sb = StringBuilder()

        sb.append("wego.here.com/directions/drive")
        sb.append(formatGeoPointToLink(trip.route.geoPointOrigin))

        for (routeStop in trip.route.stops ?: emptyList()){
            routeStop.stop?.let { stopEntity ->
                stopEntity.position?.let { geoPoint ->
                    sb.append(formatGeoPointToLink(geoPoint))
                }
            }
        }

        sb.append(formatGeoPointToLink(trip.route.geoPointDestiny))

        return "http://$sb"
    }

    private fun formatGeoPointToLink(g: GeoPointEntity) : String{
        val linkParam = "${g.address?.label}:${g.lat},${g.long}"
        val completeLink = "/${URLEncoder.encode(linkParam, Charset.defaultCharset())}"

        return completeLink
    }

    //TODO https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-309
    //TODO Remover
/*    fun sendLinkTrip(trip: TripEntity, token: InternalAuthResponse? = null) {
        trip.driverId?.let {driverId ->
            val driver = driverService.getById(driverId, token)

            var message = ""

            //TODO Ajustar número de telefone de driver
            val number: String = driver.phone_number ?: "+5524988674830"

            if (driver.phone_number == null) {
                //            throw RoutefenceException.RoutefenceNotFoundException("Driver.phone.inexistent", arrayOf(trip.driverId))
                //TODO Remover codigo abaixo e descomentar o lançamento de exceção
                val ex = RoutefenceException.RoutefenceNotFoundException("Driver.phone.inexistent", arrayOf(driverId))
                println(ex.message)
                message += "__"
            }



            // TODO Teste de marcação de processamento de mensagem
            if(trip.route.routeName.lowercase().startsWith("erro"))
                throw RoutefenceException.RoutefenceInternalException("Error.retrieving.data", arrayOf(trip.route.routeName))
            // TODO Teste de marcação de processamento de mensagem



            // TODO Preparar link. Necessário criar URL dinâmica ou chumbada no
            //  código e, inevitávelmente encurtar a url enviada
            //  Criar endpoint de detalhamento de viagem
            val link = createLinkTrip(trip)

            val completeLink = "http://$link"
//            var encLink = URLEncoder.encode(link, Charset.defaultCharset())
            println("O link01 gerado foi: $link")
//            println("O enclink gerado foi: $encLink")

            message += "ROUTEFENCE: Inicie sua viagem agendada. ${completeLink}"// - ${trip.route.routeName}"
            //        number = driver.phone_number.toString()

            println(
"""
*****************************************************************************************
**********************************      SMS MESSAGE     *********************************
*****************************************************************************************

Number: $number
Link: $completeLink
Message: $message

*****************************************************************************************
*****************************************************************************************
""".trimIndent())
            try {
                AwsSns().sendNotification(message, number)
            }catch (e: Exception){
                println("************************************   AWS - SNS   **************************************")
                println("AwsSws.sendNotification não funcionou!")
                println(e.message)
                println("*****************************************************************************************")
            }
        }
    }*/
}