package routefence_common.cloud.rio.latam_routefence.domain.response.routing

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Summary(
    @JsonProperty("duration") val duration: Long?,
    @JsonProperty("length") val length: Long?,
    @JsonProperty("baseDuration") val baseDuration: Long?
)
