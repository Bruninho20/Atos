import React, { FC, useState } from 'react'
import axios from 'axios'
import { Dialog } from 'rio-uikit'
import { useForm } from 'react-hook-form'
import { ModalForm } from './styled'

interface DialogtFaultCodesProps {
  title: string
  isOpen: boolean
  onClose: () => void
  type: string
  getLatLng: (value: object, type: string, points?: any) => void
  // onChange: () => void
}

const AddressDialog: FC<DialogtFaultCodesProps> = ({ title, isOpen, onClose, type, getLatLng }) => {
  const { setValue, register, reset } = useForm()
  const [postalCode, setPostalCode] = useState('')
  const [address, setAddress] = useState('')
  const [number, setNumber] = useState('')
  const [state, setState] = useState('')
  const [country, setCountry] = useState('')
  const [cep, setCep] = useState('')

  const handleCep = (e: any) => {
    setCep(e)
    const cep = e?.replace(/[^0-9]/g, '')

    if (cep?.length !== 8) {
      return
    }

    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(res => res.json())
      .then(data => {
        setValue('postalCode', data.numero)
        setValue('number', data.cep)
        setValue('address', data.logradouro)
        setValue('district', data.bairro)
        setValue('city', data.localidade)
        setValue('state', data.uf)
        setPostalCode(data.cep)
        setAddress(data.logradouro)
        setState(data.uf)
        setCountry(data.pais)
      })
  }

  const formatCep = (cpf: string) => {
    return cpf
      .replace(/\D/g, '')
      .replace(/[^0-9]/g, '')
      .replace(/(\d{5})(\d{3})/, '$1-$2')
  }

  const handleSaveClose = () => {
    axios
      .get(
        `https://geocode.search.hereapi.com/v1/geocode?q=${number}+${address}%2C+${postalCode}+${state}%2C+${country}&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`
      )
      .then((result: any) => {
        getLatLng(result.data.items[0], `${type}`)
      })
    onClose()
    reset()
    setCep('')
  }

  const handleOnCloseButton = () => {
    onClose()
    reset()
    setCep('')
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Dialog
        show={isOpen}
        title={title}
        body={
          <div style={{ height: 'auto', alignItems: 'center' }}>
            <ModalForm>
              <form>
                <div className='row g-3'>
                  <div className='col-md-4'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>CEP</span>
                    <input
                      value={cep}
                      autoComplete='nope'
                      onChange={(e: any) => handleCep(formatCep(e.target.value))}
                      maxLength={9}
                      id='cpf'
                      type='text'
                      name='cep'
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-6'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Endereço</span>
                    <input
                      {...register('address', {
                        required: {
                          value: true,
                          message: 'aaaa'
                        },
                        minLength: {
                          value: 9,
                          message: 'aaaa'
                        }
                      })}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}            
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Número</span>
                    <input
                      //   {...register('number', {
                      //     required: {
                      //         value: true,
                      //         message: 'aaaa'
                      //     },
                      //     minLength: {
                      //         value: 9,
                      //         message: 'aaaa'
                      //     },
                      // })}
                      autoComplete='nope'
                      onChange={e => setNumber(e.target.value)}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
                <div className='row g-3' style={{ marginTop: 8 }}>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Bairro</span>
                    <input
                      {...register('district', {
                        required: {
                          value: true,
                          message: 'aaaa'
                        },
                        minLength: {
                          value: 9,
                          message: 'aaaa'
                        }
                      })}
                      autoComplete='nope'
                      onBlur={(e: any) => handleCep(e)}
                      id='cpf'
                      type='text'
                      name='cep'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-5'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Cidade</span>
                    <input
                      {...register('city', {
                        required: {
                          value: true,
                          message: 'aaaa'
                        },
                        minLength: {
                          value: 4,
                          message: 'aaaa'
                        }
                      })}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}
                      id='cpf'
                      type='text'
                      name='address'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                  <div className='col-md-2'>
                    <span style={{ fontSize: 14, fontWeight: 600 }}>Estado</span>
                    <input
                      {...register('state', {
                        required: {
                          value: true,
                          message: 'aaaa'
                        },
                        minLength: {
                          value: 2,
                          message: 'aaaa'
                        }
                      })}
                      autoComplete='nope'
                      // onChange={(e) => form.setValue("cpf", formatCpf(e.target.value))}
                      maxLength={14}
                      id='cpf'
                      type='text'
                      name='number'
                      // placeholder={t('common:inputs.cpf')}
                      className='form-control'
                    />
                  </div>
                </div>
              </form>
            </ModalForm>
          </div>
        }
        footer={
          <div>
            <button type='button' style={{ marginRight: '10px' }} className='btn btn-default' onClick={handleSaveClose}>
              Cancelar
            </button>
            <button type='button' className='btn btn-primary' onClick={handleSaveClose}>
              Salvar
            </button>
          </div>
        }
        bsSize={Dialog.SIZE_MD}
        onHide={handleOnCloseButton}
        showCloseButton={true}
      />
    </div>
  )
}

export default AddressDialog
