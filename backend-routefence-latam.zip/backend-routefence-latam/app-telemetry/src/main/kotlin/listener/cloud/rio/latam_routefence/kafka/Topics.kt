package listener.cloud.rio.latam_routefence.kafka

class Topics {
    companion object {
        const val ASSET_IOTEVENT_TOPIC = "rio.asset-iot-events.rio-brazil"
        const val AGGREGATION_GROUP_ID = "backend.routefence"
    }
}