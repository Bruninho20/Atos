package routefence_common.cloud.rio.latam_routefence.domain.request

data class CostsRequest (
    var id: String? = null,
    var tollValue: String? = null,
    var operativeCosts: String? = null,
    var totalCosts: String? = null,
    var fuelAverageCosts: String? = null,
    var averageConsume: String? = null
)
