package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.repositories.RouteRepository
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.data.domain.Sort
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.mapper.*
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.time.LocalDateTime
import java.sql.Timestamp
import java.time.Instant
import java.util.*

@Service
@Transactional
class RouteService(
    private val routeRepository: RouteRepository,
    private val stopService: StopService,
    private val tripService: TripService,
    private val hereService: HereService
) {

    fun save(routeRequest: RouteRequest): RouteEntity {
        val accountId = AccountContext.get()
        if (routeRepository.existsRouteNameByAccountId(accountId, routeRequest.routeName!!)) {
            throw RoutefenceException.RoutefenceInvalidPayloadException(
                "Invalid.route.name",
                arrayOf(routeRequest.routeName!!)
            )
        }

        routeRequest.accountId = accountId
        val routeEntityMappedByRequest = routeRequest.mapToEntity()
        val savedRoute = routeRepository.saveAndFlush(routeEntityMappedByRequest)

        val routeStopListSaved = stopService.saveAllToRoute(routeRequest, savedRoute)
        tripService.createTrips(routeRequest.trips, savedRoute, routeStopListSaved)
        routeRepository.flush()

        savedRoute.stops = routeStopListSaved

        hereService.generateWktFiles(savedRoute)
        return savedRoute
    }

    @Transactional(readOnly = true)
    fun findAll(pageNo: Int, pageSize: Int, sortBy: String, routeName: String?): List<RouteEntity> {
        val paging: Pageable = PageRequest.of(pageNo, pageSize, Sort.by(sortBy))

        val pagedResult: Page<RouteEntity> = if (routeName != null) {
            routeRepository.findRouteByRouteName(paging, routeName, AccountContext.get())
        } else {
            routeRepository.findRoutes(paging, AccountContext.get())
        }

        if (pagedResult.hasContent()) {
            return pagedResult.content
        } else {
            return mutableListOf()
        }
    }

    fun findById(id: String): RouteEntity {
        return routeRepository.findById(id).orElseThrow {
            RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(id))
        }
    }

    @Transactional
    fun delete(id: String) {
        val route = routeRepository.findById(id).orElseThrow {
            RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(id))
        }
        if (route.deletionDate != null)
            throw RoutefenceException.RoutefenceInvalidPayloadException("Route.already.deleted")

        tripService.deleteTripsByRoute(route)
        route.deletionDate = LocalDateTime.now()

        routeRepository.save(route)
        routeRepository.flush()
    }

    @Transactional
    fun deleteByIdForTests(id: String) {
        val route = routeRepository.findById(id).orElseThrow {
            RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(id))
        }

        routeRepository.delete(route)
    }

    fun update(id: String, route: RouteRequest): RouteEntity {
        val routeEntity = routeRepository.findById(id).orElseThrow {
            RoutefenceException.RoutefenceNotFoundException("Route.not.found", arrayOf(id))
        }

        if (routeEntity.deletionDate != null)
            throw RoutefenceException.RoutefenceInvalidPayloadException("Route.not.found", arrayOf(id))

        // para edição de trip
        // checar de trip pertence a esta rota
        // checar o status dela e das outras
        // caso todas estejam SCHEDULED, editar rota
        // caso ela esteja SCHEDULED e qualquer outra não, duplicar rota, e atrelar a trip na nova rota
        // caso ela esteja STARTED, duplicar rota, criar nova trip e interromper a viagem editada (IMPORTANTE! EDITAR TRIP TORNA OBRIGATORIO O PREENCHIMENTO DO ASSET E HORA NO FRONT)

        val sameResponseHere = route.responseHere == routeEntity.responseHere
        val isEditTrip = route.tripToEdit != null

        val tripToEdit = routeEntity.trips?.firstOrNull { trip -> trip.id == route.tripToEdit?.id }
        val isFromThisRoute = tripToEdit != null

        if (!isFromThisRoute && route.tripToEdit?.id != null) {
            throw RoutefenceException.RoutefenceNotFoundException(
                "No.trip.found.on.this.route",
                arrayOf(route.tripToEdit?.id ?: "", id)
            )
        }

        if (tripToEdit?.status != TripStatusEnum.SCHEDULED && tripToEdit?.status != TripStatusEnum.STARTED && isEditTrip) {
            throw RoutefenceException.RoutefenceBusinessException(
                "Trip.cannot.be.edited",
                arrayOf(tripToEdit?.id ?: "")
            )
        }

        val tripNotScheduled = routeEntity.trips?.firstOrNull { trip -> trip.status != TripStatusEnum.SCHEDULED }
        val canEdit = tripNotScheduled == null

        // DUPLICA
        if (canEdit) {
            routeEntity.copyFromRequest(route)
            if (!sameResponseHere) hereService.generateWktFiles(routeEntity)
            routeEntity.stops = stopService.editStops(route, routeEntity)
            routeEntity.lastChangeDate = LocalDateTime.now()
            if (tripToEdit != null)
                tripService.updateTrip(tripToEdit.id!!, route.tripToEdit!!)
            return routeEntity
        } else {
            val routeDuplicated = route.mapToDuplicatedEntity(routeEntity, sameResponseHere)
            val routeSaved = routeRepository.save(routeDuplicated)
            routeSaved.stops = stopService.duplicateStops(route, routeEntity, routeSaved)
            if (!sameResponseHere) hereService.generateWktFiles(routeSaved)
            routeEntity.lastChangeDate = LocalDateTime.now()

            if (tripToEdit != null) {
                route.tripToEdit?.routeId = routeSaved.id
                if (tripToEdit.status == TripStatusEnum.STARTED) {
                    route.tripToEdit?.id = null
                    route.tripToEdit?.let { tripService.save(it) }
                    tripToEdit.status = TripStatusEnum.INTERRUPTED
                    tripToEdit.finishedAt = LocalDateTime.now()
                } else if (tripToEdit.status == TripStatusEnum.SCHEDULED) {
                    tripService.updateTrip(tripToEdit.id!!, route.tripToEdit!!)
                } else {
                    throw RoutefenceException.RoutefenceBusinessException(
                        "Trip.cannot.be.edited",
                        arrayOf(tripToEdit.id ?: "")
                    )
                }
            }

            return routeSaved
        }
    }
}