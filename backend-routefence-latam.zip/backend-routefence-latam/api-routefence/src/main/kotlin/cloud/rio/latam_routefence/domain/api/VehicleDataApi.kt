package cloud.rio.latam_routefence.domain.api

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleDataResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.VehicleResponse

@RequestMapping("/vehicles")
interface VehicleDataApi:RoutefenceBaseApi {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/decode-vin")
    fun decodeChassis(@RequestParam("chassis") chassis: String,
        @RequestParam("emissionType") emissionType: String
    ): VehicleResponse


    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/information")
    fun findVehicleByCode(@RequestParam("chassis") chassis: String, ): VehicleDataResponse?

}