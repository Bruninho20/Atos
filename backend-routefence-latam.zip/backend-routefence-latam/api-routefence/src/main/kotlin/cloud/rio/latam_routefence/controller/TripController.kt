package cloud.rio.latam_routefence.controller

import cloud.rio.latam_routefence.domain.api.TripApi
import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import cloud.rio.latam_routefence.domain.response.TripResponse
import cloud.rio.latam_routefence.domain.response.TripResumeResponse
import cloud.rio.latam_routefence.infrastructure.mapper.mapToResponse
import cloud.rio.latam_routefence.services.TripService
import org.springframework.web.bind.annotation.RestController
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.TripRequest

@RestController
class TripController(private val tripService: TripService) : TripApi {

    override fun saveTrip(trips: Collection<TripRequest>): Collection<TripResponse> {
        var tripsResponse = mutableListOf<TripResponse>()
        tripService.save(trips).forEach {
            tripsResponse.add(it.mapToResponse())
        }
        return tripsResponse
    }

    override fun getAllResume(
        orderBy: String?,
        search: String?,
        page: Int?,
        pageSize: Int?,
        status: TripStatusEnum?
    ): BaseCollectionResponse<TripResumeResponse> {
        val tripsResume = tripService.findAllResume(orderBy, search, page, pageSize, status)
        return BaseCollectionResponse(tripsResume, tripsResume.size)
    }

    override fun getOneTrip(id: String): TripResponse? {
        return tripService.findTripById(id).mapToResponse()
    }

    override fun updateOneTrip(
        id: String,
        tripRequest: TripRequest
    ): TripResponse? {
        return tripService.updateTrip(id, tripRequest)?.mapToResponse()
    }

    override fun delete(id: String) {
        tripService.deleteTrip(id)
    }

//TODO Remover endpoint de start manual de viagem qwuando implementado o start automático
// https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-362
    override fun startTrip(id: String): TripResponse? {
        val trip = tripService.findTripById(id)
        return tripService.startTrip(trip).mapToResponse()
    }
}