import styled from 'styled-components';
import { Tree } from 'rio-uikit';
import { metrics } from 'core/assets/styles';

export const StyledTree = styled(Tree)`
  .TreeHeader {
    .TreeHead {
      padding: ${metrics.baseMargin};
    }
  }

  .TreeLabelCount {
    font-size: 11px;
  }
`;
