import React, { FC, useState, useEffect, useContext } from 'react'
import { InputCurrency, Button, Spinner } from 'components'
import { Col, Row, Table } from 'react-bootstrap'
import { accessToken } from 'configuration/tokenHandling/accessToken'
import {
  ClearableInput,
  SimpleButtonDropdown,
  Slider,
  Checkbox,
  ExpanderPanel,
  Notification,
  DatePicker
} from 'rio-uikit'
import { useForm } from 'react-hook-form'
import axios from 'axios'
import moment from 'moment'
import { useHistory } from 'react-router-dom'
import { calculateTolls } from 'core/utils/calculateTolls'
import DashboardContext from 'core/DashboardContext'

interface EditTripProps {
  handleOpenAddressDialog: (value: any, type: string, open: boolean) => void
  handleOpenAddVehiclesDialog: (open: boolean) => void
  handleAddStops: (stops: any | never) => void
  handleChangeMode: (type: string) => void
  handleOpenStopDialog: () => void
  handleUpdateParameters: (routeParameters: any) => void
  setOpenConfirm: (type: string) => void
  data: any
  path: string
}

const classDangerousOptions = [
  { value: 'Selecione', label: 'Selecione' },
  { value: 'EXPLOSIVO', label: 'EXPLOSIVO' },
  { value: 'CLASSE 2 - GASES', label: 'CLASSE 2 - GASES' },
  { value: 'CLASSE 3 - LÍQUIDOS INFLAMÁVEIS', label: 'CLASSE 3 - LÍQUIDOS INFLAMÁVEIS' },
  { value: 'INFLAMÁVEL', label: 'INFLAMÁVEL' },
  {
    value: 'CLASSE 5 - SUBSTÂNCIAS (OXIDANTES) INFLAMÁVEIS, PERÓXIDO ORGÂNICO',
    label: 'CLASSE 5 - SUBSTÂNCIAS (OXIDANTES) INFLAMÁVEIS, PERÓXIDO ORGÂNICO'
  },
  { value: 'PRODUTOS TÓXICOS', label: 'PRODUTOS TÓXICOS' },
  { value: 'RADIOATIVO', label: 'RADIOATIVO' },
  { value: 'SUBSTÂNCIAS CORROSIVAS', label: 'SUBSTÂNCIAS CORROSIVAS' },
  { value: 'TÓXICO EM CASO DE INALAÇÃO', label: 'TÓXICO EM CASO DE INALAÇÃO' },
  { value: 'POLUENTE PARA A AGUA', label: 'POLUENTE PARA A AGUA' },
  { value: 'DIVERSOS', label: 'DIVERSOS' }
]

const EditTrip: FC<EditTripProps> = ({
  handleOpenAddressDialog,
  data,
  handleChangeMode,
  handleOpenAddVehiclesDialog,
  handleAddStops,
  handleUpdateParameters,
  handleOpenStopDialog,
  setOpenConfirm,
  path
}) => {
  const history = useHistory()
  const { setValue, getValues, handleSubmit, register } = useForm()
  const {
    linkedVehiclesContext,
    setLinkedVehiclesContext,
    setOriginRouteContext,
    setDestinyRouteContext,
    setAllStopsContext,
    originRouteContext,
    destinyRouteContext,
    // avoidPointsContext,
    setAvoidPointsContext,
    setResponseHereContext,
    allStopsContext,
    vehicleVocacionalContext,
    setVehicleVocacionalContext,
    costsContext,
    setCostsContext,
    roadParametersContext,
    setRoadParametersContext,
    setRouteContext,
    routeContext,
    responseHereContext
  } = useContext(DashboardContext)
  const [loading, setLoading] = useState(false)
  const [limitMeters, setLimitMeters] = useState(0)
  // const [totalCostsValue, setTotalCostsValue] = useState<any>()
  const [stopArray, setStopArray] = useState<any>([])
  const [nameStopRecent, setNameStopRecent] = useState('')
  const [typeStopRecent, setTypeStopRecent] = useState('')
  const [stopTime, setStopTime] = useState('')
  // const [startTime, setStartTime] = useState('')
  const [activeRoute, setActiveRoute] = useState(true)
  const [addressStopRecent, setAddressStopRecent] = useState('')
  const [calcLoading, setCalcLoading] = useState(false)
  const [registerData] = useState<any>({
    routeName: '',
    originRoute: {
      lat: '',
      lng: '',
      address: ''
    },
    destinyRoute: {
      lat: '',
      lng: '',
      address: ''
    },
    rangeToleranceLimit: ' ',
    // startDateTime: startTime,
    stops: [],
    roadParameters: {
      trafficConditions: false,
      avoidToll: false,
      avoidRoad: false,
      ignoreTrafficRestrictions: false
    },
    vehicleVocationalInfo: {
      type: ' ',
      comTotal: ' ',
      height: ' ',
      width: ' ',
      maxWeight: ' ',
      maxWeightAxle: ' ',
      numberAxle: ' ',
      trailerAxle: ' ',
      pollutantClass: ' ',
      dangerClassification: ' '
    },
    costs: {
      tollValue: ' ',
      operativeCosts: ' ',
      fuelAverageCosts: ' ',
      averageConsume: ' ',
      totalCosts: ' '
    }
    // avoidArea: []
  })

  console.log(data, 'DATA NO SIDESHEET EDIT TRIP')

  useEffect(() => {
    setAddressStopRecent(data?.stops?.address?.label)
  }, [data.stops])

  useEffect(() => {
    setLinkedVehiclesContext([])
    setAvoidPointsContext([])
    setAllStopsContext([])
    setOriginRouteContext({})
    setDestinyRouteContext({})
    setVehicleVocacionalContext({})
    setCostsContext({})
    setResponseHereContext({})
    setAvoidPointsContext([])
    setRouteContext({})
  }, [])

  const handleSaveStop = () => {
    const body = {
      name: nameStopRecent,
      category: getValues('stopCategory'),
      rangeLimitMeters: limitMeters,
      stayTime: moment(stopTime).format('HH:mm'),
      position: {
        lat: data?.stops?.position?.lat,
        lng: data?.stops?.position?.lng,
        address: data?.stops?.address
      }
    }

    handleAddStops([...stopArray, body])

    setStopArray([...stopArray, body])
    setNameStopRecent('')
    setAddressStopRecent('')
    setLimitMeters(0)
    setStopTime('00:00')
    setTypeStopRecent('')
  }

  const verifyVehicleType = (vehicleType: string) => {
    switch (vehicleType) {
      case 'TOW_40T_TRUCK':
        return 'CAMINHÃO E REBOQUE 40T'
      case 'TRUCK_11T':
        return 'CAMINHÃO 11T'
      case 'TRUCK_7_5T':
        return 'CAMINHÃO 7.5T'
      case 'TRUCK_3_5T':
        return 'VEÍCULO 3.5T'
      case 'CAR':
        return 'CARRO'
      default:
        return 'Selecione'
    }
  }

  useEffect(() => {
    setStopArray(data?.allStops)
    setValue('allStops', data?.allStops)
  }, [data])

  useEffect(() => {
    setValue('originRouteData', originRouteContext)
    setValue('destinyRouteData', destinyRouteContext)
  }, [data])

  const cloneObject = (object: any) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  const handleDeleteStopRow = (index: any) => {
    const cloneStopArray = cloneObject(allStopsContext)
    cloneStopArray.splice(index, 1)
    setStopArray(cloneStopArray)
    setAllStopsContext(cloneStopArray)
    handleAddStops(cloneStopArray)
  }

  const handleUpStop = (idx: any) => {
    const cloneStopArray = cloneObject(allStopsContext)
    if (idx - 1 >= 0) {
      var item = cloneStopArray[idx]
      var aux = cloneStopArray[idx - 1]
      cloneStopArray[idx - 1] = item
      cloneStopArray[idx] = aux
    }
    setAllStopsContext(cloneStopArray)
    setStopArray(cloneStopArray)
    handleAddStops(cloneStopArray)
  }
  const handleDownStop = (idx: any) => {
    const cloneStopArray = cloneObject(allStopsContext)
    if (idx + 1 < cloneStopArray.length) {
      var item = cloneStopArray[idx]
      var aux = cloneStopArray[idx + 1]
      cloneStopArray[idx + 1] = item
      cloneStopArray[idx] = aux
      setStopArray(cloneStopArray)
    }
    setAllStopsContext(cloneStopArray)
    setStopArray(cloneStopArray)
    handleAddStops(cloneStopArray)
  }

  const handleSaveRoute = async () => {
    setLoading(true)
    const body = {
      ...registerData,
      routeName: routeContext.routeName,
      originRoute: originRouteContext,
      destinyRoute: destinyRouteContext,
      status: activeRoute,
      // startDateTime: moment(startTime).subtract(3, 'hours').toISOString(),
      rangeToleranceLimit: routeContext.rangeToleranceLimit,
      stops: allStopsContext
        ?.map((value: any, index: any) => {
          return {
            category: value.category,
            name: value.name,
            position: {
              lat: value.position.lat,
              lng: value.position.lng,
              addressStop: value.position.address
            },
            rangeLimitMeters: value.rangeLimitMeters,
            stayTime: value.stayTime,
            order: index
          }
        }),
      roadParameters: {
        trafficConditions: roadParametersContext.trafficConditions,
        avoidToll: roadParametersContext.avoidToll,
        avoidRoad: roadParametersContext.avoidRoad,
        ignoreTrafficRestrictions: roadParametersContext.ignoreTrafficRestrictions
      },
      vehicleVocationalInfo: {
        type: vehicleVocacionalContext.type,
        comTotal: vehicleVocacionalContext.comTotal,
        height: vehicleVocacionalContext.height,
        width: vehicleVocacionalContext.width,
        maxWeight: vehicleVocacionalContext.maxWeight,
        maxWeightAxle: vehicleVocacionalContext.maxWeightAxle,
        numberAxle: vehicleVocacionalContext.numberAxle,
        trailerAxle: vehicleVocacionalContext.trailerAxle,
        pollutantClass: vehicleVocacionalContext.pollutantClass?.toUpperCase(),
        dangerClassification: vehicleVocacionalContext.dangerClassification?.toUpperCase()
      },
      costs: {
        tollValue: costsContext.tollValue ? String(costsContext.tollValue).replace(',', '.') : '0',
        operativeCosts: costsContext.operativeCosts ? String(costsContext.operativeCosts).replace(',', '.') : '0',
        fuelAverageCosts: costsContext.fuelAverageCosts ? String(costsContext.fuelAverageCosts).replace(',', '.') : '0',
        averageConsume: costsContext.averageConsume ? String(costsContext.averageConsume).replace(',', '.') : '0',
        totalCosts: costsContext.totalCosts ? String(costsContext.totalCosts).replace(',', '.') : '0'
      },
      linkedVehicles: linkedVehiclesContext?.map((value: any) => {
        return {
          assetId: value.id,
          driverId: value.driverSelected?.id,
          startDateTime: value.startDateTime
        }
      }),
      responseHere: responseHereContext
      // avoidArea: avoidPointsContext.slice(1)
    }

    if (!body.responseHere.routes) Notification.error('É necessário atualizar a rota para salvar')

    const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

    const customAcessToken = accessToken.getAccessToken()
    console.log(customAcessToken)

    var head = {
      headers: {
        Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpkYTcwMWU3OC1kODU0LTRmNjgtOGZhZS0yNzcyNGQwYjMwZDgiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MDExNjM1MSwiaWF0IjoxNjgwMTEyNzUxLCJqdGkiOiJ4U19zSzNWOFdjalR6a0FNN2gxSUw5MXFpZ2MiLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.xBEqitXr8y9t8U17J9C5uhif4epz6vRr8DHukxQr0ddLciFPhV3tmCKfpyEstSnMrslo_BzGJxpaOfDslGDtBRz561QNBYUUZK24jgP2-va2M-Iq3tzWfZ2nAMubvgJf27oQRLtxrXGsHdQhWy72yKbXCeqNtYlt_BgXlc3LB7ItO02aLuamcEe-YWqlNhdb_eYDDIx5_o4AuxT7DVxMRhNJfwcdtyZVZbaVCS_ghdg78NbXqrJsFWKxiswm1DX-hK7jnUkc9jNsgARtj3ojh4BepdkIJUxkZqWiNehM95Pb58v0yA6OJ6b92ID6gRgfOBPHUTS1PsfLv5PcDwq_m0W771DiUUxcKuJrOKYO6SkLqhkS2VBeQoNxHA1ZbW5Z2Z8HT5wakU-ScX4GBBoSNyYRm_7PaYum0b8j1z3Gr9YnURGyftpu_gSifcEiYh0IudmuNll2wXtc6H9FX0tQnbOYZ64jUnncKfScfJ0Zg_65Rr7CJ2iL8h6FQj8gUrjRTCOoLJaFHHH2Zvp_KDFdft6BoK3sBsfww3jDzKq53kOooMPO8S0QX0Aor_LcQ3xc4PUUBalH7cnBJBc91qnndKo6jr3KoDGomJpu7dDw3_7LqBxpqUVAOY8Au4E7pcS8imHc1rweqDAeSOEL1HZYY1y5JBSWNusgVqdXFkLViXQ`
      }
    }

    try {
      const res = await axios.post(`${baseURL}/routes/`, body, head)
      if (res.status === 200 || res.status === 201) {
        Notification.success('Rota criada com sucesso')
        history.push(`/pdis`)
        setLinkedVehiclesContext([])
        setAvoidPointsContext([])
        setAllStopsContext([])
        setOriginRouteContext({})
        setDestinyRouteContext({})
        setVehicleVocacionalContext({})
        setCostsContext({})
        setResponseHereContext({})
        setAvoidPointsContext([])
        setRouteContext({})
      } else {
        setLoading(false)
        Notification.error('Houve um erro ao criar a rota')
      }
    } catch (error) {
      setLoading(false)
      console.log(error, 'error')
    }
  }

  const handleBack = () => {
    setOpenConfirm('cancel')
  }

  const handleSelectVehicle = (type: string) => {
    if (type === 'TOW_40T_TRUCK') {
      setVehicleVocacionalContext({
        ...vehicleVocacionalContext,
        type: type,
        comTotal: 16.5,
        height: 4,
        width: 2.55,
        maxWeight: 40,
        numberAxle: 2,
        maxWeightAxle: 8.5,
        trailerAxle: 2
      })
    } else if (type === 'TRUCK_11T') {
      setVehicleVocacionalContext({
        ...vehicleVocacionalContext,
        type: type,
        comTotal: 10,
        height: 3.8,
        width: 2.55,
        maxWeight: 11,
        numberAxle: 2,
        maxWeightAxle: 5.5,
        trailerAxle: 0
      })
    } else if (type === 'TRUCK_7_5T') {
      setVehicleVocacionalContext({
        ...vehicleVocacionalContext,
        type: type,
        comTotal: 7.2,
        height: 3.4,
        width: 2.5,
        maxWeight: 7.5,
        numberAxle: 2,
        maxWeightAxle: 3.75,
        trailerAxle: 0
      })
    } else if (type === 'VEHICLE_3_5T') {
      setVehicleVocacionalContext({
        ...vehicleVocacionalContext,
        type: type,
        comTotal: 6.52,
        height: 2.55,
        width: 1.94,
        maxWeight: 3.5,
        numberAxle: 2,
        maxWeightAxle: 1.75,
        trailerAxle: 0
      })
    } else if (type === 'CAR') {
      setVehicleVocacionalContext({
        ...vehicleVocacionalContext,
        type: type,
        comTotal: 4.41,
        height: 1.67,
        width: 1.8,
        maxWeight: 1.739,
        numberAxle: 0,
        maxWeightAxle: 0,
        trailerAxle: 0
      })
    } else return
  }

  // useEffect(() => {
  //   const getCosts = async () => {
  //     if (originRouteContext.lat) {
  //       const res: any = await calculateTolls(getValues())
  //       setCostsContext({ ...costsContext, tollValue: res.tollValue, kmTotal: res.kmTotal })
  //     }
  //   }
  //   getCosts()
  // }, [vehicleSelected, avoidPointsContext, originRouteContext, destinyRouteContext])

  useEffect(() => {
    if (data?.linkedVehicles?.length > 0) {
      setActiveRoute(true)
    } else if (data?.linkedVehicles?.length < 1) {
      setActiveRoute(false)
    }
  }, [data])

  const onSubmit = () => {}

  const DummyRowDropdown = () => (
    <span>
      <SimpleButtonDropdown
        title={<span className='rioglyph rioglyph-option-vertical' />}
        bsStyle='link'
        iconOnly
        items={[
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-pencil margin-right-10' />
                <span>Edit</span>
              </div>
            )
          },
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-duplicate margin-right-10' />
                <span>Duplicate</span>
              </div>
            )
          },
          {
            value: (
              <div>
                <span className='rioglyph rioglyph-trash margin-right-10' />
                <span>Delete</span>
              </div>
            )
          }
        ]}
      />
    </span>
  )

  console.log(DummyRowDropdown)

  // const startTimeColapse = (
  //   <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
  //     <span style={{ fontSize: 14, fontWeight: 600 }}>Insira o horário</span>
  //     <DatePicker
  //       value={startTime}
  //       onChange={(e: any) => setStartTime(e)}
  //       inputProps={{ placeholder: 'Select Date' }}
  //     />
  //   </Row>
  // )

  // const categoryOptions = [
  //   { id: '1', label: 'DEALER' },
  //   { id: '2', label: 'ALMOÇO / DESCANSO' },
  //   { id: '3', label: 'FIM DE JORNADA DE TRABALHO' },
  //   { id: '4', label: 'CARGA / DESCARGA' }
  // ]

  const handleCalculateTotalCosts = () => {
    setCalcLoading(true)
    const getCosts = async () => {
      if (originRouteContext.lat) {
        const res: any = await calculateTolls({
          originRouteContext,
          destinyRouteContext,
          allStopsContext,
          vehicleVocacionalContext
        })
        if (res.status === 200) {
          setCalcLoading(false)

          const tollValue = Number(String(res?.sumTolls)?.replace(',', '.'))
          const operativeCosts = Number(String(costsContext?.operativeCosts)?.replace(',', '.'))
          const fuelAverageCosts = Number(String(costsContext?.fuelAverageCosts)?.replace(',', '.'))
          const averageConsume = Number(String(costsContext?.averageConsume)?.replace(',', '.'))

          const costsPerKm = (Number(res?.kmTotal) / 1000 / averageConsume) * fuelAverageCosts
          const total = tollValue + operativeCosts + costsPerKm
          setCostsContext({
            ...costsContext,
            totalCosts: Number(total).toFixed(2),
            tollValue: tollValue,
            kmTotal: res.kmTotal
          })
        } else {
          setCalcLoading(false)
        }
      }
    }
    getCosts()
  }

  const setStop = (
    <Row style={{ padding: 15 }}>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Nome Parada</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <ClearableInput value={nameStopRecent} onChange={(value: string) => setNameStopRecent(value)} />
        </div>
      </Row>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Categoria</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <select
            className='form-control'
            id='exampleFormControlSelect1'
            value={typeStopRecent}
            onChange={(e: any) => {
              setValue('stopCategory', e.target.value)
              setTypeStopRecent(e.target.value)
            }}>
            <option>Selecione</option>
            <option value='DEALER'>DEALER</option>
            <option value='LUNCH_REST'>ALMOÇO / DESCANSO</option>
            <option value='END_OF_DAY'>FIM DE JORNADA DE TRABALHO</option>
            <option value='LOAD_UNLOAD'>CARGA / DESCARGA</option>
          </select>
        </div>
      </Row>
      <span style={{ fontSize: 14, fontWeight: 600 }}>Endereço</span>
      <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
        <div className={'input-group'}>
          <input
            {...register('address', {
              required: {
                value: true,
                message: 'aaaa'
              },
              minLength: {
                value: 9,
                message: 'aaaa'
              }
            })}
            value={addressStopRecent}
            className='form-control'
            // onChange={(value: string) => console.log(value)}
            onClick={() => handleOpenAddressDialog('', 'stopsSidesheet', true)}
          />
        </div>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Raio</span>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Col md='8'>
          <Slider
            value={limitMeters}
            onDragEnd={(e: any) => {
              setLimitMeters(e)
            }}
            className='margin-bottom-40'
            minValue={0}
            maxValue={2000}
            step={5}
          />
        </Col>
        <Col md='4'>
          <div className={'input-group'}>
            <input
              type='text'
              defaultValue={0}
              value={limitMeters}
              onChange={(e: any) => setLimitMeters(e)}
              className='form-control'
              id='first'
              style={{ marginTop: -7 }}
            />
            <span className={'input-group-addon'} style={{ marginTop: -7 }}>
              <span aria-hidden={'true'}>m</span>
            </span>
          </div>
        </Col>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Tempo de Permanência</span>
      </Row>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <DatePicker value={stopTime} onChange={(e: any) => setStopTime(e)} dateFormat={false} />
      </Row>
      <Row style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, marginBottom: 20 }}>
        <Col md='6'>
          <Button label='Adicionar Parada' onClick={handleSaveStop} />
        </Col>
      </Row>
    </Row>
  )

  const rangeOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox
            inline
            checked={roadParametersContext.trafficConditions}
            onClick={() =>
              setRoadParametersContext({
                ...roadParametersContext,
                trafficConditions: !roadParametersContext.trafficConditions
              })
            }>
            Considerar condições de transito
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox
            inline
            checked={roadParametersContext.avoidToll}
            onClick={() =>
              setRoadParametersContext({ ...roadParametersContext, avoidToll: !roadParametersContext.avoidToll })
            }>
            Evitar pedágio
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox
            inline
            checked={roadParametersContext.avoidRoad}
            onClick={() =>
              setRoadParametersContext({ ...roadParametersContext, avoidRoad: !roadParametersContext.avoidRoad })
            }>
            Evitar Rodovia
          </Checkbox>
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Checkbox
            inline
            checked={roadParametersContext.ignoreTrafficRestrictions}
            onClick={() =>
              setRoadParametersContext({
                ...roadParametersContext,
                ignoreTrafficRestrictions: !roadParametersContext.ignoreTrafficRestrictions
              })
            }>
            Ignorar restrições em torno dos veículos
          </Checkbox>
        </Row>
      </Row>
    </>
  )

  const linkedVehicles = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10 }}>
          {linkedVehiclesContext?.length < 1 ? (
            <div></div>
          ) : (
            <div style={{ height: 200, overflow: 'scroll' }}>
              <Table striped bordered hover variant='dark'>
                <thead style={{ border: '1px solid' }}>
                  <tr>
                    <th style={{ fontSize: 14, fontWeight: 'bold' }}>Veículo</th>
                    <th style={{ fontSize: 14, fontWeight: 'bold' }}>Motorista</th>
                  </tr>
                </thead>
                <tbody>
                  {linkedVehiclesContext?.length < 1
                    ? ''
                    : linkedVehiclesContext?.map((item: any) => {
                        return (
                          <tr>
                            <td style={{ fontSize: 14 }}>
                              {item?.name?.length > 20 ? `${item?.name?.slice(0, 20)}...` : item?.name}
                            </td>
                            <td style={{ fontSize: 14 }}>
                              {item?.driverSelected?.name?.length > 20
                                ? `${item?.driverSelected?.name?.slice(0, 20)}...`
                                : item?.driverSelected?.name}
                            </td>
                          </tr>
                        )
                      })}
                </tbody>
              </Table>
            </div>
          )}
        </Row>
        <Row
          style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignContent: 'space-between' }}>
          <Button label='Adicionar veículo' onClick={() => handleOpenAddVehiclesDialog(true)} />
          <span style={{ fontSize: 14 }}>
            Total de Veículos: <b style={{ fontSize: 16 }}>{linkedVehiclesContext?.length}</b>
          </span>
        </Row>
      </Row>
    </>
  )

  const vehicleOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Tipo de Veículo</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              id='exampleFormControlSelect1'
              value={verifyVehicleType(vehicleVocacionalContext.type)}
              onChange={(e: any) => handleSelectVehicle(e.target.value)}>
              <option>
                {vehicleVocacionalContext.type !== ' ' ? verifyVehicleType(vehicleVocacionalContext.type) : 'Selecione'}
              </option>
              <option value='TOW_40T_TRUCK'>CAMINHÃO E REBOQUE 40T</option>
              <option value='TRUCK_11T'>CAMINHÃO 11T</option>
              <option value='TRUCK_7_5T'>CAMINHÃO 7.5T</option>
              <option value='VEHICLE_3_5T'>VEÍCULO 3.5T</option>
              <option value='CAR'>CARRO</option>
            </select>
          </div>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Com. total</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, comTotal: value })
                }
                value={vehicleVocacionalContext.comTotal}
              />
            </div>
          </Col>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Altura</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, height: value })
                }
                value={vehicleVocacionalContext.height}
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
              </span>
            </div>
          </Col>
          <Col md='4'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Largura</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) => setVehicleVocacionalContext({ ...vehicleVocacionalContext, width: value })}
                value={vehicleVocacionalContext.width}
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>m</span>
              </span>
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Peso max.</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, maxWeight: value })
                }
                value={vehicleVocacionalContext.maxWeight}
                type='number'
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>kg</span>
              </span>
            </div>
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Carga max. eixo</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, maxWeightAxle: value })
                }
                value={vehicleVocacionalContext.maxWeightAxle}
                type='number'
              />
              <span className={'input-group-addon'}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>kg</span>
              </span>
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Eixo de veículos</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, numberAxle: value })
                }
                value={vehicleVocacionalContext.numberAxle}
              />
            </div>
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Eixo de reboque</span>
            <div className={'input-group'}>
              <ClearableInput
                onChange={(value: string) =>
                  setVehicleVocacionalContext({ ...vehicleVocacionalContext, trailerAxle: value })
                }
                value={vehicleVocacionalContext.trailerAxle}
              />
            </div>
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Classe de emissão de poluentes</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              onChange={(e: any) =>
                setVehicleVocacionalContext({ ...vehicleVocacionalContext, pollutantClass: e.target.value })
              }
              value={vehicleVocacionalContext.pollutantClass}>
              <option>Selecione</option>
              <option value='EURO I'>EURO I</option>
              <option value='EURO II'>EURO II</option>
              <option value='EURO III'>EURO III</option>
              <option value='EURO IV'>EURO IV</option>
              <option value='EURO V'>EURO V</option>
              <option value='EURO VI'>EURO VI</option>
              <option value='EURO EEV'>EURO EEV</option>
              <option value='ELETRIC VEHICLES I'>VEÍCULO ELÉTRICO</option>
            </select>
          </div>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Classificação de perigos</span>
          <div className={'input-group'}>
            <select
              className='form-control'
              onChange={(e: any) =>
                setVehicleVocacionalContext({ ...vehicleVocacionalContext, dangerClassification: e.target.value })
              }
              value={vehicleVocacionalContext.dangerClassification}>
              <option>Selecione</option>
              {classDangerousOptions.map(item => {
                return <option value={item.value}>{item.label}</option>
              })}
            </select>
          </div>
          <div className={'input-group'}></div>
        </Row>
      </Row>
    </>
  )

  const costsOption = (
    <>
      <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Pedágio</span>
            <InputCurrency
              id='tollValue'
              name='tollValue'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              value={costsContext.tollValue}
              onValueChange={value => setCostsContext({ ...costsContext, tollValue: value === undefined ? 0 : value })}
            />
          </Col>
          <Col md='6'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Custo operacional</span>
            <InputCurrency
              id='operativeCosts'
              name='operativeCosts'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              value={costsContext.operativeCosts}
              onValueChange={value =>
                setCostsContext({ ...costsContext, operativeCosts: value === undefined ? 0 : value })
              }
            />
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, marginTop: 7 }}>
          <Col md='5'>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Combustivel Custo médio</span>
            <InputCurrency
              id='fuelAverageCosts'
              name='fuelAverageCosts'
              type='text'
              prefix={'R$ '}
              defaultValue={0}
              decimalsLimit={2}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              value={costsContext.fuelAverageCosts}
              onValueChange={value =>
                setCostsContext({ ...costsContext, fuelAverageCosts: value === undefined ? 0 : value })
              }
            />
          </Col>
          <Col md='2' style={{ marginTop: 40 }}>
            <span style={{ fontSize: 18, fontWeight: 600 }}>
              <b>X </b>1/
            </span>
          </Col>
          <Col md='5' style={{ marginTop: 20 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Consumo médio</span>
            <InputCurrency
              id='averageConsume'
              name='averageConsume'
              type='text'
              suffix=' km/l'
              defaultValue={0}
              decimalsLimit={0}
              allowDecimals={true}
              decimalSeparator=','
              groupSeparator='.'
              value={costsContext.averageConsume}
              onValueChange={value =>
                setCostsContext({ ...costsContext, averageConsume: value === undefined ? 0 : value })
              }
            />
          </Col>
        </Row>
        <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 7 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Custo Total</span>
          <InputCurrency
            id='totalCosts'
            name='totalCosts'
            type='text'
            prefix='R$ '
            decimalsLimit={2}
            allowDecimals={true}
            // value={totalCostsValue}
            decimalSeparator=','
            groupSeparator='.'
            value={costsContext.totalCosts}
            // onValueChange={(value: any) => setValue('totalCosts', value)}
          />
        </Row>
        <Row style={{ display: 'flex', justifyContent: 'space-between', marginTop: 30 }}>
          <Col md='6'>
            {calcLoading === true ? (
              <div
                style={{
                  width: '100%',
                  display: 'flex',
                  justifyContent: 'center',
                  alignContent: 'center'
                }}>
                <Spinner loading={calcLoading} fullscreen={false} />
              </div>
            ) : (
              <Button label='Calcular' onClick={handleCalculateTotalCosts} />
            )}
          </Col>
        </Row>
      </Row>
    </>
  )

  return (
    <>
      <div
        style={{
          padding: 10,
          backgroundColor: 'white',
          height: 900,
          overflow: 'scroll'
        }}>
        <Row style={{ borderBottom: '1px solid' }}>
          <Col md='8'>
            <span style={{ marginLeft: 5, marginTop: 10, marginBottom: 5, fontSize: 20 }}>
              <b>NOVA ROTA</b>
            </span>
          </Col>
          <Col md='4'>
            <div className='btn-toolbar' style={{ marginBottom: 4, display: 'none' }}>
              <div className='TableViewToggles btn-group display-flex flex-row'>
                <button
                  className='btn btn-default btn-icon-only active'
                  style={{ width: 50 }}
                  onClick={() => handleChangeMode('auto')}>
                  <span>Auto</span>
                </button>
                <button
                  className='btn btn-default btn-icon-only'
                  style={{ width: 50 }}
                  onClick={() => handleChangeMode('manual')}>
                  <span>Manual</span>
                </button>
              </div>
            </div>
          </Col>
        </Row>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Row>
            <Col style={{ padding: 15, overflow: 'scroll' }}>
              <span style={{ fontSize: 16, fontWeight: 600 }}>Nome da Rota</span>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10, marginTop: 10 }}>
                <div className={'input-group'}>
                  <ClearableInput
                    onChange={(e: any) => setRouteContext({ ...routeContext, routeName: e })}
                    value={routeContext.routeName}
                  />
                </div>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <div className={'input-group'}>
                  <span className={'input-group-addon'}>
                    <span className={'rioglyph rioglyph-time-alt'} aria-hidden={'true'}></span>
                  </span>
                  <input
                    {...register('origin.address', {
                      required: {
                        value: true,
                        message: 'aaaa'
                      },
                      minLength: {
                        value: 9,
                        message: 'aaaa'
                      }
                    })}
                    value={originRouteContext?.address?.label}
                    className='form-control'
                    placeholder={'Encontre Saída'}
                    onClick={() => handleOpenAddressDialog('', 'originRouteSidesheet', true)}
                  />
                </div>
              </Row>

              {allStopsContext?.map((value: any, index: any) => {
                return (
                  <Row style={{ marginBottom: 10 }}>
                    <Col
                      md='1'
                      style={{
                        marginTop: 20,
                        flex: 1,
                        flexDirection: 'column',
                        display: 'flex',
                        alignItems: 'flex-end'
                      }}>
                      <Row>
                        <span
                          style={{ fontSize: 12, cursor: 'pointer', marginTop: 5 }}
                          onClick={() => handleUpStop(index)}
                          className={'rioglyph rioglyph-chevron-up'}
                        />
                      </Row>
                      <Row>
                        <span
                          style={{ fontSize: 12, cursor: 'pointer', marginTop: 5 }}
                          onClick={() => handleDownStop(index)}
                          className={'rioglyph rioglyph-chevron-down'}
                        />
                      </Row>
                    </Col>
                    <Col md='11' style={{ marginRight: -5, marginTop: value.category === 'CROSSING' ? 17 : 0 }}>
                      {value.category !== 'CROSSING' ? (
                        <span style={{ fontSize: 12, marginBottom: 3, fontWeight: 600 }}>
                          <b>PARADA:</b> {value.name ? value.name.toUpperCase() : ''}
                        </span>
                      ) : null}
                      <div style={{ display: 'flex', flexDirection: 'row' }}>
                        <div className={'input-group'} style={{ width: '90%' }}>
                          <span className={'input-group-addon'}>
                            <span
                              className={
                                value.category !== 'CROSSING'
                                  ? 'rioglyph rioglyph-arrow-down'
                                  : 'rioglyph rioglyph-arrow-right'
                              }
                              aria-hidden={'true'}></span>
                          </span>
                          <input
                            value={
                              value?.position?.address?.label
                                ? value?.position?.address?.label
                                : value?.position?.addressStop?.label
                            }
                            className='form-control'
                            disabled
                            style={{ borderRadius: 7 }}
                          />
                        </div>
                        <div
                          style={{ display: 'flex', alignContent: 'center', justifyContent: 'center', width: '10%' }}>
                          <span
                            style={{ fontSize: 20, cursor: 'pointer', marginTop: 5 }}
                            onClick={() => handleDeleteStopRow(index)}
                            className={'rioglyph rioglyph-trash'}
                            aria-hidden={'true'}></span>
                        </div>
                      </div>
                    </Col>
                  </Row>
                )
              })}

              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <div className={'input-group'}>
                  <span className={'input-group-addon'}>
                    <span className={'rioglyph rioglyph-drive-history'} aria-hidden={'true'}></span>
                  </span>
                  <input
                    value={destinyRouteContext?.address?.label}
                    className='form-control'
                    placeholder={'Encontre Destino'}
                    onClick={() => handleOpenAddressDialog('', 'destinyRouteSidesheet', true)}
                  />
                </div>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Tolerância de Desvio</span>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 37, paddingRight: 10 }}>
                <Col md='8'>
                  <Slider
                    value={routeContext.rangeToleranceLimit}
                    className='margin-bottom-40'
                    onDragEnd={(e: any) => setRouteContext({ ...routeContext, rangeToleranceLimit: e })}
                    minValue={0}
                    maxValue={2000}
                    step={5}
                  />
                </Col>
                <Col md='4'>
                  <div className={'input-group'}>
                    <input
                      type='text'
                      defaultValue={0}
                      value={routeContext.rangeToleranceLimit}
                      className='form-control'
                      id='first'
                      style={{ marginTop: -7 }}
                      onChange={(e: any) => setRouteContext({ ...routeContext, rangeToleranceLimit: e.target.value })}
                    />
                    <span className={'input-group-addon'} style={{ marginTop: -7 }}>
                      <span aria-hidden={'true'}>m</span>
                    </span>
                  </div>
                </Col>
              </Row>
              <Row style={{ display: 'flex', marginTop: 20 }}>
                <Col md='12'>
                  <Button label='Adicionar Parada' onClick={handleOpenStopDialog} />
                </Col>
              </Row>
              <div style={{ display: 'none' }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Parada</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return setStop
                  }}
                </ExpanderPanel>
              </div>
              <Row style={{ marginTop: 15, marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <span style={{ fontSize: 20 }}>Opções</span>
              </Row>
              {/* <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Hora da Partida</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return startTimeColapse
                  }}
                </ExpanderPanel>
              </Row> */}
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Faixa</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return rangeOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Veículo</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return vehicleOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Custos</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return costsOption
                  }}
                </ExpanderPanel>
              </Row>
              <Row style={{ marginBottom: 10, paddingLeft: 10, paddingRight: 10 }}>
                <ExpanderPanel
                  title={<span style={{ fontSize: 16, fontWeight: 600 }}>Veículos vinculados a rota</span>}
                  iconLeft
                  bsStyle='separator'>
                  {(open: any) => {
                    return linkedVehicles
                  }}
                </ExpanderPanel>
              </Row>
              <Row
                style={{
                  paddingLeft: 20,
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginTop: 30
                }}>
                {loading === true ? (
                  <div
                    style={{
                      width: '100%',
                      display: 'flex',
                      justifyContent: 'center',
                      alignContent: 'center'
                    }}>
                    <Spinner loading={loading} fullscreen={false} />
                  </div>
                ) : (
                  <>
                    <Col md='2' style={{ display: 'none' }}>
                      <Checkbox onClick={() => setActiveRoute(!activeRoute)} checked={activeRoute}>
                        Ativo
                      </Checkbox>
                    </Col>
                    <Col md='3'>
                      <div className='btn-toolbar max-width-300'>
                        <Button label='Cancelar' onClick={() => handleBack()} />
                      </div>
                    </Col>
                    <Col md='12' style={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <Button label='Criar Routefence' color='primary' onClick={handleSaveRoute} />
                    </Col>
                  </>
                )}
              </Row>
              <Row style={{ marginBottom: 50, paddingLeft: 37, paddingRight: 10 }}></Row>
            </Col>
          </Row>
        </form>
      </div>
    </>
  )
}

export default EditTrip
