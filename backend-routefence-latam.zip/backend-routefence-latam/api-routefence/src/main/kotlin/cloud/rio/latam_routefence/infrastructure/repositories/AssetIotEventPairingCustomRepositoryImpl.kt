package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventPairingEntity
import java.sql.Timestamp
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query

@Repository
class AssetIotEventPairingCustomRepositoryImpl : AssetIotEventPairingCustomRepository {

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun getAllPairingUnprocessed(): List<AssetIotEventPairingEntity> {

        val sql = StringBuilder()

        sql.append(
            """
                select
                    id,
                    asset_id,
                    account_id,
                    device_id,
                    device_type,
                    eid,
                    occurred_at,
                    "trigger",
                    driver_identification,
                    driver_identification_type,
                    processed
                from
                    tb_asset_iot_event_pairing
                where
                    processed = false
                order by
                	occurred_at desc;
            """.trimIndent()
        )

        val query = entityManager.createNativeQuery(sql.toString())

        return getResultList(query)
    }

    private fun getResultList(query: Query): MutableList<AssetIotEventPairingEntity> {
        val pairings: MutableList<AssetIotEventPairingEntity> = mutableListOf()

        query.resultList.forEach {
            val objArray = it as Array<*>

            pairings.add(
                AssetIotEventPairingEntity(
                    id = objArray[0].toString(),
                    assetId = objArray[1].toString(),
                    accountId = objArray[2].toString(),
                    deviceId = objArray[3].toString(),
                    deviceType = objArray[4].toString(),
                    eid = objArray[5].toString(),
                    occurredAt = (objArray[6] as Timestamp).toLocalDateTime(),
                    trigger = objArray[7].toString(),
                    driverIdentification = objArray[8].toString(),
                    driverIdentificationType = objArray[9].toString(),
                    processed = objArray[10].toString().toBoolean(),
                )
            )
        }

        return pairings
    }
}