import React, { useEffect, useState, useRef, useContext } from 'react';
import axios from 'axios'
import { Map as RioMap, EventUtils, Route, Marker, SingleMapMarker, MapSettings, MapTypeSettings, ContextMenu, ContextMenuItem, Polygon } from 'rio-uikit-map';
import { decode } from 'core/utils/flexiblePolyline'
import { ColumnTripleEdit } from 'styled-icons/fluentui-system-filled';
import { accessToken } from 'configuration/tokenHandling/accessToken'
import DashboardContext from 'core/DashboardContext';
import Button from 'components/Button';

const MapToResume = ({ data, handleOpenSidesheet, openedSidesheet }) => {
  const { mapSize, setMapSize, centerMap, setCenterMap, zoomMap, setZoomMap, assets, setAssets, truckSelected, setTruckSelected } = useContext(DashboardContext)
  const [trucksToShow, setTrucksToShow] = useState([])
  const [initialPosition, setInitialPosition] = useState([
    {
      lat: -23.5475,
      lng: -46.63611
    }
  ])
  const [arrayInfractions, setArrayInfractions] = useState([])
  const [infractionsData, setInfractionsData] = useState([])
  const [contextMenuData, setContextMenuData] = useState({});
  const [dataToShowRoute, setDataToShowRoute] = useState([])
  const [refreshAssetId, setRefreshAssetsId] = useState(false)
  const [assetToFilter, setAssetToFilter] = useState('')
  const [routeData, setRouteData] = useState([])
  const [showInfractions, setShowInfractions] = useState(false)
  const [oneSelected, setOneSelected] = useState(false)

  console.log(showInfractions, 'SHOW INFRACTION')

  const STROKE_COLOR = 'rgba(90, 72, 118, 1)';
  const FILL_COLOR = 'rgba(90, 72, 118, 0.3)';
  const STROKE_AVOID_COLOR = 'rgba(139, 0, 0, 1)';
  const FILL_AVOID_COLOR = 'rgba(139, 0, 0, 0.3)';

  const allPositionsWithNames = data?.allPositions?.items?.map(position => {
    const truck = data?.trucks?.find(truck => truck.id === position.asset_id);
    const trip = data?.rowsPagineted?.flat().find(trip => trip.asset && trip.asset.id === position.asset_id);



    return {
      ...position,
      name: truck ? truck.name : null,
      type: truck ? truck.type : null,
      statusTrip: trip ? trip.status : null
    };
  });

  console.log(allPositionsWithNames, 'allPositionsWithNames')

  useEffect(() => {
    if (oneSelected === false) {

      setTrucksToShow(allPositionsWithNames)
    }

  }, [data])

  console.log(assets, 'assets NO MAPA')

  useEffect(() => {
    if (assets?.length === 1 && truckSelected === true) {
      const filtered = allPositionsWithNames?.find(elemento => assets.includes(elemento.asset_id))
      console.log(assets[0], 'assets[0]')
      const selectTruck = allPositionsWithNames?.find(elemento => elemento.asset_id === assets[0])
      console.log(selectTruck, 'selectTruck')
      setAssetToFilter(selectTruck?.name?.trim())
      setRefreshAssetsId(true)
      setTrucksToShow(filtered)
    } else if (assets?.length === 0 && truckSelected === true) {

      handleClear()

    } else if (assets?.length >= 2 && truckSelected === true) {
      const filtered = allPositionsWithNames?.filter(elemento => assets.includes(elemento.asset_id))
      setTrucksToShow(filtered)
      setShowInfractions(false)
      setRouteData([])
    }
  }, [assets])

  const baseURL = process.env.REACT_APP_ENVIRONMENT_CONFIG

  const customAcessToken = accessToken.getAccessToken()
  console.log(customAcessToken)

  var head = {
    headers: {
      Authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMwM2Y0MzAzLTk5OTgtNGRiYi1iODE0LTc4YjQyYjA2YTQ0OSJ9.eyJzdWIiOiJwcm9kLXJpby11c2VyczpiOWRmZjhkZi0zMTQ4LTQ1OGItODc4MS04MTQ5YzgwM2NiZjUiLCJzY29wZSI6ImFzc2V0LWFkbWluaXN0cmF0aW9uLnJlYWQgYXNzZXQtaGlzdG9yeS5yZWFkIGRyaXZlcnMucmVhZCBlbWFpbCBtYXAucmVhZCBvcGVuaWQgcGhvbmUgcHJvZmlsZSB0YWdzLnJlYWQiLCJpc3MiOiJodHRwczovL2F1dGguaWFtLnJpby5jbG91ZCIsImV4cCI6MTY4MTQxMjc2NywiaWF0IjoxNjgxNDA5MTY3LCJqdGkiOiJPVlpKWERvQkRPWUphZlJPZTFvYUFlRTFnR28iLCJhenAiOiJlZDcyZTdjNS1iYjdjLTQ0YmUtODY5OS02M2ZhYzAyYzZjOWQiLCJhY2NvdW50IjoiZDg3ZjlmNDEtNTk1MC00NWIxLTkwNDQtZWNiNWQzMjAzOWQ4IiwidGVuYW50IjoicmlvLWJyYXppbC5wcm9kIn0.O59wevtRPflukTPZA-dut7MKWcS1cLJEAHeZjJUwEtJMri7ARSpk-jCsKFc9vXeuT-OXoScSVKX4YVK0MMaFybm6zm1AmM4s8ew3uSkYg5YUmxNomF6kGnkvQ7etdzHCeShQA0IzYqW_bIujnZn5lu6TmInuyN6VBYAxhpaeju21kFtUTBjkQLaRdfTcYMcjgRvKaLturyF6eiUMsgELbaHTS2MjHhufm2aFtIEbd3ngaIiS_Av7ThSvnJA-IO5sBAwVTBQg0PQpZQ5d9WL_g3bFzjCNLogjGyMgYYV7PHmMpZy4Dn5icdlz110WrSh2IIDyjLr2_FOIH_n_aQ20RfvGbbQGRfunNQdxK_B_sV2xd7cRVgO2aofKLuT6if6vrmX_wGO58wUS1RqZaB5S5orbk-prBGPeh3VQpvRrkeA5gMD7T5VEKraiZ_qZHoUtcbkzyKJ8Rvx0lbMU1RtJQ71cbmoHcx9ChL8uwhfnKv9Phus3HJ0WF3vDTcGR7dG4kSEH1zWSuQSY_ta0RQg9wLPeNikrv47m8kpZ3EGIAgRjdNZaz2iHm9ihWJ5ceCJ9M2N0MOAtgJcqz4ZbVzzP_5igvvsrqo0eZAoJyhifBy8X8jiaL3tVNTogc5Cpej29V77cwyRDcXxMn4ykJVCiOfySvFHF1R59G30V6OkkcK8`
    }
  }


  const convertInfractionType = (type) => {
    switch (type) {
      case 'SPEEDING':
        return 'Alta Velocidade'
      case 'ROUTE_DEVIATION':
        return 'Desvio de Rota'
      case 'FORBIDDEN_DIRECTION':
        return 'Perda de Direção'
      case 'UNSCHEDULED_STOP':
        return 'Parada não obrigatória'
      case 'STOP_OVERTIME':
        return 'Muito tempo parado'
      case 'OVERTIME_AREA':
        return 'Fora da arêa demarcada'
      case 'MIN_SPEED':
        return 'Velocidade miníma atingida'
      case 'MAX_SPEED':
        return 'Velocidade máxima ultrapassada'
      default:
        return ''
    }
  }

  useEffect(() => {
    if (dataToShowRoute?.originRouteData?.lat) {
      setInitialPosition([{ lat: dataToShowRoute?.originRouteData?.lat, lng: dataToShowRoute?.originRouteData.long }])
    }
  }, [dataToShowRoute])

  useEffect(() => {
    if (openedSidesheet === false) {
      setDataToShowRoute([])
    } else {

    }
  }, [openedSidesheet])

  const countRef = useRef({})

  useEffect(() => {
  }, [countRef.current]);

  const markerEventListenerMap = {
    [EventUtils.TAP]: event => {
      // Note: if there is a "TAP" event defined make sure to block the event for right mouse button otherwise
      // the right click will also trigger the tap callback and may cause unwanted selection
    },
    [EventUtils.MAP_VIEW_CHANGE_END]: (event) => {
      const target = event.currentTarget;
      const updatedCenter = target.getCenter();
      const newZoom = target.getZoom();

      setInitialPosition([
        {
          lat: updatedCenter.lat,
          lng: updatedCenter.lng,
        }
      ])
    },
    [EventUtils.CONTEXTMENU]: event => {
      setAssetToFilter(event?.originalEvent?.target?.outerText)
      setRefreshAssetsId(!refreshAssetId)

      // "target" is used to decide what context menu items shall be shown
      // "event" is used to add the menu items to it/
      // "targetPosition" is used to return a fixed position on context menu open or in the item callback


      // setInitialPosition([{ lat: event.target.a.lat, lng: event.target.a.lng }])
      setContextMenuData({ target: 'marker', event });

    },
  };

  const getRouteData = async (id) => {
    const resRoute = await axios.get(`${baseURL}/routes/${id}`, head)
    setRouteData([resRoute.data])
  }

  const handleClear = () => {
    setArrayInfractions([])
    setShowInfractions(false)
    setRouteData([])
    setDataToShowRoute([])
    setTrucksToShow(allPositionsWithNames)
  }

  const getInfractionsData = async (id) => {
    const resInfractions = await axios.get(`${baseURL}/infringements/${id}`, head)
    setInfractionsData([resInfractions.data])
    setArrayInfractions(resInfractions.data)
  }

  useEffect(() => {
    if (refreshAssetId === true) {

      if (data?.rowsPagineted[0]?.length >= 1) {
        const getDataToSidesheet = data?.rowsPagineted[0]?.find(
          (item) => item.asset.name.trim() === assetToFilter.trim() && item.status === 'Em Andamento' || item.asset.name.trim() === assetToFilter.trim() && item.status === 'Programada')

        const getTruck = allPositionsWithNames?.find(item => item.name.trim() === assetToFilter.trim())
        console.log(getTruck, 'getTruck na funcao')

        if (getDataToSidesheet) {
          setOneSelected(true)
          setTrucksToShow([getTruck])

          getInfractionsData(getDataToSidesheet?.tripId)
          getRouteData(getDataToSidesheet?.routeId)
          setDataToShowRoute([getDataToSidesheet])
          // setInitialPosition([{ lat: getDataToSidesheet?.originRouteData?.lat, lng: getDataToSidesheet?.originRouteData.long }])
          handleOpenSidesheet(true, getDataToSidesheet)
          setAssets([getTruck.asset_id])
          setShowInfractions(true)
        } else {
          return
        }


        setTruckSelected(false)
        setRefreshAssetsId(false)
      }
    }

  }, [refreshAssetId])

  const stopsWaypoint = data?.allStops?.length > 0 ? data?.allStops?.map((item, index) => {
    return (
      `waypoint${index + 1}=geo!${item?.position?.lat},${item?.position?.lng}&`
    )
  }) : ''

  console.log(arrayInfractions, 'arrayInfractions')

  const destinyWaypoint = `waypoint${dataToShowRoute?.allStops?.length + 1}=geo!${dataToShowRoute?.destinyRouteData?.position?.lat},${dataToShowRoute?.destinyRouteData?.position?.lng}`

  const handleGetRoute = () => {
    axios
      .get(`https://route.ls.hereapi.com/routing/7.2/calculateroute.json?apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&mode=fastest;car&waypoint0=geo!${dataToShowRoute?.originRouteData?.position?.lat},${dataToShowRoute?.originRouteData?.position?.lng}&${stopsWaypoint.length >= 1 ? stopsWaypoint[0] : '&'}${stopsWaypoint.length === 2 ? stopsWaypoint[1] : ''}${stopsWaypoint.length === 3 ? stopsWaypoint[2] : ''}${stopsWaypoint.length === 4 ? stopsWaypoint[3] : ''}${stopsWaypoint.length === 5 ? stopsWaypoint[4] : ''}${destinyWaypoint}&height=5&routeattributes=sh,bb,gr, lg`)
      .then(result => {

        const resultData = result?.data?.response?.route[0]
        const getPoints = resultData.shape.map((value) => {
          const [lat, lng] = value.split(',')
          return { lat, lng }
        })
        setInitialPosition(getPoints)
      })
  }
  let ArrayOfShape = []

  const newData = routeData?.map((item) => {

    const getPolylineArray = item?.responseHere?.routes[0]?.sections?.map((item) => {
      return {
        shape: decode(item?.polyline)
      }
    })

    const shapeArray = getPolylineArray?.map((item) => {
      return (
        ArrayOfShape.push(item?.shape?.polyline)
      )
    })

    const concatArrays = ArrayOfShape?.flat()

    const getPoints = concatArrays?.map((value) => {
      return {
        lat: (value[0]),
        lng: (value[1])
      }
    })

    const stops = item?.stops?.map((item) => {
      return {
        stopName: item?.name,
        positions: {
          lat: item?.position?.lat,
          lng: item?.position?.lng,
        }
      }
    })

    return {
      destinyRoute: item?.destinyRoute,
      originRoute: item?.destinyRoute,
      shape: getPoints,
      stops: stops,
      geolocation: item?.geolocation,
      name: item?.route?.routeName
    }
  })

  useEffect(() => {
    if (data?.destinyRouteData?.position?.lat !== undefined && dataToShowRoute.length >= 1) {
      handleGetRoute()
    }
  }, [data?.destinyRouteData, data?.allStops])

  const position = { lat: initialPosition[0]?.lat, lng: initialPosition[0]?.lng };

  const offset = 0.3;

  const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'

  const getRandomValueToForceRerender = () => Math.random();

  const Routes = () => {
    const [activeRouteId, setActiveRouteId] = useState(1);
    const isActive = id => activeRouteId === id;
    const isFirstRouteActive = isActive(1);
    const isSecondRouteActive = isActive(2);

    return (
      <React.Fragment>
        {newData?.map((value, index) => {
          const position = value?.shape
          return (
            <Route
              key={getRandomValueToForceRerender()}
              positions={position}
              startIcon={<SingleMapMarker eventListenerMap={markerEventListenerMap} iconNames={['start']} markerColor='bg-map-marker-asset' />}
              endIcon={<SingleMapMarker iconNames={['finish']} markerColor='bg-map-marker-asset' />}
              isRouteAlternative={!isFirstRouteActive}
              eventListenerMap={markerEventListenerMap}
              hasArrows={true}
              markers={value?.stops?.map((item, index) => {
                return (
                  <>
                    <Marker
                      key={index}
                      customData={{ id: index }}
                      position={item?.positions}
                      icon={
                        <SingleMapMarker
                          iconNames={['rioglyph rioglyph-stopover']}
                          name={item.stopName}
                          markerColor='bg-map-marker-route'
                          active={isSecondRouteActive}
                          fixed
                        />
                      }
                    />
                  </>

                )
              })}
            />
          )
        })}
      </React.Fragment>
    );
  };

  const [coordLabel, setCoordLabel] = useState();

  const formatCoordinates = coordinates => {
    return [
      Math.abs(coordinates.lat.toFixed(4)) + (coordinates.lat > 0 ? 'N' : 'S'),
      Math.abs(coordinates.lng.toFixed(4)) + (coordinates.lng > 0 ? 'E' : 'W'),
    ].join(' ');
  };


  const handleOpenContextMenu = contextMenuCoordinates => {

    setCoordLabel(formatCoordinates(contextMenuCoordinates));

  };

  const contextMenuItems = [
    <ContextMenuItem
      className='bg-lightest text-color-dark'
      labelClassName='text-medium'
      label={coordLabel}
      icon='rioglyph-map-marker'
    />
  ];

  const getMiddlePos = positions => positions[Math.floor(positions.length / 2)];

  return (
    <>
      <RioMap
        credentials={{
          apikey:
            typeof apiKey === 'string'
              ? apiKey
              : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
        }}
        center={position}
        eventListenerMap={markerEventListenerMap}
        zoom={11}
        height={900}
        width={mapSize}
        mapSettings={<MapSettings options={[<MapTypeSettings tooltip='Change map type' />]} />}
      >
        <div style={{ position: 'fixed', right: 180, top: 110, zIndex: 99 }}>
          <Button color='primary' onClick={() => handleClear()} label={'Limpar'}>
          </Button>
        </div>
        <Routes />
        {/* {newData?.map((item, index) => {
          const position = item?.shape
          return (
            <Marker
              key={index}
              customData={{ id: index }}
              position={getMiddlePos(position)}
              eventListenerMap={markerEventListenerMap}
              icon={
                <SingleMapMarker
                  iconNames={['stop']}
                  name={item.name}
                  markerColor='bg-map-marker-poi'
                  moving
                />
              }
            />
          )
        })} */}
        {/* {routeData?.avoidArea[0]?.length >= 1 ?
          routeData?.avoidArea[0]?.map((item, index) => {
            return (
              <>
                <Polygon

                  points={item.points}
                  style={{ strokeColor: STROKE_AVOID_COLOR, fillColor: FILL_AVOID_COLOR }}
                />
                <Marker
                  
                  key={index}
                  customData={{ id: index + 1 }}
                  position={getMiddlePos(item.points)}
                  icon={
                    <SingleMapMarker
                      iconNames={['rioglyph rioglyph-settings']}
                      
                      markerColor='bg-map-marker-asset'
                    />
                  }
                />
              </>

            )
          })
          : null} */}
        {/* {routeData?.interestArea[0]?.length >= 1 ?
          routeData?.interestArea[0]?.map((item, index) => {
            return (
              <>
                <Polygon
                  points={item.points}
                  style={{ strokeColor: STROKE_COLOR, fillColor: FILL_COLOR }}
                />
                <Marker
                  eventListenerMap={eventConfigureAttention}
                  key={index}
                  customData={{ id: index + 1 }}
                  position={getMiddlePos(item.points)}
                  icon={
                    <SingleMapMarker
                      iconNames={['rioglyph rioglyph-settings']}
                      eventListenerMap={eventConfigureAttention}
                      markerColor='bg-map-marker-asset'
                    />
                  }
                />
              </>

            )
          })
          : null} */}
        {trucksToShow?.length >= 1 ? trucksToShow
          ?.map((item, index) => {
            const geolocation = { lat: item?.position?.value?.latitude, lng: item?.position?.value?.longitude }
            return (
              <Marker
                key={index}
                customData={{ id: index }}
                position={geolocation}
                icon={
                  <SingleMapMarker
                    eventListenerMap={markerEventListenerMap}
                    name={item?.name}
                    iconNames={['truck']}
                    exceptionCount={''}
                    markerColor={item?.statusTrip === 'Programada' ? 'bg-map-marker-route' : 'bg-map-marker-asset'}
                    active={item?.statusTrip === 'Programada' || item?.statusTrip === 'Em Andamento' ? true : false}
                    moving
                  />
                }
              />
            )
          }) : null}

        {showInfractions ? arrayInfractions
          ?.map((item, index) => {
            const position = { lat: item?.location?.lat, lng: item?.location?.lng }
            console.log(position, 'position na infraction')
            return (
              <Marker
                key={index}
                customData={{ id: index }}
                position={position}
                icon={
                  <SingleMapMarker
                    eventListenerMap={markerEventListenerMap}
                    name={convertInfractionType(item.type)}
                    iconNames={['dangerousgoods']}
                    markerColor='bg-map-marker-poi'
                    active
                  />
                }
              />
            )
          }) : null}
        <ContextMenu
          onOpen={handleOpenContextMenu}
          menuItems={contextMenuItems}
        // contextMenuEvent={contextMenuData.event}
        // targetPosition={contextMenuData.targetPosition}
        />
        <div style={{ height: 200, width: 200, position: 'relative', zIndex: 99, backgroundColor: 'white' }}></div>
      </RioMap>
    </>

  );
};

export default MapToResume;