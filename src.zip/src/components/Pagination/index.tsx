import React, { FC, useEffect, useState } from 'react'
import { Intl } from 'react-intl'

import { Button } from 'components'
import { Pager, PagerDescription, PaginationGlosary, PaginatioSection, ProgressBar, ProgressWrapper } from './styled'

interface PaginationProps {
  paginationDescription: string | React.ReactElement | Intl
  buttonLoadMoreLabel: string | React.ReactElement
  buttonEverythingLoadedLabel: string | React.ReactElement
  size: number
  page: number
  lenghtPerPage: number
  onLoadmore: (paginationLoaded: number) => void
}

const Pagination: FC<PaginationProps> = ({
  paginationDescription,
  lenghtPerPage,
  page,
  size,
  buttonLoadMoreLabel,
  buttonEverythingLoadedLabel,
  onLoadmore
}) => {
  const [paginationLoaded, setPaginationLoaded] = useState(lenghtPerPage * page)
  const shouldLoadMore = paginationLoaded !== size

  const handleLoadMore = () => {
    if (paginationLoaded !== size) {
      const newPaginationLoaded = paginationLoaded + lenghtPerPage > size ? size : paginationLoaded + lenghtPerPage
      setPaginationLoaded(newPaginationLoaded)
      onLoadmore(newPaginationLoaded)
    }
  }

  useEffect(() => {
    const newPaginationLoaded = lenghtPerPage * page
    setPaginationLoaded(newPaginationLoaded > size ? size : newPaginationLoaded)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lenghtPerPage, page])

  const percentageCal = parseFloat((100 / (size / paginationLoaded)).toFixed(2))

  return (
    <PaginatioSection>
      <PaginationGlosary>{`${paginationLoaded} ${paginationDescription}`}</PaginationGlosary>
      <Pager>
        <PagerDescription>{`${paginationLoaded} / ${size}`}</PagerDescription>
        <ProgressWrapper className='progress'>
          <ProgressBar
            className='progress-bar'
            role='progressbar'
            aria-valuenow={paginationLoaded}
            aria-valuemin={0}
            aria-valuemax={size}
            percentage={!isFinite(percentageCal) ? 0 : percentageCal}
          />
        </ProgressWrapper>
        <Button
          icon={shouldLoadMore ? 'arrow-down' : ''}
          onClick={handleLoadMore}
          color='link'
          data-testid='action-button'
          label={shouldLoadMore ? (buttonLoadMoreLabel as string) : (buttonEverythingLoadedLabel as string)}
        />
      </Pager>
    </PaginatioSection>
  )
}

export default React.memo(Pagination)
