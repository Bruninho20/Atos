import React from "react";
import ReactSpeedometer from "react-d3-speedometer"

import { Container } from './styles'


export default function Speedometer(props) {

  return (
    <Container>
      <div>
        <ReactSpeedometer
          ringWidth={20}
          width={180}
          labelFontSize={'0'}
          valueTextFontSize={'14'}
          needleHeightRatio={0.8}
          maxValue={100}
          value={props.description}
          currentValueText={'${value}%'}
          segments={3}
          segmentColors={["#D3D3D3", "#8EE5EE", "#1874CD"]}
          customSegmentStops={[0, 33, 66, 100]}
          needleColor="white"
          segments={10}
          needleTransitionDuration={3000}
          needleTransition="easeElastic"
          minValue={0}
          maxValue={100}
        />
      </div>
    </Container>

  );
}


{/* <ReactSpeedometer
width={150}
maxSegmentLabels={3}
segments={3}
customSegmentStops={[0, 33, 66, 100]}
dimensionUnit="px"
segmentColors={["#D3D3D3", "#96CDCD", "#00688B"]}
value={70}
forceRender={false}
textColor={'black'}  
needleColor={'black'}
fluidWidth={true}
ringWidth={'50'}
labelFontSize={'12'}
valueTextFontSize={'12'} 
needleTransitionDuration={3000}
needleTransition="easeElastic"
minValue={0}
maxValue={100}
/> */}