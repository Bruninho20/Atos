package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.utils.PolylineEncoderDecoder
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.io.ByteArrayResource
import org.springframework.http.*
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.AddressResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import java.io.File
import java.io.IOException
import cloud.rio.latam_routefence.domain.response.here.revGeoCode.Response as RevgeocodeResponse

@Service
@Transactional
class HereService() {
    @Value("\${here.endpoint.upload-layer}")
    private lateinit var urlUploadLayer: String

    @Value("\${here.path.wkt-files-folder}")
    private lateinit var wktFolderPath: String

    @Value("\${here.api-key}")
    private lateinit var apiKey: String

    @Value("\${here.endpoint.rev-geocode}")
    private lateinit var urlRevGeocode: String

    private val logger = LoggerFactory.getLogger(this.javaClass)

    fun generateWktFiles(routeEntity: RouteEntity) {

        val layerId = routeEntity.idLayer
        val hereRouteResponse = routeEntity.responseHere

        val polylineDecoded = mutableListOf<PolylineEncoderDecoder.LatLngZ?>()

        try {
            hereRouteResponse?.routes?.first()?.sections?.forEach {
                polylineDecoded.addAll(PolylineEncoderDecoder.decode(it.polyline))
            }

            val routeFile = "${wktFolderPath}R${layerId}.wkt"
            val routeFileContent = "NAME\tWKT\nR$layerId\tLINESTRING("

            val stopFile = "${wktFolderPath}S${layerId}.wkt"
            val stopFileContent =
                "NAME\tGEOMETRY_ID\tWKT\nORIGIN\t0\tPOINT(${routeEntity.geoPointOrigin.long} ${routeEntity.geoPointOrigin.lat})\n"

            File(routeFile).writeText(routeFileContent)

            for (poly in polylineDecoded) {
                val lngLat = "${poly?.lng} ${poly?.lat},"
                File(routeFile).appendText(lngLat)
            }
            File(routeFile).appendText(")")

            logger.debug("Arquivo de layer rota gerado: $routeFile")

            File(stopFile).writeText(stopFileContent)
            val stops = routeEntity.stops?.toList()?.sortedBy { it.stopQueueOrder }
            val stopOverList = stops?.filter { it.type == StopTypeEnum.STOPOVER }
            var count = 1
            if (stopOverList?.isNotEmpty() == true) {
                stopOverList.forEach {
                    File(stopFile).appendText("${it.id}\t${count}\tPOINT(${it.stop?.position?.long} ${it.stop?.position?.lat})\n")
                    count++
                }
            }
            File(stopFile).appendText("DESTINATION\t${count}\tPOINT(${routeEntity.geoPointDestiny.long} ${routeEntity.geoPointDestiny.lat})")

            logger.debug("Arquivo de layer de parada gerado: $stopFile")

            uploadRouteStopLayers(layerId.toString())

        } catch (e: IOException) {
            logger.error("Erro na geracao de arquivos [$layerId]: ${e.localizedMessage}")
        }
    }

    private fun uploadRouteStopLayers(layerId: String) {
        val apiKey = apiKey
        val routeUrl = "${urlUploadLayer}?layer_id=R${layerId}&apiKey=${apiKey}"
        val stopUrl = "${urlUploadLayer}?layer_id=S${layerId}&apiKey=${apiKey}"
        val routeFile = "${wktFolderPath}R${layerId}.wkt"
        val stopFile = "${wktFolderPath}S${layerId}.wkt"

        val headers = HttpHeaders()
        headers.contentType = MediaType.MULTIPART_FORM_DATA

        try {

            val routeBytes = File(routeFile).readBytes()
            val routeResource = object : ByteArrayResource(routeBytes) {
                override fun getFilename() = routeFile
            }
            val routeBody: MultiValueMap<String, Any> = LinkedMultiValueMap()
            routeBody.add("zipfile", routeResource)
            val routeRequestEntity = HttpEntity<MultiValueMap<String, Any>>(routeBody, headers)
            val routeResponse: ResponseEntity<String> =
                RestTemplate().postForEntity(routeUrl, routeRequestEntity, String::class.java)
            logger.debug("Codigo de resposta da requisicao de upload de layer [R$layerId] de rota: ${routeResponse.statusCode}")

            val stopBytes = File(stopFile).readBytes()
            val stopResource = object : ByteArrayResource(stopBytes) {
                override fun getFilename() = stopFile
            }
            val stopBody: MultiValueMap<String, Any> = LinkedMultiValueMap()
            stopBody.add("zipfile", stopResource)
            val stopRequestEntity = HttpEntity<MultiValueMap<String, Any>>(stopBody, headers)
            val stopResponse: ResponseEntity<String> =
                RestTemplate().postForEntity(stopUrl, stopRequestEntity, String::class.java)
            logger.debug("Codigo de resposta da requisicao de upload de layer [S$layerId] de parada: ${stopResponse.statusCode}")

        } catch (e: HttpClientErrorException) {
            logger.error("Erro no envio de arquivos para criação da layer [$layerId]: ${e.localizedMessage}")
        }
    }

    fun getAddressByGeopoint(geoReq: GeoPointRequest): GeoPointResponse? {
        val revGeocodeUrl = "${urlRevGeocode}?apiKey=${apiKey}&at=${geoReq.lat},${geoReq.lng}"
        try {
            val revGeocodeResponse = RestTemplate().getForObject(
                revGeocodeUrl, RevgeocodeResponse::class.java
            )
            if (revGeocodeResponse != null) {
                val address = revGeocodeResponse.items.firstOrNull()?.address
                return GeoPointResponse(
                    null,
                    geoReq.lat,
                    geoReq.lng,
                    AddressResponse(
                        null,
                        address?.label,
                        address?.countryCode,
                        address?.countryName,
                        address?.stateCode,
                        address?.state,
                        address?.city,
                        address?.district,
                        address?.street,
                        address?.postalCode,
                        address?.houseNumber
                    )
                )
            }
        } catch (e: HttpClientErrorException) {
            logger.error("Erro na checagem de endereço: ${e.localizedMessage}")
        }
        return null
    }
}