package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetApiClient
import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.assets.AssetsDTO
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import javax.servlet.http.HttpServletRequest

@Service
@Transactional
class AssetService(private val assetApiClient: AssetApiClient) {

    fun get(id: String): AssetDTO {
        return assetApiClient.getAsset(id)
            ?: throw RoutefenceException.RoutefenceBusinessException("Vehicle.not.found")
    }

    fun list(
        request: HttpServletRequest,
        tagsIds: List<String>? = null,
        assetsIds: List<String>? = null
    ): HashMap<String, AssetDTO> {
        val mapAssets: HashMap<String, AssetDTO> = HashMap()

        if (tagsIds.isNullOrEmpty() && !assetsIds.isNullOrEmpty() && assetsIds.size == 1) {
            val assetDTO = get(assetsIds.first())
            mapAssets[assetDTO.id!!] = assetDTO
        } else {
            val result: ResponseEntity<AssetsDTO> = assetApiClient.listAsset()

            result.body?.let {
                if (!tagsIds.isNullOrEmpty() || !assetsIds.isNullOrEmpty()) {
                    filterByTag(tagsIds, it, mapAssets)
                    filterByAsset(assetsIds, it, mapAssets)
                } else {
                    it.items.forEach { asset -> mapAssets[asset.id!!] = asset }
                }
            } ?: throw RoutefenceException.RoutefenceBusinessException("Vehicles.not.found")
        }
        return mapAssets
    }


    private fun filterByAsset(assetsIds: List<String>?, assets: AssetsDTO, mapAssets: HashMap<String, AssetDTO>) {
        assetsIds?.forEach { assetId ->
            if (!mapAssets.containsKey(assetId)) {
                if (assets.items.firstOrNull { it.id == assetId } != null)
                    mapAssets[assetId] = assets.items.first { it.id == assetId }
            }
        }
    }

    private fun filterByTag(tagsIds: List<String>?, assets: AssetsDTO, mapAssets: HashMap<String, AssetDTO>) {
        tagsIds?.let {
            assets.items.forEach { asset ->
                asset._embedded?.tags?.items?.forEach {
                    if (tagsIds.contains(it.id))
                        mapAssets[asset.id!!] = asset
                }
            }
        }
    }
}