package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize

data class DriverStateMessage(
    @JsonProperty("working_state")
    val workingState: DriverWorkingStateMessage,
    @JsonProperty("driving_and_resting_details")
    val drivingAndRestingDetails: DrivingAndRestingDetailsMessage?
)

data class DriverWorkingStateMessage(
    @JsonProperty("state")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val state: String
)

data class DrivingAndRestingDetailsMessage(
    @JsonProperty("specification")
    val specification: String,
    @JsonProperty("source")
    val source: String,
    @JsonProperty("continuous_driving_time")
    val continuousDrivingTime: Int?,
    @JsonProperty("cumulative_break_time")
    val cumulativeBreakTime: Int?,
    @JsonProperty("current_duration_of_selected_activity")
    val currentDurationOfSelectedActivity: Int?,
    @JsonProperty("cumulated_driving_time_previous_and_current_week")
    val cumulatedDrivingTimePreviousAndCurrentWeek: Int?,
    @JsonProperty("end_of_last_daily_rest_period")
    val endOfLastDailyRestPeriod: Long?,
    @JsonProperty("end_of_last_weekly_rest_period")
    val endOfLastWeeklyRestPeriod: Long?,
    @JsonProperty("end_of_second_last_weekly_rest_period")
    val endOfSecondLastWeeklyRestPeriod: Long?,
    @JsonProperty("current_daily_driving_time")
    val currentDailyDrivingTime: Int?,
    @JsonProperty("current_weekly_driving_time")
    val currentWeeklyDrivingTime: Int?,
    @JsonProperty("time_left_until_new_daily_rest_period")
    val timeLeftUntilNewDailyRestPeriod: Int?,
    @JsonProperty("time_left_until_new_weekly_rest_period")
    val timeLeftUntilNewWeeklyRestPeriod: Int?,
    @JsonProperty("number_of_times_9h_daily_driving_times_exceeded")
    val numberOfTimes9hDailyDrivingTimesExceeded: Int?,
    @JsonProperty("cumulative_uninterrupted_rest_time")
    val cumulativeUninterruptedRestTime: Int?,
    @JsonProperty("minimum_daily_rest")
    val minimumDailyRest: Int?,
    @JsonProperty("minimum_weekly_rest")
    val minimumWeeklyRest: Int?,
    @JsonProperty("maximum_daily_period")
    val maximumDailyPeriod: Int?,
    @JsonProperty("maximum_daily_driving_time")
    val maximumDailyDrivingTime: Int?,
    @JsonProperty("number_of_used_reduced_daily_rest_periods")
    val numberOfUsedReducedDailyRestPeriods: Int?,
    @JsonProperty("remaining_current_driving_time")
    val remainingCurrentDrivingTime: Int?,
    @JsonProperty("remaining_driving_time_on_current_shift")
    val remainingDrivingTimeOnCurrentShift: Int?,
    @JsonProperty("remaining_driving_time_of_current_week")
    val remainingDrivingTimeOfCurrentWeek: Int?,
    @JsonProperty("remaining_2_weeks_driving_time")
    val remainingTwoWeeksDrivingTime: Int?,
    @JsonProperty("time_left_until_next_driving_period")
    val timeLeftUntilNextDrivingPeriod: Int?,
    @JsonProperty("duration_of_next_driving_period")
    val durationOfNextDrivingPeriod: Int?,
    @JsonProperty("duration_of_next_break_rest")
    val durationOfNextBreakRest: Int?,
    @JsonProperty("remaining_time_of_current_break_rest")
    val remainingTimeOfCurrentBreakRest: Int?,
    @JsonProperty("remaining_time_until_next_break_or_rest")
    val remainingTimeUntilNextBreakOrRest: Int?,
    @JsonProperty("open_compensation_in_the_last_week")
    val openCompensationInTheLastWeek: Int?,
    @JsonProperty("open_compensation_in_week_before_last")
    val openCompensationInWeekBeforeLast: Int?,
    @JsonProperty("open_compensation_in_2nd_week_before_last")
    val openCompensationIn2ndWeekBeforeLast: Int?,
    @JsonProperty("additional_information")
    val additionalInformation: DrivingAndRestingDetailsAdditionalInformationMessage?
)

data class DrivingAndRestingDetailsAdditionalInformationMessage(
    @JsonProperty("remaining_10h_driving_times")
    val remaining10hDrivingTimes: Int?,
    @JsonProperty("remaining_reduced_daily_rest_periods")
    val remainingReducedDailyRestPeriods: Int?,
    @JsonProperty("unknown_periods")
    val unknownPeriods: Boolean?,
    @JsonProperty("data_availability_on_driver_card")
    val dataAvailabilityOnDriverCard: Boolean?,
    @JsonProperty("weekly_rest_period_calculation_status")
    val weeklyRestPeriodCalculationStatus: Boolean?,
    @JsonProperty("multi_manning_detection_status")
    val multiManningDetectionStatus: Boolean?,
    @JsonProperty("time_overlap_detection_status")
    val timeOverlapDetectionStatus: Boolean?
)
