import styled, { css } from 'styled-components'

import colors from 'core/assets/styles/colors'

import Button from 'components/Button'

export const CardStyled = styled.div`
  background-color: ${colors.white};
  border: 1px solid ${colors.borderDefault};
  border-radius: 5px;
  min-width: 491px;
  transition: box-shadow 0.3s;
  :hover {
    box-shadow: 0px 0px 11px 0px ${colors.grayMedium};
  }
`

export const Header = styled.div`
  align-items: center;
  background-color: ${colors.white};
  border-bottom: 1px solid ${colors.borderDefault};
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  display: flex;
  justify-content: space-between;
  padding: 5px 10px;
`

export const HeaderTitle = styled.p`
  font-size: 2.1rem;
  font-weight: bold;
  padding-right: 10px;
`

export const Body = styled.div`
  align-items: center;
  display: flex;
  justify-content: space-around;
  padding: 10px;
`

export const Link = styled(Button)<{ clicked: boolean }>`
  font-size: 20px;
  padding-bottom: 20px;
  width: 100%;

  ${({ clicked }) =>
    clicked &&
    css`
      font-weight: bold;
    `}

  :hover :active {
    color: ${colors.primaryDark};
  }

  :hover {
    color: ${colors.primaryDark};
  }

  :active {
    color: ${colors.primaryDark};
  }

  :focus {
    color: ${colors.primaryDark};
  }
`
