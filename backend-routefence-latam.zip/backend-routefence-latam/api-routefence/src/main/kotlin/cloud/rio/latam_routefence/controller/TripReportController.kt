package cloud.rio.latam_routefence.controller


import cloud.rio.latam_routefence.domain.api.TripReportApi
import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import cloud.rio.latam_routefence.services.TripReportService
import org.springframework.http.HttpHeaders
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RestController
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.TripResumeReportResponse
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RestController
class TripReportController(private val tripReportService : TripReportService) : TripReportApi {

    override fun getAllIdTripReport(
        tripId: String,
        orderBy: String?,
        search: String?,
        page: Int?,
        pageSize: Int?,
        status: TripStatusEnum?
    ): BaseCollectionResponse<TripResumeReportResponse> {
        val tripsResumeReport = tripReportService.findAllResumeReport(tripId, orderBy, search, page, pageSize, status)
        return BaseCollectionResponse(tripsResumeReport, tripsResumeReport.size)
    }

    override fun downloadCsv(
        tripId: String,
        orderBy: String?,
        search: String?,
        status: TripStatusEnum?,
    ): ResponseEntity<ByteArray> {
        val fileName = "trip_report_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))}.csv"
        val csvData = tripReportService.getCsvDataForDownload(tripId, orderBy, search, status)
        val contentDisposition = "attachment; filename=\"$fileName\""
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition)
            .body(csvData.toByteArray())
    }

    override fun downloadXlsx(
        tripId: String,
        orderBy: String?,
        search: String?,
        status: TripStatusEnum?
    ): ResponseEntity<ByteArray> {
        val fileName = "trip_report_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))}.xlsx"
        val xlsxData = tripReportService.getXlsxDataForDownload(tripId, orderBy, search, status)
        val contentDisposition = "attachment; filename=\"$fileName\""
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition)
            .body(xlsxData.toByteArray())
    }


}