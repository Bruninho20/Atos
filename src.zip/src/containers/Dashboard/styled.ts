import styled from 'styled-components'
import media from 'styled-media-query'

export const DashboardWrapper = styled.div`
  ${media.greaterThan('large')`
  .table-wrapper {
    margin-top: -49px;
  }`}
`
