import React, { FC } from 'react';

import { Dialog } from 'rio-uikit';
import { Button } from 'components';

import { BodyWrapper } from './style';

interface CustomDialogProps {
  cancelText?: string | React.ReactElement;
  confirmText?: string | React.ReactElement;
  description: string | React.ReactElement;
  id: string;
  onCancel?(): void;
  onConfirm?(): void;
  onClose?(): void;
  open: boolean;
  showCloseButton?: boolean;
  title: string | React.ReactElement;
}

const CustomDialog: FC<CustomDialogProps> = ({
  cancelText,
  confirmText,
  description,
  id,
  showCloseButton,
  onCancel,
  onConfirm,
  onClose,
  open,
  title
}) => {
  const renderActions = () => {
    return (
      <BodyWrapper id={id}>
        {cancelText && onCancel && (
          <Button
            className="tracking-cancel-button"
            color="default"
            label={cancelText}
            onClick={onCancel}
          />
        )}
        {confirmText && onConfirm && (
          <Button
            className="tracking-confirm-button"
            color="primary"
            label={confirmText}
            onClick={onConfirm}
          />
        )}
      </BodyWrapper>
    );
  };

  return (
    <Dialog
      show={open}
      title={title}
      body={description}
      footer={
        cancelText && onCancel && confirmText && onConfirm && renderActions()
      }
      onHide={onClose}
      showCloseButton={showCloseButton as boolean}
    />
  );
};

export default CustomDialog;
