import './polyfills'

import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { Route, Router, Switch } from 'react-router-dom'
import { SWRConfig } from 'swr'
import { ThemeProvider } from 'styled-components'
import { handleLoginRedirect, history, main, store } from './configuration'
import { config } from './config'
import AppContainer from 'features/app/containers/App.container'
import { NoMatch } from 'features/app/components/NoMatch'
import { ErrorBoundary } from 'features/app/components/ErrorBoundary'

import theme from 'core/assets/styles/theme'
import { GlobalStyle } from 'core/assets/styles/global'

const renderApplication = () => {
  const root = document.getElementById('root')

  ReactDOM.render(
    <ErrorBoundary>
      <ThemeProvider theme={theme}>
        <SWRConfig
          value={{
            revalidateOnFocus: false,
            revalidateOnMount: true,
            revalidateOnReconnect: false,
            refreshInterval: 300000
          }}>
          <Provider store={store}>
            <Router history={history}>
              <GlobalStyle />
              <Switch>
                <Route path={'/error'} component={NoMatch} />
                <Route path={'/'} component={AppContainer} />
                <Route component={NoMatch} />
              </Switch>
            </Router>
          </Provider>
        </SWRConfig>
      </ThemeProvider>
    </ErrorBoundary>,
    root
  )
}

if (window.location.href.startsWith(config.login.redirectUri as string)) {
  handleLoginRedirect()
} else {
  main(renderApplication)
}

main(renderApplication)
