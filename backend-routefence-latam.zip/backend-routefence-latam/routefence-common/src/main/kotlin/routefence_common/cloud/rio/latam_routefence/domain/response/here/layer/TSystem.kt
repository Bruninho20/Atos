package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class TSystem(
    @JsonProperty("id") var id: Int?,
    @JsonProperty("languageCode") var languageCode: String?,
    @JsonProperty("name") var name: String?
)
