import React, { useState, useEffect } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container, SidesheetWrapper } from './styled'
import CreateRouteSidesheetAuto from './CreteRouteSidesheetAuto'
import CreateRouteSidesheetManual from './CreteRouteSidesheetManual'
import {
  AddressDialog,
  MapRoutefenceAuto,
  StopConfigDialog,
  MapRoutefenceManual,
  AddressDialogManual,
  ModalConfirm
} from '../../../components'
import AddVehicleDialog from 'components/AddVehicleDialog'

const MapDash: React.FC = () => {
  const [openAddressDialog, setOpenAddressDialog] = useState(false)
  const [openAddressDialogManual, setOpenAddressDialogManual] = useState(false)
  const [openStopConfigDialog, setOpenStopConfigDialog] = useState(false)
  const [openConfirm, setOpenConfirm] = useState(false)
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [changeMode, setChangeMode] = useState('auto')
  const [geolocationStop, setGeolocationStop] = useState<any>()
  const [typeRoupePoint, setTypeRoutePoint] = useState('')
  const [data, setData] = useState({
    originRouteData: { lat: '', lng: '', addressStop: '' },
    destinyRouteData: { lat: '', lng: '', addressStop: '' },
    stops: {},
    allStops: [],
    linkedVehicles: [],
    routeParameters: {},
    responseHere: {}
  })

  useEffect(() => {
    localStorage.setItem('originRouteData', JSON.stringify({ lat: '', lng: '', addressStop: '' }))
    localStorage.setItem('destinyRouteData', JSON.stringify({ lat: '', lng: '', addressStop: '' }))
  }, [])

  const handleOpenAddressDialog = (type: string, open: boolean) => {
    setOpenAddressDialog(open)
    setTypeRoutePoint(type)
  }

  const handleOpenAddressDialogManual = (value: any, type: string, open: boolean) => {
    setOpenAddressDialogManual(open)
    setTypeRoutePoint(type)
    setGeolocationStop(value)
  }

  const handleOpenAddVehiclesDialog = (open: boolean) => {
    setOpenAddVehicleDialog(open)
  }

  const handleOpenConfigDialog = (geolocation: any, open: boolean) => {
    setGeolocationStop(geolocation)
    setTypeRoutePoint('stops')
    setOpenStopConfigDialog(open)
  }

  const handleOpenStopDialog = (open: boolean) => {
    setGeolocationStop(undefined)
    setOpenStopConfigDialog(open)
    setTypeRoutePoint('stopsSidesheet')
  }

  const handleGetLatLng = (value: any, type: string, points: any) => {
    if (type === 'originRoute') {
      setData({
        ...data,
        originRouteData: {
          lat: value?.position?.lat,
          lng: value?.position?.lng,
          addressStop: value?.address
        }
        // responseHere: {
        //   response: {
        //     route: [
        //       {
        //         shape: points
        //       }
        //     ]
        //   }
        // }
      })
      localStorage.setItem(
        'originRouteData',
        JSON.stringify({
          lat: value?.position?.lat,
          lng: value?.position?.lng,
          addressStop: value?.address
        })
      )
    }
    if (type === 'destinyRoute') {
      setData({
        ...data,
        destinyRouteData: {
          lat: value?.position?.lat,
          lng: value?.position?.lng,
          addressStop: value?.address
        }
        // responseHere: {
        //   response: {
        //     route: [
        //       {
        //         shape: points
        //       }
        //     ]
        //   }
        // }
      })
      localStorage.setItem(
        'destinyRouteData',
        JSON.stringify({
          lat: value?.position?.lat,
          lng: value?.position?.lng,
          addressStop: value?.address
        })
      )
    }
    if (type === 'stops') {
      setData({ ...data, stops: value })
    }
    // if(type === 'points') {
    //   setData({
    //     ...data,
    //     responseHere: {
    //       response: {
    //         route: [
    //           {
    //             shape: points
    //           }
    //         ]
    //       }
    //     }
    //   })
    // }
  }

  const handleSaveRouteParameters = (parameters: object) => {
    setData({ ...data, responseHere: parameters })
  }

  // const handleAddPointsToShape = (shape: any) => {
  //   handleGetLatLng('value', 'points', shape)
  // }

  const handleAddVehicles = (vehicles: any) => {
    console.log(vehicles, 'VEHICLES FORA')
    setData({ ...data, linkedVehicles: vehicles })
  }

  const handleAddStops = (stops: any) => {
    setData({ ...data, allStops: stops })
  }

  const handleUpdateParameters = (routeParameters: any) => {
    setData({ ...data, routeParameters })
  }

  const handleChangeMode = (type: string) => {
    setChangeMode(type)
  }

  const handleAddCrossing = (crossing: never) => {
    console.log(crossing, 'CROSSING')
    const originRouteData: any = localStorage.getItem('originRouteData')
    const destinyRouteData: any = localStorage.getItem('destinyRouteData')
    const newData = { ...data }

    newData.allStops.push(crossing)
    newData.originRouteData = JSON.parse(originRouteData)
    newData.destinyRouteData = JSON.parse(destinyRouteData)

    console.log(newData, 'NEW DATA AGORA')
    setData(newData)
  }

  console.log(data, 'DATA FORA')

  return (
    <div>
      <AddressDialog
        title='Procurar endereço'
        isOpen={openAddressDialog}
        onClose={() => setOpenAddressDialog(false)}
        type={typeRoupePoint}
        getLatLng={handleGetLatLng}
      />
      <ModalConfirm
        title='Deseja mesmo cancelar a criação de rota?'
        subtitle='Ao cancelar perderá todos os dados cadastrados'
        isOpen={openConfirm}
        onClose={() => setOpenConfirm(false)}
      />
      <AddressDialogManual
        title='Procurar endereço manual'
        isOpen={openAddressDialogManual}
        onClose={() => setOpenAddressDialogManual(false)}
        type={typeRoupePoint}
        getLatLng={handleGetLatLng}
        geolocation={geolocationStop}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type={'addVehicle'}
        typeToTrip=''
        saveLinkedVehicles={handleAddVehicles}
        data={undefined}
      />
      <StopConfigDialog
        title='Adicionar Parada'
        isOpen={openStopConfigDialog}
        onClose={() => setOpenStopConfigDialog(false)}
        type={typeRoupePoint}
        handleSaveStopManual={handleAddCrossing}
        geolocation={geolocationStop}
        getLatLng={handleGetLatLng}
      />
      {changeMode === 'auto' ? (
        <Container>
          <MapWrapper>
            <MapRoutefenceAuto
              data={data}
              handleSaveRouteParameters={handleSaveRouteParameters}
              handleOpenConfigDialog={handleOpenConfigDialog}
              handleOpenAddressDialogManual={handleOpenAddressDialogManual}
              handleAddStops={handleAddCrossing}
            />
          </MapWrapper>
          <SidesheetWrapper>
            <CreateRouteSidesheetAuto
              setOpenConfirm={() => setOpenConfirm(true)}
              handleOpenStopDialog={() => handleOpenStopDialog(true)}
              handleChangeMode={handleChangeMode}
              handleOpenAddressDialog={handleOpenAddressDialogManual}
              handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
              handleAddStops={handleAddStops}
              data={data}
              handleUpdateParameters={handleUpdateParameters}
            />
          </SidesheetWrapper>
        </Container>
      ) : (
        <Container>
          <MapWrapper>
            <MapRoutefenceManual
              data={data}
              handleAddStops={handleAddCrossing}
              handleOpenConfigDialog={handleOpenConfigDialog}
              handleOpenAddressDialogManual={handleOpenAddressDialogManual}
              // handleAddPointsToShape={handleAddPointsToShape}
              handleSaveRouteParameters={handleSaveRouteParameters}
            />
          </MapWrapper>
          <SidesheetWrapper>
            <CreateRouteSidesheetManual
              handleChangeMode={handleChangeMode}
              handleOpenAddressDialog={handleOpenAddressDialog}
              handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
              handleAddStops={handleAddStops}
              data={data}
              handleUpdateParameters={handleUpdateParameters}
            />
          </SidesheetWrapper>
        </Container>
      )}
    </div>
  )
}

export default injectIntl(MapDash)
