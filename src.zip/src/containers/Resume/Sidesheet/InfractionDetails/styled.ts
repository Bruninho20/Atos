import styled from 'styled-components'

export const WrapperContent = styled.div`
  padding: 7px;
  display: flex;
  flex-direction: column;
  width: 430px;
  height: 100%;
  padding: 15px;
`

export const SideSheetContentWrapper = styled.div`
  padding: 0 15px 45px 15px;
  margin-top: 15px;
  width: 100%;
  margin-bottom: 100px;
`

export const CardContent = styled.div`
  margin-top: 25px;
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  width: 100%
  border: 1px solid;
  height: auto;
  box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
`

export const Card = styled.div`
  padding: 5px;
  height: 75px;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-content: center;
  align-items: center;
  border-bottom: 1px solid #d6d2d2;
`

export const IconCard = styled.div`
  display: flex;
  width: 35px;
  height: auto;
  justify-content: center;
  align-content: center;
  align-items: center;
`

export const TextArea = styled.div`
  display: flex;
  width: 280px;
  height: auto;
  flex-direction: column;
  justify-content: flex-start;
  align-content: flex-start;
  align-items: flex-start;
`

export const DateArea = styled.div`
  display: flex;
  width: 100px;
  height: auto;
  flex-direction: column;
  justify-content: flex-start;
  align-content: flex-start;
  align-items: flex-start;
  margin-right: -10px;
`

export const HeaderCard = styled.div`
  margin-top: 20px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 40px 10px;
  width: 100%;
  height: 120px;
  border-bottom: 1px solid #d6d2d2;
`

export const Container = styled.div`
  margin-top: 25px;
  display: flex;
  flex-direction: column;
  justify-content: start-flex;
  border-bottom: 1px solid #adadad;
`

export const Label = styled.span`
  color: #878585;
  margin-left: 3px;
  margin-bottom: 0;
  font-size: 12px;
`

export const TypeInfraction = styled.span`
  color: #878585;
  font-size: 14px;
  font-weight: bold;
  margin-left: 5px;
`

export const Description = styled.span`
  color: #878585;
  font-size: 14px;
  margin-left: 5px;
`

export const DateInfraction = styled.span`
  color: #878585;
  font-size: 11px;
`
