package cloud.rio.latam_routefence.RouteSimulator

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.readValue
import org.springframework.boot.autoconfigure.SpringBootApplication
import java.io.File
import java.time.LocalDateTime
import java.time.OffsetDateTime

@SpringBootApplication
class HistoryAsset2
fun main(args: Array<String>) {

    data class DataAsset(
        val latitude: Double,
        val longitude: Double,
        val occurredAt: OffsetDateTime,
        val speed: Double,
        val mileageInKm: Double
    )

    fun convertJsonToDataAsset(jsonFile: File): List<DataAsset> {
        val mapper = ObjectMapper().registerModule(JavaTimeModule())
        var previousLat: Double? = null
        var previousLong: Double? = null
        val jsonList = mapper.readValue<List<Map<String, Any>>>(jsonFile)

        var c = jsonList.size / 6
        var minSpd = 30.0
        var maxSpd = 130.0


        var cSpd = (maxSpd - minSpd) / c


        var lastSpd = minSpd



        return jsonList.mapIndexed{idx, jsonObj ->
            val latitude = jsonObj["latitude"] as Double
            val longitude = jsonObj["longitude"] as Double
            val occurredAt = OffsetDateTime.parse(jsonObj["occurred_at"] as String)
//            var speed = (10..120).random().toDouble()
            val mileage_in_km = jsonObj["mileage_in_km"] as Double ?: 0.0

            lastSpd =
                if(idx %6 == 0)
                    lastSpd + cSpd
                else
                    lastSpd

            var speed = lastSpd

            if (latitude == previousLat && longitude == previousLong) {
                speed = 0.0
            } else {
                previousLat = latitude
                previousLong = longitude
            }
            DataAsset(
                latitude = latitude,
                longitude = longitude,
                speed = speed,
                occurredAt = occurredAt,
                mileageInKm = mileage_in_km
            )
//            DataAsset(occurredAt, latitude, longitude, speed)
        }
    }

    fun writeDataAssetToFile(dataAssetList: List<DataAsset>, outputFile: String) {
        var currentOccurredAt = LocalDateTime.now()

        val dataAssetStringList = dataAssetList.joinToString(",\n") { dataAsset ->
            val occurredAtString = currentOccurredAt.toString()
            currentOccurredAt = currentOccurredAt.plusSeconds(1)

            var speedString = dataAsset.speed.toString()
            if (dataAsset.speed == 0.0) {
                "\n//parada\n"
            } else {
                ""
            } + """
        DataAsset(
            occurred_at= OffsetDateTime.parse("${occurredAtString}Z"),
            latitude= ${dataAsset.latitude},
            longitude= ${dataAsset.longitude},
            speed= ${speedString},
            mileage_in_km = ${dataAsset.mileageInKm}
        )
        """.trimIndent()
        }
        File(outputFile).writeText(dataAssetStringList)
    }

    val basePath = "C:\\Projetos\\vwco\\back\\backend-routefence-latam"
    val projPath = "\\src\\test\\kotlin\\cloud\\rio\\latam_routefence\\RouteSimulator"
    val fileName = "data_dummy_edelivery"


    val jsonFile = File("${basePath}${projPath}\\json\\${fileName}.json")
    val dataAssets = convertJsonToDataAsset(jsonFile)

    val outputFile = "${basePath}${projPath}\\${fileName}_assets.txt"

    writeDataAssetToFile(dataAssets, outputFile)
    println("Pronto")
}
