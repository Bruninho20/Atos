package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_COSTS")
data class CostsEntity (
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "TOLL_VALUE")
    var tollValue: Float? = null,

    @Column(name = "OPERATIVE_COSTS")
    var operativeCosts: Float? = null,

    @Column(name = "TOTAL_COSTS")
    var totalCosts: Float? = null,

    @Column(name = "FUEL_AVERAGE_COSTS")
    var fuelAverageCosts: Float? = null,

    @Column(name = "AVERAGE_CONSUME")
    var averageConsume: Float? = null,

    override var accountId: String = ""
): AccountTenantEntity(accountId)
