package cloud.rio.latam_routefence.infrastructure.infringement

import cloud.rio.latam_routefence.services.InfringementService
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import java.time.LocalDateTime

@Service
class ForbiddenDirection(private val infringementService: InfringementService) : IInfringible {

    private val logger = LoggerFactory.getLogger(this.javaClass)

    override fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest? {
        if (trip.status == TripStatusEnum.STARTED) {
            val speed = asset.position?.speed ?: 0.0
            if (speed > 1) {
                val trafficViolation =
                    trafficViolationList.firstOrNull { it.type == InfringementTypeEnum.FORBIDDEN_DIRECTION }
                if (trafficViolation != null) {
                    logger.debug("Veiculo entrou em sentido proibido.")
                    return setInfringement(
                        asset.position!!.latitude.toFloat(),
                        asset.position!!.longitude.toFloat(),
                        trip.id,
                        trafficViolation.note
                    )
                } else {
                    val openInfringements =
                        infringementService.findByTripAndType(trip.id, InfringementTypeEnum.FORBIDDEN_DIRECTION)
                    openInfringements.forEach {
                        it.endDateTime = LocalDateTime.now()
                        infringementService.closeInfringement(it)
                    }
                }
            }
        }
        return null
    }

    private fun setInfringement(
        lat: Float, lng: Float, tripId: String, note: String?
    ): InfringementRequest {
        return InfringementRequest(
            null,
            InfringementTypeEnum.FORBIDDEN_DIRECTION,
            note,
            LocalDateTime.now(),
            null,
            GeoPointRequest(null, lat, lng, null),
            tripId
        )
    }

}