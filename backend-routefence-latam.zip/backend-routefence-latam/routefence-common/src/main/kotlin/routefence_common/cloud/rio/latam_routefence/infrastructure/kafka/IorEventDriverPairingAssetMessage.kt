package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import org.springframework.format.annotation.DateTimeFormat
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.EnumStringConsistencyDeserializer
import java.time.OffsetDateTime
import java.util.*

data class IorEventDriverPairingAssetMessage(
    @JsonProperty("asset_id")
    val assetId: UUID,

    @JsonProperty("account_id")
    val accountId: String,

    @JsonProperty("device_id")
    val deviceId: UUID,

    @JsonProperty("device_type")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val deviceType: String?,
    @JsonProperty("driver_identification")
    val driverIdentification: String?,

    @JsonProperty("driver_identification_type")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val driverIdentificationType: String?,

    @JsonProperty("eid")
    val eid: String,

    @JsonProperty("occurred_at")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    val occurredAt: OffsetDateTime,

    @JsonProperty("trigger")
    @JsonDeserialize(using = EnumStringConsistencyDeserializer::class)
    val trigger: String
)
