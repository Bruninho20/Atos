package cloud.rio.latam_routefence.domain.request

import javax.validation.constraints.NotBlank

data class MessageRequest (

    @NotBlank
    var recipientList:List<String>,

    @NotBlank
    var subject:String,

    @NotBlank
    var content:String
)
