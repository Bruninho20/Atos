import React, { FC } from 'react'
import { IconItem } from 'core/assets/images'
import { WelcomeStyled } from './styled'

interface WelcomePageProps {
  title: string | React.ReactElement
  description: string | React.ReactElement
}

const WelcomePage: FC<WelcomePageProps> = ({ title, description }) => {
  return (
    <WelcomeStyled>
      {IconItem('welcome')}
      <h2>{title}</h2>
      <p>{description}</p>
    </WelcomeStyled>
  )
}

export default WelcomePage
