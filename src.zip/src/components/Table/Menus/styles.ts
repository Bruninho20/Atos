import styled from 'styled-components';

export const Wrapper = styled.div`
  display: flex;
`;

export const Button = styled.div`
  display: flex;
  min-width: 90px;
  height: 30px;
  padding-left: 10px;
  margin: 10px 10px 0 0;
  color: #4d4d4dd5;
  cursor: pointer;
  font-size: 14px;
`;
