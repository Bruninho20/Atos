import React, { FC, useState, useEffect } from 'react'
import axios from 'axios'
import { FormattedMessage } from 'react-intl'
import { format } from 'date-fns'
import ContentLoader from 'react-content-loader'
import { Row, Col } from 'react-bootstrap'
import useSWR from 'swr'

import { SideSheet } from 'components'
import IsolineModal from '../IsolineModal'

import { fetcherGet } from 'core/utils/fetch'

import dataSidesheet from '../../../importsJsons/json-server/dataSidesheetEfleet.json'

import MiniCard from '../../../components/MiniCard'
import SidesheetCard from '../../../components/SidesheetCard'
import OperativeSidesheetCard from '../../../components/OperativeSidesheetCard'

import {
  InfractionDetailsTable,
  InfractionDetailsTableColumnLeft,
  InfractionDetailsTableColumnRight,
  InfractionDetailsTableRow,
  SideSheetContentWrapper,
  StyledExpanderPanel
} from 'components/SidesheetTable/styled'

import { CentralizedContent } from './styled'
import DialogFaultCodes from '../VehiclesStatusTable/DialogFaultCodes'

interface Score {
  score: string
  type: string
}

interface OperativeCardData {
  scores: Score[]
  title: string
  batteryLevel: any
  speed: any
  autonomy: any
  regenLevel: any
  vehicleFault: any
  odometer: any
  averageConsuption: any
  avgPowerConsumption: any
  avgPowerAvailability: any
  coolSysFault: any
  ecoMode: any
  turtleMode: any
  name: any
  lat: any
  long: any
  status: any
  statusOfCharging: any
  timeSinceLastCharge: any
  distanceSinceLastCharge: any
}

const DiagnosticDataSidesheet: FC<{
  isOpen: boolean
  assetId: string
  chassis: string
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, assetId, chassis, onClose }) => {
  const [faultCodesDialog, setFaultCodesDialog] = useState({
    isOpen: false
  })

  const { data } = useSWR<OperativeCardData>(['/api/perla-tests/vehicleStatus/newefleet', assetId], url => fetcherGet(url, { assetId }))

  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  const [isolineModal, setIsolineModal] = useState({
    isOpen: false
  })

  const renderSkeletonTable = (data: string[]) => (
    <InfractionDetailsTable>
      {data.map((item, index) => (
        <InfractionDetailsTableRow key={index}>
          <InfractionDetailsTableColumnLeft>
            <ContentLoader width='50%' height='13px' style={{ borderRadius: '3px' }}>
              <rect width='100%' height='100%' />
            </ContentLoader>
          </InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>
            <ContentLoader width='50%' height='13px' style={{ borderRadius: '3px' }}>
              <rect width='100%' height='100%' />
            </ContentLoader>
          </InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const customData = dataSidesheet?.map(item => ({
    title: item.title,
    scores: item.scores.map(score =>
      score.type === 'D'
        ? { ...score, score: format(new Date(score.score), "yyyy-MM-dd'T'HH:mm:ss.SSS") + '-00:00' }
        : score
    )
  }))

  const [points, setPoints] = useState([])

  const rangeSub = data?.autonomy === "0.0" ? (data?.batteryLevel * 200 / 100).toLocaleString().split(',', 1) : data?.autonomy

  const rangeAutonomy = Number(rangeSub) * 1000

  const latSub = data?.lat === "0.0" ? "-23.50922" : data?.lat
  
  const lngSub = data?.long === "0.0" ? "-46.66885" : data?.long

  
  useEffect(() => {
    const herePolygonData = () => {
      axios
        .get(
         `https://isoline.route.ls.hereapi.com/routing/7.2/calculateisoline.json?apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&mode=shortest;car;traffic:disabled&start=geo!${latSub},${lngSub}&range=${rangeAutonomy}&rangetype=distance&singlecomponent=true`
         //`https://isoline.router.hereapi.com/v8/isolines?apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&mode=car&origin=${latSub},${lngSub}&range[values]=${rangeAutonomy}&range[type]=distance&transportMode=car`
          )
        .then((result: any) => {
          const polygonData = result.data
          const getPoints = polygonData.response.isoline[0].component[0].shape.map((value: string) => {
            const [lat, lng] = value.split(',')
            return { lat, lng
         }
          })
          setPoints(getPoints)
        })
    }
    herePolygonData()
  }, [data])

  const activeFault = <p style={{ fontWeight: 'normal', fontFamily: 'Antonio', color: '#FF0000' }}>{<FormattedMessage id='activeFailure' />}</p>

  const powerOff = <p style={{ fontWeight: 'normal', fontFamily: 'Antonio', color: '#FF0000' }}>{<FormattedMessage id='off' />}</p>

  const powerOn = <p style={{ fontWeight: 'normal', fontFamily: 'Antonio', color: '#32CD32' }}>{<FormattedMessage id='on' />}</p>

  const speedToFixed = Number(data?.speed).toFixed(1)

  const timeLastCharge = `${String(data?.timeSinceLastCharge / 3600).slice(0, 2)} hs` 

  const titleFormated = <p style={{ fontWeight: 'normal', fontFamily: 'Antonio'}}>{<FormattedMessage id='sidesheet.operationOfVehicle' />}</p>

 
  return (
    <>
      <DialogFaultCodes
        assetId={assetId}
        chassis={chassis}
        isOpen={faultCodesDialog.isOpen}
        onClose={() => setFaultCodesDialog({ isOpen: false })}
      />
      <IsolineModal
      apiKey='E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
      vehicle={data?.name}
      points={points}
      lat={latSub}
      lng={lngSub}
      assetId={assetId}
      chassis={chassis}
      isOpen={isolineModal.isOpen}
      onClose={() => setIsolineModal({ isOpen: false })}
      autonomy={data?.autonomy}
      batteryLevel={data?.batteryLevel}
      statusNow={data?.status}
    />
      <SideSheet
        modal
        width='700px'
        padding='0'
        open={isOpen}
        title={data?.name}
        onClick={() => handleOnClose(false)}>
        <SideSheetContentWrapper>
          <CentralizedContent>
          <Row>
            <Col md='4'>
              <SidesheetCard title={<FormattedMessage id='sidesheet.batteryLevel' />} description={data?.batteryLevel} />
            </Col>
            <Col md='4'>
              <SidesheetCard title={<FormattedMessage id='sidesheet.regenLevel' />} description={data?.regenLevel} />
            </Col>
            <Col md='4'>
              <SidesheetCard title={<FormattedMessage id='sidesheet.avgPowerAvailability' />} description={data?.avgPowerAvailability} />
            </Col>
          </Row>
          </CentralizedContent>
          {customData
            ? customData.map(item => (
                <>
                  <Row>
                    <Col md='8'>
                      <OperativeSidesheetCard
                        title={titleFormated}
                        onCharge={data?.statusOfCharging === "NÃO CARREGANDO" ? powerOff : powerOn}
                        potencyLimiter={data?.turtleMode === 'false' ? powerOff : powerOn}
                        ecoMode={data?.ecoMode === 'false' ? powerOff : powerOn}
                        eletricFail={data?.vehicleFault === "0.0" ? <FormattedMessage id='noFault' /> : activeFault}
                        coolingFail={data?.coolSysFault === "0.0" ? <FormattedMessage id='noFault' /> : activeFault}
                        odometer={`${(data?.odometer / 1000).toFixed(2)} km`}
                        distance={`${(data?.distanceSinceLastCharge / 1000).toFixed(2)} km`}
                        time={timeLastCharge}
                      />
                    </Col>
                    <CentralizedContent>
                    <Col md='4'>
                      <Row>
                        <Col md='12'>
                          <MiniCard title={<FormattedMessage id='sidesheet.autonomy' />} description={`${rangeSub} km` } />
                        </Col>
                      </Row>
                      <Row>
                        <Col md='12'>
                          <MiniCard title={<FormattedMessage id='sidesheet.speed' />} description={`${speedToFixed} km/h`} />
                        </Col>
                      </Row>
                      <Row>
                        <Col md='12'>
                          <MiniCard title={<FormattedMessage id='sidesheet.avgPowerConsumption' />} description={`${data?.avgPowerConsumption} kWh/km`} />
                        </Col>
                      </Row>
                    </Col>
                    </CentralizedContent>
                    
                  </Row>
                </>
              ))
            : [
                ['', '', '', '', ''],
                ['', '', '', '', '']
              ].map((values, index) => (
                <StyledExpanderPanel
                  key={index}
                  title={
                    <ContentLoader width='100%' height='13px' style={{ borderRadius: '3px' }}>
                      <rect width='100%' height='100%' />
                    </ContentLoader>
                  }
                  open={isOpen}>
                  {renderSkeletonTable(values)}
                </StyledExpanderPanel>
              ))}
          <div>
            <button type='button' className='btn btn-default' onClick={() => setIsolineModal({ isOpen: true })}>
              <span className='rioglyph rioglyph-map-marker' aria-hidden='true'></span>
              {<FormattedMessage id='sidesheet.seeTheMap' />}
            </button>
          </div>
        </SideSheetContentWrapper>
      </SideSheet>
    </>
  )
}

export default DiagnosticDataSidesheet
