package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.AddressRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.AddressResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AddressEntity

fun AddressRequest.mapToEntity(): AddressEntity {
    return AddressEntity(
        label = this.label,
        countryCode = this.countryCode,
        countryName = this.countryName,
        stateCode = this.stateCode,
        state = this.state,
        city = this.city,
        district = this.district,
        street = this.street,
        postalCode = this.postalCode,
        houseNumber = this.houseNumber
    )
}

fun AddressEntity.mapToResponse() : AddressResponse {
    return AddressResponse(
        id = this.id,
        label = this.label,
        countryCode = this.countryCode,
        countryName = this.countryName,
        stateCode = this.stateCode,
        state = this.state,
        city = this.city,
        district = this.district,
        street = this.street,
        postalCode = this.postalCode,
        houseNumber = this.houseNumber
    )
}

fun AddressEntity.copyFromRequest(req: AddressRequest?) : AddressEntity? {
    req?.label?.let { this.label = it }
    req?.countryCode?.let { this?.countryCode = it }
    req?.countryName?.let { this?.countryName = it }
    req?.stateCode?.let { this?.stateCode = it }
    req?.state?.let { this?.state = it }
    req?.city?.let { this?.city = it }
    req?.district?.let { this?.district = it }
    req?.street?.let { this?.street = it }
    req?.postalCode?.let { this?.postalCode = it }
    req?.houseNumber?.let { this?.houseNumber = it }

    return this
}