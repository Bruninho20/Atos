import React, { FC } from 'react'
import { FormattedMessage } from 'react-intl'

import { SideSheet } from 'components'

import Map from 'components/Map'

import { FaultCodeModel } from '.'

import {
  InfractionDetailsTable,
  InfractionDetailsTableColumnLeft,
  InfractionDetailsTableColumnRight,
  InfractionDetailsTableRow,
  SideSheetContentWrapper,
  StyledExpanderPanel
} from 'components/SidesheetTable/styled'

export type CustomFaultCodesModel = Pick<
  FaultCodeModel,
  | 'vehicle'
  | 'date'
  | 'description'
  | 'spn'
  | 'spnDescription'
  | 'fmi'
  | 'fmiDescription'
  | 'latitude'
  | 'longitude'
  | 'lampStatus'
  | 'sourceAddress'
> & {
  geolocation: string
}

const FaultCodesDetailsSidesheet: FC<{
  isOpen: boolean
  data?: CustomFaultCodesModel
  onClose?: (val: boolean) => void
}> = ({ isOpen = false, data, onClose }) => {
  const handleOnClose = (close: boolean) => {
    onClose && onClose(close)
  }

  const renderTable = (
    faultCodes: Pick<
      CustomFaultCodesModel,
      'vehicle' | 'date' | 'description' | 'spn' | 'fmi' | 'lampStatus' | 'geolocation' | 'sourceAddress'
    >
  ) => (
    <InfractionDetailsTable>
      {Object.entries(faultCodes).map(faultCode => (
        <InfractionDetailsTableRow key={faultCode[0]}>
          <InfractionDetailsTableColumnLeft><FormattedMessage id={faultCode[0]} /></InfractionDetailsTableColumnLeft>
          <InfractionDetailsTableColumnRight>{faultCode[1]}</InfractionDetailsTableColumnRight>
        </InfractionDetailsTableRow>
      ))}
    </InfractionDetailsTable>
  )

  const customDataFormat: Pick<
    CustomFaultCodesModel,
    'vehicle' | 'date' | 'description' | 'spn' | 'fmi' | 'lampStatus' | 'geolocation' | 'sourceAddress'
  > = {
    vehicle: data?.vehicle || '',
    date: data?.date || '',
    description: data?.description || '',
    spn: `${data?.spn} - ${data?.spnDescription}`,
    fmi: `${data?.fmi} - ${data?.fmiDescription}`,
    lampStatus: data?.lampStatus || '',
    geolocation: data?.geolocation || '',
    sourceAddress: data?.sourceAddress || ''
  }

  return (
    <>
      <SideSheet
        modal
        width='445px'
        padding='0'
        open={isOpen}
        title={`Detalhes da infração de ${data?.vehicle}`}
        onClick={() => handleOnClose(false)}>
        <SideSheetContentWrapper>
          <StyledExpanderPanel title={<FormattedMessage id='faultCodes.details.sidesheet.summary'  />} open={true}>
            {customDataFormat && renderTable(customDataFormat)}
          </StyledExpanderPanel>
          {typeof data?.latitude === 'number' && typeof data?.longitude === 'number' && (
            <StyledExpanderPanel title={<FormattedMessage id='faultCodes.details.sidesheet.map' />} open={true}>
              <Map
                height='300px'
                apiKey='E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
                labelName={data?.description}
                latitude={data?.latitude}
                longitude={data?.longitude}
              />
            </StyledExpanderPanel>
          )}
        </SideSheetContentWrapper>
      </SideSheet>
    </>
  )
}

export default FaultCodesDetailsSidesheet
