import React, { FC } from 'react'
import { StyledButton } from './styled'

interface Props {
  color?: string
  className?: string
  disabled?: boolean
  icon?: string
  label?: string | undefined | React.ReactElement
  onClick(): void
  onlyIcon?: boolean
  type?: 'button' | 'submit' | 'reset' | undefined
}

const Button: FC<Props> = ({
  color = 'default',
  className = '',
  disabled = false,
  icon,
  label,
  onClick,
  onlyIcon = false,
  type = 'button'
}) => (
  <StyledButton
    type={type}
    className={`${className} btn btn-${color} ${disabled && 'disabled'}`}
    onClick={onClick}
    onlyIcon={onlyIcon}>
    {icon && <span data-testid={`icon-${icon}`} className={`rioglyph rioglyph-${icon}`} aria-hidden='true'></span>}
    <span className='text-button'>{label}</span>
  </StyledButton>
)

export default React.memo(Button)
