package routefence_common.cloud.rio.latam_routefence.tenant

import org.aspectj.lang.JoinPoint
import org.hibernate.Session
import javax.persistence.EntityManager

open class ServiceAspectBase(private val em: EntityManager) {

    open fun filter(pjp: JoinPoint) {
        em.unwrap(Session::class.java)
            ?.enableFilter(AccountContext.ACCOUNT_FILTER)
            ?.setParameter(AccountContext.ACCOUNT_ID_PARAM, AccountContext.get())
            ?.validate()
    }
}
