import { Store } from 'redux'
import { History } from 'history'

type IdToken = {
  sub: string
  azp: string
  account: string
  given_name: string
  family_name: string
  name: string
  locale: string
  email: string
}

type AccessToken = string | undefined | null

type UserProfileType = {
  email?: string
  givenName?: string
  familyName?: string
  locale: string
}

interface LanguageDataInterface {
  [key: string]: string
}

interface MessagesInterface {
  [key: string]: LanguageDataInterface
}

interface AccessTokenState {
  accessToken: AccessToken
  idToken: IdToken | null
}

interface LanguageState {
  allMessages: MessagesInterface
  canFetchSupportedLocale?: boolean
  displayMessages?: LanguageDataInterface
  displayLocale?: string
  preferredLocale?: string
  supportedLocale?: string
}

interface LoginState {
  hasUserSessionEverExpired: boolean
  userProfile: UserProfileType | null
  userSessionExpired: boolean
}

interface GenericActionInterface {
  type?: string
  payload?: uknown
}

declare function configReducer(state: uknown, action: GenericActionInterface): uknown
declare function langReducer(state: uknown, action: GenericActionInterface): uknown
declare function loginReducer(state: uknown, action: GenericActionInterface): uknown
declare function tokenHandlingReducer(state: uknown, action: GenericActionInterface): uknown

declare function handleLoginRedirect(): void
declare function main(renderFn: () => void): void
declare function getAccessToken(state: State): AccessToken
declare function getIdToken(state: uknown): IdToken
declare function isUserSessionExpired(state: uknown): boolean
declare function getLanguageData(state: uknown): LanguageDataInterface
declare function getLocale(state: uknown): string
declare function getUserAccount(state: uknown): string | null

declare const store: Store
declare const history: History<uknown>
declare const DEFAULT_LOCALE: string

export {
  main,
  handleLoginRedirect,
  configReducer,
  getAccessToken,
  getIdToken,
  getLanguageData,
  getLocale,
  getUserAccount,
  history,
  isUserSessionExpired,
  langReducer,
  loginReducer,
  store,
  tokenHandlingReducer,
  AccessToken,
  AccessTokenState,
  IdToken,
  LanguageDataInterface,
  LanguageState,
  LoginState,
  MessagesInterface,
  UserProfileType,
  DEFAULT_LOCALE
}
