package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.request.RouteRequest
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteEntity
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import java.sql.Timestamp
import java.time.Instant
import java.time.LocalDateTime

fun RouteRequest.mapToEntity(): RouteEntity {
    return RouteEntity(
        routeName = this.routeName!!.toString(),
        accountId = this.accountId ?: throw RoutefenceException.RoutefenceInternalException("Invalid.account.id"),
        geoPointOrigin = this.originRoute!!.mapToEntity(),
        geoPointDestiny = this.destinyRoute!!.mapToEntity(),
        rangeToleranceLimit = this.rangeToleranceLimit,
        range = this.roadParameters!!.mapToEntity(),
        vehicleVocationalInfo = this.vehicleVocationalInfo!!.mapToEntity(),
        costs = this.costs!!.mapToEntity(),
        creationDate = LocalDateTime.now(),
        deletionDate = null,
        routeParentId = null,
        lastChangeDate = null,
        trips = null,
        stops = null,
        avoidArea = avoidArea,
        responseHere = responseHere
    )
}

fun RouteEntity.mapToResponse() : RouteResponse {
    return RouteResponse(
        id = this.id,
        idLayer = this.idLayer.toString(),
        creationDate = this.creationDate.toString(),
        accountId = this.accountId,
        routeName = this.routeName,
        status = trips?.let{ it.any{ it.status == TripStatusEnum.STARTED || it.status == TripStatusEnum.SCHEDULED }} ?: false,
        originRoute = this.geoPointOrigin.mapToResponse(),
        destinyRoute = this.geoPointDestiny.mapToResponse(),
        rangeToleranceLimit = this.rangeToleranceLimit.toString(),
        stops = this.stops?.map { it.mapToResponse() },
        roadParameters = this.range?.mapToResponse(),
        vehicleVocationalInfo = this.vehicleVocationalInfo?.mapToResponse(),
        costs = this.costs?.mapToResponse(),
        avoidArea = this.avoidArea,
        responseHere = this.responseHere
    )
}

fun RouteEntity.copyFromRequest(req: RouteRequest?) : RouteEntity {
    req?.routeName?.let { this.routeName = it }
    req?.originRoute?.let { this.geoPointOrigin.copyFromRequest(it) }
    req?.destinyRoute?.let { this.geoPointDestiny.copyFromRequest(it) }
    req?.rangeToleranceLimit?.let { this.rangeToleranceLimit = it }
    req?.roadParameters?.let { this.range.copyFromRequest(it) }
    req?.costs?.let { this.costs.copyFromRequest(it) }
    req?.vehicleVocationalInfo?.let { this.vehicleVocationalInfo.copyFromRequest((it)) }
    this.stops = null
    req?.avoidArea?.let { this.avoidArea = it }
    req?.responseHere?.let { this.responseHere = it }
    return this
}

fun RouteRequest.mapToDuplicatedEntity(routeEntity:RouteEntity, sameResponseHere: Boolean): RouteEntity {
    return RouteEntity(
        idLayer = if(sameResponseHere) routeEntity.idLayer else Timestamp.from(Instant.now()).time,
        routeName = this.routeName ?: routeEntity.routeName,
        accountId = this.accountId ?: routeEntity.accountId,
        geoPointOrigin = this.originRoute?.mapToDuplicateEntity(routeEntity.geoPointOrigin)!!,
        geoPointDestiny = this.destinyRoute?.mapToDuplicateEntity(routeEntity.geoPointDestiny)!!,
        rangeToleranceLimit = this.rangeToleranceLimit,
        range = this.roadParameters?.mapToDuplicatedEntity(routeEntity.range),
        vehicleVocationalInfo = this.vehicleVocationalInfo?.mapToDuplicatedEntity(routeEntity.vehicleVocationalInfo),
        costs = this.costs?.mapToDuplicatedEntity(routeEntity.costs),
        creationDate = LocalDateTime.now(),
        deletionDate = null,
        routeParentId = routeEntity.id,
        lastChangeDate = null,
        trips = null,
        stops = null,
        avoidArea = this.avoidArea ?: routeEntity.avoidArea,
        responseHere = this.responseHere ?: routeEntity.responseHere
    )
}
