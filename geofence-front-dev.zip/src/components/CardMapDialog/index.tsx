import React, { FC } from 'react';
import { FormattedMessage } from 'react-intl';
import PropTypes from 'prop-types';

import {
  Driver,
  BateryInformation,
  AutonomyInformation,
  // DriverTitle,
  // DriverTotal,
  StyledCard,
  StyledSubTitle,
  BateryLevel,
  ContentTitle,
  StatusTitle,
  ContentCard
} from './styled';

interface MapCardProps {
    action?(): void;
    vehicle: any;
    chassis: any;
    autonomy?: any;
    batteryLevel: any;
    status: any,
}

const CardMap: FC<MapCardProps> = ({
  action,
  vehicle,
  chassis,
  autonomy,
  batteryLevel,
  status,
}) => {
  return (
    <StyledCard
      action={action}
      title='Chassis'
      className="card-title"
    >
      <StyledSubTitle>
          <p>{chassis}</p>
        </StyledSubTitle>
      <ContentCard>
        <ContentTitle>{vehicle}</ContentTitle>   
        <StatusTitle>{status}</StatusTitle>
      </ContentCard>
      <Driver>
      <BateryLevel>
          <p>{<FormattedMessage id='sidesheet.batteryLevel' />} </p>
        </BateryLevel>
        <BateryInformation>
          <div className="progress" style={{alignItems: 'center', backgroundColor: '#2F4F4F', width: '99%', height: '20%'}}>
            <div className="progress-bar" role="progressbar" style={{width: `${batteryLevel}%`, alignItems: 'center', backgroundColor: '#2ddada'}}>
              {`${batteryLevel} %`}
            </div>
          </div>
        </BateryInformation>
      </Driver>
      <AutonomyInformation>
        <p>{<FormattedMessage id='sidesheet.autonomy' />} <b>{autonomy} km</b></p>
      </AutonomyInformation>
    </StyledCard>
  );
};

CardMap.propTypes = {
  vehicle: PropTypes.string.isRequired,
  chassis: PropTypes.string.isRequired,
  autonomy: PropTypes.string.isRequired,
  batteryLevel: PropTypes.string.isRequired,
  status: PropTypes.string.isRequired
};

export default CardMap;


