import styled from 'styled-components'

import { colors, metrics } from 'core/assets/styles'
import CardEfleetSidesheet from '../CardEfleetSidesheet'

export const StyledCard = styled(CardEfleetSidesheet)`
  height: 180px;
  justify-content: space-between;
  padding: 0;
  text-align: center;
  align-items: center;
  width: 200px;
  margin-right: 8px;
  margin-bottom: 15px;
  color: ${colors.infoRed};
  transition: box-shadow 10ms linear 0s;
  box-shadow: rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;
  cursor: pointer;
  border: 1px solid rgb(208, 216, 222);
  border-radius: 3px;

  &.card-title {
    font-size: ${metrics.fontSizeDefault};
    color: 'red';

    > div {
      margin-top: 5px;
      text-align: center;
      h1 {
        color: rgb(105, 122, 139);
        font-size: 1.5rem;
        font-family: 'Antonio';
        font-weight: normal;
        margin: 0;
        text-transform: none;
      }
    }
  }

  .speedometer {
    width: 80px;
  }
`
