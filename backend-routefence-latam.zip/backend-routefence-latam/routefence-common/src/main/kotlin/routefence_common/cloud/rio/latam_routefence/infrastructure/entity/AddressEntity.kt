package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_ADDRESSES")
data class AddressEntity (
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "LABEL")
    var label: String? = null,

    @Column(name = "COUNTRY_CODE")
    var countryCode: String? = null,

    @Column(name = "COUNTRY_NAME")
    var countryName: String? = null,

    @Column(name = "STATE_CODE")
    var stateCode: String? = null,

    @Column(name = "STATE")
    var state: String? = null,

    @Column(name = "CITY")
    var city: String? = null,

    @Column(name = "DISTRICT")
    var district: String? = null,

    @Column(name = "STREET")
    var street: String? = null,

    @Column(name = "POSTAL_CODE")
    var postalCode: String? = null,

    @Column(name = "HOUSE_NUMBER")
    var houseNumber: String? = null
) {
    fun acceptNewValues(address: AddressEntity) {
        this.label = address.label
        this.countryCode = address.countryCode
        this.countryName = address.countryName
        this.stateCode = address.stateCode
        this.state = address.state
        this.city = address.city
        this.district = address.district
        this.street = address.street
        this.postalCode = address.postalCode
        this.houseNumber = address.houseNumber
    }
}
