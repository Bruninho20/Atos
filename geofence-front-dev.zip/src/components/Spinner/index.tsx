import React, { FC } from 'react'
import { StyledLoader } from './styled'

interface SpinnerProps {
  loading?: boolean
  fullscreen?: boolean
}

const Spinner: FC<SpinnerProps> = ({ loading = false, fullscreen = false }) =>
  loading ? (
    <StyledLoader fullscreen={fullscreen} data-testid='spinner-loading'>
      <div className='loading'>
        <div className='spinner'>
          <div className='mask' />
        </div>
      </div>
    </StyledLoader>
  ) : (
    <></>
  )

export default React.memo(Spinner)
