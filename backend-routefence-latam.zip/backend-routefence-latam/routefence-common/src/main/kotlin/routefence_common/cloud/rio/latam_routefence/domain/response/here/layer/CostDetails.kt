package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class CostDetails(
    @JsonProperty("driverCost") var driverCost: String?,
    @JsonProperty("energyCost") var energyCost: String?,
    @JsonProperty("optionalValue") var optionalValue: String?,
    @JsonProperty("tollCost") var tollCost: String?,
    @JsonProperty("totalCost") var totalCost: Double?,
    @JsonProperty("vehicleCost") var vehicleCost: String?
)