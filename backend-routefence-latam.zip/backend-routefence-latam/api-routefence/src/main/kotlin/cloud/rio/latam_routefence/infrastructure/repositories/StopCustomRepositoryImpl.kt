package cloud.rio.latam_routefence.infrastructure.repositories

import routefence_common.cloud.rio.latam_routefence.domain.response.AddressResponse
import routefence_common.cloud.rio.latam_routefence.domain.response.GeoPointResponse
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopCategoryEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.StopTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteStopResponse
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query

@Repository
class StopCustomRepositoryImpl : StopCustomRepository {

    @PersistenceContext
    lateinit var entityManager: EntityManager

    override fun getAllStopsByRouteId(routeId: String): List<RouteStopResponse> {

        val sql = """
            select
                trhs.id as trhs_id,
                trhs.range_limit_meters,
                trhs.stay_time,
                trhs.stop_queue_order,
                
                ts."name",
                ts.category,
                   
                tg.id as tgId,
                tg.lat as lat,                
                tg.long as long,
                
                ta.id as taId, 
                ta.city,
                ta.country_Code,
                ta.country_Name,
                ta.district,
                ta.house_Number,
                ta.label,
                ta.postal_Code,
                ta.state,
                ta.state_Code,
                ta.street,
                trhs.stop_type
                
            from
                tb_stops ts
            left join tb_route_has_stop trhs
            on
                ts.id = trhs.stop_id
            left join tb_geopoints tg 
            on
                tg.id = ts.geo_point_id
            left join tb_addresses ta on
                tg.address_id = ta.id
            where
                trhs.route_id = :routeId
        """.trimIndent()

        val query = entityManager.createNativeQuery(sql)
        setQueryParameters(query, routeId)

        return getResultList(query)
    }


    private fun getResultList(query: Query): MutableList<RouteStopResponse> {
        val stops: MutableList<RouteStopResponse> = mutableListOf()

        query.resultList.forEach {
            val objArray = it as Array<*>

            stops.add(
                RouteStopResponse(
                    id = objArray[0].toString(),
                    rangeLimitMeters = objArray[1].toString(),
                    stayTime = objArray[2].toString(),
                    stopQueueOrder = objArray[3] as Int,
                    name = objArray[4].toString(),
                    category = StopCategoryEnum.valueOf(objArray[5].toString()),
                    position = GeoPointResponse(
                        id = objArray[6].toString(),
                        lat = objArray[7] as Float?,
                        lng = objArray[8] as Float?,
                        address = AddressResponse(
                            id = objArray[9].toString(),
                            city = objArray[10].toString(),
                            countryCode = objArray[11].toString(),
                            countryName = objArray[12].toString(),
                            district = objArray[13].toString(),
                            houseNumber = objArray[14].toString(),
                            label = objArray[15].toString(),
                            postalCode = objArray[16].toString(),
                            state = objArray[17].toString(),
                            stateCode = objArray[18].toString(),
                            street = objArray[19].toString()
                        )
                    ),
                    type = StopTypeEnum.valueOf(objArray[20].toString())
                )
            )
        }

        return stops
    }


    private fun setQueryParameters(query: Query, routeId: String?) {
        query.setParameter("routeId", routeId)
    }
}