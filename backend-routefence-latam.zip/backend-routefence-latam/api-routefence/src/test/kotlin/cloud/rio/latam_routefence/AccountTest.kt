package cloud.rio.latam_routefence

import cloud.rio.latam_routefence.services.RouteService
import cloud.rio.latam_routefence.services.StopService
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext

@SpringBootTest
class AccountTest : TestBase (
) {
    private var idRoute: String? = null

    @Autowired
    private lateinit var routeService: RouteService

    @Autowired
    private lateinit var stopService: StopService

    @BeforeEach
    fun init(){
        setAccountContext()
    }

    @AfterEach
    fun clearData(){
        idRoute?.let {
            stopService.deleteByRouteForTests(it)
            routeService.deleteByIdForTests(it)
        }
        AccountContext.clear()
    }

    @Test
    fun validateAccountForTrip() {
        getPayload("trip/trip.json").replace("route_name", "TESTE ATOS").also { payload ->
            val routeEntity = routeService.save(createRouteRequest(payload))
            this.idRoute = routeEntity.id

            Assertions.assertEquals(AccountContext.get(), routeEntity.accountId)
        }
    }
}