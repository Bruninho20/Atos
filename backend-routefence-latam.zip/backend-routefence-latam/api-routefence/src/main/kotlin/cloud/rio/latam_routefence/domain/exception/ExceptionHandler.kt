package cloud.rio.latam_routefence.domain.exception

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.databind.ObjectMapper
import com.project.custom.domain.exception.RioUtilsException
import org.slf4j.LoggerFactory
import org.springframework.context.MessageSource
import org.springframework.context.i18n.LocaleContextHolder
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.FieldError
import org.springframework.validation.ObjectError
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.context.request.WebRequest
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException

data class PerformError(
    val code: String,
    val message: String,
    @field:JsonInclude(JsonInclude.Include.NON_NULL)
    val errors: List<FieldErrorProperty>? = null
)

data class FieldErrorProperty(
    val name: String,
    val message: String
)

@ControllerAdvice
class ExceptionHandler(
    val messageSource: MessageSource
) : ResponseEntityExceptionHandler() {

    private val log = LoggerFactory.getLogger(this.javaClass)

    override fun handleExceptionInternal(
        ex: java.lang.Exception,
        body: Any?,
        headers: HttpHeaders,
        status: HttpStatus,
        request: WebRequest
    ): ResponseEntity<Any> {
        return super.handleExceptionInternal(ex, PerformError("500",ex.message?:"Internal server error",null), headers, status, request)
    }

    override fun handleMethodArgumentNotValid(
        ex: MethodArgumentNotValidException,
        headers: HttpHeaders,
        status: HttpStatus,
        request: WebRequest
    ): ResponseEntity<Any> {
        val errorsByProperties = ex.bindingResult.allErrors.map {
            FieldErrorProperty(
                name = (it as FieldError).field,
                message = getCustomMessage(it)
            )
        }

        return ResponseEntity(PerformError("400", "Validation Error", errorsByProperties), HttpStatus.BAD_REQUEST)
    }

    @ResponseBody
    @ExceptionHandler(RioUtilsException::class)
    fun handleRioUtilsException(e: RioUtilsException): ResponseEntity<PerformError> =
        buildCustomResponse(e, HttpStatus.INTERNAL_SERVER_ERROR)

    @ResponseBody
    @ExceptionHandler(RioUtilsException.DocumentWriterException::class)
    fun handleDocumentWriter(e: RioUtilsException): ResponseEntity<PerformError> =
        buildCustomResponse(e, HttpStatus.UNPROCESSABLE_ENTITY)

    @ResponseBody
    @ExceptionHandler(RoutefenceException.RoutefenceNotFoundException::class)
    fun notFoundHandlerException(e: RoutefenceException): ResponseEntity<String> = buildDefaultResponse(e)

    @ResponseBody
    @ExceptionHandler(RoutefenceException.RoutefenceBusinessException::class)
    fun businessHandlerException(e: RoutefenceException): ResponseEntity<String> = buildDefaultResponse(e)

    @ResponseBody
    @ExceptionHandler(Exception::class)
    fun handlerException(e: Exception): ResponseEntity<PerformError> = buildCustomResponse(e, HttpStatus.INTERNAL_SERVER_ERROR)

    @ResponseBody
    @ExceptionHandler(RoutefenceException.RoutefenceInvalidPayloadException::class)
    fun invalidPayloadHandlerException(e: RoutefenceException): ResponseEntity<String> = buildDefaultResponse(e)

    @ResponseBody
    @ExceptionHandler(RoutefenceException.RoutefenceForbiddenException::class)
    fun forbiddenHandlerException(e: RoutefenceException): ResponseEntity<String> = buildDefaultResponse(e)

    @ResponseBody
    @ExceptionHandler(RoutefenceException.RoutefenceSendMailException::class)
    fun maintenanceSendMailExceptionException(e: RoutefenceException): ResponseEntity<String> = buildDefaultResponse(e)

    private fun buildCustomResponse(e: Exception, status: HttpStatus): ResponseEntity<PerformError> {
        val error = PerformError(status.name, e.message ?: "RioUtils Exception")
        log.error(e.message)
        return ResponseEntity.status(status).body(error)
    }

    private fun buildDefaultResponse(e: RoutefenceException): ResponseEntity<String> {
        val json = ObjectMapper().writeValueAsString(
            PerformError(e.code, getMessage(e.code, e.msgParameters))
        )
        log.error(json)
        return ResponseEntity.status(e.status).body(json)
    }

    protected fun getMessage(messageKey: String, parameters: Array<String>? = null): String {
        return messageSource.getMessage(messageKey, parameters, LocaleContextHolder.getLocale())
    }

    private fun getCustomMessage(objectError: ObjectError): String {
        return when (val code = objectError.code) {
            "Size" -> objectError.defaultMessage ?: "Field size invalid!"
            else -> messageSource.getMessage("$code", null, LocaleContextHolder.getLocale())
        }
    }
}