package cloud.rio.latam_routefence.infrastructure.consumedapi.assets

import cloud.rio.latam_routefence.infrastructure.consumedapi.base.BaseAPIClient
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Component
import org.springframework.web.client.RestTemplate
import javax.servlet.http.HttpServletRequest


@Component
class AssetApiClient(private val restTemplate: RestTemplate, request: HttpServletRequest) : BaseAPIClient(request) {

    companion object {
        private const val URL_ASSET_BASE = "https://api.assets.rio.cloud"

        const val URL_ASSET_GET = "$URL_ASSET_BASE/assets/{id}"
        const val URL_ASSET_LIST = "$URL_ASSET_BASE/assets?embed=(tags)"
    }

    fun getAsset(id: String): AssetDTO? {
        return restTemplate.exchange(
            URL_ASSET_GET.replace("{id}", id),
            HttpMethod.GET,
            HttpEntity("parameters", getHeaders()),
            AssetDTO::class.java
        ).body
    }

    fun listAsset(): ResponseEntity<AssetsDTO> {
        return restTemplate.exchange(
            URL_ASSET_LIST,
            HttpMethod.GET,
            HttpEntity("parameters", getHeaders()),
            AssetsDTO::class.java
        )
    }
}