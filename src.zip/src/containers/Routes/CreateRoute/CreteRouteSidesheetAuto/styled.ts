import styled from 'styled-components'

import { Button } from 'components'

export const StyledButton = styled(Button)`
  margin-bottom: 20px;
  width: 100%;
`

export const MiniCard = styled.div`  
  flex: 1;
  width: 90%;
  height: 27%;
  border-color: gray;
  border-radius: 7px;
  justify-content: center;
  align-items: center;
`

export const CentralizedContent = styled.div`
  @media (max-width: 980px) {
    width: 330px;
    display: flex;
    justify-content: center;
  }
`
