package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Summary(
    @JsonProperty("travelTime") var travelTime: Int?,
    @JsonProperty("distance") var distance: Int?,
    @JsonProperty("baseTime") var baseTime: Int?,
    @JsonProperty("trafficTime") var trafficTime: Int?,
    @JsonProperty("flags") var flags: Collection<String>?,
    @JsonProperty("arrival") var arrival: String?,
    @JsonProperty("departure") var departure: String?
)