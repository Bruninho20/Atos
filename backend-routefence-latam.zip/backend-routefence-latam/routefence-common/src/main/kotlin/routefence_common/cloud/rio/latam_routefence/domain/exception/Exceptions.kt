package routefence_common.cloud.rio.latam_routefence.domain.exception

sealed class RoutefenceException(
    val status: Int,
    val code: String,
    val msgParameters: Array<String>?
): RuntimeException() {
    companion object {
        const val BUSINESS_STATUS = 422
        const val INVALID_PAYLOAD = 400
        const val NOT_FOUND = 404
        const val ACCESS_DENIED = 403
        const val INTERNAL_SERVER_ERROR = 500
    }

    class RoutefenceBusinessException(code: String, msgParameters: Array<String>? = null) : RoutefenceException(
        BUSINESS_STATUS, code = code, msgParameters = msgParameters
    )

    class RoutefenceInvalidPayloadException(code: String, msgParameters: Array<String>? = null) : RoutefenceException(
        INVALID_PAYLOAD, code = code, msgParameters = msgParameters
    )

    class RoutefenceNotFoundException(code: String, msgParameters: Array<String>? = null) : RoutefenceException(
        NOT_FOUND, code = code, msgParameters = msgParameters
    )

    class RoutefenceForbiddenException(code: String, msgParameters: Array<String>? = null): RoutefenceException(
        ACCESS_DENIED, code = code, msgParameters = msgParameters
    )

    class RoutefenceSendMailException(code: String, msgParameters: Array<String>? = null) : RoutefenceException(
        BUSINESS_STATUS, code = code, msgParameters = msgParameters
    )

    class RoutefenceInternalException(code: String, msgParameters: Array<String>? = null) : RoutefenceException(
        INTERNAL_SERVER_ERROR, code = code, msgParameters = msgParameters
    )
}