package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class PointOfInterestEnum {
    ORIGIN, ROUTE, STOP, DESTINATION
}