package listener.cloud.rio.latam_routefence.kafka

import listener.cloud.rio.latam_routefence.TestBase
import listener.cloud.rio.latam_routefence.services.InfringementDetection
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetPositionMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.*

@SpringBootTest
class RouteSimulator2Test(@Autowired val infringementDetection: InfringementDetection): TestBase() {

    @Test
    fun testRouteSimulador() {
//        val accountId = "d87f9f41-5950-45b1-9044-ecb5d32039d8" //Onibus
//        val assetId = "507e051f-2f87-47ab-af7d-b5159bcec63a" //48....
        val accountId = "58d21607-1dd6-4aaf-8f4b-4e2ae409b323" //Dummy
        val assetId = "507e051f-2f87-47ab-af7d-b5159bcec63a" //Dummy E-Delivery

        setAccountContext(accountId)

        val list = listOf(
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:23.614789900Z"),
                latitude= -23.921142578125,
                longitude= -46.41878890991211,
                speed= 30.869565217391305,
                mileage_in_km = 97416.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:24.614789900Z"),
                latitude= -23.92173194885254,
                longitude= -46.420684814453125,
                speed= 30.869565217391305,
                mileage_in_km = 97417.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:25.614789900Z"),
                latitude= -23.922378540039062,
                longitude= -46.422786712646484,
                speed= 30.869565217391305,
                mileage_in_km = 97417.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:26.614789900Z"),
                latitude= -23.923011779785156,
                longitude= -46.424827575683594,
                speed= 30.869565217391305,
                mileage_in_km = 97417.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:27.614789900Z"),
                latitude= -23.923694610595703,
                longitude= -46.4269905090332,
                speed= 30.869565217391305,
                mileage_in_km = 97417.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:28.614789900Z"),
                latitude= -23.924327850341797,
                longitude= -46.429039001464844,
                speed= 30.869565217391305,
                mileage_in_km = 97417.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:29.614789900Z"),
                latitude= -23.92470932006836,
                longitude= -46.4312858581543,
                speed= 31.73913043478261,
                mileage_in_km = 97418.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:30.614789900Z"),
                latitude= -23.924192428588867,
                longitude= -46.433250427246094,
                speed= 31.73913043478261,
                mileage_in_km = 97418.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:31.614789900Z"),
                latitude= -23.92285919189453,
                longitude= -46.43482971191406,
                speed= 31.73913043478261,
                mileage_in_km = 97418.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:32.614789900Z"),
                latitude= -23.9212703704834,
                longitude= -46.436119079589844,
                speed= 31.73913043478261,
                mileage_in_km = 97418.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:33.614789900Z"),
                latitude= -23.919597625732422,
                longitude= -46.43745040893555,
                speed= 31.73913043478261,
                mileage_in_km = 97419.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:34.614789900Z"),
                latitude= -23.91798210144043,
                longitude= -46.43873596191406,
                speed= 31.73913043478261,
                mileage_in_km = 97419.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:35.614789900Z"),
                latitude= -23.916351318359375,
                longitude= -46.44003677368164,
                speed= 32.608695652173914,
                mileage_in_km = 97419.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:36.614789900Z"),
                latitude= -23.914756774902344,
                longitude= -46.4412956237793,
                speed= 32.608695652173914,
                mileage_in_km = 97419.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:37.614789900Z"),
                latitude= -23.9130916595459,
                longitude= -46.442623138427734,
                speed= 32.608695652173914,
                mileage_in_km = 97419.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:38.614789900Z"),
                latitude= -23.910659790039062,
                longitude= -46.444557189941406,
                speed= 32.608695652173914,
                mileage_in_km = 97420.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:39.614789900Z"),
                latitude= -23.90980339050293,
                longitude= -46.44524002075195,
                speed= 32.608695652173914,
                mileage_in_km = 97420.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:40.614789900Z"),
                latitude= -23.908306121826172,
                longitude= -46.44643020629883,
                speed= 32.608695652173914,
                mileage_in_km = 97420.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:41.614789900Z"),
                latitude= -23.906618118286133,
                longitude= -46.44776916503906,
                speed= 33.47826086956522,
                mileage_in_km = 97420.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:42.614789900Z"),
                latitude= -23.90506362915039,
                longitude= -46.449031829833984,
                speed= 33.47826086956522,
                mileage_in_km = 97421.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:43.614789900Z"),
                latitude= -23.90367889404297,
                longitude= -46.45060729980469,
                speed= 33.47826086956522,
                mileage_in_km = 97421.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:44.614789900Z"),
                latitude= -23.90266227722168,
                longitude= -46.45252227783203,
                speed= 33.47826086956522,
                mileage_in_km = 97421.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:45.614789900Z"),
                latitude= -23.902156829833984,
                longitude= -46.45452880859375,
                speed= 33.47826086956522,
                mileage_in_km = 97421.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:46.614789900Z"),
                latitude= -23.902095794677734,
                longitude= -46.456703186035156,
                speed= 33.47826086956522,
                mileage_in_km = 97421.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:47.614789900Z"),
                latitude= -23.902273178100586,
                longitude= -46.458892822265625,
                speed= 34.34782608695652,
                mileage_in_km = 97422.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:48.614789900Z"),
                latitude= -23.90236473083496,
                longitude= -46.46106719970703,
                speed= 34.34782608695652,
                mileage_in_km = 97422.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:49.614789900Z"),
                latitude= -23.901914596557617,
                longitude= -46.46332931518555,
                speed= 34.34782608695652,
                mileage_in_km = 97422.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:50.614789900Z"),
                latitude= -23.900985717773438,
                longitude= -46.4652214050293,
                speed= 34.34782608695652,
                mileage_in_km = 97423.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:51.614789900Z"),
                latitude= -23.899919509887695,
                longitude= -46.46705627441406,
                speed= 34.34782608695652,
                mileage_in_km = 97423.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:52.614789900Z"),
                latitude= -23.89894676208496,
                longitude= -46.468994140625,
                speed= 34.34782608695652,
                mileage_in_km = 97423.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:53.614789900Z"),
                latitude= -23.8985538482666,
                longitude= -46.47117233276367,
                speed= 35.21739130434783,
                mileage_in_km = 97423.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:54.614789900Z"),
                latitude= -23.89879035949707,
                longitude= -46.473270416259766,
                speed= 35.21739130434783,
                mileage_in_km = 97423.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:55.614789900Z"),
                latitude= -23.899362564086914,
                longitude= -46.475303649902344,
                speed= 35.21739130434783,
                mileage_in_km = 97423.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:56.614789900Z"),
                latitude= -23.899932861328125,
                longitude= -46.47732162475586,
                speed= 35.21739130434783,
                mileage_in_km = 97424.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:57.614789900Z"),
                latitude= -23.900182723999023,
                longitude= -46.47947692871094,
                speed= 35.21739130434783,
                mileage_in_km = 97424.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:58.614789900Z"),
                latitude= -23.899980545043945,
                longitude= -46.48160934448242,
                speed= 35.21739130434783,
                mileage_in_km = 97424.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:51:59.614789900Z"),
                latitude= -23.899690628051758,
                longitude= -46.48392105102539,
                speed= 36.08695652173913,
                mileage_in_km = 97424.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:00.614789900Z"),
                latitude= -23.89942741394043,
                longitude= -46.486019134521484,
                speed= 36.08695652173913,
                mileage_in_km = 97425.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:01.614789900Z"),
                latitude= -23.89910888671875,
                longitude= -46.48815155029297,
                speed= 36.08695652173913,
                mileage_in_km = 97425.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:02.614789900Z"),
                latitude= -23.898691177368164,
                longitude= -46.49040985107422,
                speed= 36.08695652173913,
                mileage_in_km = 97425.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:03.614789900Z"),
                latitude= -23.89672088623047,
                longitude= -46.49351501464844,
                speed= 36.08695652173913,
                mileage_in_km = 97425.9296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:04.614789900Z"),
                latitude= -23.89639663696289,
                longitude= -46.49370193481445,
                speed= 36.08695652173913,
                mileage_in_km = 97425.9296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:05.614789900Z"),
                latitude= -23.89449119567871,
                longitude= -46.49441909790039,
                speed= 36.95652173913044,
                mileage_in_km = 97426.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:06.614789900Z"),
                latitude= -23.892318725585938,
                longitude= -46.4944953918457,
                speed= 36.95652173913044,
                mileage_in_km = 97426.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:07.614789900Z"),
                latitude= -23.890380859375,
                longitude= -46.494564056396484,
                speed= 36.95652173913044,
                mileage_in_km = 97426.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:08.614789900Z"),
                latitude= -23.888614654541016,
                longitude= -46.49510955810547,
                speed= 36.95652173913044,
                mileage_in_km = 97427.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:09.614789900Z"),
                latitude= -23.887161254882812,
                longitude= -46.496646881103516,
                speed= 36.95652173913044,
                mileage_in_km = 97427.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:10.614789900Z"),
                latitude= -23.88642120361328,
                longitude= -46.498870849609375,
                speed= 36.95652173913044,
                mileage_in_km = 97427.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:11.614789900Z"),
                latitude= -23.88663101196289,
                longitude= -46.50086212158203,
                speed= 37.82608695652174,
                mileage_in_km = 97427.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:12.614789900Z"),
                latitude= -23.887765884399414,
                longitude= -46.50279235839844,
                speed= 37.82608695652174,
                mileage_in_km = 97427.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:13.614789900Z"),
                latitude= -23.88951873779297,
                longitude= -46.50392532348633,
                speed= 37.82608695652174,
                mileage_in_km = 97427.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:14.614789900Z"),
                latitude= -23.891481399536133,
                longitude= -46.504364013671875,
                speed= 37.82608695652174,
                mileage_in_km = 97428.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:15.614789900Z"),
                latitude= -23.893280029296875,
                longitude= -46.5046501159668,
                speed= 37.82608695652174,
                mileage_in_km = 97428.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:16.614789900Z"),
                latitude= -23.895166397094727,
                longitude= -46.505340576171875,
                speed= 37.82608695652174,
                mileage_in_km = 97428.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:17.614789900Z"),
                latitude= -23.896923065185547,
                longitude= -46.506324768066406,
                speed= 38.69565217391305,
                mileage_in_km = 97428.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:18.614789900Z"),
                latitude= -23.898822784423828,
                longitude= -46.50665283203125,
                speed= 38.69565217391305,
                mileage_in_km = 97429.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:19.614789900Z"),
                latitude= -23.900909423828125,
                longitude= -46.50630187988281,
                speed= 38.69565217391305,
                mileage_in_km = 97429.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:20.614789900Z"),
                latitude= -23.902751922607422,
                longitude= -46.50558853149414,
                speed= 38.69565217391305,
                mileage_in_km = 97429.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:21.614789900Z"),
                latitude= -23.90479850769043,
                longitude= -46.50540542602539,
                speed= 38.69565217391305,
                mileage_in_km = 97429.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:22.614789900Z"),
                latitude= -23.906721115112305,
                longitude= -46.50636672973633,
                speed= 38.69565217391305,
                mileage_in_km = 97429.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:23.614789900Z"),
                latitude= -23.9079532623291,
                longitude= -46.507877349853516,
                speed= 39.56521739130435,
                mileage_in_km = 97430.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:24.614789900Z"),
                latitude= -23.90839958190918,
                longitude= -46.50989532470703,
                speed= 39.56521739130435,
                mileage_in_km = 97430.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:25.614789900Z"),
                latitude= -23.908342361450195,
                longitude= -46.512237548828125,
                speed= 39.56521739130435,
                mileage_in_km = 97430.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:26.614789900Z"),
                latitude= -23.908349990844727,
                longitude= -46.514366149902344,
                speed= 39.56521739130435,
                mileage_in_km = 97431.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:27.614789900Z"),
                latitude= -23.908681869506836,
                longitude= -46.51634216308594,
                speed= 39.56521739130435,
                mileage_in_km = 97431.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:28.614789900Z"),
                latitude= -23.91127586364746,
                longitude= -46.518707275390625,
                speed= 39.56521739130435,
                mileage_in_km = 97431.4609375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:29.614789900Z"),
                latitude= -23.911949157714844,
                longitude= -46.51905822753906,
                speed= 40.434782608695656,
                mileage_in_km = 97431.4609375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:30.614789900Z"),
                latitude= -23.913515090942383,
                longitude= -46.51995086669922,
                speed= 40.434782608695656,
                mileage_in_km = 97431.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:31.614789900Z"),
                latitude= -23.915241241455078,
                longitude= -46.52103805541992,
                speed= 40.434782608695656,
                mileage_in_km = 97431.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:32.614789900Z"),
                latitude= -23.91654396057129,
                longitude= -46.52268600463867,
                speed= 40.434782608695656,
                mileage_in_km = 97432.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:33.614789900Z"),
                latitude= -23.91742706298828,
                longitude= -46.524723052978516,
                speed= 40.434782608695656,
                mileage_in_km = 97432.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:34.614789900Z"),
                latitude= -23.91774559020996,
                longitude= -46.526912689208984,
                speed= 40.434782608695656,
                mileage_in_km = 97432.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:35.614789900Z"),
                latitude= -23.918140411376953,
                longitude= -46.52903366088867,
                speed= 41.30434782608696,
                mileage_in_km = 97433.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:36.614789900Z"),
                latitude= -23.919137954711914,
                longitude= -46.530975341796875,
                speed= 41.30434782608696,
                mileage_in_km = 97433.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:37.614789900Z"),
                latitude= -23.920757293701172,
                longitude= -46.532135009765625,
                speed= 41.30434782608696,
                mileage_in_km = 97433.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:38.614789900Z"),
                latitude= -23.922588348388672,
                longitude= -46.533199310302734,
                speed= 41.30434782608696,
                mileage_in_km = 97433.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:39.614789900Z"),
                latitude= -23.923877716064453,
                longitude= -46.534732818603516,
                speed= 41.30434782608696,
                mileage_in_km = 97433.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:40.614789900Z"),
                latitude= -23.924436569213867,
                longitude= -46.53693389892578,
                speed= 41.30434782608696,
                mileage_in_km = 97433.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:41.614789900Z"),
                latitude= -23.92447853088379,
                longitude= -46.53911590576172,
                speed= 42.173913043478265,
                mileage_in_km = 97434.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:42.614789900Z"),
                latitude= -23.924896240234375,
                longitude= -46.54117965698242,
                speed= 42.173913043478265,
                mileage_in_km = 97434.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:43.614789900Z"),
                latitude= -23.92578125,
                longitude= -46.542999267578125,
                speed= 42.173913043478265,
                mileage_in_km = 97434.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:44.614789900Z"),
                latitude= -23.926776885986328,
                longitude= -46.54490280151367,
                speed= 42.173913043478265,
                mileage_in_km = 97434.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:45.614789900Z"),
                latitude= -23.927671432495117,
                longitude= -46.546810150146484,
                speed= 42.173913043478265,
                mileage_in_km = 97435.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:46.614789900Z"),
                latitude= -23.927978515625,
                longitude= -46.54901885986328,
                speed= 42.173913043478265,
                mileage_in_km = 97435.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:47.614789900Z"),
                latitude= -23.92750358581543,
                longitude= -46.55120849609375,
                speed= 43.04347826086957,
                mileage_in_km = 97435.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:48.614789900Z"),
                latitude= -23.926374435424805,
                longitude= -46.55297088623047,
                speed= 43.04347826086957,
                mileage_in_km = 97435.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:49.614789900Z"),
                latitude= -23.924819946289062,
                longitude= -46.55415344238281,
                speed= 43.04347826086957,
                mileage_in_km = 97435.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:50.614789900Z"),
                latitude= -23.92287254333496,
                longitude= -46.55472183227539,
                speed= 43.04347826086957,
                mileage_in_km = 97436.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:51.614789900Z"),
                latitude= -23.920793533325195,
                longitude= -46.55510711669922,
                speed= 43.04347826086957,
                mileage_in_km = 97436.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:52.614789900Z"),
                latitude= -23.918949127197266,
                longitude= -46.55545425415039,
                speed= 43.04347826086957,
                mileage_in_km = 97436.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:53.614789900Z"),
                latitude= -23.916093826293945,
                longitude= -46.556087493896484,
                speed= 43.913043478260875,
                mileage_in_km = 97436.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:54.614789900Z"),
                latitude= -23.91506004333496,
                longitude= -46.55640411376953,
                speed= 43.913043478260875,
                mileage_in_km = 97437.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:55.614789900Z"),
                latitude= -23.913150787353516,
                longitude= -46.55702209472656,
                speed= 43.913043478260875,
                mileage_in_km = 97437.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:56.614789900Z"),
                latitude= -23.911020278930664,
                longitude= -46.55775451660156,
                speed= 43.913043478260875,
                mileage_in_km = 97437.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:57.614789900Z"),
                latitude= -23.90932273864746,
                longitude= -46.55833053588867,
                speed= 43.913043478260875,
                mileage_in_km = 97437.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:58.614789900Z"),
                latitude= -23.907032012939453,
                longitude= -46.559112548828125,
                speed= 43.913043478260875,
                mileage_in_km = 97437.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:52:59.614789900Z"),
                latitude= -23.905254364013672,
                longitude= -46.55971908569336,
                speed= 44.78260869565218,
                mileage_in_km = 97438.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:00.614789900Z"),
                latitude= -23.90336036682129,
                longitude= -46.560367584228516,
                speed= 44.78260869565218,
                mileage_in_km = 97438.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:01.614789900Z"),
                latitude= -23.901512145996094,
                longitude= -46.56100845336914,
                speed= 44.78260869565218,
                mileage_in_km = 97438.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:02.614789900Z"),
                latitude= -23.899633407592773,
                longitude= -46.56166458129883,
                speed= 44.78260869565218,
                mileage_in_km = 97438.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:03.614789900Z"),
                latitude= -23.897563934326172,
                longitude= -46.56237030029297,
                speed= 44.78260869565218,
                mileage_in_km = 97439.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:04.614789900Z"),
                latitude= -23.89580726623535,
                longitude= -46.562957763671875,
                speed= 44.78260869565218,
                mileage_in_km = 97439.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:05.614789900Z"),
                latitude= -23.893898010253906,
                longitude= -46.563602447509766,
                speed= 45.652173913043484,
                mileage_in_km = 97439.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:06.614789900Z"),
                latitude= -23.891908645629883,
                longitude= -46.56428909301758,
                speed= 45.652173913043484,
                mileage_in_km = 97439.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:07.614789900Z"),
                latitude= -23.889986038208008,
                longitude= -46.56494140625,
                speed= 45.652173913043484,
                mileage_in_km = 97439.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:08.614789900Z"),
                latitude= -23.888263702392578,
                longitude= -46.565547943115234,
                speed= 45.652173913043484,
                mileage_in_km = 97440.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:09.614789900Z"),
                latitude= -23.886316299438477,
                longitude= -46.56623077392578,
                speed= 45.652173913043484,
                mileage_in_km = 97440.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:10.614789900Z"),
                latitude= -23.884435653686523,
                longitude= -46.56687927246094,
                speed= 45.652173913043484,
                mileage_in_km = 97440.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:11.614789900Z"),
                latitude= -23.88248634338379,
                longitude= -46.56754684448242,
                speed= 46.52173913043479,
                mileage_in_km = 97440.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:12.614789900Z"),
                latitude= -23.88060760498047,
                longitude= -46.56818771362305,
                speed= 46.52173913043479,
                mileage_in_km = 97441.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:13.614789900Z"),
                latitude= -23.87868881225586,
                longitude= -46.56884002685547,
                speed= 46.52173913043479,
                mileage_in_km = 97441.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:14.614789900Z"),
                latitude= -23.876754760742188,
                longitude= -46.569496154785156,
                speed= 46.52173913043479,
                mileage_in_km = 97441.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:15.614789900Z"),
                latitude= -23.874605178833008,
                longitude= -46.57023239135742,
                speed= 46.52173913043479,
                mileage_in_km = 97441.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:16.614789900Z"),
                latitude= -23.87295913696289,
                longitude= -46.57080841064453,
                speed= 46.52173913043479,
                mileage_in_km = 97441.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:17.614789900Z"),
                latitude= -23.870981216430664,
                longitude= -46.57152557373047,
                speed= 47.39130434782609,
                mileage_in_km = 97442.53125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:18.614789900Z"),
                latitude= -23.868083953857422,
                longitude= -46.572505950927734,
                speed= 47.39130434782609,
                mileage_in_km = 97442.53125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:19.614789900Z"),
                latitude= -23.867055892944336,
                longitude= -46.57283020019531,
                speed= 47.39130434782609,
                mileage_in_km = 97442.53125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:20.614789900Z"),
                latitude= -23.8652400970459,
                longitude= -46.57326126098633,
                speed= 47.39130434782609,
                mileage_in_km = 97442.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:21.614789900Z"),
                latitude= -23.862985610961914,
                longitude= -46.57350158691406,
                speed= 47.39130434782609,
                mileage_in_km = 97443.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:22.614789900Z"),
                latitude= -23.861051559448242,
                longitude= -46.573612213134766,
                speed= 47.39130434782609,
                mileage_in_km = 97443.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:23.614789900Z"),
                latitude= -23.859180450439453,
                longitude= -46.573734283447266,
                speed= 48.2608695652174,
                mileage_in_km = 97443.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:24.614789900Z"),
                latitude= -23.857179641723633,
                longitude= -46.5738639831543,
                speed= 48.2608695652174,
                mileage_in_km = 97443.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:25.614789900Z"),
                latitude= -23.854999542236328,
                longitude= -46.574005126953125,
                speed= 48.2608695652174,
                mileage_in_km = 97443.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:26.614789900Z"),
                latitude= -23.85305404663086,
                longitude= -46.57416534423828,
                speed= 48.2608695652174,
                mileage_in_km = 97444.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:27.614789900Z"),
                latitude= -23.851043701171875,
                longitude= -46.57451248168945,
                speed= 48.2608695652174,
                mileage_in_km = 97444.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:28.614789900Z"),
                latitude= -23.849231719970703,
                longitude= -46.5749626159668,
                speed= 48.2608695652174,
                mileage_in_km = 97444.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:29.614789900Z"),
                latitude= -23.847286224365234,
                longitude= -46.57546615600586,
                speed= 49.1304347826087,
                mileage_in_km = 97444.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:30.614789900Z"),
                latitude= -23.845312118530273,
                longitude= -46.57598114013672,
                speed= 49.1304347826087,
                mileage_in_km = 97445.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:31.614789900Z"),
                latitude= -23.84344482421875,
                longitude= -46.57646560668945,
                speed= 49.1304347826087,
                mileage_in_km = 97445.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:32.614789900Z"),
                latitude= -23.84139060974121,
                longitude= -46.577003479003906,
                speed= 49.1304347826087,
                mileage_in_km = 97445.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:33.614789900Z"),
                latitude= -23.839378356933594,
                longitude= -46.57752990722656,
                speed= 49.1304347826087,
                mileage_in_km = 97445.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:34.614789900Z"),
                latitude= -23.837392807006836,
                longitude= -46.57805252075195,
                speed= 49.1304347826087,
                mileage_in_km = 97445.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:35.614789900Z"),
                latitude= -23.835521697998047,
                longitude= -46.57853698730469,
                speed= 50.00000000000001,
                mileage_in_km = 97446.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:36.614789900Z"),
                latitude= -23.833410263061523,
                longitude= -46.57908630371094,
                speed= 50.00000000000001,
                mileage_in_km = 97446.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:37.614789900Z"),
                latitude= -23.831762313842773,
                longitude= -46.57951354980469,
                speed= 50.00000000000001,
                mileage_in_km = 97446.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:38.614789900Z"),
                latitude= -23.829803466796875,
                longitude= -46.58000946044922,
                speed= 50.00000000000001,
                mileage_in_km = 97446.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:39.614789900Z"),
                latitude= -23.827714920043945,
                longitude= -46.58054733276367,
                speed= 50.00000000000001,
                mileage_in_km = 97447.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:40.614789900Z"),
                latitude= -23.825777053833008,
                longitude= -46.58107376098633,
                speed= 50.00000000000001,
                mileage_in_km = 97447.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:41.614789900Z"),
                latitude= -23.823827743530273,
                longitude= -46.58157730102539,
                speed= 50.86956521739131,
                mileage_in_km = 97447.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:42.614789900Z"),
                latitude= -23.82187843322754,
                longitude= -46.581844329833984,
                speed= 50.86956521739131,
                mileage_in_km = 97447.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:43.614789900Z"),
                latitude= -23.819021224975586,
                longitude= -46.58262252807617,
                speed= 50.86956521739131,
                mileage_in_km = 97447.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:44.614789900Z"),
                latitude= -23.81796646118164,
                longitude= -46.583072662353516,
                speed= 50.86956521739131,
                mileage_in_km = 97448.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:45.614789900Z"),
                latitude= -23.816097259521484,
                longitude= -46.58366012573242,
                speed= 50.86956521739131,
                mileage_in_km = 97448.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:46.614789900Z"),
                latitude= -23.814247131347656,
                longitude= -46.58440399169922,
                speed= 50.86956521739131,
                mileage_in_km = 97448.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:47.614789900Z"),
                latitude= -23.812286376953125,
                longitude= -46.5853157043457,
                speed= 51.739130434782616,
                mileage_in_km = 97448.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:48.614789900Z"),
                latitude= -23.810470581054688,
                longitude= -46.58614730834961,
                speed= 51.739130434782616,
                mileage_in_km = 97449.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:49.614789900Z"),
                latitude= -23.808622360229492,
                longitude= -46.58698654174805,
                speed= 51.739130434782616,
                mileage_in_km = 97449.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:50.614789900Z"),
                latitude= -23.80661964416504,
                longitude= -46.587894439697266,
                speed= 51.739130434782616,
                mileage_in_km = 97449.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:51.614789900Z"),
                latitude= -23.804874420166016,
                longitude= -46.58868408203125,
                speed= 51.739130434782616,
                mileage_in_km = 97449.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:52.614789900Z"),
                latitude= -23.803071975708008,
                longitude= -46.589561462402344,
                speed= 51.739130434782616,
                mileage_in_km = 97449.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:53.614789900Z"),
                latitude= -23.801259994506836,
                longitude= -46.5904541015625,
                speed= 52.60869565217392,
                mileage_in_km = 97450.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:54.614789900Z"),
                latitude= -23.799339294433594,
                longitude= -46.591400146484375,
                speed= 52.60869565217392,
                mileage_in_km = 97450.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:55.614789900Z"),
                latitude= -23.797605514526367,
                longitude= -46.59226608276367,
                speed= 52.60869565217392,
                mileage_in_km = 97450.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:56.614789900Z"),
                latitude= -23.795917510986328,
                longitude= -46.593135833740234,
                speed= 52.60869565217392,
                mileage_in_km = 97450.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:57.614789900Z"),
                latitude= -23.794055938720703,
                longitude= -46.59408950805664,
                speed= 52.60869565217392,
                mileage_in_km = 97451.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:58.614789900Z"),
                latitude= -23.792251586914062,
                longitude= -46.594993591308594,
                speed= 52.60869565217392,
                mileage_in_km = 97451.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:53:59.614789900Z"),
                latitude= -23.790328979492188,
                longitude= -46.595951080322266,
                speed= 53.478260869565226,
                mileage_in_km = 97451.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:00.614789900Z"),
                latitude= -23.788476943969727,
                longitude= -46.59684371948242,
                speed= 53.478260869565226,
                mileage_in_km = 97451.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:01.614789900Z"),
                latitude= -23.786663055419922,
                longitude= -46.597469329833984,
                speed= 53.478260869565226,
                mileage_in_km = 97451.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:02.614789900Z"),
                latitude= -23.78458023071289,
                longitude= -46.5977668762207,
                speed= 53.478260869565226,
                mileage_in_km = 97452.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:03.614789900Z"),
                latitude= -23.782682418823242,
                longitude= -46.597660064697266,
                speed= 53.478260869565226,
                mileage_in_km = 97452.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:04.614789900Z"),
                latitude= -23.780532836914062,
                longitude= -46.5971565246582,
                speed= 53.478260869565226,
                mileage_in_km = 97452.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:05.614789900Z"),
                latitude= -23.778703689575195,
                longitude= -46.59638595581055,
                speed= 54.34782608695653,
                mileage_in_km = 97453.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:06.614789900Z"),
                latitude= -23.77704429626465,
                longitude= -46.595584869384766,
                speed= 54.34782608695653,
                mileage_in_km = 97453.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:07.614789900Z"),
                latitude= -23.775117874145508,
                longitude= -46.59462356567383,
                speed= 54.34782608695653,
                mileage_in_km = 97453.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:08.614789900Z"),
                latitude= -23.772294998168945,
                longitude= -46.5933837890625,
                speed= 54.34782608695653,
                mileage_in_km = 97453.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:09.614789900Z"),
                latitude= -23.771411895751953,
                longitude= -46.59295654296875,
                speed= 54.34782608695653,
                mileage_in_km = 97453.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:10.614789900Z"),
                latitude= -23.76963233947754,
                longitude= -46.59208297729492,
                speed= 54.34782608695653,
                mileage_in_km = 97453.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:11.614789900Z"),
                latitude= -23.7678165435791,
                longitude= -46.59147262573242,
                speed= 55.217391304347835,
                mileage_in_km = 97454.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:12.614789900Z"),
                latitude= -23.765670776367188,
                longitude= -46.591064453125,
                speed= 55.217391304347835,
                mileage_in_km = 97454.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:13.614789900Z"),
                latitude= -23.763736724853516,
                longitude= -46.59101867675781,
                speed= 55.217391304347835,
                mileage_in_km = 97454.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:14.614789900Z"),
                latitude= -23.761821746826172,
                longitude= -46.59126663208008,
                speed= 55.217391304347835,
                mileage_in_km = 97455.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:15.614789900Z"),
                latitude= -23.759714126586914,
                longitude= -46.591861724853516,
                speed= 55.217391304347835,
                mileage_in_km = 97455.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:16.614789900Z"),
                latitude= -23.75778579711914,
                longitude= -46.59260177612305,
                speed= 55.217391304347835,
                mileage_in_km = 97455.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:17.614789900Z"),
                latitude= -23.755891799926758,
                longitude= -46.59333038330078,
                speed= 56.08695652173914,
                mileage_in_km = 97455.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:18.614789900Z"),
                latitude= -23.754047393798828,
                longitude= -46.594024658203125,
                speed= 56.08695652173914,
                mileage_in_km = 97455.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:19.614789900Z"),
                latitude= -23.752321243286133,
                longitude= -46.59467697143555,
                speed= 56.08695652173914,
                mileage_in_km = 97455.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:20.614789900Z"),
                latitude= -23.750244140625,
                longitude= -46.595458984375,
                speed= 56.08695652173914,
                mileage_in_km = 97456.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:21.614789900Z"),
                latitude= -23.748336791992188,
                longitude= -46.59619140625,
                speed= 56.08695652173914,
                mileage_in_km = 97456.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:22.614789900Z"),
                latitude= -23.746641159057617,
                longitude= -46.59684753417969,
                speed= 56.08695652173914,
                mileage_in_km = 97456.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:23.614789900Z"),
                latitude= -23.744604110717773,
                longitude= -46.597625732421875,
                speed= 56.956521739130444,
                mileage_in_km = 97456.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:24.614789900Z"),
                latitude= -23.74275779724121,
                longitude= -46.598350524902344,
                speed= 56.956521739130444,
                mileage_in_km = 97457.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:25.614789900Z"),
                latitude= -23.740982055664062,
                longitude= -46.59927749633789,
                speed= 56.956521739130444,
                mileage_in_km = 97457.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:26.614789900Z"),
                latitude= -23.7392635345459,
                longitude= -46.60032653808594,
                speed= 56.956521739130444,
                mileage_in_km = 97457.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:27.614789900Z"),
                latitude= -23.73753547668457,
                longitude= -46.60139465332031,
                speed= 56.956521739130444,
                mileage_in_km = 97457.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:28.614789900Z"),
                latitude= -23.735647201538086,
                longitude= -46.60255432128906,
                speed= 56.956521739130444,
                mileage_in_km = 97457.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:29.614789900Z"),
                latitude= -23.7340087890625,
                longitude= -46.60356140136719,
                speed= 57.82608695652175,
                mileage_in_km = 97458.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:30.614789900Z"),
                latitude= -23.73213005065918,
                longitude= -46.604713439941406,
                speed= 57.82608695652175,
                mileage_in_km = 97458.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:31.614789900Z"),
                latitude= -23.730478286743164,
                longitude= -46.60573196411133,
                speed= 57.82608695652175,
                mileage_in_km = 97458.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:32.614789900Z"),
                latitude= -23.728742599487305,
                longitude= -46.60653305053711,
                speed= 57.82608695652175,
                mileage_in_km = 97458.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:33.614789900Z"),
                latitude= -23.72530174255371,
                longitude= -46.60695266723633,
                speed= 57.82608695652175,
                mileage_in_km = 97459.2421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:34.614789900Z"),
                latitude= -23.724712371826172,
                longitude= -46.60686492919922,
                speed= 57.82608695652175,
                mileage_in_km = 97459.2421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:35.614789900Z"),
                latitude= -23.7226505279541,
                longitude= -46.60643005371094,
                speed= 58.695652173913054,
                mileage_in_km = 97459.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:36.614789900Z"),
                latitude= -23.720783233642578,
                longitude= -46.605987548828125,
                speed= 58.695652173913054,
                mileage_in_km = 97459.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:37.614789900Z"),
                latitude= -23.71881866455078,
                longitude= -46.60553741455078,
                speed= 58.695652173913054,
                mileage_in_km = 97459.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:38.614789900Z"),
                latitude= -23.716903686523438,
                longitude= -46.60513687133789,
                speed= 58.695652173913054,
                mileage_in_km = 97460.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:39.614789900Z"),
                latitude= -23.714736938476562,
                longitude= -46.60466766357422,
                speed= 58.695652173913054,
                mileage_in_km = 97460.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:40.614789900Z"),
                latitude= -23.712873458862305,
                longitude= -46.604248046875,
                speed= 58.695652173913054,
                mileage_in_km = 97460.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:41.614789900Z"),
                latitude= -23.71100616455078,
                longitude= -46.60382080078125,
                speed= 59.56521739130436,
                mileage_in_km = 97460.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:42.614789900Z"),
                latitude= -23.708873748779297,
                longitude= -46.60334396362305,
                speed= 59.56521739130436,
                mileage_in_km = 97461.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:43.614789900Z"),
                latitude= -23.706995010375977,
                longitude= -46.60295486450195,
                speed= 59.56521739130436,
                mileage_in_km = 97461.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:44.614789900Z"),
                latitude= -23.70494270324707,
                longitude= -46.60249710083008,
                speed= 59.56521739130436,
                mileage_in_km = 97461.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:45.614789900Z"),
                latitude= -23.70307731628418,
                longitude= -46.60210037231445,
                speed= 59.56521739130436,
                mileage_in_km = 97461.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:46.614789900Z"),
                latitude= -23.701120376586914,
                longitude= -46.60190200805664,
                speed= 59.56521739130436,
                mileage_in_km = 97461.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:47.614789900Z"),
                latitude= -23.6991024017334,
                longitude= -46.602020263671875,
                speed= 60.43478260869566,
                mileage_in_km = 97462.40625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:48.614789900Z"),
                latitude= -23.697175979614258,
                longitude= -46.6024169921875,
                speed= 60.43478260869566,
                mileage_in_km = 97462.40625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:49.614789900Z"),
                latitude= -23.694915771484375,
                longitude= -46.60297775268555,
                speed= 60.43478260869566,
                mileage_in_km = 97462.40625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:50.614789900Z"),
                latitude= -23.693191528320312,
                longitude= -46.60340118408203,
                speed= 60.43478260869566,
                mileage_in_km = 97462.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:51.614789900Z"),
                latitude= -23.691190719604492,
                longitude= -46.60393524169922,
                speed= 60.43478260869566,
                mileage_in_km = 97463.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:52.614789900Z"),
                latitude= -23.689271926879883,
                longitude= -46.60476303100586,
                speed= 60.43478260869566,
                mileage_in_km = 97463.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:53.614789900Z"),
                latitude= -23.687694549560547,
                longitude= -46.605777740478516,
                speed= 61.30434782608697,
                mileage_in_km = 97463.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:54.614789900Z"),
                latitude= -23.685916900634766,
                longitude= -46.6068229675293,
                speed= 61.30434782608697,
                mileage_in_km = 97463.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:55.614789900Z"),
                latitude= -23.684797286987305,
                longitude= -46.605587005615234,
                speed= 61.30434782608697,
                mileage_in_km = 97463.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:56.614789900Z"),
                latitude= -23.68402862548828,
                longitude= -46.603450775146484,
                speed= 61.30434782608697,
                mileage_in_km = 97464.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:57.614789900Z"),
                latitude= -23.68290138244629,
                longitude= -46.601863861083984,
                speed= 61.30434782608697,
                mileage_in_km = 97464.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:58.614789900Z"),
                latitude= -23.681364059448242,
                longitude= -46.59929656982422,
                speed= 61.30434782608697,
                mileage_in_km = 97464.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:54:59.614789900Z"),
                latitude= -23.6810359954834,
                longitude= -46.598228454589844,
                speed= 62.17391304347827,
                mileage_in_km = 97464.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:00.614789900Z"),
                latitude= -23.68061637878418,
                longitude= -46.59601593017578,
                speed= 62.17391304347827,
                mileage_in_km = 97465.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:01.614789900Z"),
                latitude= -23.682388305664062,
                longitude= -46.595088958740234,
                speed= 62.17391304347827,
                mileage_in_km = 97465.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:02.614789900Z"),
                latitude= -23.68412971496582,
                longitude= -46.5942497253418,
                speed= 62.17391304347827,
                mileage_in_km = 97465.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:03.614789900Z"),
                latitude= -23.685983657836914,
                longitude= -46.593116760253906,
                speed= 62.17391304347827,
                mileage_in_km = 97465.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:04.614789900Z"),
                latitude= -23.68760108947754,
                longitude= -46.591976165771484,
                speed= 62.17391304347827,
                mileage_in_km = 97465.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:05.614789900Z"),
                latitude= -23.689298629760742,
                longitude= -46.59073257446289,
                speed= 63.04347826086958,
                mileage_in_km = 97466.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:06.614789900Z"),
                latitude= -23.690967559814453,
                longitude= -46.58984375,
                speed= 63.04347826086958,
                mileage_in_km = 97466.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:07.614789900Z"),
                latitude= -23.691606521606445,
                longitude= -46.58776092529297,
                speed= 63.04347826086958,
                mileage_in_km = 97466.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:08.614789900Z"),
                latitude= -23.691938400268555,
                longitude= -46.58559036254883,
                speed= 63.04347826086958,
                mileage_in_km = 97466.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:09.614789900Z"),
                latitude= -23.692481994628906,
                longitude= -46.584228515625,
                speed= 63.04347826086958,
                mileage_in_km = 97467.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:10.614789900Z"),
                latitude= -23.692249298095703,
                longitude= -46.58220291137695,
                speed= 63.04347826086958,
                mileage_in_km = 97467.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:11.614789900Z"),
                latitude= -23.691213607788086,
                longitude= -46.5804443359375,
                speed= 63.91304347826088,
                mileage_in_km = 97467.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:12.614789900Z"),
                latitude= -23.690670013427734,
                longitude= -46.578285217285156,
                speed= 63.91304347826088,
                mileage_in_km = 97467.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:13.614789900Z"),
                latitude= -23.69022560119629,
                longitude= -46.57619094848633,
                speed= 63.91304347826088,
                mileage_in_km = 97467.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:14.614789900Z"),
                latitude= -23.68973159790039,
                longitude= -46.5741081237793,
                speed= 63.91304347826088,
                mileage_in_km = 97468.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:15.614789900Z"),
                latitude= -23.689613342285156,
                longitude= -46.574344635009766,
                speed= 63.91304347826088,
                mileage_in_km = 97468.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:16.614789900Z"),
                latitude= -23.69011688232422,
                longitude= -46.576473236083984,
                speed= 63.91304347826088,
                mileage_in_km = 97468.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:17.614789900Z"),
                latitude= -23.688276290893555,
                longitude= -46.57749938964844,
                speed= 64.78260869565219,
                mileage_in_km = 97468.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:18.614789900Z"),
                latitude= -23.686473846435547,
                longitude= -46.57844161987305,
                speed= 64.78260869565219,
                mileage_in_km = 97469.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:19.614789900Z"),
                latitude= -23.686296463012695,
                longitude= -46.578529357910156,
                speed= 64.78260869565219,
                mileage_in_km = 97469.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:20.614789900Z"),
                latitude= -23.68816566467285,
                longitude= -46.57755661010742,
                speed= 64.78260869565219,
                mileage_in_km = 97469.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:21.614789900Z"),
                latitude= -23.689912796020508,
                longitude= -46.57665252685547,
                speed= 64.78260869565219,
                mileage_in_km = 97469.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:22.614789900Z"),
                latitude= -23.69037437438965,
                longitude= -46.57847213745117,
                speed= 64.78260869565219,
                mileage_in_km = 97469.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:23.614789900Z"),
                latitude= -23.691513061523438,
                longitude= -46.581214904785156,
                speed= 65.65217391304348,
                mileage_in_km = 97470.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:24.614789900Z"),
                latitude= -23.691965103149414,
                longitude= -46.58249282836914,
                speed= 65.65217391304348,
                mileage_in_km = 97470.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:25.614789900Z"),
                latitude= -23.692466735839844,
                longitude= -46.58436965942383,
                speed= 65.65217391304348,
                mileage_in_km = 97470.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:26.614789900Z"),
                latitude= -23.693082809448242,
                longitude= -46.58635711669922,
                speed= 65.65217391304348,
                mileage_in_km = 97471.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:27.614789900Z"),
                latitude= -23.69413948059082,
                longitude= -46.58808517456055,
                speed= 65.65217391304348,
                mileage_in_km = 97471.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:28.614789900Z"),
                latitude= -23.696067810058594,
                longitude= -46.58888626098633,
                speed= 65.65217391304348,
                mileage_in_km = 97471.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:29.614789900Z"),
                latitude= -23.69776153564453,
                longitude= -46.589664459228516,
                speed= 66.52173913043478,
                mileage_in_km = 97471.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:30.614789900Z"),
                latitude= -23.699661254882812,
                longitude= -46.590187072753906,
                speed= 66.52173913043478,
                mileage_in_km = 97471.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:31.614789900Z"),
                latitude= -23.701696395874023,
                longitude= -46.590843200683594,
                speed= 66.52173913043478,
                mileage_in_km = 97471.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:32.614789900Z"),
                latitude= -23.703670501708984,
                longitude= -46.5910758972168,
                speed= 66.52173913043478,
                mileage_in_km = 97472.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:33.614789900Z"),
                latitude= -23.705305099487305,
                longitude= -46.592281341552734,
                speed= 66.52173913043478,
                mileage_in_km = 97472.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:34.614789900Z"),
                latitude= -23.706588745117188,
                longitude= -46.593833923339844,
                speed= 66.52173913043478,
                mileage_in_km = 97472.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:35.614789900Z"),
                latitude= -23.70789337158203,
                longitude= -46.595401763916016,
                speed= 67.39130434782608,
                mileage_in_km = 97473.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:36.614789900Z"),
                latitude= -23.70940589904785,
                longitude= -46.596961975097656,
                speed= 67.39130434782608,
                mileage_in_km = 97473.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:37.614789900Z"),
                latitude= -23.71054458618164,
                longitude= -46.598594665527344,
                speed= 67.39130434782608,
                mileage_in_km = 97473.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:38.614789900Z"),
                latitude= -23.712125778198242,
                longitude= -46.5990104675293,
                speed= 67.39130434782608,
                mileage_in_km = 97473.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:39.614789900Z"),
                latitude= -23.713607788085938,
                longitude= -46.60033416748047,
                speed= 67.39130434782608,
                mileage_in_km = 97473.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:40.614789900Z"),
                latitude= -23.715566635131836,
                longitude= -46.601322174072266,
                speed= 67.39130434782608,
                mileage_in_km = 97473.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:41.614789900Z"),
                latitude= -23.717288970947266,
                longitude= -46.60161590576172,
                speed= 68.26086956521738,
                mileage_in_km = 97474.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:42.614789900Z"),
                latitude= -23.718107223510742,
                longitude= -46.60352325439453,
                speed= 68.26086956521738,
                mileage_in_km = 97474.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:43.614789900Z"),
                latitude= -23.71952247619629,
                longitude= -46.604713439941406,
                speed= 68.26086956521738,
                mileage_in_km = 97474.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:44.614789900Z"),
                latitude= -23.72110366821289,
                longitude= -46.60425567626953,
                speed= 68.26086956521738,
                mileage_in_km = 97474.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:45.614789900Z"),
                latitude= -23.723081588745117,
                longitude= -46.60422134399414,
                speed= 68.26086956521738,
                mileage_in_km = 97475.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:46.614789900Z"),
                latitude= -23.724971771240234,
                longitude= -46.60332489013672,
                speed= 68.26086956521738,
                mileage_in_km = 97475.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:47.614789900Z"),
                latitude= -23.726755142211914,
                longitude= -46.602970123291016,
                speed= 69.13043478260867,
                mileage_in_km = 97475.890625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:48.614789900Z"),
                latitude= -23.725404739379883,
                longitude= -46.60097885131836,
                speed= 69.13043478260867,
                mileage_in_km = 97475.890625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:49.614789900Z"),
                latitude= -23.725404739379883,
                longitude= -46.60002136230469,
                speed= 69.13043478260867,
                mileage_in_km = 97475.890625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:50.614789900Z"),
                latitude= -23.72372055053711,
                longitude= -46.60007858276367,
                speed= 69.13043478260867,
                mileage_in_km = 97476.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:51.614789900Z"),
                latitude= -23.722623825073242,
                longitude= -46.60111618041992,
                speed= 69.13043478260867,
                mileage_in_km = 97476.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:52.614789900Z"),
                latitude= -23.722139358520508,
                longitude= -46.60237121582031,
                speed= 69.13043478260867,
                mileage_in_km = 97476.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:53.614789900Z"),
                latitude= -23.722627639770508,
                longitude= -46.6007194519043,
                speed= 69.99999999999997,
                mileage_in_km = 97476.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:54.614789900Z"),
                latitude= -23.72422218322754,
                longitude= -46.60002899169922,
                speed= 69.99999999999997,
                mileage_in_km = 97477.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:55.614789900Z"),
                latitude= -23.72540283203125,
                longitude= -46.60060119628906,
                speed= 69.99999999999997,
                mileage_in_km = 97477.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:56.614789900Z"),
                latitude= -23.72655487060547,
                longitude= -46.601863861083984,
                speed= 69.99999999999997,
                mileage_in_km = 97477.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:57.614789900Z"),
                latitude= -23.726516723632812,
                longitude= -46.603057861328125,
                speed= 69.99999999999997,
                mileage_in_km = 97477.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:58.614789900Z"),
                latitude= -23.724573135375977,
                longitude= -46.603397369384766,
                speed= 69.99999999999997,
                mileage_in_km = 97477.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:55:59.614789900Z"),
                latitude= -23.722686767578125,
                longitude= -46.60423278808594,
                speed= 70.86956521739127,
                mileage_in_km = 97478.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:00.614789900Z"),
                latitude= -23.720685958862305,
                longitude= -46.6042594909668,
                speed= 70.86956521739127,
                mileage_in_km = 97478.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:01.614789900Z"),
                latitude= -23.718671798706055,
                longitude= -46.604286193847656,
                speed= 70.86956521739127,
                mileage_in_km = 97478.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:02.614789900Z"),
                latitude= -23.717662811279297,
                longitude= -46.60249710083008,
                speed= 70.86956521739127,
                mileage_in_km = 97478.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:03.614789900Z"),
                latitude= -23.716384887695312,
                longitude= -46.6015739440918,
                speed= 70.86956521739127,
                mileage_in_km = 97479.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:04.614789900Z"),
                latitude= -23.714445114135742,
                longitude= -46.60075759887695,
                speed= 70.86956521739127,
                mileage_in_km = 97479.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:05.614789900Z"),
                latitude= -23.71260643005371,
                longitude= -46.59974670410156,
                speed= 71.73913043478257,
                mileage_in_km = 97479.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:06.614789900Z"),
                latitude= -23.71108627319336,
                longitude= -46.59895706176758,
                speed= 71.73913043478257,
                mileage_in_km = 97479.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:07.614789900Z"),
                latitude= -23.709964752197266,
                longitude= -46.59756851196289,
                speed= 71.73913043478257,
                mileage_in_km = 97479.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:08.614789900Z"),
                latitude= -23.708337783813477,
                longitude= -46.59602355957031,
                speed= 71.73913043478257,
                mileage_in_km = 97480.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:09.614789900Z"),
                latitude= -23.7072811126709,
                longitude= -46.594520568847656,
                speed= 71.73913043478257,
                mileage_in_km = 97480.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:10.614789900Z"),
                latitude= -23.705821990966797,
                longitude= -46.59273910522461,
                speed= 71.73913043478257,
                mileage_in_km = 97480.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:11.614789900Z"),
                latitude= -23.70257568359375,
                longitude= -46.59084701538086,
                speed= 72.60869565217386,
                mileage_in_km = 97481.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:12.614789900Z"),
                latitude= -23.698184967041016,
                longitude= -46.589630126953125,
                speed= 72.60869565217386,
                mileage_in_km = 97481.59375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:13.614789900Z"),
                latitude= -23.698184967041016,
                longitude= -46.589630126953125,
                speed= 0.0,
                mileage_in_km = 97481.59375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:14.614789900Z"),
                latitude= -23.698184967041016,
                longitude= -46.589630126953125,
                speed= 0.0,
                mileage_in_km = 97481.59375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:15.614789900Z"),
                latitude= -23.696748733520508,
                longitude= -46.589073181152344,
                speed= 72.60869565217386,
                mileage_in_km = 97481.59375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:16.614789900Z"),
                latitude= -23.694808959960938,
                longitude= -46.588497161865234,
                speed= 72.60869565217386,
                mileage_in_km = 97481.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:17.614789900Z"),
                latitude= -23.69355010986328,
                longitude= -46.5872917175293,
                speed= 73.47826086956516,
                mileage_in_km = 97482.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:18.614789900Z"),
                latitude= -23.692771911621094,
                longitude= -46.58507537841797,
                speed= 73.47826086956516,
                mileage_in_km = 97482.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:19.614789900Z"),
                latitude= -23.692598342895508,
                longitude= -46.583045959472656,
                speed= 73.47826086956516,
                mileage_in_km = 97482.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:20.614789900Z"),
                latitude= -23.691726684570312,
                longitude= -46.58110809326172,
                speed= 73.47826086956516,
                mileage_in_km = 97482.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:21.614789900Z"),
                latitude= -23.69078254699707,
                longitude= -46.5794563293457,
                speed= 73.47826086956516,
                mileage_in_km = 97483.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:22.614789900Z"),
                latitude= -23.69044303894043,
                longitude= -46.57709503173828,
                speed= 73.47826086956516,
                mileage_in_km = 97483.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:23.614789900Z"),
                latitude= -23.689973831176758,
                longitude= -46.575157165527344,
                speed= 74.34782608695646,
                mileage_in_km = 97483.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:24.614789900Z"),
                latitude= -23.689390182495117,
                longitude= -46.57344055175781,
                speed= 74.34782608695646,
                mileage_in_km = 97483.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:25.614789900Z"),
                latitude= -23.68988037109375,
                longitude= -46.57542419433594,
                speed= 74.34782608695646,
                mileage_in_km = 97483.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:26.614789900Z"),
                latitude= -23.689218521118164,
                longitude= -46.57701110839844,
                speed= 74.34782608695646,
                mileage_in_km = 97484.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:27.614789900Z"),
                latitude= -23.687524795532227,
                longitude= -46.577884674072266,
                speed= 74.34782608695646,
                mileage_in_km = 97484.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:28.614789900Z"),
                latitude= -23.685686111450195,
                longitude= -46.578857421875,
                speed= 74.34782608695646,
                mileage_in_km = 97484.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:29.614789900Z"),
                latitude= -23.687089920043945,
                longitude= -46.5781135559082,
                speed= 75.21739130434776,
                mileage_in_km = 97485.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:30.614789900Z"),
                latitude= -23.688894271850586,
                longitude= -46.577178955078125,
                speed= 75.21739130434776,
                mileage_in_km = 97485.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:31.614789900Z"),
                latitude= -23.69031524658203,
                longitude= -46.57733917236328,
                speed= 75.21739130434776,
                mileage_in_km = 97485.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:32.614789900Z"),
                latitude= -23.69049072265625,
                longitude= -46.57932662963867,
                speed= 75.21739130434776,
                mileage_in_km = 97485.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:33.614789900Z"),
                latitude= -23.690553665161133,
                longitude= -46.577518463134766,
                speed= 75.21739130434776,
                mileage_in_km = 97485.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:34.614789900Z"),
                latitude= -23.68999481201172,
                longitude= -46.57524108886719,
                speed= 75.21739130434776,
                mileage_in_km = 97485.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:35.614789900Z"),
                latitude= -23.689651489257812,
                longitude= -46.57318115234375,
                speed= 76.08695652173905,
                mileage_in_km = 97486.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:36.614789900Z"),
                latitude= -23.68960952758789,
                longitude= -46.571083068847656,
                speed= 76.08695652173905,
                mileage_in_km = 97486.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:37.614789900Z"),
                latitude= -23.689809799194336,
                longitude= -46.56906509399414,
                speed= 76.08695652173905,
                mileage_in_km = 97486.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:38.614789900Z"),
                latitude= -23.692073822021484,
                longitude= -46.56633377075195,
                speed= 76.08695652173905,
                mileage_in_km = 97486.765625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:39.614789900Z"),
                latitude= -23.692073822021484,
                longitude= -46.56633377075195,
                speed= 0.0,
                mileage_in_km = 97487.2109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:40.614789900Z"),
                latitude= -23.69196891784668,
                longitude= -46.56538772583008,
                speed= 76.08695652173905,
                mileage_in_km = 97487.2109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:41.614789900Z"),
                latitude= -23.69314956665039,
                longitude= -46.56400680541992,
                speed= 76.95652173913035,
                mileage_in_km = 97487.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:42.614789900Z"),
                latitude= -23.695308685302734,
                longitude= -46.563255310058594,
                speed= 76.95652173913035,
                mileage_in_km = 97487.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:43.614789900Z"),
                latitude= -23.69706916809082,
                longitude= -46.56264114379883,
                speed= 76.95652173913035,
                mileage_in_km = 97487.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:44.614789900Z"),
                latitude= -23.698820114135742,
                longitude= -46.56201934814453,
                speed= 76.95652173913035,
                mileage_in_km = 97488.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:45.614789900Z"),
                latitude= -23.70088005065918,
                longitude= -46.56160354614258,
                speed= 76.95652173913035,
                mileage_in_km = 97488.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:46.614789900Z"),
                latitude= -23.70295524597168,
                longitude= -46.561580657958984,
                speed= 76.95652173913035,
                mileage_in_km = 97488.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:47.614789900Z"),
                latitude= -23.704957962036133,
                longitude= -46.561580657958984,
                speed= 77.82608695652165,
                mileage_in_km = 97488.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:48.614789900Z"),
                latitude= -23.7071590423584,
                longitude= -46.561580657958984,
                speed= 77.82608695652165,
                mileage_in_km = 97489.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:49.614789900Z"),
                latitude= -23.708887100219727,
                longitude= -46.561588287353516,
                speed= 77.82608695652165,
                mileage_in_km = 97489.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:50.614789900Z"),
                latitude= -23.710994720458984,
                longitude= -46.56160354614258,
                speed= 77.82608695652165,
                mileage_in_km = 97489.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:51.614789900Z"),
                latitude= -23.71305274963379,
                longitude= -46.56158447265625,
                speed= 77.82608695652165,
                mileage_in_km = 97489.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:52.614789900Z"),
                latitude= -23.715124130249023,
                longitude= -46.56123352050781,
                speed= 77.82608695652165,
                mileage_in_km = 97489.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:53.614789900Z"),
                latitude= -23.716665267944336,
                longitude= -46.56019973754883,
                speed= 78.69565217391295,
                mileage_in_km = 97490.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:54.614789900Z"),
                latitude= -23.718093872070312,
                longitude= -46.55873489379883,
                speed= 78.69565217391295,
                mileage_in_km = 97490.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:55.614789900Z"),
                latitude= -23.719493865966797,
                longitude= -46.55727767944336,
                speed= 78.69565217391295,
                mileage_in_km = 97490.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:56.614789900Z"),
                latitude= -23.720916748046875,
                longitude= -46.55579376220703,
                speed= 78.69565217391295,
                mileage_in_km = 97490.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:57.614789900Z"),
                latitude= -23.722400665283203,
                longitude= -46.55425262451172,
                speed= 78.69565217391295,
                mileage_in_km = 97491.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:58.614789900Z"),
                latitude= -23.72385025024414,
                longitude= -46.5527458190918,
                speed= 78.69565217391295,
                mileage_in_km = 97491.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:56:59.614789900Z"),
                latitude= -23.7255859375,
                longitude= -46.551177978515625,
                speed= 79.56521739130424,
                mileage_in_km = 97491.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:00.614789900Z"),
                latitude= -23.727197647094727,
                longitude= -46.549957275390625,
                speed= 79.56521739130424,
                mileage_in_km = 97491.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:01.614789900Z"),
                latitude= -23.728670120239258,
                longitude= -46.54884338378906,
                speed= 79.56521739130424,
                mileage_in_km = 97491.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:02.614789900Z"),
                latitude= -23.730297088623047,
                longitude= -46.54759979248047,
                speed= 79.56521739130424,
                mileage_in_km = 97492.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:03.614789900Z"),
                latitude= -23.734386444091797,
                longitude= -46.54418182373047,
                speed= 79.56521739130424,
                mileage_in_km = 97492.765625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:04.614789900Z"),
                latitude= -23.734386444091797,
                longitude= -46.54418182373047,
                speed= 0.0,
                mileage_in_km = 97492.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:05.614789900Z"),
                latitude= -23.73533058166504,
                longitude= -46.54344940185547,
                speed= 80.43478260869554,
                mileage_in_km = 97493.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:06.614789900Z"),
                latitude= -23.736961364746094,
                longitude= -46.54226303100586,
                speed= 80.43478260869554,
                mileage_in_km = 97493.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:07.614789900Z"),
                latitude= -23.738861083984375,
                longitude= -46.541648864746094,
                speed= 80.43478260869554,
                mileage_in_km = 97493.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:08.614789900Z"),
                latitude= -23.74064064025879,
                longitude= -46.541221618652344,
                speed= 80.43478260869554,
                mileage_in_km = 97493.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:09.614789900Z"),
                latitude= -23.7427921295166,
                longitude= -46.54070281982422,
                speed= 80.43478260869554,
                mileage_in_km = 97493.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:10.614789900Z"),
                latitude= -23.744503021240234,
                longitude= -46.54022216796875,
                speed= 80.43478260869554,
                mileage_in_km = 97493.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:11.614789900Z"),
                latitude= -23.746688842773438,
                longitude= -46.5394172668457,
                speed= 81.30434782608684,
                mileage_in_km = 97494.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:12.614789900Z"),
                latitude= -23.748289108276367,
                longitude= -46.53841781616211,
                speed= 81.30434782608684,
                mileage_in_km = 97494.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:13.614789900Z"),
                latitude= -23.74993133544922,
                longitude= -46.537254333496094,
                speed= 81.30434782608684,
                mileage_in_km = 97494.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:14.614789900Z"),
                latitude= -23.751676559448242,
                longitude= -46.53641891479492,
                speed= 81.30434782608684,
                mileage_in_km = 97495.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:15.614789900Z"),
                latitude= -23.753496170043945,
                longitude= -46.53510284423828,
                speed= 81.30434782608684,
                mileage_in_km = 97495.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:16.614789900Z"),
                latitude= -23.75545883178711,
                longitude= -46.53434371948242,
                speed= 81.30434782608684,
                mileage_in_km = 97495.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:17.614789900Z"),
                latitude= -23.757081985473633,
                longitude= -46.534759521484375,
                speed= 82.17391304347814,
                mileage_in_km = 97495.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:18.614789900Z"),
                latitude= -23.759044647216797,
                longitude= -46.534645080566406,
                speed= 82.17391304347814,
                mileage_in_km = 97495.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:19.614789900Z"),
                latitude= -23.761016845703125,
                longitude= -46.53413009643555,
                speed= 82.17391304347814,
                mileage_in_km = 97495.7421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:20.614789900Z"),
                latitude= -23.763044357299805,
                longitude= -46.534088134765625,
                speed= 82.17391304347814,
                mileage_in_km = 97496.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:21.614789900Z"),
                latitude= -23.764982223510742,
                longitude= -46.53430938720703,
                speed= 82.17391304347814,
                mileage_in_km = 97496.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:22.614789900Z"),
                latitude= -23.767009735107422,
                longitude= -46.53450393676758,
                speed= 82.17391304347814,
                mileage_in_km = 97496.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:23.614789900Z"),
                latitude= -23.76911163330078,
                longitude= -46.534339904785156,
                speed= 83.04347826086943,
                mileage_in_km = 97496.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:24.614789900Z"),
                latitude= -23.770923614501953,
                longitude= -46.53338623046875,
                speed= 83.04347826086943,
                mileage_in_km = 97497.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:25.614789900Z"),
                latitude= -23.772375106811523,
                longitude= -46.53215789794922,
                speed= 83.04347826086943,
                mileage_in_km = 97497.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:26.614789900Z"),
                latitude= -23.773942947387695,
                longitude= -46.530731201171875,
                speed= 83.04347826086943,
                mileage_in_km = 97497.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:27.614789900Z"),
                latitude= -23.77570152282715,
                longitude= -46.529747009277344,
                speed= 83.04347826086943,
                mileage_in_km = 97497.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:28.614789900Z"),
                latitude= -23.77887725830078,
                longitude= -46.529300689697266,
                speed= 83.04347826086943,
                mileage_in_km = 97498.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:29.614789900Z"),
                latitude= -23.77915382385254,
                longitude= -46.528953552246094,
                speed= 83.91304347826073,
                mileage_in_km = 97498.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:30.614789900Z"),
                latitude= -23.779645919799805,
                longitude= -46.5279655456543,
                speed= 83.91304347826073,
                mileage_in_km = 97498.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:31.614789900Z"),
                latitude= -23.781763076782227,
                longitude= -46.52709197998047,
                speed= 83.91304347826073,
                mileage_in_km = 97498.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:32.614789900Z"),
                latitude= -23.783292770385742,
                longitude= -46.526275634765625,
                speed= 83.91304347826073,
                mileage_in_km = 97499.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:33.614789900Z"),
                latitude= -23.784589767456055,
                longitude= -46.52493667602539,
                speed= 83.91304347826073,
                mileage_in_km = 97499.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:34.614789900Z"),
                latitude= -23.786176681518555,
                longitude= -46.523155212402344,
                speed= 83.91304347826073,
                mileage_in_km = 97499.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:35.614789900Z"),
                latitude= -23.78748321533203,
                longitude= -46.521663665771484,
                speed= 84.78260869565203,
                mileage_in_km = 97499.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:36.614789900Z"),
                latitude= -23.789003372192383,
                longitude= -46.52006912231445,
                speed= 84.78260869565203,
                mileage_in_km = 97499.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:37.614789900Z"),
                latitude= -23.790172576904297,
                longitude= -46.5186653137207,
                speed= 84.78260869565203,
                mileage_in_km = 97499.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:38.614789900Z"),
                latitude= -23.791645050048828,
                longitude= -46.516841888427734,
                speed= 84.78260869565203,
                mileage_in_km = 97500.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:39.614789900Z"),
                latitude= -23.792869567871094,
                longitude= -46.51540756225586,
                speed= 84.78260869565203,
                mileage_in_km = 97500.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:40.614789900Z"),
                latitude= -23.794382095336914,
                longitude= -46.51363754272461,
                speed= 84.78260869565203,
                mileage_in_km = 97500.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:41.614789900Z"),
                latitude= -23.795705795288086,
                longitude= -46.51215362548828,
                speed= 85.65217391304333,
                mileage_in_km = 97500.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:42.614789900Z"),
                latitude= -23.797374725341797,
                longitude= -46.5110969543457,
                speed= 85.65217391304333,
                mileage_in_km = 97501.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:43.614789900Z"),
                latitude= -23.799354553222656,
                longitude= -46.51077651977539,
                speed= 85.65217391304333,
                mileage_in_km = 97501.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:44.614789900Z"),
                latitude= -23.8015193939209,
                longitude= -46.5105094909668,
                speed= 85.65217391304333,
                mileage_in_km = 97501.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:45.614789900Z"),
                latitude= -23.803531646728516,
                longitude= -46.51025390625,
                speed= 85.65217391304333,
                mileage_in_km = 97501.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:46.614789900Z"),
                latitude= -23.80537223815918,
                longitude= -46.50975799560547,
                speed= 85.65217391304333,
                mileage_in_km = 97501.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:47.614789900Z"),
                latitude= -23.80708122253418,
                longitude= -46.509220123291016,
                speed= 86.52173913043463,
                mileage_in_km = 97502.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:48.614789900Z"),
                latitude= -23.80927276611328,
                longitude= -46.508583068847656,
                speed= 86.52173913043463,
                mileage_in_km = 97502.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:49.614789900Z"),
                latitude= -23.8111572265625,
                longitude= -46.50834274291992,
                speed= 86.52173913043463,
                mileage_in_km = 97502.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:50.614789900Z"),
                latitude= -23.813074111938477,
                longitude= -46.50817108154297,
                speed= 86.52173913043463,
                mileage_in_km = 97502.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:51.614789900Z"),
                latitude= -23.815288543701172,
                longitude= -46.50795364379883,
                speed= 86.52173913043463,
                mileage_in_km = 97503.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:52.614789900Z"),
                latitude= -23.8172664642334,
                longitude= -46.50776672363281,
                speed= 86.52173913043463,
                mileage_in_km = 97503.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:53.614789900Z"),
                latitude= -23.821157455444336,
                longitude= -46.507389068603516,
                speed= 87.39130434782592,
                mileage_in_km = 97503.4375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:54.614789900Z"),
                latitude= -23.821157455444336,
                longitude= -46.507389068603516,
                speed= 0.0,
                mileage_in_km = 97503.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:55.614789900Z"),
                latitude= -23.82314109802246,
                longitude= -46.5071907043457,
                speed= 87.39130434782592,
                mileage_in_km = 97503.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:56.614789900Z"),
                latitude= -23.825292587280273,
                longitude= -46.50697708129883,
                speed= 87.39130434782592,
                mileage_in_km = 97504.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:57.614789900Z"),
                latitude= -23.827180862426758,
                longitude= -46.50679016113281,
                speed= 87.39130434782592,
                mileage_in_km = 97504.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:58.614789900Z"),
                latitude= -23.829008102416992,
                longitude= -46.506622314453125,
                speed= 87.39130434782592,
                mileage_in_km = 97504.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:57:59.614789900Z"),
                latitude= -23.83114242553711,
                longitude= -46.50642395019531,
                speed= 88.26086956521722,
                mileage_in_km = 97504.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:00.614789900Z"),
                latitude= -23.83310317993164,
                longitude= -46.50623321533203,
                speed= 88.26086956521722,
                mileage_in_km = 97505.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:01.614789900Z"),
                latitude= -23.834983825683594,
                longitude= -46.50604248046875,
                speed= 88.26086956521722,
                mileage_in_km = 97505.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:02.614789900Z"),
                latitude= -23.837106704711914,
                longitude= -46.50584030151367,
                speed= 88.26086956521722,
                mileage_in_km = 97505.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:03.614789900Z"),
                latitude= -23.83913803100586,
                longitude= -46.50564956665039,
                speed= 88.26086956521722,
                mileage_in_km = 97505.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:04.614789900Z"),
                latitude= -23.84102439880371,
                longitude= -46.505470275878906,
                speed= 88.26086956521722,
                mileage_in_km = 97505.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:05.614789900Z"),
                latitude= -23.843313217163086,
                longitude= -46.50524139404297,
                speed= 89.13043478260852,
                mileage_in_km = 97506.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:06.614789900Z"),
                latitude= -23.845165252685547,
                longitude= -46.50505447387695,
                speed= 89.13043478260852,
                mileage_in_km = 97506.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:07.614789900Z"),
                latitude= -23.847061157226562,
                longitude= -46.5048828125,
                speed= 89.13043478260852,
                mileage_in_km = 97506.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:08.614789900Z"),
                latitude= -23.84903907775879,
                longitude= -46.50468063354492,
                speed= 89.13043478260852,
                mileage_in_km = 97506.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:09.614789900Z"),
                latitude= -23.851041793823242,
                longitude= -46.50448226928711,
                speed= 89.13043478260852,
                mileage_in_km = 97507.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:10.614789900Z"),
                latitude= -23.85304832458496,
                longitude= -46.50428771972656,
                speed= 89.13043478260852,
                mileage_in_km = 97507.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:11.614789900Z"),
                latitude= -23.855159759521484,
                longitude= -46.504085540771484,
                speed= 89.99999999999982,
                mileage_in_km = 97507.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:12.614789900Z"),
                latitude= -23.85715675354004,
                longitude= -46.503692626953125,
                speed= 89.99999999999982,
                mileage_in_km = 97507.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:13.614789900Z"),
                latitude= -23.85893440246582,
                longitude= -46.50265884399414,
                speed= 89.99999999999982,
                mileage_in_km = 97507.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:14.614789900Z"),
                latitude= -23.86032485961914,
                longitude= -46.501182556152344,
                speed= 89.99999999999982,
                mileage_in_km = 97508.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:15.614789900Z"),
                latitude= -23.861806869506836,
                longitude= -46.4995002746582,
                speed= 89.99999999999982,
                mileage_in_km = 97508.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:16.614789900Z"),
                latitude= -23.863069534301758,
                longitude= -46.49808120727539,
                speed= 89.99999999999982,
                mileage_in_km = 97508.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:17.614789900Z"),
                latitude= -23.86437225341797,
                longitude= -46.496604919433594,
                speed= 90.86956521739111,
                mileage_in_km = 97509.2578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:18.614789900Z"),
                latitude= -23.86746597290039,
                longitude= -46.494503021240234,
                speed= 90.86956521739111,
                mileage_in_km = 97509.2578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:19.614789900Z"),
                latitude= -23.86823844909668,
                longitude= -46.494075775146484,
                speed= 90.86956521739111,
                mileage_in_km = 97509.2578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:20.614789900Z"),
                latitude= -23.86968231201172,
                longitude= -46.49314498901367,
                speed= 90.86956521739111,
                mileage_in_km = 97509.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:21.614789900Z"),
                latitude= -23.87093734741211,
                longitude= -46.49129104614258,
                speed= 90.86956521739111,
                mileage_in_km = 97509.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:22.614789900Z"),
                latitude= -23.87228775024414,
                longitude= -46.49028015136719,
                speed= 90.86956521739111,
                mileage_in_km = 97509.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:23.614789900Z"),
                latitude= -23.87350845336914,
                longitude= -46.49147033691406,
                speed= 91.73913043478241,
                mileage_in_km = 97510.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:24.614789900Z"),
                latitude= -23.874629974365234,
                longitude= -46.49323654174805,
                speed= 91.73913043478241,
                mileage_in_km = 97510.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:25.614789900Z"),
                latitude= -23.875160217285156,
                longitude= -46.491451263427734,
                speed= 91.73913043478241,
                mileage_in_km = 97510.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:26.614789900Z"),
                latitude= -23.875553131103516,
                longitude= -46.48942565917969,
                speed= 91.73913043478241,
                mileage_in_km = 97511.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:27.614789900Z"),
                latitude= -23.877281188964844,
                longitude= -46.48862838745117,
                speed= 91.73913043478241,
                mileage_in_km = 97511.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:28.614789900Z"),
                latitude= -23.878978729248047,
                longitude= -46.48796463012695,
                speed= 91.73913043478241,
                mileage_in_km = 97511.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:29.614789900Z"),
                latitude= -23.880861282348633,
                longitude= -46.48824691772461,
                speed= 92.60869565217371,
                mileage_in_km = 97511.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:30.614789900Z"),
                latitude= -23.882644653320312,
                longitude= -46.48741149902344,
                speed= 92.60869565217371,
                mileage_in_km = 97511.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:31.614789900Z"),
                latitude= -23.8845157623291,
                longitude= -46.487884521484375,
                speed= 92.60869565217371,
                mileage_in_km = 97511.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:32.614789900Z"),
                latitude= -23.886240005493164,
                longitude= -46.486637115478516,
                speed= 92.60869565217371,
                mileage_in_km = 97512.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:33.614789900Z"),
                latitude= -23.88727569580078,
                longitude= -46.48503875732422,
                speed= 92.60869565217371,
                mileage_in_km = 97512.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:34.614789900Z"),
                latitude= -23.888044357299805,
                longitude= -46.48304748535156,
                speed= 92.60869565217371,
                mileage_in_km = 97512.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:35.614789900Z"),
                latitude= -23.888851165771484,
                longitude= -46.481178283691406,
                speed= 93.478260869565,
                mileage_in_km = 97512.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:36.614789900Z"),
                latitude= -23.887346267700195,
                longitude= -46.4800910949707,
                speed= 93.478260869565,
                mileage_in_km = 97513.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:37.614789900Z"),
                latitude= -23.88577651977539,
                longitude= -46.47929000854492,
                speed= 93.478260869565,
                mileage_in_km = 97513.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:38.614789900Z"),
                latitude= -23.886577606201172,
                longitude= -46.477821350097656,
                speed= 93.478260869565,
                mileage_in_km = 97513.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:39.614789900Z"),
                latitude= -23.887710571289062,
                longitude= -46.479164123535156,
                speed= 93.478260869565,
                mileage_in_km = 97513.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:40.614789900Z"),
                latitude= -23.889501571655273,
                longitude= -46.4802360534668,
                speed= 93.478260869565,
                mileage_in_km = 97513.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:41.614789900Z"),
                latitude= -23.891069412231445,
                longitude= -46.481624603271484,
                speed= 94.3478260869563,
                mileage_in_km = 97514.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:42.614789900Z"),
                latitude= -23.892364501953125,
                longitude= -46.48295974731445,
                speed= 94.3478260869563,
                mileage_in_km = 97514.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:43.614789900Z"),
                latitude= -23.889970779418945,
                longitude= -46.485374450683594,
                speed= 94.3478260869563,
                mileage_in_km = 97514.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:44.614789900Z"),
                latitude= -23.88968276977539,
                longitude= -46.48577117919922,
                speed= 94.3478260869563,
                mileage_in_km = 97514.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:45.614789900Z"),
                latitude= -23.888744354248047,
                longitude= -46.48752212524414,
                speed= 94.3478260869563,
                mileage_in_km = 97515.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:46.614789900Z"),
                latitude= -23.889514923095703,
                longitude= -46.48945236206055,
                speed= 94.3478260869563,
                mileage_in_km = 97515.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:47.614789900Z"),
                latitude= -23.88946533203125,
                longitude= -46.4913330078125,
                speed= 95.2173913043476,
                mileage_in_km = 97515.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:48.614789900Z"),
                latitude= -23.889427185058594,
                longitude= -46.49314498901367,
                speed= 95.2173913043476,
                mileage_in_km = 97515.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:49.614789900Z"),
                latitude= -23.891387939453125,
                longitude= -46.49334716796875,
                speed= 95.2173913043476,
                mileage_in_km = 97515.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:50.614789900Z"),
                latitude= -23.891258239746094,
                longitude= -46.49140167236328,
                speed= 95.2173913043476,
                mileage_in_km = 97516.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:51.614789900Z"),
                latitude= -23.89054298400879,
                longitude= -46.48937225341797,
                speed= 95.2173913043476,
                mileage_in_km = 97516.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:52.614789900Z"),
                latitude= -23.89194679260254,
                longitude= -46.488460540771484,
                speed= 95.2173913043476,
                mileage_in_km = 97516.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:53.614789900Z"),
                latitude= -23.893878936767578,
                longitude= -46.48897933959961,
                speed= 96.0869565217389,
                mileage_in_km = 97516.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:54.614789900Z"),
                latitude= -23.895708084106445,
                longitude= -46.48973083496094,
                speed= 96.0869565217389,
                mileage_in_km = 97517.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:55.614789900Z"),
                latitude= -23.896425247192383,
                longitude= -46.48797607421875,
                speed= 96.0869565217389,
                mileage_in_km = 97517.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:56.614789900Z"),
                latitude= -23.896305084228516,
                longitude= -46.48603439331055,
                speed= 96.0869565217389,
                mileage_in_km = 97517.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:57.614789900Z"),
                latitude= -23.896392822265625,
                longitude= -46.48398208618164,
                speed= 96.0869565217389,
                mileage_in_km = 97517.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:58.614789900Z"),
                latitude= -23.894784927368164,
                longitude= -46.4825439453125,
                speed= 96.0869565217389,
                mileage_in_km = 97517.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:58:59.614789900Z"),
                latitude= -23.894733428955078,
                longitude= -46.48035430908203,
                speed= 96.9565217391302,
                mileage_in_km = 97518.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:00.614789900Z"),
                latitude= -23.893587112426758,
                longitude= -46.478580474853516,
                speed= 96.9565217391302,
                mileage_in_km = 97518.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:01.614789900Z"),
                latitude= -23.893598556518555,
                longitude= -46.47651672363281,
                speed= 96.9565217391302,
                mileage_in_km = 97518.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:02.614789900Z"),
                latitude= -23.893707275390625,
                longitude= -46.474510192871094,
                speed= 96.9565217391302,
                mileage_in_km = 97518.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:03.614789900Z"),
                latitude= -23.8931941986084,
                longitude= -46.47238540649414,
                speed= 96.9565217391302,
                mileage_in_km = 97519.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:04.614789900Z"),
                latitude= -23.892332077026367,
                longitude= -46.47047805786133,
                speed= 96.9565217391302,
                mileage_in_km = 97519.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:05.614789900Z"),
                latitude= -23.891036987304688,
                longitude= -46.46894073486328,
                speed= 97.8260869565215,
                mileage_in_km = 97519.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:06.614789900Z"),
                latitude= -23.88917350769043,
                longitude= -46.468265533447266,
                speed= 97.8260869565215,
                mileage_in_km = 97519.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:07.614789900Z"),
                latitude= -23.888856887817383,
                longitude= -46.466033935546875,
                speed= 97.8260869565215,
                mileage_in_km = 97519.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:08.614789900Z"),
                latitude= -23.886333465576172,
                longitude= -46.46199035644531,
                speed= 97.8260869565215,
                mileage_in_km = 97520.1171875
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:09.614789900Z"),
                latitude= -23.886333465576172,
                longitude= -46.46199035644531,
                speed= 0.0,
                mileage_in_km = 97520.546875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:10.614789900Z"),
                latitude= -23.885648727416992,
                longitude= -46.461631774902344,
                speed= 97.8260869565215,
                mileage_in_km = 97520.546875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:11.614789900Z"),
                latitude= -23.883914947509766,
                longitude= -46.46051025390625,
                speed= 98.69565217391279,
                mileage_in_km = 97520.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:12.614789900Z"),
                latitude= -23.88243865966797,
                longitude= -46.4588737487793,
                speed= 98.69565217391279,
                mileage_in_km = 97521.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:13.614789900Z"),
                latitude= -23.880931854248047,
                longitude= -46.45753860473633,
                speed= 98.69565217391279,
                mileage_in_km = 97521.09375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:14.614789900Z"),
                latitude= -23.87948989868164,
                longitude= -46.456058502197266,
                speed= 98.69565217391279,
                mileage_in_km = 97521.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:15.614789900Z"),
                latitude= -23.87917709350586,
                longitude= -46.45368194580078,
                speed= 98.69565217391279,
                mileage_in_km = 97521.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:16.614789900Z"),
                latitude= -23.87949562072754,
                longitude= -46.4515380859375,
                speed= 98.69565217391279,
                mileage_in_km = 97521.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:17.614789900Z"),
                latitude= -23.88068389892578,
                longitude= -46.449764251708984,
                speed= 99.56521739130409,
                mileage_in_km = 97522.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:18.614789900Z"),
                latitude= -23.88180160522461,
                longitude= -46.44839859008789,
                speed= 99.56521739130409,
                mileage_in_km = 97522.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:19.614789900Z"),
                latitude= -23.883249282836914,
                longitude= -46.446632385253906,
                speed= 99.56521739130409,
                mileage_in_km = 97522.4140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:20.614789900Z"),
                latitude= -23.884666442871094,
                longitude= -46.44490051269531,
                speed= 99.56521739130409,
                mileage_in_km = 97523.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:21.614789900Z"),
                latitude= -23.885921478271484,
                longitude= -46.4433708190918,
                speed= 99.56521739130409,
                mileage_in_km = 97523.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:22.614789900Z"),
                latitude= -23.887325286865234,
                longitude= -46.44166564941406,
                speed= 99.56521739130409,
                mileage_in_km = 97523.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:23.614789900Z"),
                latitude= -23.888614654541016,
                longitude= -46.440093994140625,
                speed= 100.43478260869539,
                mileage_in_km = 97523.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:24.614789900Z"),
                latitude= -23.88988494873047,
                longitude= -46.438541412353516,
                speed= 100.43478260869539,
                mileage_in_km = 97523.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:25.614789900Z"),
                latitude= -23.89130973815918,
                longitude= -46.43680953979492,
                speed= 100.43478260869539,
                mileage_in_km = 97523.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:26.614789900Z"),
                latitude= -23.892539978027344,
                longitude= -46.43540573120117,
                speed= 100.43478260869539,
                mileage_in_km = 97524.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:27.614789900Z"),
                latitude= -23.894132614135742,
                longitude= -46.433837890625,
                speed= 100.43478260869539,
                mileage_in_km = 97524.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:28.614789900Z"),
                latitude= -23.895687103271484,
                longitude= -46.43233871459961,
                speed= 100.43478260869539,
                mileage_in_km = 97524.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:29.614789900Z"),
                latitude= -23.897232055664062,
                longitude= -46.43083953857422,
                speed= 101.30434782608668,
                mileage_in_km = 97525.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:30.614789900Z"),
                latitude= -23.898685455322266,
                longitude= -46.42927932739258,
                speed= 101.30434782608668,
                mileage_in_km = 97525.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:31.614789900Z"),
                latitude= -23.900142669677734,
                longitude= -46.42792892456055,
                speed= 101.30434782608668,
                mileage_in_km = 97525.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:32.614789900Z"),
                latitude= -23.901779174804688,
                longitude= -46.42692565917969,
                speed= 101.30434782608668,
                mileage_in_km = 97526.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:33.614789900Z"),
                latitude= -23.905776977539062,
                longitude= -46.42546463012695,
                speed= 101.30434782608668,
                mileage_in_km = 97526.0
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:34.614789900Z"),
                latitude= -23.905776977539062,
                longitude= -46.42546463012695,
                speed= 0.0,
                mileage_in_km = 97526.0
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:35.614789900Z"),
                latitude= -23.907564163208008,
                longitude= -46.424896240234375,
                speed= 102.17391304347798,
                mileage_in_km = 97526.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:36.614789900Z"),
                latitude= -23.909442901611328,
                longitude= -46.42427444458008,
                speed= 102.17391304347798,
                mileage_in_km = 97526.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:37.614789900Z"),
                latitude= -23.911270141601562,
                longitude= -46.42340087890625,
                speed= 102.17391304347798,
                mileage_in_km = 97526.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:38.614789900Z"),
                latitude= -23.9129638671875,
                longitude= -46.42231369018555,
                speed= 102.17391304347798,
                mileage_in_km = 97527.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:39.614789900Z"),
                latitude= -23.91461944580078,
                longitude= -46.420928955078125,
                speed= 102.17391304347798,
                mileage_in_km = 97527.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:40.614789900Z"),
                latitude= -23.916091918945312,
                longitude= -46.41932678222656,
                speed= 102.17391304347798,
                mileage_in_km = 97527.1015625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:41.614789900Z"),
                latitude= -23.91737174987793,
                longitude= -46.417564392089844,
                speed= 103.04347826086928,
                mileage_in_km = 97527.4296875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:42.614789900Z"),
                latitude= -23.918428421020508,
                longitude= -46.416046142578125,
                speed= 103.04347826086928,
                mileage_in_km = 97527.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:43.614789900Z"),
                latitude= -23.919641494750977,
                longitude= -46.41429901123047,
                speed= 103.04347826086928,
                mileage_in_km = 97527.75
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:44.614789900Z"),
                latitude= -23.920886993408203,
                longitude= -46.41250228881836,
                speed= 103.04347826086928,
                mileage_in_km = 97528.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:45.614789900Z"),
                latitude= -23.922195434570312,
                longitude= -46.410614013671875,
                speed= 103.04347826086928,
                mileage_in_km = 97528.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:46.614789900Z"),
                latitude= -23.923341751098633,
                longitude= -46.408966064453125,
                speed= 103.04347826086928,
                mileage_in_km = 97528.4453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:47.614789900Z"),
                latitude= -23.92453384399414,
                longitude= -46.40725326538086,
                speed= 103.91304347826058,
                mileage_in_km = 97528.7890625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:48.614789900Z"),
                latitude= -23.925691604614258,
                longitude= -46.40559005737305,
                speed= 103.91304347826058,
                mileage_in_km = 97529.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:49.614789900Z"),
                latitude= -23.926820755004883,
                longitude= -46.403629302978516,
                speed= 103.91304347826058,
                mileage_in_km = 97529.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:50.614789900Z"),
                latitude= -23.927562713623047,
                longitude= -46.40177917480469,
                speed= 103.91304347826058,
                mileage_in_km = 97529.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:51.614789900Z"),
                latitude= -23.9281063079834,
                longitude= -46.399627685546875,
                speed= 103.91304347826058,
                mileage_in_km = 97529.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:52.614789900Z"),
                latitude= -23.928508758544922,
                longitude= -46.39739227294922,
                speed= 103.91304347826058,
                mileage_in_km = 97529.7578125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:53.614789900Z"),
                latitude= -23.928478240966797,
                longitude= -46.395286560058594,
                speed= 104.78260869565187,
                mileage_in_km = 97530.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:54.614789900Z"),
                latitude= -23.928239822387695,
                longitude= -46.39316177368164,
                speed= 104.78260869565187,
                mileage_in_km = 97530.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:55.614789900Z"),
                latitude= -23.92795753479004,
                longitude= -46.39082336425781,
                speed= 104.78260869565187,
                mileage_in_km = 97530.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:56.614789900Z"),
                latitude= -23.92738151550293,
                longitude= -46.38676071166992,
                speed= 104.78260869565187,
                mileage_in_km = 97531.078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:57.614789900Z"),
                latitude= -23.92690658569336,
                longitude= -46.38243865966797,
                speed= 104.78260869565187,
                mileage_in_km = 97531.078125
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:58.614789900Z"),
                latitude= -23.92690658569336,
                longitude= -46.38243865966797,
                speed= 0.0,
                mileage_in_km = 97531.5234375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T04:59:59.614789900Z"),
                latitude= -23.92690658569336,
                longitude= -46.38243865966797,
                speed= 0.0,
                mileage_in_km = 97531.5234375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:00.614789900Z"),
                latitude= -23.926761627197266,
                longitude= -46.379974365234375,
                speed= 105.65217391304317,
                mileage_in_km = 97531.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:01.614789900Z"),
                latitude= -23.926942825317383,
                longitude= -46.37793731689453,
                speed= 105.65217391304317,
                mileage_in_km = 97531.7734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:02.614789900Z"),
                latitude= -23.927274703979492,
                longitude= -46.37590408325195,
                speed= 105.65217391304317,
                mileage_in_km = 97532.109375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:03.614789900Z"),
                latitude= -23.927642822265625,
                longitude= -46.37342071533203,
                speed= 105.65217391304317,
                mileage_in_km = 97532.453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:04.614789900Z"),
                latitude= -23.92793846130371,
                longitude= -46.37150573730469,
                speed= 105.65217391304317,
                mileage_in_km = 97532.453125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:05.614789900Z"),
                latitude= -23.928285598754883,
                longitude= -46.3691291809082,
                speed= 106.52173913043447,
                mileage_in_km = 97532.78125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:06.614789900Z"),
                latitude= -23.928674697875977,
                longitude= -46.3669548034668,
                speed= 106.52173913043447,
                mileage_in_km = 97533.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:07.614789900Z"),
                latitude= -23.92938232421875,
                longitude= -46.36510467529297,
                speed= 106.52173913043447,
                mileage_in_km = 97533.1171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:08.614789900Z"),
                latitude= -23.92925262451172,
                longitude= -46.36343002319336,
                speed= 106.52173913043447,
                mileage_in_km = 97533.4375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:09.614789900Z"),
                latitude= -23.9271297454834,
                longitude= -46.3630485534668,
                speed= 106.52173913043447,
                mileage_in_km = 97533.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:10.614789900Z"),
                latitude= -23.92603302001953,
                longitude= -46.362464904785156,
                speed= 106.52173913043447,
                mileage_in_km = 97533.765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:11.614789900Z"),
                latitude= -23.927988052368164,
                longitude= -46.36324691772461,
                speed= 107.39130434782577,
                mileage_in_km = 97534.125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:12.614789900Z"),
                latitude= -23.92731475830078,
                longitude= -46.36461639404297,
                speed= 107.39130434782577,
                mileage_in_km = 97534.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:13.614789900Z"),
                latitude= -23.927003860473633,
                longitude= -46.36693572998047,
                speed= 107.39130434782577,
                mileage_in_km = 97534.421875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:14.614789900Z"),
                latitude= -23.92668342590332,
                longitude= -46.36921310424805,
                speed= 107.39130434782577,
                mileage_in_km = 97535.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:15.614789900Z"),
                latitude= -23.926403045654297,
                longitude= -46.37104797363281,
                speed= 107.39130434782577,
                mileage_in_km = 97535.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:16.614789900Z"),
                latitude= -23.926025390625,
                longitude= -46.373512268066406,
                speed= 107.39130434782577,
                mileage_in_km = 97535.0859375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:17.614789900Z"),
                latitude= -23.925384521484375,
                longitude= -46.37777328491211,
                speed= 108.26086956521706,
                mileage_in_km = 97536.40625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:18.614789900Z"),
                latitude= -23.92302894592285,
                longitude= -46.380821228027344,
                speed= 108.26086956521706,
                mileage_in_km = 97536.40625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:19.614789900Z"),
                latitude= -23.92302894592285,
                longitude= -46.380821228027344,
                speed= 0.0,
                mileage_in_km = 97536.40625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:20.614789900Z"),
                latitude= -23.92436408996582,
                longitude= -46.37184143066406,
                speed= 108.26086956521706,
                mileage_in_km = 97537.3359375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:21.614789900Z"),
                latitude= -23.92436408996582,
                longitude= -46.37184143066406,
                speed= 0.0,
                mileage_in_km = 97537.3359375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:22.614789900Z"),
                latitude= -23.92436408996582,
                longitude= -46.37184143066406,
                speed= 0.0,
                mileage_in_km = 97537.3359375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:23.614789900Z"),
                latitude= -23.92436408996582,
                longitude= -46.37184143066406,
                speed= 0.0,
                mileage_in_km = 97537.3359375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:24.614789900Z"),
                latitude= -23.92436408996582,
                longitude= -46.37184143066406,
                speed= 0.0,
                mileage_in_km = 97537.3359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:25.614789900Z"),
                latitude= -23.924484252929688,
                longitude= -46.37101364135742,
                speed= 109.13043478260836,
                mileage_in_km = 97537.3359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:26.614789900Z"),
                latitude= -23.924728393554688,
                longitude= -46.36932373046875,
                speed= 109.13043478260836,
                mileage_in_km = 97537.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:27.614789900Z"),
                latitude= -23.925058364868164,
                longitude= -46.3671989440918,
                speed= 109.13043478260836,
                mileage_in_km = 97537.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:28.614789900Z"),
                latitude= -23.92539405822754,
                longitude= -46.364952087402344,
                speed= 109.13043478260836,
                mileage_in_km = 97537.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:29.614789900Z"),
                latitude= -23.925825119018555,
                longitude= -46.36299133300781,
                speed= 109.99999999999966,
                mileage_in_km = 97538.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:30.614789900Z"),
                latitude= -23.927881240844727,
                longitude= -46.36338806152344,
                speed= 109.99999999999966,
                mileage_in_km = 97538.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:31.614789900Z"),
                latitude= -23.92841339111328,
                longitude= -46.365089416503906,
                speed= 109.99999999999966,
                mileage_in_km = 97538.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:32.614789900Z"),
                latitude= -23.92802619934082,
                longitude= -46.3670768737793,
                speed= 109.99999999999966,
                mileage_in_km = 97538.8203125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:33.614789900Z"),
                latitude= -23.927698135375977,
                longitude= -46.369319915771484,
                speed= 109.99999999999966,
                mileage_in_km = 97539.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:34.614789900Z"),
                latitude= -23.927392959594727,
                longitude= -46.37141799926758,
                speed= 109.99999999999966,
                mileage_in_km = 97539.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:35.614789900Z"),
                latitude= -23.927230834960938,
                longitude= -46.3736457824707,
                speed= 110.86956521739096,
                mileage_in_km = 97539.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:36.614789900Z"),
                latitude= -23.926959991455078,
                longitude= -46.3757438659668,
                speed= 110.86956521739096,
                mileage_in_km = 97539.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:37.614789900Z"),
                latitude= -23.926687240600586,
                longitude= -46.377864837646484,
                speed= 110.86956521739096,
                mileage_in_km = 97539.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:38.614789900Z"),
                latitude= -23.926532745361328,
                longitude= -46.3801383972168,
                speed= 110.86956521739096,
                mileage_in_km = 97540.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:39.614789900Z"),
                latitude= -23.926593780517578,
                longitude= -46.3823127746582,
                speed= 110.86956521739096,
                mileage_in_km = 97540.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:40.614789900Z"),
                latitude= -23.92682647705078,
                longitude= -46.38438415527344,
                speed= 110.86956521739096,
                mileage_in_km = 97540.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:41.614789900Z"),
                latitude= -23.92711639404297,
                longitude= -46.386680603027344,
                speed= 111.73913043478225,
                mileage_in_km = 97541.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:42.614789900Z"),
                latitude= -23.927385330200195,
                longitude= -46.38874435424805,
                speed= 111.73913043478225,
                mileage_in_km = 97541.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:43.614789900Z"),
                latitude= -23.927671432495117,
                longitude= -46.39106369018555,
                speed= 111.73913043478225,
                mileage_in_km = 97541.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:44.614789900Z"),
                latitude= -23.928226470947266,
                longitude= -46.39777374267578,
                speed= 111.73913043478225,
                mileage_in_km = 97542.0703125
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:45.614789900Z"),
                latitude= -23.928226470947266,
                longitude= -46.39777374267578,
                speed= 0.0,
                mileage_in_km = 97542.0703125
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:46.614789900Z"),
                latitude= -23.928226470947266,
                longitude= -46.39777374267578,
                speed= 0.0,
                mileage_in_km = 97542.0703125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:47.614789900Z"),
                latitude= -23.927988052368164,
                longitude= -46.39973831176758,
                speed= 112.60869565217355,
                mileage_in_km = 97542.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:48.614789900Z"),
                latitude= -23.927492141723633,
                longitude= -46.40167236328125,
                speed= 112.60869565217355,
                mileage_in_km = 97542.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:49.614789900Z"),
                latitude= -23.926633834838867,
                longitude= -46.40379333496094,
                speed= 112.60869565217355,
                mileage_in_km = 97542.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:50.614789900Z"),
                latitude= -23.92555046081543,
                longitude= -46.4056396484375,
                speed= 112.60869565217355,
                mileage_in_km = 97543.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:51.614789900Z"),
                latitude= -23.924436569213867,
                longitude= -46.40724563598633,
                speed= 112.60869565217355,
                mileage_in_km = 97543.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:52.614789900Z"),
                latitude= -23.923118591308594,
                longitude= -46.40910720825195,
                speed= 112.60869565217355,
                mileage_in_km = 97543.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:53.614789900Z"),
                latitude= -23.921960830688477,
                longitude= -46.41077423095703,
                speed= 113.47826086956485,
                mileage_in_km = 97543.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:54.614789900Z"),
                latitude= -23.920814514160156,
                longitude= -46.41244888305664,
                speed= 113.47826086956485,
                mileage_in_km = 97543.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:55.614789900Z"),
                latitude= -23.919584274291992,
                longitude= -46.414222717285156,
                speed= 113.47826086956485,
                mileage_in_km = 97543.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:56.614789900Z"),
                latitude= -23.918378829956055,
                longitude= -46.41596221923828,
                speed= 113.47826086956485,
                mileage_in_km = 97544.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:57.614789900Z"),
                latitude= -23.917160034179688,
                longitude= -46.41771697998047,
                speed= 113.47826086956485,
                mileage_in_km = 97544.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:58.614789900Z"),
                latitude= -23.915903091430664,
                longitude= -46.41939926147461,
                speed= 113.47826086956485,
                mileage_in_km = 97544.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:00:59.614789900Z"),
                latitude= -23.914480209350586,
                longitude= -46.420921325683594,
                speed= 114.34782608695615,
                mileage_in_km = 97544.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:00.614789900Z"),
                latitude= -23.912912368774414,
                longitude= -46.422237396240234,
                speed= 114.34782608695615,
                mileage_in_km = 97545.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:01.614789900Z"),
                latitude= -23.911039352416992,
                longitude= -46.42341995239258,
                speed= 114.34782608695615,
                mileage_in_km = 97545.140625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:02.614789900Z"),
                latitude= -23.909259796142578,
                longitude= -46.42423629760742,
                speed= 114.34782608695615,
                mileage_in_km = 97545.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:03.614789900Z"),
                latitude= -23.907386779785156,
                longitude= -46.42485427856445,
                speed= 114.34782608695615,
                mileage_in_km = 97545.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:04.614789900Z"),
                latitude= -23.905353546142578,
                longitude= -46.42550277709961,
                speed= 114.34782608695615,
                mileage_in_km = 97545.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:05.614789900Z"),
                latitude= -23.903413772583008,
                longitude= -46.42612838745117,
                speed= 115.21739130434744,
                mileage_in_km = 97546.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:06.614789900Z"),
                latitude= -23.90149688720703,
                longitude= -46.42696762084961,
                speed= 115.21739130434744,
                mileage_in_km = 97546.5
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:07.614789900Z"),
                latitude= -23.899919509887695,
                longitude= -46.427982330322266,
                speed= 115.21739130434744,
                mileage_in_km = 97546.5
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:08.614789900Z"),
                latitude= -23.89373016357422,
                longitude= -46.43401336669922,
                speed= 115.21739130434744,
                mileage_in_km = 97547.625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:09.614789900Z"),
                latitude= -23.89373016357422,
                longitude= -46.43401336669922,
                speed= 0.0,
                mileage_in_km = 97547.625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:10.614789900Z"),
                latitude= -23.89373016357422,
                longitude= -46.43401336669922,
                speed= 0.0,
                mileage_in_km = 97547.625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:11.614789900Z"),
                latitude= -23.89373016357422,
                longitude= -46.43401336669922,
                speed= 0.0,
                mileage_in_km = 97547.625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:12.614789900Z"),
                latitude= -23.89240837097168,
                longitude= -46.435081481933594,
                speed= 116.08695652173874,
                mileage_in_km = 97547.625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:13.614789900Z"),
                latitude= -23.89044189453125,
                longitude= -46.43466567993164,
                speed= 116.08695652173874,
                mileage_in_km = 97547.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:14.614789900Z"),
                latitude= -23.88889503479004,
                longitude= -46.433162689208984,
                speed= 116.08695652173874,
                mileage_in_km = 97548.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:15.614789900Z"),
                latitude= -23.8872013092041,
                longitude= -46.432125091552734,
                speed= 116.08695652173874,
                mileage_in_km = 97548.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:16.614789900Z"),
                latitude= -23.88680648803711,
                longitude= -46.43389129638672,
                speed= 116.08695652173874,
                mileage_in_km = 97548.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:17.614789900Z"),
                latitude= -23.887168884277344,
                longitude= -46.4361572265625,
                speed= 116.95652173913004,
                mileage_in_km = 97548.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:18.614789900Z"),
                latitude= -23.887537002563477,
                longitude= -46.43816375732422,
                speed= 116.95652173913004,
                mileage_in_km = 97549.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:19.614789900Z"),
                latitude= -23.888202667236328,
                longitude= -46.4400749206543,
                speed= 116.95652173913004,
                mileage_in_km = 97549.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:20.614789900Z"),
                latitude= -23.88776206970215,
                longitude= -46.44174575805664,
                speed= 116.95652173913004,
                mileage_in_km = 97549.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:21.614789900Z"),
                latitude= -23.88656234741211,
                longitude= -46.44319534301758,
                speed= 116.95652173913004,
                mileage_in_km = 97549.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:22.614789900Z"),
                latitude= -23.886423110961914,
                longitude= -46.44276428222656,
                speed= 116.95652173913004,
                mileage_in_km = 97549.8125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:23.614789900Z"),
                latitude= -23.887908935546875,
                longitude= -46.44095230102539,
                speed= 117.82608695652134,
                mileage_in_km = 97550.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:24.614789900Z"),
                latitude= -23.889196395874023,
                longitude= -46.43938446044922,
                speed= 117.82608695652134,
                mileage_in_km = 97550.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:25.614789900Z"),
                latitude= -23.890474319458008,
                longitude= -46.437828063964844,
                speed= 117.82608695652134,
                mileage_in_km = 97550.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:26.614789900Z"),
                latitude= -23.891923904418945,
                longitude= -46.436065673828125,
                speed= 117.82608695652134,
                mileage_in_km = 97550.8359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:27.614789900Z"),
                latitude= -23.89322280883789,
                longitude= -46.43471145629883,
                speed= 117.82608695652134,
                mileage_in_km = 97551.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:28.614789900Z"),
                latitude= -23.894716262817383,
                longitude= -46.43327713012695,
                speed= 117.82608695652134,
                mileage_in_km = 97551.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:29.614789900Z"),
                latitude= -23.896244049072266,
                longitude= -46.431800842285156,
                speed= 118.69565217391263,
                mileage_in_km = 97551.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:30.614789900Z"),
                latitude= -23.897666931152344,
                longitude= -46.430416107177734,
                speed= 118.69565217391263,
                mileage_in_km = 97551.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:31.614789900Z"),
                latitude= -23.899089813232422,
                longitude= -46.42884826660156,
                speed= 118.69565217391263,
                mileage_in_km = 97551.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:32.614789900Z"),
                latitude= -23.902637481689453,
                longitude= -46.42652893066406,
                speed= 118.69565217391263,
                mileage_in_km = 97552.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:33.614789900Z"),
                latitude= -23.907405853271484,
                longitude= -46.42494583129883,
                speed= 118.69565217391263,
                mileage_in_km = 97553.046875
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:34.614789900Z"),
                latitude= -23.907405853271484,
                longitude= -46.42494583129883,
                speed= 0.0,
                mileage_in_km = 97553.046875
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:35.614789900Z"),
                latitude= -23.907405853271484,
                longitude= -46.42494583129883,
                speed= 0.0,
                mileage_in_km = 97553.046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:36.614789900Z"),
                latitude= -23.908313751220703,
                longitude= -46.42465591430664,
                speed= 119.56521739130393,
                mileage_in_km = 97553.046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:37.614789900Z"),
                latitude= -23.91022300720215,
                longitude= -46.42393493652344,
                speed= 119.56521739130393,
                mileage_in_km = 97553.046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:38.614789900Z"),
                latitude= -23.912113189697266,
                longitude= -46.42289352416992,
                speed= 119.56521739130393,
                mileage_in_km = 97553.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:39.614789900Z"),
                latitude= -23.913612365722656,
                longitude= -46.421817779541016,
                speed= 119.56521739130393,
                mileage_in_km = 97553.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:40.614789900Z"),
                latitude= -23.915189743041992,
                longitude= -46.420352935791016,
                speed= 119.56521739130393,
                mileage_in_km = 97553.8046875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:41.614789900Z"),
                latitude= -23.91661262512207,
                longitude= -46.418643951416016,
                speed= 120.43478260869523,
                mileage_in_km = 97554.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:42.614789900Z"),
                latitude= -23.917818069458008,
                longitude= -46.41691970825195,
                speed= 120.43478260869523,
                mileage_in_km = 97554.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:43.614789900Z"),
                latitude= -23.918949127197266,
                longitude= -46.4152946472168,
                speed= 120.43478260869523,
                mileage_in_km = 97554.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:44.614789900Z"),
                latitude= -23.920284271240234,
                longitude= -46.41337203979492,
                speed= 120.43478260869523,
                mileage_in_km = 97554.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:45.614789900Z"),
                latitude= -23.92144012451172,
                longitude= -46.41170120239258,
                speed= 120.43478260869523,
                mileage_in_km = 97555.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:46.614789900Z"),
                latitude= -23.92262077331543,
                longitude= -46.410003662109375,
                speed= 120.43478260869523,
                mileage_in_km = 97555.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:47.614789900Z"),
                latitude= -23.923803329467773,
                longitude= -46.40830612182617,
                speed= 121.30434782608653,
                mileage_in_km = 97555.8359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:48.614789900Z"),
                latitude= -23.925125122070312,
                longitude= -46.40640640258789,
                speed= 121.30434782608653,
                mileage_in_km = 97555.8359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:49.614789900Z"),
                latitude= -23.92630958557129,
                longitude= -46.404605865478516,
                speed= 121.30434782608653,
                mileage_in_km = 97555.8359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:50.614789900Z"),
                latitude= -23.92723274230957,
                longitude= -46.40269088745117,
                speed= 121.30434782608653,
                mileage_in_km = 97556.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:51.614789900Z"),
                latitude= -23.92790412902832,
                longitude= -46.40057373046875,
                speed= 121.30434782608653,
                mileage_in_km = 97556.5078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:52.614789900Z"),
                latitude= -23.928247451782227,
                longitude= -46.39868927001953,
                speed= 121.30434782608653,
                mileage_in_km = 97556.5078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:53.614789900Z"),
                latitude= -23.928525924682617,
                longitude= -46.39659118652344,
                speed= 122.17391304347782,
                mileage_in_km = 97557.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:54.614789900Z"),
                latitude= -23.928354263305664,
                longitude= -46.39417266845703,
                speed= 122.17391304347782,
                mileage_in_km = 97557.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:55.614789900Z"),
                latitude= -23.928089141845703,
                longitude= -46.391963958740234,
                speed= 122.17391304347782,
                mileage_in_km = 97557.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:56.614789900Z"),
                latitude= -23.9278507232666,
                longitude= -46.38997268676758,
                speed= 122.17391304347782,
                mileage_in_km = 97557.5
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:57.614789900Z"),
                latitude= -23.927513122558594,
                longitude= -46.38786315917969,
                speed= 122.17391304347782,
                mileage_in_km = 97557.8203125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:58.614789900Z"),
                latitude= -23.927244186401367,
                longitude= -46.385623931884766,
                speed= 122.17391304347782,
                mileage_in_km = 97557.8203125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:01:59.614789900Z"),
                latitude= -23.926759719848633,
                longitude= -46.38027572631836,
                speed= 123.04347826086912,
                mileage_in_km = 97558.1640625
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:00.614789900Z"),
                latitude= -23.926759719848633,
                longitude= -46.38027572631836,
                speed= 0.0,
                mileage_in_km = 97558.59375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:01.614789900Z"),
                latitude= -23.926795959472656,
                longitude= -46.379241943359375,
                speed= 123.04347826086912,
                mileage_in_km = 97558.59375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:02.614789900Z"),
                latitude= -23.927085876464844,
                longitude= -46.37714767456055,
                speed= 123.04347826086912,
                mileage_in_km = 97558.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:03.614789900Z"),
                latitude= -23.92742156982422,
                longitude= -46.37489700317383,
                speed= 123.04347826086912,
                mileage_in_km = 97559.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:04.614789900Z"),
                latitude= -23.92778205871582,
                longitude= -46.372528076171875,
                speed= 123.04347826086912,
                mileage_in_km = 97559.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:05.614789900Z"),
                latitude= -23.928064346313477,
                longitude= -46.37063980102539,
                speed= 123.91304347826042,
                mileage_in_km = 97559.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:06.614789900Z"),
                latitude= -23.928407669067383,
                longitude= -46.36830139160156,
                speed= 123.91304347826042,
                mileage_in_km = 97559.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:07.614789900Z"),
                latitude= -23.92892837524414,
                longitude= -46.36634063720703,
                speed= 123.91304347826042,
                mileage_in_km = 97559.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:08.614789900Z"),
                latitude= -23.92967987060547,
                longitude= -46.36437225341797,
                speed= 123.91304347826042,
                mileage_in_km = 97560.171875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:09.614789900Z"),
                latitude= -23.928255081176758,
                longitude= -46.36324691772461,
                speed= 123.91304347826042,
                mileage_in_km = 97560.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:10.614789900Z"),
                latitude= -23.926342010498047,
                longitude= -46.36290740966797,
                speed= 123.91304347826042,
                mileage_in_km = 97560.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:11.614789900Z"),
                latitude= -23.926725387573242,
                longitude= -46.36282730102539,
                speed= 124.78260869565172,
                mileage_in_km = 97560.8359375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:12.614789900Z"),
                latitude= -23.92746353149414,
                longitude= -46.3635139465332,
                speed= 124.78260869565172,
                mileage_in_km = 97561.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:13.614789900Z"),
                latitude= -23.92716407775879,
                longitude= -46.365745544433594,
                speed= 124.78260869565172,
                mileage_in_km = 97561.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:14.614789900Z"),
                latitude= -23.92690086364746,
                longitude= -46.3676643371582,
                speed= 124.78260869565172,
                mileage_in_km = 97561.5078125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:15.614789900Z"),
                latitude= -23.926563262939453,
                longitude= -46.37002182006836,
                speed= 124.78260869565172,
                mileage_in_km = 97561.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:16.614789900Z"),
                latitude= -23.926233291625977,
                longitude= -46.372154235839844,
                speed= 124.78260869565172,
                mileage_in_km = 97561.828125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:17.614789900Z"),
                latitude= -23.925912857055664,
                longitude= -46.3742561340332,
                speed= 125.65217391304301,
                mileage_in_km = 97562.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:18.614789900Z"),
                latitude= -23.925580978393555,
                longitude= -46.37647247314453,
                speed= 125.65217391304301,
                mileage_in_km = 97562.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:19.614789900Z"),
                latitude= -23.92525291442871,
                longitude= -46.3786506652832,
                speed= 125.65217391304301,
                mileage_in_km = 97562.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:20.614789900Z"),
                latitude= -23.92494010925293,
                longitude= -46.38069534301758,
                speed= 125.65217391304301,
                mileage_in_km = 97562.8203125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:21.614789900Z"),
                latitude= -23.924304962158203,
                longitude= -46.38164138793945,
                speed= 125.65217391304301,
                mileage_in_km = 97563.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:22.614789900Z"),
                latitude= -23.924264907836914,
                longitude= -46.37983322143555,
                speed= 125.65217391304301,
                mileage_in_km = 97563.1484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:23.614789900Z"),
                latitude= -23.924606323242188,
                longitude= -46.37758255004883,
                speed= 126.52173913043431,
                mileage_in_km = 97564.1875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:24.614789900Z"),
                latitude= -23.925457000732422,
                longitude= -46.37183380126953,
                speed= 126.52173913043431,
                mileage_in_km = 97564.1875
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:25.614789900Z"),
                latitude= -23.925457000732422,
                longitude= -46.37183380126953,
                speed= 0.0,
                mileage_in_km = 97564.1875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:26.614789900Z"),
                latitude= -23.925552368164062,
                longitude= -46.37120056152344,
                speed= 126.52173913043431,
                mileage_in_km = 97564.1875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:27.614789900Z"),
                latitude= -23.92527198791504,
                longitude= -46.36935806274414,
                speed= 126.52173913043431,
                mileage_in_km = 97564.5
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:28.614789900Z"),
                latitude= -23.92496681213379,
                longitude= -46.3677864074707,
                speed= 126.52173913043431,
                mileage_in_km = 97564.5
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:29.614789900Z"),
                latitude= -23.925315856933594,
                longitude= -46.36550521850586,
                speed= 127.39130434782561,
                mileage_in_km = 97565.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:30.614789900Z"),
                latitude= -23.925617218017578,
                longitude= -46.3633918762207,
                speed= 127.39130434782561,
                mileage_in_km = 97565.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:31.614789900Z"),
                latitude= -23.927356719970703,
                longitude= -46.36320114135742,
                speed= 127.39130434782561,
                mileage_in_km = 97565.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:32.614789900Z"),
                latitude= -23.92852783203125,
                longitude= -46.36437225341797,
                speed= 127.39130434782561,
                mileage_in_km = 97565.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:33.614789900Z"),
                latitude= -23.928115844726562,
                longitude= -46.366729736328125,
                speed= 127.39130434782561,
                mileage_in_km = 97565.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:34.614789900Z"),
                latitude= -23.92775535583496,
                longitude= -46.36893081665039,
                speed= 127.39130434782561,
                mileage_in_km = 97565.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:35.614789900Z"),
                latitude= -23.927453994750977,
                longitude= -46.37099075317383,
                speed= 128.26086956521692,
                mileage_in_km = 97566.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:36.614789900Z"),
                latitude= -23.92729949951172,
                longitude= -46.37293243408203,
                speed= 128.26086956521692,
                mileage_in_km = 97566.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:37.614789900Z"),
                latitude= -23.927059173583984,
                longitude= -46.375057220458984,
                speed= 128.26086956521692,
                mileage_in_km = 97566.484375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:38.614789900Z"),
                latitude= -23.9267578125,
                longitude= -46.3773193359375,
                speed= 128.26086956521692,
                mileage_in_km = 97566.8515625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:39.614789900Z"),
                latitude= -23.926544189453125,
                longitude= -46.37958526611328,
                speed= 128.26086956521692,
                mileage_in_km = 97567.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:40.614789900Z"),
                latitude= -23.926557540893555,
                longitude= -46.38178253173828,
                speed= 128.26086956521692,
                mileage_in_km = 97567.1640625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:41.614789900Z"),
                latitude= -23.926780700683594,
                longitude= -46.38401412963867,
                speed= 129.13043478260823,
                mileage_in_km = 97567.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:42.614789900Z"),
                latitude= -23.92706298828125,
                longitude= -46.38624954223633,
                speed= 129.13043478260823,
                mileage_in_km = 97567.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:43.614789900Z"),
                latitude= -23.927330017089844,
                longitude= -46.38836669921875,
                speed= 129.13043478260823,
                mileage_in_km = 97567.84375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:44.614789900Z"),
                latitude= -23.927574157714844,
                longitude= -46.3902473449707,
                speed= 129.13043478260823,
                mileage_in_km = 97568.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:45.614789900Z"),
                latitude= -23.927839279174805,
                longitude= -46.39239501953125,
                speed= 129.13043478260823,
                mileage_in_km = 97568.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:46.614789900Z"),
                latitude= -23.92815589904785,
                longitude= -46.39485168457031,
                speed= 129.13043478260823,
                mileage_in_km = 97568.4765625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:47.614789900Z"),
                latitude= -23.9281005859375,
                longitude= -46.39904022216797,
                speed= 129.99999999999955,
                mileage_in_km = 97569.734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:48.614789900Z"),
                latitude= -23.92636489868164,
                longitude= -46.4043083190918,
                speed= 129.99999999999955,
                mileage_in_km = 97569.734375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:49.614789900Z"),
                latitude= -23.92636489868164,
                longitude= -46.4043083190918,
                speed= 0.0,
                mileage_in_km = 97569.734375
            ),

//parada
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:50.614789900Z"),
                latitude= -23.92636489868164,
                longitude= -46.4043083190918,
                speed= 0.0,
                mileage_in_km = 97569.734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:51.614789900Z"),
                latitude= -23.925832748413086,
                longitude= -46.40520477294922,
                speed= 129.99999999999955,
                mileage_in_km = 97569.734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:52.614789900Z"),
                latitude= -23.92464828491211,
                longitude= -46.40694046020508,
                speed= 129.99999999999955,
                mileage_in_km = 97569.734375
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:53.614789900Z"),
                latitude= -23.92345428466797,
                longitude= -46.40864562988281,
                speed= 130.86956521739086,
                mileage_in_km = 97570.15625
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:54.614789900Z"),
                latitude= -23.922279357910156,
                longitude= -46.410316467285156,
                speed= 130.86956521739086,
                mileage_in_km = 97570.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:55.614789900Z"),
                latitude= -23.92110824584961,
                longitude= -46.41187286376953,
                speed= 130.86956521739086,
                mileage_in_km = 97570.4921875
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:56.614789900Z"),
                latitude= -23.91988182067871,
                longitude= -46.4135627746582,
                speed= 130.86956521739086,
                mileage_in_km = 97570.8203125
            ),
            DataAsset(
                occurred_at= OffsetDateTime.parse("2023-02-27T05:02:57.614789900Z"),
                latitude= -23.918649673461914,
                longitude= -46.41550827026367,
                speed= 130.86956521739086,
                mileage_in_km = 97571.15625
            )

        )


        val intervalDelay = if (list.isNotEmpty() && list.size >= 2){
            list[1].occurred_at.toInstant().toEpochMilli() -
            list[0].occurred_at.toInstant().toEpochMilli()
        }else{5000L}


        val cinter = if (list.isNotEmpty() && list.size >= 1){
            LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli() - list[0].occurred_at.toInstant().toEpochMilli()
        }else{5000L}

//        println("Diferença ${OffsetDateTime.ofInstant(Instant.ofEpochMilli(cinter), ZoneOffset.UTC)}")

        list.forEach {
            Thread.sleep(intervalDelay);

            val iotMessage = AssetIotEventMessage(
                assetId = UUID.fromString(assetId),
                accountId = accountId,
                deviceId = UUID.fromString("8664cbbb-ff0b-4332-89dc-1aa283f1856d"),
                deviceType = "tbm3",
                driverIdentification = null,
                driverIdentificationType = null,
                eid = "tbm:2006290118/67/1675694409761/394/state/d9010aed-3df8-432f-bdc2-b4f0bd7d9949",
                occurredAt = it.occurred_at.toInstant().plusMillis(cinter).atOffset(ZoneOffset.UTC),
                trigger = "timer",
                position = AssetPositionMessage(
                    it.latitude,
                    it.longitude,
                    altitude = 739.2000122070312,
                    accuracy = 3.200000047683716,
                    altitudeAccuracy = null,
                    heading = 51.9900016784668,
                    speed = it.speed
                ),
                state = AssetStateMessage(
                    mileage = 0.0,//it.mileage_in_km,
                    ignitionOn = true,
                    fuelLevel = 71.19999694824219,
                    stateOfCharge = null,
                    electricRange = null,
                    engineSpeed = 1566.0,
                    wheelSpeed = 27.8984375,
                    tachoSpeed = 28.0,
                    fuelConsumption = null,
                    acceleratorPedal = null,
                    weightTotal = null,
                    ptoInformation = null,
                    electronicRetarderState = null,
                    driveState = null,
                    fuelRate = null,
                    instantaneousFuelEconomy = null,
                    engineOperationTime = null
                ),
                driverInfo = null,
                driverState = null
            )

            println(iotMessage.occurredAt)
            println(iotMessage)
            infringementDetection.start(iotMessage)
        }
    }
}