package routefence_common.cloud.rio.latam_routefence.infrastructure.entity

import org.hibernate.annotations.DynamicUpdate
import routefence_common.cloud.rio.latam_routefence.domain.enums.VehicleTypesEnum
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@Table(name = "TB_VEHICLE_VOCATIONAL_INFO")
data class VehicleVocationalInfoEntity(
    @Id
    @Column(name = "ID")
    var id: String = UUID.randomUUID().toString(),

    @Column(name = "VEHICLE_TYPE")
    @Enumerated(EnumType.STRING)
    var vehicleType: VehicleTypesEnum?,

    @Column(name = "WIDTH")
    var width: Float?,

    @Column(name = "HEIGHT")
    var height: Float?,

    @Column(name = "COM_TOTAL")
    var comTotal: Float?,

    @Column(name = "NUMBER_AXLE")
    var numberAxle: Int?,

    @Column(name = "TRAILER_AXLE")
    var trailerAxle: Int?,

    @Column(name = "MAX_WEIGHT")
    var maxWeight: Float?,

    @Column(name = "POLLUTANT_CLASS")
    var pollutantClass: String?,

    @Column(name = "MAX_WEIGHT_AXLE")
    var maxWeightAxle: Float?,

    @Column(name = "DANGER_CLASSIFICATION")
    var dangerClassification: String?
)