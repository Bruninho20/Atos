import React, { FC, useState } from 'react'
import { FormattedMessage, injectIntl, Intl } from 'react-intl'
import useSWR from 'swr'
import { isEmpty } from 'lodash'

import { fetcherPost } from 'core/utils/fetch'

import { CardOneScore, Placeholder } from 'components'
import { PlaceholderProps } from 'components/Placeholder'
import { CardFilter, FilterType } from '..'
import { ScoreTypes } from 'components/CardMultipleScores'

export type ScoreObject = {
  id: string
  score: number
  type: ScoreTypes
}

interface OperativeCardData {
  link: string
  more: {
    description: string
    id: string
  }[]
  scores: ScoreObject[]
}

interface OperativeCardProps {
  assetsId: string[]
  tagsId: string[]
  filter: FilterType
  intl: Intl
  onFilterClick: (filter: CardFilter) => void
}

type MoreLinkDescriptionType = 'DISTANCE' | 'ENGINE_HOURS'

const moreLinkIcons = (description: string): string => {
  const descriptionObject: Record<MoreLinkDescriptionType, string> = {
    DISTANCE: 'road',
    ENGINE_HOURS: 'time'
  }

  return descriptionObject[(description as MoreLinkDescriptionType) || description]
}

type TogleOptions = 'DISTANCE' | 'ENGINE_HOURS'

const OperativeCard: FC<OperativeCardProps> = ({ assetsId, tagsId, filter, intl, onFilterClick }) => {
  const [checkedList, setCheckedList] = useState({ DISTANCE: false, ENGINE_HOURS: false })

  const { data, error, isValidating } = useSWR<OperativeCardData>(
    ['/api/perla-tests/vehicleStatus/operativeCard', checkedList, assetsId, tagsId],
    url => {
      return fetcherPost(url, {
        assetIds: assetsId,
        tagIds: tagsId,
        vehicleOperationCondition: checkedList.DISTANCE
          ? 'TOTAL_DISTANCE'
          : checkedList.ENGINE_HOURS
          ? 'ENGINE_HOURS'
          : 'DEFAULT'
      })
    }
  )

  const handleFilterClick = (id: string) => {
    onFilterClick({
      card: 'operative',
      filter: id
    })
  }

  const handleMoreLinkCLick = (id: string) => {
    if (id === 'TOTAL_DISTANCE') {
      setCheckedList({
        ENGINE_HOURS: false,
        DISTANCE: !checkedList.DISTANCE
      })
    } else if (id === 'ENGINE_HOURS') {
      setCheckedList({
        DISTANCE: false,
        ENGINE_HOURS: !checkedList.ENGINE_HOURS
      })
    }
  }

  const handleLinkClick = (id: string) => {
    handleFilterClick(id)
  }

  const isEmptyData = isEmpty(data)

  const titleMoreLink =
    data && data?.more
      ? data.more.map(moreData => ({
          icon: moreLinkIcons(moreData.description),
          description: intl.formatMessage({ id: moreData.description }),
          checked: checkedList[moreData.description as TogleOptions],
          onClick: () => handleMoreLinkCLick(moreData.id)
        }))
      : undefined

  return (
    <div style={{ minHeight: '215px', width: '100%' }}>
      <Placeholder
        short
        contentsName={<FormattedMessage id='vehiclesStatus.operative.placeholder.contentsName' />}
        isEmpty={isEmptyData && !isValidating}
        status={error ? 'error' : ('success' as PlaceholderProps['status'])}>
        <>
          <CardOneScore
            title={<FormattedMessage id='vehiclesStatus.operative.card.title' />}
            loading={isEmptyData}
            description={<FormattedMessage id='vehiclesStatus.operative.card.description' />}
            score={!isEmptyData ? data?.scores[0] : undefined}
            descriptionScore={!isEmptyData ? data?.scores[1] : undefined}
            descriptionScoreUnit={<FormattedMessage id='vehiclesStatus.operative.card.scoreUnit' />}
            footerTitle={<FormattedMessage id='vehiclesStatus.operative.card.footer' />}
            hasFooterClick={true}
            hasMoreLinks={true}
            titleMoreLinks={titleMoreLink}
            footerClicked={filter === 'operative'}
            onFooterClick={() => handleLinkClick(data?.link || '')}
          />
        </>
      </Placeholder>
    </div>
  )
}

export default injectIntl(OperativeCard)
