package listener.cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity.AssetIotEventStateEntity
import java.util.*

@Repository
interface AssetIotEventStateEntityRepository : JpaRepository<AssetIotEventStateEntity, String> {
    @Query(value ="SELECT ev FROM AssetIotEventStateEntity ev WHERE ev.eid = :eid")
    fun findByEid(@Param("eid") eid: String) : AssetIotEventStateEntity?
}