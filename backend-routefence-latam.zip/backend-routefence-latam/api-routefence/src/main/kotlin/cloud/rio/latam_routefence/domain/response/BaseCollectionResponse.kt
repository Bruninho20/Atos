package cloud.rio.latam_routefence.domain.response

data class BaseCollectionResponse<T> (
    var data: Collection<T>? = null,
    var count: Int = 0
)