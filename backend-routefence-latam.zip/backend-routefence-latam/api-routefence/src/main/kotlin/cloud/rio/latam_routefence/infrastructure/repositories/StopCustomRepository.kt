package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.repository.query.Param
import routefence_common.cloud.rio.latam_routefence.domain.response.RouteStopResponse

interface StopCustomRepository {

    fun getAllStopsByRouteId(@Param("routeId") routeId: String): List<RouteStopResponse>

}