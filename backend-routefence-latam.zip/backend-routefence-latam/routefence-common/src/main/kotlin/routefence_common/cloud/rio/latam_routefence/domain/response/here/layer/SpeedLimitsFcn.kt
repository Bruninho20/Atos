package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class SpeedLimitsFcn(
    @param:JsonProperty("SPEED_LIMITS_FCN")
    @get:JsonProperty("SPEED_LIMITS_FCN")
    var speedLimitsFcn: Collection<Map<String, String>>?,

    @param:JsonProperty("TRUCK_SPEED_LIMITS_FCN")
    @get:JsonProperty("TRUCK_SPEED_LIMITS_FCN")
    var truckSpeedLimitsFcn: Collection<Map<String, String>>?
)
