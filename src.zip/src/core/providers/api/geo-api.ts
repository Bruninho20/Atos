import { dmCode } from './routes/dm-code-api'
import { email } from './routes/email-api'

export const geoApi = {
  dmCode,
  email
}
