package routefence_common.cloud.rio.latam_routefence.domain.response

data class CostsResponse (
    var id: String? = null,
    var tollValue: String? = null,
    var operativeCosts: String? = null,
    var totalCosts: String? = null,
    var fuelAverageCosts: String? = null,
    var averageConsume: String? = null
)