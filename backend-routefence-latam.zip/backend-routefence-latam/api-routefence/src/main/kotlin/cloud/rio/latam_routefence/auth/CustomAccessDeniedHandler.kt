package cloud.rio.latam_maintenance.auth

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.security.access.AccessDeniedException
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.oauth2.server.resource.BearerTokenErrorCodes
import org.springframework.security.oauth2.server.resource.authentication.AbstractOAuth2TokenAuthenticationToken
import org.springframework.security.web.access.AccessDeniedHandler
import org.springframework.util.StringUtils
import java.io.IOException
import java.security.Principal
import java.util.*
import java.util.stream.Collectors
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class CustomAccessDeniedHandler : AccessDeniedHandler{

    private val logger: Logger = LoggerFactory.getLogger(javaClass)

    private val TOKEN_SCOPE_ATTRIBUTE = "SCOPE"
    private val ERROR_DESCRIPTION = "The token has insufficient permissions for this request"
    private val ERROR_URI = "https://tools.ietf.org/html/rfc6750#section-3.1"

    @Throws(IOException::class, ServletException::class)
    override fun handle(httpServletRequest: HttpServletRequest, httpServletResponse: HttpServletResponse, e: AccessDeniedException) {
        val parameters = extractExceptionParameters(httpServletRequest.userPrincipal)
        val wwwAuthenticate = WwwAuthenticateHelper.computeWWWAuthenticateHeaderValue(parameters)
        httpServletResponse.addHeader(HttpHeaders.WWW_AUTHENTICATE, wwwAuthenticate)
        httpServletResponse.status = HttpStatus.FORBIDDEN.value()
        logger.debug("Access was denied because of insufficient permissions.")
    }

    private fun extractExceptionParameters(principal: Principal): LinkedHashMap<String, String> {
        val parameters = LinkedHashMap<String, String>()
        if (principal is AbstractOAuth2TokenAuthenticationToken<*>) {
            parameters["error"] = BearerTokenErrorCodes.INSUFFICIENT_SCOPE
            parameters["error_description"] = ERROR_DESCRIPTION
            parameters["error_uri"] = ERROR_URI
            val scope = getScope(principal)
            logger.info("Scope: {}", scope)
            if (StringUtils.hasText(scope)) {
                parameters["scope"] = scope
            }
        }
        return parameters
    }

    private fun getScope(token: AbstractOAuth2TokenAuthenticationToken<*>): String {
        return if (!token.authorities.isEmpty()) {
            token.authorities.stream().map { it: GrantedAuthority ->
                it.authority
                        .replace(TOKEN_SCOPE_ATTRIBUTE, "")
            }
                    .collect(Collectors.joining(" "))
        } else ""
    }


}