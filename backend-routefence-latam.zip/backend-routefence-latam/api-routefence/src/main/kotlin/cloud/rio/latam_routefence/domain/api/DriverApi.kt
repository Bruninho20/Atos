package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriverDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriversDTO
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import javax.servlet.http.HttpServletRequest

@RequestMapping("/driver")
interface DriverApi : RoutefenceBaseApi {

    @GetMapping(produces = ["application/json"])
    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun getDrivers(request: HttpServletRequest, @RequestParam(required = false, value = "assetId") assetId: String?): DriversDTO?

    @GetMapping("/{driverId}", produces = ["application/json"])
    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun getById(@PathVariable(value = "driverId") driverId:String): DriverDTO?
}