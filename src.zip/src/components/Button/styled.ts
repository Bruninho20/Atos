import styled, { css } from 'styled-components'

interface StyledButtonProps {
  onlyIcon?: boolean
}

export const StyledButton = styled.button<StyledButtonProps>`
  ${({ onlyIcon }) =>
    onlyIcon &&
    css`
      padding: 0 6px;
      .rioglyph {
        font-size: 2.1rem;
        margin: 0;
      }
      .text-button {
        display: none;
      }
    `};
`
