package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.auth.InternalAuthResponse
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriverDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriversDTO
import cloud.rio.latam_routefence.infrastructure.consumedapi.drivers.DriverApiClient
import cloud.rio.latam_routefence.infrastructure.repositories.DriverCustomRepository
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.tenant.AccountContext
import java.util.*
import java.util.Optional.empty
import java.util.Optional.of
import javax.servlet.http.HttpServletRequest
import javax.transaction.Transactional

@Service
@Transactional
class DriverService (private val driverApiClient: DriverApiClient, private val driverCustomRepository: DriverCustomRepository) {
    fun list(request: HttpServletRequest, assetId: String?): DriversDTO? {
        val drivers = driverApiClient.listDriver(request)?.items

        if (assetId.isNullOrBlank()) {
            return DriversDTO( items = drivers?.toMutableList() ?: mutableListOf())
        }

        if (drivers != null) {
            val allDrivers = drivers.toMutableList()

            val linkedDriverIds = driverCustomRepository.getDriversOrderByMostLinkedToAsset(assetId)

            val linkedDrivers = linkedDriverIds.mapNotNull { id -> allDrivers.find { it.id == id } }

            val remainingDrivers = allDrivers.filterNot { linkedDrivers.contains(it) }

            val driversDto = DriversDTO()
            driversDto.priority = linkedDrivers.toMutableList()
            driversDto.items = remainingDrivers.toMutableList()

            return driversDto
        }

        return null
    }

    private fun getDriverById(driverId: String, token: InternalAuthResponse? = null): Optional<DriverDTO> {
        val accountId: String = AccountContext.get()

        var ret: Optional<DriverDTO> = empty()

        try {
            val search = driverApiClient.getByIdentification(driverId, accountId, token)

            search?.let {
                if (it.items.size > 0)
                    ret = of(it.items.first())
            }
        } catch (e: Exception) {
            println("Error on search driver id [$driverId] with accountId [$accountId] - DriverService #22")
            println(e.message)
        }

        return ret
    }

    fun getById(driverId: String, token: InternalAuthResponse? = null): DriverDTO {
        return this.getDriverById(driverId, token).orElseThrow(){
            throw RoutefenceException.RoutefenceNotFoundException("Driver.not.found", arrayOf(driverId))
        }
    }
}