import React, { useState } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container, SidesheetWrapper } from './styled'
import CreateRouteSidesheetAuto from './CreteRouteSidesheetAuto'
import {
  AddressDialog,
  MapRoutefenceAuto,
  StopConfigDialog,
  AddressDialogManual,
  ModalConfirm
} from '../../../components'
import AddVehicleDialog from 'components/AddVehicleDialog'

const MapDash: React.FC = () => {
  const [openAddressDialog, setOpenAddressDialog] = useState(false)
  const [openAddressDialogManual, setOpenAddressDialogManual] = useState(false)
  const [openStopConfigDialog, setOpenStopConfigDialog] = useState(false)
  const [openConfirm, setOpenConfirm] = useState(false)
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [changeMode, setChangeMode] = useState('auto')
  const [geolocationStop, setGeolocationStop] = useState<any>()
  const [typeRoupePoint, setTypeRoutePoint] = useState('')
  const [data, setData] = useState({
    originRouteData: { lat: '', lng: '', addressStop: '' },
    destinyRouteData: { lat: '', lng: '', addressStop: '' },
    stops: {},
    allStops: [],
    linkedVehicles: [],
    routeParameters: {},
    responseHere: {}
  })

  const handleOpenAddressDialogManual = (value: any, type: string, open: boolean) => {
    setOpenAddressDialogManual(open)
    setTypeRoutePoint(type)
    setGeolocationStop(value)
  }

  const handleOpenAddVehiclesDialog = (open: boolean) => {
    setOpenAddVehicleDialog(open)
  }

  const handleOpenConfigDialog = (geolocation: any, open: boolean) => {
    setGeolocationStop(geolocation)
    setTypeRoutePoint('stops')
    setOpenStopConfigDialog(open)
  }

  const handleOpenStopDialog = (open: boolean) => {
    setGeolocationStop(undefined)
    setOpenStopConfigDialog(open)
    setTypeRoutePoint('stopsSidesheet')
  }  

  const handleSaveRouteParameters = (parameters: object) => {
    setData({ ...data, responseHere: parameters })
  }

  const handleAddStops = (stops: any) => {
    setData({ ...data, allStops: stops })
  }

  const handleUpdateParameters = (routeParameters: any) => {
    setData({ ...data, routeParameters })
  }

  const handleChangeMode = (type: string) => {
    setChangeMode(type)
  }

  return (
    <div>
      <AddressDialog
        title='Procurar endereço'
        isOpen={openAddressDialog}
        onClose={() => setOpenAddressDialog(false)}
        type={typeRoupePoint}
      />
      <ModalConfirm
        title='Deseja mesmo cancelar a criação de rota?'
        subtitle='Ao cancelar perderá todos os dados cadastrados'
        isOpen={openConfirm}
        onClose={() => setOpenConfirm(false)}
      />
      <AddressDialogManual
        title='Procurar endereço manual'
        isOpen={openAddressDialogManual}
        onClose={() => setOpenAddressDialogManual(false)}
        type={typeRoupePoint}
        geolocation={geolocationStop}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type={'addVehicle'}
        typeToTrip=''
        data={undefined}
      />
      <StopConfigDialog
        title='Adicionar Parada'
        isOpen={openStopConfigDialog}
        onClose={() => setOpenStopConfigDialog(false)}
        type={typeRoupePoint}
        geolocation={geolocationStop}
      />
      {changeMode === 'auto' ? (
        <Container>
          <MapWrapper>
            <MapRoutefenceAuto
              data={data}
              handleSaveRouteParameters={handleSaveRouteParameters}
              handleOpenConfigDialog={handleOpenConfigDialog}
              handleOpenAddressDialogManual={handleOpenAddressDialogManual}
            />
          </MapWrapper>
          <SidesheetWrapper>
            <CreateRouteSidesheetAuto
              setOpenConfirm={() => setOpenConfirm(true)}
              handleOpenStopDialog={() => handleOpenStopDialog(true)}
              handleChangeMode={handleChangeMode}
              handleOpenAddressDialog={handleOpenAddressDialogManual}
              handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
              handleAddStops={handleAddStops}
              data={data}
              handleUpdateParameters={handleUpdateParameters}
            />
          </SidesheetWrapper>
        </Container>
      ) : (
        <Container>
        </Container>
      )}
    </div>
  )
}

export default injectIntl(MapDash)
