package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class VehicleTypesEnum {
    CAR, TRUCK, BUS
}