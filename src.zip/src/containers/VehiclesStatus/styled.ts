import styled from 'styled-components'
import { Section } from 'components';

export const Container = styled.div`
  padding: 30px
`

export const DashboardWrapper = styled.div``

export const CarouselSection = styled(Section)`
  height: 269px;
  position: relative;
`;
