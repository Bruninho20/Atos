import React from 'react';
import { cleanup, fireEvent, render } from '@testing-library/react';
import sinon from 'sinon';
import '@testing-library/jest-dom';
import { Card } from 'components';

afterEach(cleanup);

it('should trigger the function after click on <Card /> title', () => {
  const handleClick = sinon.spy();
  const { getByText } = render(
    <Card
      action={handleClick}
      className="important-info-card"
      title="Important information title"
    >
      Important information on card
    </Card>
  );
  expect(handleClick.called).toEqual(false);
  fireEvent.click(getByText('Important information title'));
  expect(handleClick.called).toEqual(true);
});

it('should trigger the function after click on <Card /> body', () => {
  const handleClick = sinon.spy();
  const { getByText } = render(
    <Card
      action={handleClick}
      className="important-info-card"
      title="Important information title"
    >
      Important information on card
    </Card>
  );
  expect(handleClick.called).toEqual(false);
  fireEvent.click(getByText('Important information on card'));
  expect(handleClick.called).toEqual(true);
});
