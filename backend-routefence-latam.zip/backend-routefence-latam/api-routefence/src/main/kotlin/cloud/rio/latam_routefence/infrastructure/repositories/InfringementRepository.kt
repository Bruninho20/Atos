package cloud.rio.latam_routefence.infrastructure.repositories

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.InfringementEntity
import java.time.LocalDateTime

@Repository
interface InfringementRepository : PagingAndSortingRepository<InfringementEntity, String> {

    @Query(value = "SELECT i FROM InfringementEntity i INNER JOIN TripEntity t ON t.id = :tripId WHERE i.type = :type AND i.endDateTime = null")
    fun getByTripIdAndType(@Param("tripId") tripId: String, @Param("type") type: InfringementTypeEnum): Collection<InfringementEntity>

    @Query(value = "SELECT i FROM InfringementEntity i WHERE i.trip.id = :tripId AND i.startDateTime BETWEEN :startDateTime AND :endDateTime")
    fun getByTripByPeriod(@Param("tripId") tripId: String,
                          @Param("startDateTime") startDateTime: LocalDateTime,
                          @Param("endDateTime") endDateTime: LocalDateTime): List<InfringementEntity>

    @Query(value = "SELECT i FROM InfringementEntity i WHERE i.trip.id = :tripId")
    fun getByTrip(@Param("tripId") tripId: String): List<InfringementEntity>
}