import React, { FC, useEffect, useRef, useState } from 'react';

import { KeyboardArrowLeft as ArrowLeft } from '@styled-icons/material/KeyboardArrowLeft';
import { KeyboardArrowRight as ArrowRight } from '@styled-icons/material/KeyboardArrowRight';

import { CarouselWrapper, StyledButton, StyledCarousel } from './styled';

interface CarouselProps {
  children: Array<React.ReactNode>;
}

const Carousel: FC<CarouselProps> = ({ children }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const containerWrapperRef = useRef<HTMLDivElement>(null);
  const [shouldRenderButon, setShouldRenderButon] = useState<boolean>(false);

  const childrenLength = children.length;

  const movePrevious = () => {
    if (containerRef.current) {
      const shouldMove = containerRef.current.scrollWidth / childrenLength;
      containerRef.current.scrollLeft =
        containerRef.current.scrollLeft - shouldMove;
    }
  };

  const moveNext = () => {
    if (containerRef.current) {
      const shouldMove = containerRef.current.scrollWidth / childrenLength;
      containerRef.current.scrollLeft =
        containerRef.current.scrollLeft + shouldMove;
    }
  };

  const updateWidthAndHeight = () => {
    if (containerWrapperRef.current && containerRef.current) {
      const containerWrapperWidth = containerWrapperRef.current?.scrollWidth;
      const containerWidth = containerRef.current?.scrollWidth;
      if (containerWidth > containerWrapperWidth) {
        setShouldRenderButon(true);
      } else {
        setShouldRenderButon(false);
      }
    }
  };

  const renderButons = () => (
    <>
      <StyledButton
        className="arrowLeft"
        aria-label="Move Previous"
        onClick={movePrevious}
      >
        <ArrowLeft />
      </StyledButton>
      <StyledButton
        className="arrowRight"
        aria-label="Move Next"
        onClick={moveNext}
      >
        <ArrowRight />
      </StyledButton>
    </>
  );

  useEffect(() => {
    window.addEventListener('resize', updateWidthAndHeight);
    return () => {
      window.removeEventListener('resize', updateWidthAndHeight);
    };
  }, []);

  return (
    <CarouselWrapper ref={containerWrapperRef}>
      <StyledCarousel ref={containerRef}>{children}</StyledCarousel>
      {shouldRenderButon && renderButons()}
    </CarouselWrapper>
  );
};

export default React.memo(Carousel);
