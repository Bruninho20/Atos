package listener.cloud.rio.latam_routefence.services

import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.utils.DateFormatter
import java.time.OffsetDateTime

@Service
class Speeding(private val infringementService: InfringementService) : IInfringible {

    private val logger = LoggerFactory.getLogger(this.javaClass)

    override fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest? {
        if (trip.status == TripStatusEnum.STARTED) {
            val speed = asset.position?.speed ?: 0.0
            val openInfringement = infringementService.findByTripAndType(trip.id, InfringementTypeEnum.SPEEDING)
                .sortedByDescending { it.startDateTime }.firstOrNull()
            if (speed > 1.0) {
                val trafficViolation = trafficViolationList.firstOrNull { it.type == InfringementTypeEnum.SPEEDING }
                if (trafficViolation != null) {
                    logger.debug("Excesso de velocidade na via")
                    if (openInfringement == null) {
                        return setInfringement(
                            asset.occurredAt,
                            asset.position!!.latitude.toFloat(),
                            asset.position!!.longitude.toFloat(),
                            trip.id,
                            trafficViolation.note
                        )
                    }
                }else{
                    if(openInfringement != null){
                        infringementService.closeInfringement(openInfringement)
                    }
                }
            }else{
                if(openInfringement != null){
                    infringementService.closeInfringement(openInfringement)
                }
            }
        }
        return null
    }

    private fun setInfringement(
        occurredAt: OffsetDateTime, lat: Float, lng: Float, tripId: String, note: String?
    ): InfringementRequest {
        return InfringementRequest(
            null,
            InfringementTypeEnum.SPEEDING,
            note,
            DateFormatter.formatUTC(occurredAt),
            null,
            GeoPointRequest(null, lat, lng, null),
            tripId
        )
    }

}