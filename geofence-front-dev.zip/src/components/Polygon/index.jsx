import React, { useEffect, useState } from 'react';
import { Map, Polygon, Marker, SingleMapMarker, EventUtils, MapSettings, MapTypeSettings } from 'rio-uikit-map';
import axios from 'axios';
import polygonData from './polygonData.json'

const STROKE_COLOR = 'rgba(90, 72, 118, 1)';
const FILL_COLOR = 'rgba(90, 72, 118, 0.3)';
const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
const hereCredentials = {
    id: 'taZnpQ5ImkHyDEUf3aXg',
    key: 'jCib4OGUgnFdbUZ6__kMZA',
 }

const PolygonExample = ({position = { lat: -23.539205196591556, lng: -46.634366366793806 }, range = 15000}) => {
    const [points, setPoints] = useState([])

    const getPoints = polygonData.response.isoline[0].component[0].shape.map(value=>{
                        const [lat,lng] = value.split(',')
                        return {lat, lng}})
                        console.log(getPoints, 'getPoints')

    const eventListenerMap = {
        [EventUtils.TAP]: event => console.log(event),
    };

    const markerIcon = (
        <SingleMapMarker
            iconNames={['geofence']}
            name='São Paulo'
            markerColor={'bg-map-marker-poi'}
        />
    );

    return (
        <>
        <Map
            credentials={{
                apikey: typeof apiKey === 'string'
                    ? apiKey
                    : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
            }}
            center={position}
            zoom={12}
            height={600}
            mapSettings={<MapSettings options={[<MapTypeSettings tooltip={'Change map type'} />]} />}
        >
            <Marker
                position={position}
                icon={markerIcon}
            />
            <Polygon
                points={getPoints}
                style={{ strokeColor: STROKE_COLOR, fillColor: FILL_COLOR }}
                eventListenerMap={eventListenerMap}
            />
        </Map>
        {/* {hereData.length > 0 ? 
        <table>
            <ul>Teste</ul>
            <li>{` Teste ${hereData.shape.shape}`}</li>
        </table>
        : <h1>Falhou</h1> } */}
        </>
    );
};

export default PolygonExample;