package routefence_common.cloud.rio.latam_routefence.domain.enums

enum class InfringementTypeEnum {
    SPEEDING,ROUTE_DEVIATION,FORBIDDEN_DIRECTION,UNSCHEDULED_STOP,STOP_OVERTIME
}