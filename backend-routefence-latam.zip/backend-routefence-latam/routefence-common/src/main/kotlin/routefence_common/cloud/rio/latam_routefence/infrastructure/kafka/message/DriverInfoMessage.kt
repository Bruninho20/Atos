package routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message

import com.fasterxml.jackson.annotation.JsonProperty

data class DriverInfoMessage(
    @JsonProperty("first_name")
    val firstName: String?,
    @JsonProperty("last_name")
    val lastName: String?
)
