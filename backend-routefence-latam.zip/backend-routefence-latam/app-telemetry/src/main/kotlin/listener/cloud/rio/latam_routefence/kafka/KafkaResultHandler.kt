package listener.cloud.rio.latam_routefence.kafka

import org.springframework.kafka.support.KafkaHeaders
import org.springframework.kafka.support.SendResult

fun onError(ex: Throwable?, prefix: String? = null) {
    println("$prefix Send: failure for topic ${KafkaHeaders.TOPIC}, exception $ex")
}

fun onSuccessSend(result: SendResult<String, String>?, prefix: String? = null) {
    println(
        "$prefix Result: success for topic ${result?.producerRecord?.topic()}, partition ${result?.recordMetadata?.partition()}, " +
                "offset ${result?.recordMetadata?.offset()}, timestamp ${result?.recordMetadata?.timestamp()}, message ${result?.producerRecord?.value()}"
    )
}