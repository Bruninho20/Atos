package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class Category(
    val id: String?,
    val name: String?,
    val primary: Boolean?
)
