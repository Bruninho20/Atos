import React, { FC } from 'react';
import { injectIntl, Intl } from 'react-intl';

interface InjectIntlWrapper {
  intl: Intl;
  children: React.ReactElement;
}

const InjectIntlWrapper: FC<InjectIntlWrapper> = ({ intl, children }) => {
  return <div>{React.cloneElement(children, { intl })}</div>;
};

export default injectIntl(InjectIntlWrapper);
