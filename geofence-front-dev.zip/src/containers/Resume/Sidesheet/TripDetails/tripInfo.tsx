import React from 'react'

const TripInfo: React.FC = () => {
  return <div></div>
}

export default TripInfo
