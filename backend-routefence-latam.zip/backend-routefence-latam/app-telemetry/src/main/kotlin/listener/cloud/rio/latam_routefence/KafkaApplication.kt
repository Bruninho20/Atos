package listener.cloud.rio.latam_routefence

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.boot.runApplication
import org.springframework.context.annotation.ComponentScan

/**
 *class used only for the test suite, to test the telemetry use MainTest.kt
 **/

@SpringBootApplication
@EntityScan("routefence_common.cloud.rio.latam_routefence.infrastructure.entity")
@ComponentScan("routefence_common.cloud.rio.latam_routefence.*","listener.cloud.rio.latam_routefence.*")
class KafkaApplication

fun main(args: Array<String>) {
	runApplication<KafkaApplication>(*args)
}
