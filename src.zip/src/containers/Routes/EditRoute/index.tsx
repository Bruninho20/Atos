import React, { useState } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container, SidesheetWrapper } from './styled'
import EditRouteSidesheet from './EditRouteSidesheet'
import { AddressDialog, AddressDialogManual, MapRoutefenceAuto } from '../../../components'
import AddVehicleDialog from 'components/AddVehicleDialog'
import StopConfigDialog from 'components/StopConfigDialog'

const EditRoute: React.FC = (props: any) => {
  const [openAddressDialog, setOpenAddressDialog] = useState(false)
  const [openStopConfigDialog, setOpenStopConfigDialog] = useState(false)
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [typeRoupePoint, setTypeRoutePoint] = useState('')
  const [data, setData] = useState(props?.history?.location?.state?.body)
  const [geolocationStop, setGeolocationStop] = useState<any>()
  const [openAddressDialogManual, setOpenAddressDialogManual] = useState(false)
  const [typeAddVehicles, setTypeAddVehicles] = useState('')

  const path = props.match.path

  const handleOpenAddVehiclesDialog = (open: boolean, type: string) => {
    setTypeAddVehicles(type)
    setOpenAddVehicleDialog(open)
  }

  const handleSaveRouteParameters = (parameters: object) => {
    setData({ ...data, routeParameters: parameters })
  }

  const handleAddStops = (stops: any) => {
    setData({ ...data, allStops: stops })
  }

  const handleUpdateParameters = (routeParameters: any) => {
    setData({ ...data, routeParameters })
  }

  const handleOpenAddressDialogManual = (value: any, type: string, open: boolean) => {
    setOpenAddressDialogManual(open)
    setTypeRoutePoint(type)
    setGeolocationStop(value)
  }

  const handleOpenConfigDialog = (geolocation: any, open: boolean) => {
    setGeolocationStop(geolocation)
    setTypeRoutePoint('stops')
    setOpenStopConfigDialog(open)
  }

  const handleOpenStopDialog = (open: boolean) => {
    setGeolocationStop(undefined)
    setOpenStopConfigDialog(open)
    setTypeRoutePoint('stopsSidesheet')
  }

  return (
    <div>
      <AddressDialog
        title='Procurar endereço'
        isOpen={openAddressDialog}
        onClose={() => setOpenAddressDialog(false)}
        type={typeRoupePoint}
      />
      <AddressDialogManual
        title='Procurar endereço manual'
        isOpen={openAddressDialogManual}
        onClose={() => setOpenAddressDialogManual(false)}
        type={typeRoupePoint}
        geolocation={geolocationStop}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type='linkVehicleOut'
        typeToTrip={typeAddVehicles}
        data={undefined}
      />
      <StopConfigDialog
        title='Adicionar Parada'
        isOpen={openStopConfigDialog}
        onClose={() => setOpenStopConfigDialog(false)}
        type={typeRoupePoint}
        geolocation={'teste'}
      />

      <Container>
        <MapWrapper>
          <MapRoutefenceAuto
            data={data}
            handleSaveRouteParameters={handleSaveRouteParameters}
            handleOpenConfigDialog={handleOpenConfigDialog}
            handleOpenAddressDialogManual={handleOpenAddressDialogManual}
          />
        </MapWrapper>
        <SidesheetWrapper>
          <EditRouteSidesheet
            handleChangeMode={() => console.log('teste')}
            handleOpenAddressDialog={handleOpenAddressDialogManual}
            handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
            handleAddStops={handleAddStops}            
            data={data}
            path={path}
            handleUpdateParameters={handleUpdateParameters}
            handleOpenStopDialog={() => handleOpenStopDialog(true)}
          />
        </SidesheetWrapper>
      </Container>
    </div>
  )
}

export default injectIntl(EditRoute)
