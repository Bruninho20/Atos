import React, { FC, useState } from 'react';
import { FormattedMessage, injectIntl, Intl } from 'react-intl';
import styled from 'styled-components';

import { IconItem } from 'core/assets/images';

import { Button, PlaceholderDialog } from 'components';

import { EmptyStateStyled, ErrorStateStyled, ShortPlaceholder } from './styled';

export interface PlaceholderProps {
  status: string
  isEmpty: boolean;
  short?: boolean;
  contentsName: string | React.ReactElement;
  intl: Intl;
  children: React.ReactElement;
}

const StyledButton = styled(Button)`
  margin-top: 40px;
`;

const Placeholder: FC<PlaceholderProps> = ({
  status,
  isEmpty,
  children,
  short,
  intl,
  contentsName
}) => {
  const [open, setOpen] = useState(false);

  const renderState = (
    state: 'error' | 'empty',
    title: React.ReactElement,
    message: React.ReactElement
  ) => {
    if (state === 'empty') {
      if (short) {
        return (
          <ShortPlaceholder>
            {IconItem('empty')}
            <p>
              <FormattedMessage
                id="state.empty.title"
                values={{ contentsName }}
              />
            </p>
          </ShortPlaceholder>
        );
      }
      return (
        <div
          style={{
            position: 'relative',
            display: 'flex',
            justifyContent: 'center'
          }}
        >
          <PlaceholderDialog open={open} onClose={() => setOpen(false)} />
          <EmptyStateStyled
            data-testid="empty"
            headline={title}
            message={
              <div>
                {message}
                <StyledButton
                  label={intl.formatMessage({
                    id: 'placeholder.empty.helper.button'
                  })}
                  onClick={() => setOpen(true)}
                  color=""
                  className="btn-link"
                />
              </div>
            }
          />
        </div>
      );
    }

    if (short) {
      return (
        <ShortPlaceholder>
          {IconItem('breakdown')}
          <p>
            <FormattedMessage id="state.error.title" />
          </p>
        </ShortPlaceholder>
      );
    }

    return (
      <ErrorStateStyled
        data-testid="error"
        headline={title}
        message={message}
      />
    );
  };

  if (status === 'error') {
    return renderState(
      'error',
      <h3>
        <FormattedMessage id="state.error.title" />
      </h3>,
      <>
        <p>
          <FormattedMessage id="state.error.description" />
        </p>
        <p>
          <FormattedMessage id="state.error.description.sugestion" />
        </p>
      </>
    );
  }

  if (isEmpty && status === undefined) {
    return renderState(
      'empty',
      <h3>
        <FormattedMessage id="state.empty.title" values={{ contentsName }} />
      </h3>,
      <>
        <p>
          <FormattedMessage id="state.empty.description" />
        </p>
        <p>
          <FormattedMessage id="state.empty.description.sugestion" />
        </p>
      </>
    );
  }

  return children;
};

export default injectIntl(Placeholder);
