import React, { useState } from 'react'
import { injectIntl } from 'react-intl'
import { MapWrapper, Container, SidesheetWrapper } from './styled'
import EditRouteSidesheet from './EditRouteSidesheet'
import { AddressDialog, AddressDialogManual, MapRoutefenceAuto } from '../../../components'
import AddVehicleDialog from 'components/AddVehicleDialog'
import StopConfigDialog from 'components/StopConfigDialog'

const EditRoute: React.FC = (props: any) => {
  const [openAddressDialog, setOpenAddressDialog] = useState(false)
  const [openStopConfigDialog, setOpenStopConfigDialog] = useState(false)
  const [openAddVehicleDialog, setOpenAddVehicleDialog] = useState(false)
  const [typeRoupePoint, setTypeRoutePoint] = useState('')
  const [data, setData] = useState(props?.history?.location?.state?.body)
  const [geolocationStop, setGeolocationStop] = useState<any>()
  const [openAddressDialogManual, setOpenAddressDialogManual] = useState(false)
  const [typeAddVehicles, setTypeAddVehicles] = useState('')

  const path = props.match.path

  const handleOpenAddVehiclesDialog = (open: boolean, type: string) => {
    setTypeAddVehicles(type)
    setOpenAddVehicleDialog(open)
  }

  const handleGetLatLng = (value: any, type: string) => {
    if (type === 'originRoute') {
      setData({
        ...data,
        originRouteData: {
          addressStop: value.address,
          lat: value.position.lat,
          lng: value.position.lng
        }
      })
    }
    if (type === 'destinyRoute') {
      setData({
        ...data,
        destinyRouteData: {
          addressStop: value.address,
          lat: value.position.lat,
          lng: value.position.lng
        }
      })
    }
    if (type === 'stops') {
      setData({ ...data, stops: value })
    }
  }

  const handleSaveRouteParameters = (parameters: object) => {
    setData({ ...data, routeParameters: parameters })
  }

  const handleAddVehicles = (vehicles: any) => {
    setData({ ...data, linkedVehicles: vehicles })
  }

  const handleAddStops = (stops: any) => {
    setData({ ...data, allStops: stops })
  }

  const handleUpdateParameters = (routeParameters: any) => {
    setData({ ...data, routeParameters })
  }

  let stopArrayManual: any = []

  const handleAddStopsManual = (stop: object) => {
    stopArrayManual.push(stop)
    handleAddStops(stopArrayManual)
  }

  const handleOpenAddressDialogManual = (value: any, type: string, open: boolean) => {
    setOpenAddressDialogManual(open)
    setTypeRoutePoint(type)
    setGeolocationStop(value)
  }

  const handleOpenConfigDialog = (geolocation: any, open: boolean) => {
    setGeolocationStop(geolocation)
    setTypeRoutePoint('stops')
    setOpenStopConfigDialog(open)
  }

  const handleAddCrossing = (crossing: never) => {
    // crie uma cópia do objeto data
    const newData = { ...data }

    // adicione o novo objeto no array allStops
    newData.allStops.push(crossing)

    // atualize o estado do objeto data com a nova cópia
    setData(newData)
  }

  const handleOpenStopDialog = (open: boolean) => {
    setGeolocationStop(undefined)
    setOpenStopConfigDialog(open)
    setTypeRoutePoint('stopsSidesheet')
  }

  return (
    <div>
      <AddressDialog
        title='Procurar endereço'
        isOpen={openAddressDialog}
        onClose={() => setOpenAddressDialog(false)}
        type={typeRoupePoint}
        getLatLng={handleGetLatLng}
      />
      <AddressDialogManual
        title='Procurar endereço manual'
        isOpen={openAddressDialogManual}
        onClose={() => setOpenAddressDialogManual(false)}
        type={typeRoupePoint}
        getLatLng={handleGetLatLng}
        geolocation={geolocationStop}
      />
      <AddVehicleDialog
        isOpen={openAddVehicleDialog}
        onClose={() => setOpenAddVehicleDialog(false)}
        type='linkVehicleOut'
        typeToTrip={typeAddVehicles}
        saveLinkedVehicles={handleAddVehicles}
        data={undefined}
      />
      <StopConfigDialog
        title='Adicionar Parada'
        isOpen={openStopConfigDialog}
        onClose={() => setOpenStopConfigDialog(false)}
        type={typeRoupePoint}
        handleSaveStopManual={handleAddStopsManual}
        geolocation={'teste'}
        getLatLng={handleGetLatLng}
      />

      <Container>
        <MapWrapper>
          <MapRoutefenceAuto
            data={data}
            handleSaveRouteParameters={handleSaveRouteParameters}
            handleOpenConfigDialog={handleOpenConfigDialog}
            handleOpenAddressDialogManual={handleOpenAddressDialogManual}
            handleAddStops={handleAddCrossing}
          />
        </MapWrapper>
        <SidesheetWrapper>
          <EditRouteSidesheet
            handleChangeMode={() => console.log('teste')}
            handleOpenAddressDialog={handleOpenAddressDialogManual}
            handleOpenAddVehiclesDialog={handleOpenAddVehiclesDialog}
            handleAddStops={handleAddStops}            
            data={data}
            path={path}
            handleUpdateParameters={handleUpdateParameters}
            handleOpenStopDialog={() => handleOpenStopDialog(true)}
          />
        </SidesheetWrapper>
      </Container>
    </div>
  )
}

export default injectIntl(EditRoute)
