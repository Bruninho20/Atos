/* eslint-disable indent */
import styled, { css, keyframes } from 'styled-components'
import { colors, metrics } from 'core/assets/styles'

interface ContentProps {
  open?: boolean
  padding?: string | number
  position?: string
  isOnModal?: boolean
  width: string | number
}

interface PositionProps {
  position?: string
}

const grow = keyframes`
  0% {
    background-color: rgba(0, 0, 0, 0);
  }

  100% {
    background-color: rgba(0, 0, 0, 0.32);
  }
`

export const Content = styled.div<ContentProps>`
  background-color: white;
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.08), 0 0 15px 0 rgba(0, 0, 0, 0.02), 0 0 20px 4px rgba(0, 0, 0, 0.06);
  height: 100%;
  min-height: 100%;
  overflow: auto;
  padding: 0 0 ${({ padding }) => (padding ? padding : metrics.baseMargin)} 0;
  position: fixed;
  top: ${({ isOnModal }) => (isOnModal ? '0' : '50px')};
  transform: ${({ open }) => (open ? 'translateX(0)' : 'translateX(100vw)')};
  transition: transform 0.3s ease-in-out;
  width: ${({ width }) => width};
  z-index: 999;

  ${({ position, open, width }) =>
    position === 'right'
      ? css`
          right: 0;
          transform: ${open ? 'translateX(0)' : 'translateX(100vw)'};
        `
      : css`
          left: 0;
          transform: ${open ? 'translateX(0)' : `translateX(-${width})`};
        `}
`

export const Overlay = styled.div`
  -ms-touch-action: none;
  animation: ${grow} 0.2s forwards;
  animation-delay: 200ms;
  background: transparent;
  bottom: 0;
  left: 0;
  opacity: 1;
  position: fixed;
  right: 0;
  top: 0;
  touch-action: none;
  transition: opacity 525ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  z-index: 2;
`

export const Header = styled.div`
  align-items: center;
  border-bottom: 1px solid ${colors.borderDefault};
  display: flex;
  height: 65px;
  justify-content: space-between;
  margin-bottom: ${metrics.baseLargeMargin};
  padding: ${metrics.baseMargin};

  h1 {
    margin: 0;
  }

  .closeBtn {
    color: ${colors.blackMedium};
    cursor: pointer;
    transition: transform 150ms linear;
    &:hover {
      color: ${colors.black};
      transform: rotate(-90deg);
    }
  }
`

export const WrapperCloseBtn = styled(Header)<PositionProps>`
  align-items: center;
  border: 0;
  display: flex;
  height: 26px;
  justify-content: ${({ position }) => (position === 'right' ? 'flex-end' : 'flex-start')};
  margin-bottom: 0;
`

export const Title = styled.h1`
  font-size: ${metrics.fontSizeTitle};
  font-weight: normal;
`
