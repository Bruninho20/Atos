package routefence_common.cloud.rio.latam_routefence.domain.response

data class VehicleResponse(
    val geographicArea: String,
    val country: String,
    val manufacturer: String,
    val bodywork: String,
    val engine:String,
    val safetySystem:String,
    val vehicleClass: String,
    val controlDigit: String,
    val modelYear: String,
    val factoryCode: String,
    val sequentialProd:String
)

data class VehicleDataResponse(
    val id: String?,
    var model: String?,
    var commercialName: String?,
    var m_m_v: String?,
    var renavamCode: String?,
    var modelCodes: String?,
    var position123: String?,
    var position4: String?,
    var motor: String?,
    var position6: String?,
    var securitySystemMin: String?,
    var securitySystemMax: String?,
    var position7_8: String?,
    var controlDigit: String?,
    var modelYear: String?,
    var factoryCode: String?,
    var sequentialProd: String?,
    var regulatoryWeightKg: String?,
    var technicalWeightKg: String?,
    var firstAxleKg: String?,
    var secondAxleKg: String?,
    var thirdAxleKg: String?,
    var fourthAxleKg: String?,
    var pbtc: String?,
    var cmt: String?,
    var wheelbase: String?,
    var issueType: String?
)