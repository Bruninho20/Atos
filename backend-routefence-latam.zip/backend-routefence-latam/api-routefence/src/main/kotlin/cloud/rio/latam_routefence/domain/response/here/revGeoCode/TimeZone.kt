package cloud.rio.latam_routefence.domain.response.here.revGeoCode

data class TimeZone(
    val name: String?,
    val utcOffset: String?
)