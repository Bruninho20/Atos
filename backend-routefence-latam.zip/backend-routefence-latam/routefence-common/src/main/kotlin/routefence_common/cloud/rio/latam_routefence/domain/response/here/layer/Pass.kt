package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Pass(
    @JsonProperty("annual") var annual: Boolean?,
    @JsonProperty("extendedAnnual") var extendedAnnual: Boolean?,
    @JsonProperty("id") var id: Int?,
    @JsonProperty("nrOfDays") var nrOfDays: Int?,
    @JsonProperty("nrOfMonths") var nrOfMonths: Int?,
    @JsonProperty("nrOfTravels") var nrOfTravels: Int?,
    @JsonProperty("seniorPass") var seniorPass: Boolean?
)
