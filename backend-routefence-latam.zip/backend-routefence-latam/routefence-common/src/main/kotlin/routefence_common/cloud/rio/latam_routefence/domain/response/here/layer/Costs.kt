package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.layer.CostDetails

@JsonIgnoreProperties(ignoreUnknown = true)
data class Costs(
    @JsonProperty("currency") var currency: String?,
    @JsonProperty("details") var details: CostDetails?,
    @JsonProperty("totalCost") var totalCost: String?
)