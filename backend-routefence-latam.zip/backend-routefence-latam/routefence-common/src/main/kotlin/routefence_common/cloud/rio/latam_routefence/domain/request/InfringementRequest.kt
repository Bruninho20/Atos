package routefence_common.cloud.rio.latam_routefence.domain.request

import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import java.time.LocalDateTime

data class InfringementRequest(
    var id: String?,
    val type: InfringementTypeEnum,
    val note: String?,
    val startDateTime: LocalDateTime?,
    val endDateTime: LocalDateTime?,
    val location: GeoPointRequest,
    val trip: String
)
