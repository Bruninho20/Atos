import isEmpty from 'lodash/fp/isEmpty';
import { FormattedMessage } from 'react-intl';
import React from 'react'

export const sanitizeTagsList = (items) => {
  const tags = items.map((item) => ({ id: item.id, name: item.name }));
  return [
    ...tags,
    {
      id: 'empty',
      name: <FormattedMessage id={'assetsTree.unassignedVehicles'} />
      // name: intl.formatMessage({
      //   id: 'assetsTree.unassignedVehicles'
      // })
    }
  ];
};

export const sanitizeAssetsList = (items) => {
  const assets = items.map((item) => {
    const { items } = item._embedded.tags;
    const groups = items.map((groups) => groups.id);
    const groupIds = isEmpty(groups) ? ['empty'] : groups;

    return { id: item.id, name: item.name, type: item.type, groupIds };
  });
  return assets;
};

export const createAssetsList = ({ groups, items, trucks }) => {
  let arrayAssetList = []

  if (groups.length >= 1) {
    const filtered = trucks.filter(elemento => groups.includes(elemento.groupIds[0]))
    filtered.map(item => item.id).forEach(function (element) {
      arrayAssetList.push(element);
    });
  }
  if (items.length >= 1) {
    items.forEach(function (element) {
      arrayAssetList.push(element);
    });
  }
  return arrayAssetList
}

