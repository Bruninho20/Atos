import { accessToken } from 'configuration/tokenHandling/accessToken'
import CustomBaseApi from 'core/providers/api'

export const fetcherPost = (url: string, params: Record<string, unknown>) => {
  const customAcessToken = accessToken.getAccessToken()
  return CustomBaseApi(customAcessToken)
    .post(url, { ...params })
    .then(res => res.data)
}

export const fetcherGet = (url: string, params?: Record<string, unknown>) => {
  const customAcessToken = accessToken.getAccessToken()

  return CustomBaseApi(customAcessToken)
    .get(url, { params })
    .then(res => res.data)
}
