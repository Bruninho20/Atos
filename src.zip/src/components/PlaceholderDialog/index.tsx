import React, { FC } from 'react';
import { FormattedMessage, injectIntl, Intl } from 'react-intl';

import { Dialog as CustomDialog } from 'components';
import { CustomDialogText } from './styled'

const PlaceholderDialog: FC<{
  open: boolean;
  intl: Intl;
  onClose: () => void;
}> = ({ open = false, intl, onClose }) => {
  return (
    <CustomDialog
      id="placeholderDialog"
      title={<FormattedMessage id="placeholder.empty.helper.dialog.title" />}
      description={
        <CustomDialogText
          dangerouslySetInnerHTML={{
            __html: intl.formatMessage({
              id: 'placeholder.empty.helper.dialog.description'
            })
          }}
        />
      }
      open={open}
      onClose={onClose}
    />
  );
};

export default injectIntl(PlaceholderDialog);
