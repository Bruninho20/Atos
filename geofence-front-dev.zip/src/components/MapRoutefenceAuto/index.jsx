import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios'
import { decode } from 'core/utils/flexiblePolyline'
import { Map as RioMap, EventUtils, Route, Marker, SingleMapMarker, ContextMenu, ContextMenuItem, Polygon, Circle } from 'rio-uikit-map';
import Button from 'components/Button';
import DashboardContext from 'core/DashboardContext';


const RouteExample = ({ data, handleSaveRouteParameters, handleOpenConfigDialog, handleAddStops, handleOpenAddressDialogManual }) => {
  const {
    allStopsContext,
    setAllStopsContext,
    originRouteContext,
    destinyRouteContext,
    setOriginRouteContext,
    setDestinyRouteContext,
    setAvoidPointsContext,
    setOriginGeolocationContext,
    setDestinyGeolocationContext,
    avoidPointsContext,
    setSidesheetIsOpen,
    responseHereContext,
    setResponseHereContext
  } = useContext(DashboardContext)
  const [stopArray, setStopArray] = useState([])
  const [stopArrayV8, setStopArrayV8] = useState([])
  const [showSpinner, setShowSpinner] = useState(true);
  const [coordLabel, setCoordLabel] = useState();
  const [dataToSaveCrossing, setDataToSaveCrossing] = useState()
  const [avoidPointsToSave, setAvoidPointsToSave] = useState([])
  const [summaryRoute, setSummaryRoute] = useState()
  const [arrayAvoidPoints, setArrayAvoidPoints] = useState(initialPosition)
  const [initialPosition, setInitialPosition] = useState([
    {
      lat: -23.5475,
      lng: -46.63611
    }
  ])
  const [refresh, setRefresh] = useState(false)
  const [avoidFeature, setAvoidFeature] = useState([])
  const [newData, setNewData] = useState([])

  const STROKE_COLOR = 'rgba(90, 72, 118, 1)';
  const FILL_COLOR = 'rgba(90, 72, 118, 0.3)';
  const STROKE_AVOID_COLOR = 'rgba(139, 0, 0, 1)';
  const FILL_AVOID_COLOR = 'rgba(139, 0, 0, 0.3)';

  useEffect(() => {
    if (data?.destinyRouteContext?.addressStop?.postalCode !== newData?.destinyRouteContext?.addressStop?.postalCode
      || data?.originRouteContext?.addressStop?.postalCode !== newData?.originRouteContext?.addressStop?.postalCode
      || data?.allStops !== allStopsContext
    )
      setNewData(data)
  }, [data])

  let arrayAvoidFeature = []

  const handleGetAvoidFeature = () => {
    if (newData?.routeParameters?.avoidRoad === true) {
      if (!arrayAvoidFeature.includes('controlledAccessHighway')) {
        arrayAvoidFeature.push('controlledAccessHighway')
      } else {
        const index = arrayAvoidFeature.indexOf('controlledAccessHighway')
        arrayAvoidFeature.splice(index, 1)
      }
    }
    if (newData?.routeParameters?.avoidToll === true) {
      if (!arrayAvoidFeature.includes('tollRoad')) {
        arrayAvoidFeature.push('tollRoad')
      } else {
        const index = arrayAvoidFeature.indexOf('tollRoad')
        arrayAvoidFeature.splice(index, 1)
      }
    }
    setAvoidFeature(arrayAvoidFeature)
  }

  useEffect(() => {
    handleGetAvoidFeature()
  }, [newData?.routeParameters])

  // useEffect(() => {
  //   if (stopArrayV8.length !== 0) {
  //     handleGetShape()
  //   }
  // }, [])

  // let jaExecutou = false;

  // setTimeout(function () {
  //   if (!jaExecutou) {
  //     handleGetShape();
  //     jaExecutou = true;
  //   }
  // }, 2000);


  const handlSetStopArray = () => {

    const arrayStopV8 = allStopsContext?.map((item) => {
      return (
        `&via=${item?.position?.lat},${item?.position?.lng}`
      )
    })
    setStopArrayV8(arrayStopV8)
  }

  useEffect(() => {
    handlSetStopArray()
  }, [newData, data])

  const trafficConditions = newData?.routeParameters?.trafficConditions === true ? 'traffic&' : ''

  // const avoidArea = avoidPointsContext.length > 3 ? `&avoid[areas]=bbox:${avoidPointsContext[0]?.lng},${avoidPointsContext[0]?.lat},${avoidPointsContext[2]?.lng},${avoidPointsContext[2]?.lat}` : ''

  const avoidArea = avoidPointsContext.length > 2 ? avoidPointsContext.map(item => {
    return `${item?.lat},${item?.lng};`
  }) : ''

  const destinyRouteGeo = destinyRouteContext?.lat === undefined && allStopsContext?.length < 1 ? ''
    : destinyRouteContext?.lat === undefined && allStopsContext?.length >= 1 ?
      `${allStopsContext[allStopsContext?.length - 1]?.position?.lat},${allStopsContext[allStopsContext?.length - 1]?.position?.lng}`
      : `${destinyRouteContext?.lat},${destinyRouteContext?.lng}`

  let ArrayOfShape = []

  const handleGetShape = () => {
    axios
      .get(` https://router.hereapi.com/v8/routes?lang=pt-br,en-us&apikey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw&${trafficConditions}return=polyline,summary,actions,instructions,routeHandle&transportMode=truck&origin=${originRouteContext?.lat},${originRouteContext?.lng}&destination=${destinyRouteGeo}${stopArrayV8?.join('')}${avoidArea ? `&avoid[areas]=polygon:${avoidArea.join('')}` : ''}`)
      .then(result => {
        const getPolylineArray = result?.data?.routes[0]?.sections.map((item) => {
          return {
            shape: decode(item.polyline)
          }
        })

        const shapeArray = getPolylineArray.map((item) => {
          return (
            ArrayOfShape.push(item.shape.polyline)
          )
        })

        const concatArrays = ArrayOfShape.flat()
        const getPoints = concatArrays.map((value) => {
          return {
            lat: (value[0]).toString(),
            lng: (value[1]).toString()
          }
        })
        setInitialPosition(getPoints)
        handleSaveRouteParameters(result?.data)
        setResponseHereContext(result?.data)
        setSummaryRoute(result?.data?.routes[0].sections[0].summary)
      })
  }

  useEffect(() => {
    handleGetShape()
  }, [])

  const getMiddlePos = (positions) =>
    positions[Math.floor(positions.length / 2)]

  const position = { lat: initialPosition[0]?.lat, lng: initialPosition[0]?.lng };

  const formatCoordinates = coordinates => {
    return [
      Math.abs(coordinates?.lat?.toFixed(4)) + (coordinates?.lat > 0 ? 'N' : 'S'),
      Math.abs(coordinates?.lng?.toFixed(4)) + (coordinates?.lng > 0 ? 'E' : 'W'),
    ].join(' ');
  };

  const handleOpenContextMenu = contextMenuCoordinates => {
    setShowSpinner(true);

    setCoordLabel(formatCoordinates(contextMenuCoordinates));

    setTimeout(() => setShowSpinner(false), 1000);
  };

  const handleAvoidPoints = (coordinates) => {
    setAvoidPointsToSave({ lat: coordinates.lat, lng: coordinates.lng })
  }

  const handleSaveAvoidPoints = () => {
    if (avoidPointsToSave?.lat) {
      let cloneAvoidPoints = cloneObject(avoidPointsContext)
      cloneAvoidPoints.push(avoidPointsToSave)
      setAvoidPointsContext(cloneAvoidPoints)
      setArrayAvoidPoints(cloneAvoidPoints)

    }
  }

  useEffect(() => {
    handleSaveAvoidPoints()
  }, [avoidPointsToSave])


  const handleSetStartRoute = (coordinates) => {
    setOriginGeolocationContext({
      lat: coordinates.lat, lng: coordinates.lng
    })
    handleOpenAddressDialogManual({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      }
    }, 'originRoute', true)
  }

  const handleSetStop = (coordinates) => {
    handleOpenConfigDialog({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      }
    }, 'stops', true)
  }

  const handleSetFinishRoute = (coordinates) => {
    setDestinyGeolocationContext({
      lat: coordinates.lat, lng: coordinates.lng
    })
    handleOpenAddressDialogManual({
      position: {
        lat: coordinates.lat, lng: coordinates.lng
      }
    }, 'destinyRoute', true)
  }

  const cloneObject = (object) => {
    const aux = JSON.stringify(object)
    const newObject = JSON.parse(aux)
    return newObject
  }

  const handleSaveCrossing = () => {

    if (dataToSaveCrossing) {
      let cloneAllStops = cloneObject(allStopsContext)
      cloneAllStops.push(dataToSaveCrossing)
      setAllStopsContext(cloneAllStops)
    }

  }

  useEffect(() => {
    handleSaveCrossing()
  }, [dataToSaveCrossing])


  const handleGetAndSaveCrossing = async (data) => {
    const result = await axios.get(`https://revgeocode.search.hereapi.com/v1/revgeocode?at=${data.lat},${data.lng}&lang=en-US&apiKey=E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw`)
    const body = {
      name: '',
      category: '',
      type: 'CROSSING',
      rangeLimitMeters: 300,
      stayTime: '00:00',
      position: {
        lat: result?.data?.items[0]?.position?.lat,
        lng: result?.data?.items[0]?.position?.lng,
        address: result?.data?.items[0]?.address
      }
    }
    setDataToSaveCrossing(body)
    handleAddStops(body)
  }

  // let teste = []

  const handleAddPoint = (coordinates) => {
    handleGetAndSaveCrossing({ lat: coordinates.lat, lng: coordinates.lng })
  }


  const contextMenuItems = [
    <ContextMenuItem
      className='bg-lightest text-color-dark'
      labelClassName='text-medium'
      label={coordLabel}
      icon='rioglyph-map-marker'
      hasSpinner={showSpinner}
    />,
    <ContextMenuItem icon='rioglyph-start' label='Ínicio da Rota' callback={(e) => handleSetStartRoute(e)} />,
    <ContextMenuItem icon='rioglyph rioglyph-plus-sign' label='Adicionar arêa de interesse' callback={(e) => handleAddPoint(e)} />,
    // <ContextMenuItem icon='rioglyph rioglyph-minus-sign' label='Remover Ponto' callback={() => handleSubtractPoint()} />,
    <ContextMenuItem icon='rioglyph rioglyph-dangerousgoods' label='Evitar ponto' callback={(e) => handleAvoidPoints(e)} />,
    <ContextMenuItem icon='rioglyph-pushpin' label='Adicionar Parada' callback={(e) => handleSetStop(e)} />,
    <ContextMenuItem icon='rioglyph-finish' label='Fim da Rota' callback={(e) => handleSetFinishRoute(e)} />,
  ];

  const eventListenerMap = {
    [EventUtils.TAP]: event => {
      event.stopPropagation();
      console.log(event.currentTarget.c.R.src.a.position)

    },
    [EventUtils.CONTEXTMENU]: event => {
      event.stopPropagation();
      console.log('teste', event)
      handleOpenContextMenu({ lat: event.target.a.lat, lng: event.target.a.lng })
      // handleOpenContextMenu(event)

    },
  };



  const offset = 0.3;

  const apiKey = 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'

  const getRandomValueToForceRerender = () => Math.random();

  const Routes = () => {
    const [activeRouteId, setActiveRouteId] = useState(1);
    const isActive = id => activeRouteId === id;
    const isFirstRouteActive = isActive(1);
    const isSecondRouteActive = isActive(2);

    const markersStops = allStopsContext?.length > 0 ? allStopsContext?.map((item, index) => {
      const position = { lat: item?.position?.lat, lng: item?.position?.lng }

      return (
        <>
          <Circle
            position={position}
            radius={item.rangeLimitMeters}
            style={{ strokeColor: STROKE_COLOR, fillColor: FILL_COLOR }}
            precision={30}
            eventListenerMap={eventListenerMap}

          />
          <Marker
            key={index}
            customData={{ id: index + 1 }}
            position={position}
            eventListenerMap={markerEventListenerMap}
            icon={
              <SingleMapMarker
                iconNames={item.type !== 'CROSSING' ? ['pushpin'] : ''}
                name={item.name}
                markerColor='bg-map-marker-route'
              />
            }
          />
        </>
      )
    }) : ''

    const markerEventListenerMap = {
      [EventUtils.TAP]: event => {
        event.stopPropagation();
        setActiveRouteId(event.currentTarget.getData().id);
      },
    };

    return (
      <React.Fragment>
        <Route
          key={getRandomValueToForceRerender()}
          positions={initialPosition}
          startIcon={responseHereContext?.routes ? <SingleMapMarker iconNames={['start']} markerColor='bg-map-marker-asset' /> : null}
          endIcon={responseHereContext?.routes ? <SingleMapMarker iconNames={['finish']} markerColor='bg-map-marker-asset' /> : null}
          isRouteAlternative={!isFirstRouteActive}
          hasArrows={true}
          markers={markersStops}
        />
      </React.Fragment>
    );
  };

  const timeLeftRouteToCalc = (summaryRoute?.duration / 60) / 60
  const minutesLeftRoute = (Number(String(timeLeftRouteToCalc)?.split('.')[1]?.slice(0, 2)) / 100) * 60
  const calculetedTimeToRoute = String(timeLeftRouteToCalc)?.split('.')[0] === '0' ? `${Number(minutesLeftRoute).toFixed(0)}m` : `${String(timeLeftRouteToCalc)?.split('.')[0]}h ${Number(minutesLeftRoute).toFixed(0)}m`


  return (
    <>
      <RioMap
        credentials={{
          apikey:
            typeof apiKey === 'string'
              ? apiKey
              : 'E7mg47EL_rC1J597uqkmmiWMYwPp5K6yrO_O03iDpZw'
        }}
        center={getMiddlePos(initialPosition)}
        zoom={11}
        height={900}
        width={'126%'}
        hideMapSettings
      >
        {avoidPointsContext.length > 1 ?
          <Polygon
            points={arrayAvoidPoints}
            style={{ strokeColor: STROKE_AVOID_COLOR, fillColor: FILL_AVOID_COLOR }}
            eventListenerMap={eventListenerMap}
          />
          : null}


        <Routes />
        {originRouteContext?.lat ?
          <Marker
            key={1}
            customData={{ id: 1 }}
            position={{ lat: originRouteContext?.lat, lng: originRouteContext?.lng }}
            icon={
              <SingleMapMarker
                iconNames={''}
                markerColor='bg-map-marker-route'
                active
              />
            }
          />
          : null}
        {destinyRouteContext.lat ?
          <Marker
            key={1}
            customData={{ id: 1 }}
            position={{ lat: destinyRouteContext?.lat, lng: destinyRouteContext?.lng }}
            icon={
              <SingleMapMarker
                iconNames={''}
                markerColor='bg-map-marker-route'
                active
              />
            }
          />
          : null}
        {responseHereContext?.routes ?
          <Marker
            key={1}
            customData={{ id: 1 }}
            position={getMiddlePos(initialPosition)}
            icon={
              <SingleMapMarker
                iconNames={['route']}
                name={!summaryRoute ? '' : `${(summaryRoute?.length / 1000).toFixed(1)} km / ${calculetedTimeToRoute}`
                }
                markerColor='bg-map-marker-asset'
                active
              />
            }
          />
          : null}
        <ContextMenu
          onOpen={handleOpenContextMenu}
          menuItems={contextMenuItems}
        // contextMenuEvent={contextMenuData.event}
        // targetPosition={contextMenuData.targetPosition}
        />
        <div style={{ position: 'fixed', left: 90, top: 80, zIndex: 99 }}>
          <Button color='primary' onClick={() => handleGetShape()} label={'Atualizar'}>
          </Button>
        </div>
      </RioMap>
    </>

  );
};

export default RouteExample;