package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.domain.response.BaseCollectionResponse
import cloud.rio.latam_routefence.domain.response.TripResponse
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.TripRequest
import cloud.rio.latam_routefence.domain.response.TripResumeResponse

@RequestMapping("/trips")
interface TripApi : RoutefenceBaseApi {
    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(produces = ["application/json"])
    fun saveTrip(@RequestBody trips: Collection<TripRequest>): Collection<TripResponse>?


    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/resume", produces = ["application/json"])
    fun getAllResume(
        @RequestParam(required = false, value = "orderBy") orderBy: String?,
        @RequestParam(required = false, value = "search") search: String?,
        @RequestParam(required = false, value = "page") page: Int?,
        @RequestParam(required = false, value = "pageSize") pageSize: Int?,
        @RequestParam(required = false, value = "status") status: TripStatusEnum?
    ): BaseCollectionResponse<TripResumeResponse>

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/{id}", produces = ["application/json"])
    fun getOneTrip(@PathVariable(value = "id") id: String): TripResponse?

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @PutMapping("/{id}", produces = ["application/json"])
    fun updateOneTrip(@PathVariable(value = "id") id: String, @RequestBody tripRequest: TripRequest): TripResponse?

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    fun delete(@PathVariable id: String)

// TODO Remover endpoint de start manual de viagem
//  https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-362
    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/start/{id}", produces = ["application/json"])
    fun startTrip(@PathVariable(value = "id") id: String): TripResponse?
}