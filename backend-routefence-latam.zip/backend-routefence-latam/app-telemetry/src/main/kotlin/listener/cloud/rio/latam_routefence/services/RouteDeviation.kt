package listener.cloud.rio.latam_routefence.services


import routefence_common.cloud.rio.latam_routefence.domain.bo.PointOfInterestBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TrafficViolationBO
import routefence_common.cloud.rio.latam_routefence.domain.bo.TripBO
import routefence_common.cloud.rio.latam_routefence.domain.enums.InfringementTypeEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.PointOfInterestEnum
import routefence_common.cloud.rio.latam_routefence.domain.enums.TripStatusEnum
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import routefence_common.cloud.rio.latam_routefence.domain.request.InfringementRequest
import routefence_common.cloud.rio.latam_routefence.infrastructure.infringement.arquiteture.IInfringible
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import routefence_common.cloud.rio.latam_routefence.utils.DateFormatter
import java.time.Duration
import java.time.OffsetDateTime

@Service
class RouteDeviation(private val infringementService: InfringementService) : IInfringible {

    private val logger = LoggerFactory.getLogger(this.javaClass)

    override fun check(
        trip: TripBO,
        asset: AssetIotEventMessage,
        poiList: Collection<PointOfInterestBO>?,
        trafficViolationList: Collection<TrafficViolationBO>
    ): InfringementRequest? {
        if (trip.status == TripStatusEnum.STARTED) {
            val speed = asset.position?.speed ?: 0.0
            if (speed > 1) {
                if (poiList?.firstOrNull { it.type == PointOfInterestEnum.ROUTE } == null) {
                    logger.debug("Asset fora da rota")
                    return setInfringement(
                        asset.occurredAt,
                        asset.position!!.latitude.toFloat(),
                        asset.position!!.longitude.toFloat(),
                        trip.id
                    )
                } else {
                    val openInfringements =
                        infringementService.findByTripAndType(trip.id, InfringementTypeEnum.ROUTE_DEVIATION)
                    openInfringements.forEach {

                        val downtime = Duration.between(
                            it.startDateTime,
                            DateFormatter.formatUTC(asset.occurredAt)
                        )

                        it.endDateTime = DateFormatter.formatUTC(asset.occurredAt)
                        it.note = "Permaneceu ${downtime.toMinutes()} min fora da rota"

                        infringementService.closeInfringement(it)
                    }
                }
            }
        }
        return null
    }

    private fun setInfringement(
        occurredAt: OffsetDateTime, lat: Float, lng: Float, tripId: String
    ): InfringementRequest {
        return InfringementRequest(
            null,
            InfringementTypeEnum.ROUTE_DEVIATION,
            null,
            DateFormatter.formatUTC(occurredAt),
            null,
            GeoPointRequest(null, lat, lng, null),
            tripId
        )
    }
}