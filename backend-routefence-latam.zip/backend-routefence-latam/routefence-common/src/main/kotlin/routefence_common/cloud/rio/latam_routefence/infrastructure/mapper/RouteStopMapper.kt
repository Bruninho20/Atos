package routefence_common.cloud.rio.latam_routefence.infrastructure.mapper

import routefence_common.cloud.rio.latam_routefence.domain.response.RouteStopResponse
import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.RouteStopEntity
import routefence_common.cloud.rio.latam_routefence.utils.timeFromDateTime

fun RouteStopEntity.mapToResponse(): RouteStopResponse {
    return RouteStopResponse(
        id = this.id,
        name = this.stop?.name,
        category = this.stop?.category,
        rangeLimitMeters = this.rangeLimitMeters.toString(),
        position = this.stop?.position?.mapToResponse(),
        stayTime = this.stayTime.timeFromDateTime(),
        type = this.type,
        stopQueueOrder = this.stopQueueOrder
    )
}