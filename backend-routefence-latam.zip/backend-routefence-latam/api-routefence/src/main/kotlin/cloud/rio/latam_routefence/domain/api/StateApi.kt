package cloud.rio.latam_routefence.domain.api

import cloud.rio.latam_routefence.domain.request.LiveStateRequest
import cloud.rio.latam_routefence.domain.response.LiveStateResponse
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import javax.servlet.http.HttpServletRequest

@RequestMapping()
interface StateApi {

    @CrossOrigin(origins = [RoutefenceBaseApi.testCrossOriginURL, RoutefenceBaseApi.prodCrossOriginURL])
    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/live-state", produces = ["application/json"])
    fun liveState(
        request: HttpServletRequest,
        @RequestBody liveStateRequest: LiveStateRequest
    ): List<LiveStateResponse>

}