package routefence_common.cloud.rio.latam_routefence.infrastructure.entity.iotEventEntity

import routefence_common.cloud.rio.latam_routefence.infrastructure.entity.AccountTenantEntity
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.AssetIotEventMessage
import routefence_common.cloud.rio.latam_routefence.infrastructure.kafka.message.AssetStateMessage
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "TB_ASSET_IOT_EVENT_STATE")
data class AssetIotEventStateEntity(
    @Id
    @Column(name = "ID", nullable = false)
    val id: String = UUID.randomUUID().toString(),

    @Column(name = "ASSET_ID")
    val assetId: String,

    override var accountId: String = "",

    @Column(name = "DEVICE_ID")
    val deviceId: String,

    @Column(name = "DEVICE_TYPE")
    val deviceType: String?,

    @Column(name = "EID")
    val eid: String,

    @Column(name = "OCCURRED_AT")
    val occurredAt: LocalDateTime,

    @Column(name = "TRIGGER")
    val trigger: String,

    @Column(name = "DRIVER_IDENTIFICATION")
    val driverIdentification: String?,

    @Column(name = "DRIVER_IDENTIFICATION_TYPE")
    val driverIdentificationType: String?,

    @Column(name = "MILEAGE")
    val mileage: Double?,

    @Column(name = "IGNITION_ON")
    val ignitionOn: Boolean?,

    @Column(name = "FUEL_LEVEL")
    val fuelLevel: Double?,

    @Column(name = "STATE_OF_CHARGE")
    val stateOfCharge: Double?,

    @Column(name = "ELECTRIC_RANGE")
    val electricRange: Double?,

    @Column(name = "ENGINE_SPEED")
    val engineSpeed: Double?,

    @Column(name = "WHEEL_SPEED")
    val wheelSpeed: Double?,

    @Column(name = "TACHOS_PEED")
    val tachoSpeed: Double?,

    @Column(name = "FUEL_CONSUMPTION")
    val fuelConsumption: Double?,

    @Column(name = "ACCELERATOR_PEDAL")
    val acceleratorPedal: Double?,

    @Column(name = "WEIGHT_TOTAL")
    val weightTotal: Double?,

    @Column(name = "PTO_INFORMATION")
    val ptoInformation: String?,

    @Column(name = "ELECTRONIC_RETARDER_STATE")
    val electronicRetarderState: Int?,

    @Column(name = "DRIVE_STATE")
    val driveState: String?,

    @Column(name = "FUEL_RATE")
    val fuelRate: Double?,

    @Column(name = "INSTANTANEOUS_FUEL_ECONOMY")
    val instantaneousFuelEconomy: Double?,

    @Column(name = "ENGINE_OPERATION_TIME")
    val engineOperationTime: Double?
): AccountTenantEntity(accountId) {
    fun mapToAssetIotEventMessage() = AssetIotEventMessage(
        accountId = accountId,
        assetId =  UUID.fromString(assetId),
        deviceId = UUID.fromString(deviceId),
        deviceType = deviceType,
        driverIdentification = driverIdentification,
        driverIdentificationType = driverIdentificationType,
        eid = eid,
        occurredAt = occurredAt.atOffset(ZoneOffset.UTC),
        trigger = trigger,
        state = AssetStateMessage(
            mileage = this.mileage,
            ignitionOn = this.ignitionOn,
            fuelLevel = this.fuelLevel,
            stateOfCharge = this.stateOfCharge,
            electricRange = this.electricRange,
            engineSpeed = this.engineSpeed,
            wheelSpeed = this.wheelSpeed,
            tachoSpeed = this.tachoSpeed,
            fuelConsumption = this.fuelConsumption,
            acceleratorPedal = this.acceleratorPedal,
            weightTotal = this.weightTotal,
            ptoInformation = this.ptoInformation,
            electronicRetarderState = this.electronicRetarderState,
            driveState = this.driveState,
            fuelRate = this.fuelRate,
            instantaneousFuelEconomy = this.instantaneousFuelEconomy,
            engineOperationTime = this.engineOperationTime
        ),
        driverState=null,
        position = null,
        driverInfo = null
    )
}




