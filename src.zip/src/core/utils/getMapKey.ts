import { accessToken } from 'configuration/tokenHandling/accessToken';
import CustomBaseApi from 'core/providers/api';

export const getMapKey = async () => {
  const customAcessToken = accessToken.getAccessToken();

  return await CustomBaseApi(customAcessToken)
    .get('https://api.map.rio.cloud/configurations')
    .then((res) => res.data.items[0].api_key);
};
