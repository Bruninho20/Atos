package routefence_common.cloud.rio.latam_routefence.domain.response.here.layer

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty

@JsonIgnoreProperties(ignoreUnknown = true)
data class Leg(
    @JsonProperty("length") var length: Int?,
    @JsonProperty("travelTime") var travelTime: Int?,
    @JsonProperty("link") var link: Collection<Link>?,
    @JsonProperty("trafficTime") var trafficTime: Int?,
    @JsonProperty("baseTime") var baseTime: Int?,
    @JsonProperty("arrivalBatteryCharge") var arrivalBatteryCharge: Double?,
    @JsonProperty("boundingBox") var boundingBox: BoundingBox?,
    @JsonProperty("firstPoint") var firstPoint: Int?,
    @JsonProperty("lastPoint") var lastPoint: Int?,
    @JsonProperty("maneuver") var maneuver: Collection<Maneuver>?,
    @JsonProperty("shape") var shape: Collection<Double>?,
    @JsonProperty("stayingTime") var stayingTime: Int?,
    @JsonProperty("targetBatteryCharge") var targetBatteryCharge: Double?,
    @JsonProperty("turnByTurnManeuver") var turnByTurnManeuver: Collection<TurnByTurnManeuver>?
)