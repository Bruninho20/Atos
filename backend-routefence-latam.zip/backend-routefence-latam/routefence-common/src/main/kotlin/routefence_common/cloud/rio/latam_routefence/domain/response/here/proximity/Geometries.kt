package routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import routefence_common.cloud.rio.latam_routefence.domain.response.here.proximity.Attributes

@JsonIgnoreProperties(ignoreUnknown = true)
data class Geometries (
    @JsonProperty("attributes") var attributes: Attributes?,
    @JsonProperty("distance") var distance: Double?,
    @JsonProperty("geometry") var geometry: String?,
    @JsonProperty("layerId") var layerId: String?,
    @JsonProperty("nearestLat") var nearestLat: Double?,
    @JsonProperty("nearestLon") var nearestLon: Double?
)