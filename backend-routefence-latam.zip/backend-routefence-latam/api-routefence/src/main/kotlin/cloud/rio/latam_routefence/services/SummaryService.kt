package cloud.rio.latam_routefence.services

import cloud.rio.latam_routefence.domain.response.SummaryResponse
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import routefence_common.cloud.rio.latam_routefence.domain.exception.RoutefenceException
import routefence_common.cloud.rio.latam_routefence.domain.request.GeoPointRequest
import java.time.LocalDateTime
import java.time.ZoneOffset

@Service
@Transactional
class SummaryService(
    private val assetCourseService: AssetCourseService,
    private val tripService: TripService,
    private val hereService: HereService,
    private val driverService: DriverService,
    private val assetService: AssetService
) {
    private val logger = LoggerFactory.getLogger(this.javaClass)

    @Transactional(readOnly = true)
    fun getSummaryData(id: String): SummaryResponse {
        val trip = tripService.findTripById(id)
        val assetCourse = assetCourseService.findByTripId(id).firstOrNull()

        val latLongLastPosition = hereService.getAddressByGeopoint(
            GeoPointRequest(
                null,
                assetCourse?.lat?.toFloat(),
                assetCourse?.lng?.toFloat(),
                null
            )

        )
        var driverName: String = "unidentified"
        try {
            trip.driverId?.let {id ->
                val driver = driverService.getById(id)
                driver.display_name?.let {name ->
                    driverName = name
                }
            }
        } catch (_: RoutefenceException) {
        }

        val asset = assetService.get(trip.assetId)
        val assetName = asset.name
        val chassi: String? = asset.identification


        //TODO Corrigir tempo RESTANTE de viagem. O trecho abaixo, soma o tempo total
        // https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-341
        var totalTime: Long = 0
        trip.route.responseHere?.let { it.routes.firstOrNull()?.sections?.forEach { totalTime += it.summary?.duration ?: 0L } }



        val dateTimeLastPosition: LocalDateTime? = assetCourse?.occurredAt
        val speed: Double? = assetCourse?.speed
        val mileage: Double? = assetCourse?.mileage
        val remainDistance: Double? = null
        val driverActivity: String? = null
        val remainTimeSeconds: Double? = totalTime.toDouble()

        //TODO Fornecer dados para a aba de resumo
        // https://collaboration.msi.audi.com/jira/browse/ROUTEFENCE-226

        return SummaryResponse(
            dateTimeLastPosition?.atOffset(ZoneOffset.UTC).toString(),
            assetName,
            chassi,
            driverName,
            latLongLastPosition,
            remainDistance,
            speed,
            driverActivity,
            remainTimeSeconds,
            mileage
        )
    }
}